#!/usr/bin/env python3
import json, math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'compiled'
WINDOWS={
 'rokoko_high_reach_capture_v5.json':('high_reach_capture',10.55,14.15),
 'rokoko_give_capture_v5.json':('give_capture',5.10,8.45),
}

def contacts(frames,joints,fps=30):
 a=np.asarray(frames,float);ix={j:i for i,j in enumerate(joints)};out={}
 for side in ['l','r']:
  an=a[:,ix[f'ankle_{side}']];toe=a[:,ix[f'toe_{side}']]
  va=np.linalg.norm(np.gradient(an,axis=0)*fps,axis=1);vt=np.linalg.norm(np.gradient(toe,axis=0)*fps,axis=1)
  v=np.minimum(va,vt);h=np.minimum(an[:,1],toe[:,1]);floor=np.percentile(h,4);mask=(h<floor+.055)&(v<.34)
  segs=[];st=None
  for i,x in enumerate(mask.tolist()+[False]):
   if x and st is None:st=i
   elif not x and st is not None:
    if i-st>=2:
     m=(st+i-1)//2;segs.append({'start':round(st/fps,5),'end':round((i-1)/fps,5),'anchor':[round(float(x),6) for x in an[m]]})
    st=None
  out[side]=segs
 return out

def yaw_delta(frames,joints):
 ix={j:i for i,j in enumerate(joints)};ys=[]
 for p in np.asarray(frames,float):
  lr=p[ix['hip_r']]-p[ix['hip_l']];f=np.cross(lr,[0,1,0]);ys.append(math.atan2(f[0],f[2]))
 return math.degrees(np.unwrap(ys)[-1]-np.unwrap(ys)[0]) if len(ys)>1 else 0

for fn,(key,t0,t1) in WINDOWS.items():
 p=OUT/fn;v=json.loads(p.read_text());c=v['clips'][key];times=c['times'];fps=c.get('fps',v.get('fps',30));
 ids=[i for i,t in enumerate(times) if t0-1e-9<=t<=t1+1e-9]
 if len(ids)<2:raise RuntimeError((fn,'trim empty'))
 st,en=ids[0],ids[-1];frames=np.asarray(c['frames'][st:en+1],float);j=v['joints'];root_i=j.index('root');canonical=np.asarray(json.loads((ROOT/'data/canonical_ref.json').read_text())['referencePose']['root'],float)
 delta=canonical-frames[0,root_i]
 frames=frames+delta
 c['frames']=np.round(frames,6).tolist();c['times']=[round(i/fps,6) for i in range(len(frames))];c['duration']=round((len(frames)-1)/fps,6);c['rootDelta']=np.round(frames[-1,root_i]-frames[0,root_i],6).tolist();c['contacts']=contacts(c['frames'],j,fps);c['yawDeltaDeg']=round(yaw_delta(c['frames'],j),2)
 c['crop']={'semanticTrim':True,'sourceStartSeconds':t0,'sourceEndSeconds':t1,'sourceStartFrame':st,'sourceEndFrame':en,'reason':'trim long raw capture to the mechanically relevant action window'}
 p.write_text(json.dumps(v,separators=(',',':')))
 mp=OUT/fn.replace('_v5.json','_manifest_v5.json')
 if mp.exists():
  m=json.loads(mp.read_text());m['semanticTrim']=c['crop'];m['duration']=c['duration'];m['frames']=len(c['frames']);m['yawDeltaDeg']=c['yawDeltaDeg'];mp.write_text(json.dumps(m,indent=2))
 print(key,'trimmed',c['duration'],'sec frames',len(c['frames']),'yaw',c['yawDeltaDeg'])
