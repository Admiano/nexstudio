#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'compiled'
files=['rokoko_walkspline_turn_v5.json','rokoko_high_reach_capture_v5.json','rokoko_give_capture_v5.json','rokoko_typing_leanback_v5.json','rokoko_presenter_papers_v5.json','rokoko_documentary_acting_v5.json']
clips={}; sources=[]; joints=None; fps=30
for fn in files:
 p=OUT/fn
 if not p.exists(): continue
 v=json.load(open(p)); joints=joints or v['joints']; fps=v['fps']; clips.update(v['clips']); sources.append(fn)
v={'version':'5.0.0','source':'Selected legally acquired Rokoko captured-motion donors','fps':fps,'joints':joints,'clips':clips}
json.dump(v,open(OUT/'rokoko_motion_vault_v5.json','w'),separators=(',',':'))
with open(OUT/'nex-rokoko-motion-vault-v5.js','w') as f:f.write("(function(root){'use strict';root.NexRokokoMotionVaultV5="+json.dumps(v,separators=(',',':'))+";})(typeof window!=='undefined'?window:globalThis);")
json.dump({'version':'5.0.0','sources':sources,'compiledClips':len(clips),'clips':[{'id':k,'semantic':c['semantic'],'duration':c['duration'],'sourceFile':c.get('sourceFile'),'yawDeltaDeg':c.get('yawDeltaDeg'),'license':c.get('license')} for k,c in clips.items()]},open(OUT/'rokoko_merged_manifest_v5.json','w'),indent=2)
print('merged',len(clips),'clips')
