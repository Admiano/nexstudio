'use strict';
const crypto=require('crypto');
const C=require('../cast/runtime/nexstick-cast-v2.js');
const families=C.familyIds;
const stable=o=>JSON.stringify(o,(k,v)=>typeof v==='number'?Number(v.toFixed(12)):v);
const hash=o=>crypto.createHash('sha256').update(stable(o)).digest('hex');
function morph(f){return C.derivePerformanceMorphology(f)}
function single(f,req){const q=C.sequence({familyId:f,steps:[{...req,personality:'calm'}]},{qa:{fps:60,maxFootSlideM:.02,maxHorizontalAccelMps2:15,maxHorizontalJerkMps3:200}});if(q.blocked)return q;const probes=[0,Math.min(.1,q.duration),Math.min(.5,q.duration),Math.min(1.0,q.duration),q.duration];for(const t of probes){const st=q.state(t);if(st?.blocked)return st;}return {blocked:false,duration:q.duration};}
const adversarial=[];
function expect(name,fn,pred){let obs;try{obs=fn();}catch(e){obs={threw:true,message:e.message}}const pass=!!pred(obs);adversarial.push({name,pass,observed:obs&&{blocked:obs.blocked,failure:obs.failure,requestBodyReposition:obs.requestBodyReposition,reachability:obs.reachability}});}
const ma=morph('adult_man_average'), mc=morph('neutral_child');
expect('target_below_floor',()=>single('adult_man_average',{action:'pickup',floorY:0,activeHand:'right',grip:{position:[-.2,-.08,.25],approachNormal:[0,0,-1],object:{id:'x'}}}),x=>x.blocked&&x.failure==='TARGET_BELOW_FLOOR');
expect('far_pickup_requests_reposition',()=>single('adult_man_average',{action:'pickup',floorY:0,activeHand:'right',grip:{position:[-2.0,.65,.2],approachNormal:[0,0,-1],object:{id:'x'}}}),x=>x.blocked&&x.failure==='BODY_REPOSITION_REQUIRED'&&x.requestBodyReposition===true);
expect('unsupported_turn_180',()=>single('adult_man_average',{action:'turn',angleDeg:180}),x=>x.blocked&&x.failure==='TURN_ANGLE_OUTSIDE_CAPTURED_90_DEG_ENVELOPE');
expect('heavy_carry_fail_closed',()=>single('adult_man_average',{action:'carry',grip:{loadClass:'heavy',object:{id:'heavy',size:[.4,.3,.3]}}}),x=>x.blocked&&x.failure==='HEAVY_CARRY_DONOR_NOT_ADMITTED');
expect('child_incompatible_high_chair',()=>single('neutral_child',{action:'sit',seat:{seatCenter:[0,.92,0],seatNormal:[0,1,0],seatForward:[0,0,1],floorY:0,depth:.44}}),x=>x.blocked&&['CHAIR_TOO_HIGH_FOR_FLOOR_AWARE_SEAT','CHAIR_BINDING_LEG_UNREACHABLE'].includes(x.failure));
expect('extreme_handoff_fail_closed',()=>C.handoffPair({giverFamilyId:'adult_woman_tall',receiverFamilyId:'diminutive_girl',giverHand:'right',receiverHand:'left'},.9),x=>x.blocked===true);

const det=[];
for(const f of families){const m=morph(f),x=-.24*m.armScale,z=.34*m.heightScale;const steps=[{action:'idle',transitionDuration:.18},{action:'walk',transitionDuration:.24},{action:'turn',direction:'left',transitionDuration:.22},{action:'conversation',transitionDuration:.25},{action:'pickup',floorY:0,activeHand:'right',grip:{position:[x,.47*m.heightScale,z],approachNormal:[0,0,-1],palmOffset:.075*m.handScale,object:{id:'box',size:[.12,.08,.1].map(v=>v*m.heightScale)}},transitionDuration:.28},{action:'place',floorY:0,activeHand:'right',grip:{position:[x,.50*m.heightScale,z],approachNormal:[0,0,-1],palmOffset:.075*m.handScale,object:{id:'box',size:[.12,.08,.1].map(v=>v*m.heightScale)}},transitionDuration:.28}];const build=()=>C.sequence({familyId:f,steps},{qa:{fps:60,maxFootSlideM:.02,maxHorizontalAccelMps2:15,maxHorizontalJerkMps3:200}});const a=build(),b=build();if(a.blocked||b.blocked){det.push({family:f,pass:false,failure:a.failure||b.failure});continue;}const times=[0,.173,.5,1.11,2.07,Math.max(0,a.duration*.37),Math.max(0,a.duration*.71),Math.max(0,a.duration-.001),a.duration];const ha=times.map(t=>hash(a.state(Math.min(t,a.duration)))),hb=times.map(t=>hash(b.state(Math.min(t,b.duration))));const reverse=[...times].reverse().map(t=>hash(a.state(Math.min(t,a.duration)))).reverse();det.push({family:f,pass:ha.every((h,i)=>h===hb[i]&&h===reverse[i]),durationEqual:Math.abs(a.duration-b.duration)<1e-12,hashes:ha});}
const summary={adversarialPassed:adversarial.filter(x=>x.pass).length,adversarialTotal:adversarial.length,determinismPassed:det.filter(x=>x.pass&&x.durationEqual).length,determinismTotal:det.length,overallPass:adversarial.every(x=>x.pass)&&det.every(x=>x.pass&&x.durationEqual)};
console.log(JSON.stringify({version:'NEXSTICK_MASTER_V2_ADVERSARIAL_DETERMINISM_1',generatedAt:new Date().toISOString(),adversarial,determinism:det,summary},null,2));
