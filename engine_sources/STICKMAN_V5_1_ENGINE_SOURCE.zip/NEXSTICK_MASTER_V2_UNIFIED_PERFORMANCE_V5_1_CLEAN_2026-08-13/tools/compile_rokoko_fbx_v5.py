#!/usr/bin/env python3
import json, math, struct, zlib, sys
from pathlib import Path
from collections import defaultdict
import numpy as np
from scipy.spatial.transform import Rotation as Rot

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'compiled'; OUT.mkdir(parents=True,exist_ok=True)
REF=json.load(open(ROOT/'data/canonical_ref.json'))
JOINTS=REF['joints']; SEG=REF['segments']; RPOSE={k:np.array(v,float) for k,v in REF['referencePose'].items()}
FPS=30.0; FBX_TICKS=46186158000.0
SOURCES={
 'walkspline_turn':('rokoko_walkrun/03-walkspline.fbx','turn',['turn','locomotion_transition','walk_spline']),
 'turn_capture':('turn-and-scare.fbx','turn',['turn','locomotion_transition']),
 'give_capture':('give-candy.fbx','give_capture',['give','offer','handoff_donor']),
 'high_reach_capture':('high-reach.fbx','high_reach_capture',['reach','high_reach']),
 'typing_leanback':('typing-leanback.fbx','typing_leanback',['typing','office','seated']),
 'presenter_papers':('news-anchor-papers.fbx','presenter_papers',['presenter','papers','office']),
 'stretch_capture':('stretching-out.fbx','stretch_capture',['stretch','idle_variation']),
 'documentary_acting':('NatureDocumentary_GoneWrong_hik.fbx','documentary_acting',['presenter','acting','reaction']),
}
MAP={
 'pelvis':'Hips','spine':'Spine','chest':'Spine2','neck':'Neck','head':'Head',
 'clavicle_l':'LeftShoulder','shoulder_l':'LeftArm','elbow_l':'LeftForeArm','wrist_l':'LeftHand',
 'clavicle_r':'RightShoulder','shoulder_r':'RightArm','elbow_r':'RightForeArm','wrist_r':'RightHand',
 'hip_l':'LeftUpLeg','knee_l':'LeftLeg','ankle_l':'LeftFoot','toe_l':'LeftToeBase',
 'hip_r':'RightUpLeg','knee_r':'RightLeg','ankle_r':'RightFoot','toe_r':'RightToeBase',
}
MAP_ALT={**MAP,'spine':'Spine1','chest':'Spine3','hip_l':'LeftThigh','knee_l':'LeftShin','toe_l':'LeftToe','hip_r':'RightThigh','knee_r':'RightShin','toe_r':'RightToe'}
ROT_ORDERS=['xyz','xzy','yzx','yxz','zxy','zyx']

class Reader:
 def __init__(self,b): self.b=b; self.n=len(b)
 def prop(self,o):
  t=chr(self.b[o]);o+=1
  if t=='Y': return struct.unpack_from('<h',self.b,o)[0],o+2
  if t=='C': return bool(self.b[o]),o+1
  if t=='I': return struct.unpack_from('<i',self.b,o)[0],o+4
  if t=='F': return struct.unpack_from('<f',self.b,o)[0],o+4
  if t=='D': return struct.unpack_from('<d',self.b,o)[0],o+8
  if t=='L': return struct.unpack_from('<q',self.b,o)[0],o+8
  if t in 'fdlib':
   ln,enc,cl=struct.unpack_from('<III',self.b,o);o+=12; raw=self.b[o:o+cl];o+=cl
   if enc: raw=zlib.decompress(raw)
   fm={'f':'f','d':'d','l':'q','i':'i','b':'b'}[t]
   return list(struct.unpack('<'+fm*ln,raw[:struct.calcsize('<'+fm*ln)])) if ln else [],o
  if t in 'SR':
   ln=struct.unpack_from('<I',self.b,o)[0];o+=4; raw=self.b[o:o+ln];o+=ln
   return (raw.decode('utf-8','replace') if t=='S' else raw),o
  raise ValueError((t,o))
 def node(self,o):
  if o+25>self.n:return None,self.n
  end,np_,plen=struct.unpack_from('<QQQ',self.b,o); namelen=self.b[o+24];o+=25
  if end==0:return None,o
  name=self.b[o:o+namelen].decode('utf-8','replace');o+=namelen; props=[]
  for _ in range(np_):v,o=self.prop(o);props.append(v)
  kids=[]
  while o<end-25:
   k,no=self.node(o)
   if k is None:o=no;break
   kids.append(k);o=no
  return {'name':name,'props':props,'kids':kids},end

def parse(path):
 b=path.read_bytes(); assert b[:18]==b'Kaydara FBX Binary'; r=Reader(b);ver=struct.unpack_from('<I',b,23)[0];assert ver>=7500
 o=27; roots=[]
 while o<len(b)-25:
  n,no=r.node(o)
  if n is None:break
  roots.append(n);o=no
 return roots

def clean_name(s):
 s=s.split('\x00')[0]
 return s.split('Character1_',1)[-1] if 'Character1_' in s else s

def p70(model):
 out={}
 ps=next((k for k in model['kids'] if k['name']=='Properties70'),None)
 if ps:
  for p in ps['kids']:
   if p['name']=='P' and p['props']:out[p['props'][0]]=p['props'][4:]
 return out

def arr_child(n,name,default=None):
 k=next((x for x in n['kids'] if x['name']==name),None)
 return k['props'][0] if k and k['props'] else default

def lerp_curve(times,vals,t,default):
 if not times:return float(default)
 if len(times)==1:return float(vals[0])
 ts=np.asarray(times,dtype=np.float64)/FBX_TICKS; vs=np.asarray(vals,dtype=np.float64)
 return float(np.interp(t,ts,vs,left=vs[0],right=vs[-1]))

def mat(t,r,s,order):
 # FBX Euler order. For skeleton positions, dense HumanIK curves plus local offsets are sufficient.
 rr=Rot.from_euler(ROT_ORDERS[order] if 0<=order<6 else 'xyz',r,degrees=True).as_matrix()
 M=np.eye(4);M[:3,:3]=rr@np.diag(s);M[:3,3]=t;return M

def safe_dir(v,fallback):
 n=np.linalg.norm(v);return np.array(fallback,float) if n<1e-9 else v/n

def chain(out,a,b,d,L):out[b]=out[a]+safe_dir(d,RPOSE[b]-RPOSE[a])*L

def retarget(src,rest):
 # FBX HumanIK coordinates are centimeters, Y-up. Preserve captured root travel, retarget limb directions to canonical lengths.
 donor_root=np.array([src['pelvis'][0],0,src['pelvis'][2]])
 rest_root=np.array([rest['pelvis'][0],0,rest['pelvis'][2]])
 dr=(donor_root-rest_root)/100.0
 pelvis_delta=(src['pelvis']-donor_root-(rest['pelvis']-rest_root))/100.0
 out={'root':RPOSE['root']+dr,'pelvis':RPOSE['pelvis']+dr+pelvis_delta}
 chain(out,'pelvis','spine',src['spine']-src['pelvis'],SEG['pelvis->spine']);chain(out,'spine','chest',src['chest']-src['spine'],SEG['spine->chest'])
 chain(out,'chest','neck',src['neck']-src['chest'],SEG['chest->neck']);chain(out,'neck','head',src['head']-src['neck'],SEG['neck->head'])
 for side in ['l','r']:
  chain(out,'chest',f'clavicle_{side}',src[f'clavicle_{side}']-src['chest'],SEG[f'chest->clavicle_{side}'])
  chain(out,f'clavicle_{side}',f'shoulder_{side}',src[f'shoulder_{side}']-src[f'clavicle_{side}'],SEG[f'clavicle_{side}->shoulder_{side}'])
  chain(out,f'shoulder_{side}',f'elbow_{side}',src[f'elbow_{side}']-src[f'shoulder_{side}'],SEG[f'shoulder_{side}->elbow_{side}'])
  chain(out,f'elbow_{side}',f'wrist_{side}',src[f'wrist_{side}']-src[f'elbow_{side}'],SEG[f'elbow_{side}->wrist_{side}'])
  chain(out,'pelvis',f'hip_{side}',src[f'hip_{side}']-src['pelvis'],SEG[f'pelvis->hip_{side}'])
  chain(out,f'hip_{side}',f'knee_{side}',src[f'knee_{side}']-src[f'hip_{side}'],SEG[f'hip_{side}->knee_{side}'])
  chain(out,f'knee_{side}',f'ankle_{side}',src[f'ankle_{side}']-src[f'knee_{side}'],SEG[f'knee_{side}->ankle_{side}'])
  chain(out,f'ankle_{side}',f'toe_{side}',src[f'toe_{side}']-src[f'ankle_{side}'],SEG[f'ankle_{side}->toe_{side}'])
 return np.array([out[j] for j in JOINTS],float)

def contacts(frames):
 a=np.asarray(frames,float); ix={j:i for i,j in enumerate(JOINTS)}; out={}
 for side in ['l','r']:
  an=a[:,ix[f'ankle_{side}']];toe=a[:,ix[f'toe_{side}']]; v=np.minimum(np.linalg.norm(np.gradient(an,axis=0)*FPS,axis=1),np.linalg.norm(np.gradient(toe,axis=0)*FPS,axis=1));h=np.minimum(an[:,1],toe[:,1]);floor=np.percentile(h,4);mask=(h<floor+.055)&(v<.34); segs=[];st=None
  for i,x in enumerate(mask.tolist()+[False]):
   if x and st is None:st=i
   elif not x and st is not None:
    if i-st>=2:
     m=(st+i-1)//2;segs.append({'start':round(st/FPS,5),'end':round((i-1)/FPS,5),'anchor':[round(float(x),6) for x in an[m]]})
    st=None
  out[side]=segs
 return out

def yaw_series(frames):
 a=np.asarray(frames,float);ix={j:i for i,j in enumerate(JOINTS)}; y=[]
 for p in a:
  lr=p[ix['hip_r']]-p[ix['hip_l']]; f=np.cross(lr,[0,1,0]); y.append(math.atan2(f[0],f[2]))
 return np.unwrap(y)

def trim_turn(frames):
 # Find a compact monotonic ~90-degree body turn inside a longer captured locomotion path.
 # This keeps actual captured stepping/weight-shift while excluding unrelated path segments.
 y=np.degrees(yaw_series(frames)); a=np.asarray(frames,float); best=None
 for i in range(0,len(y)-20):
  for j in range(i+20,min(len(y),i+76)):
   d=float(y[j]-y[i])
   if not (70<=abs(d)<=105): continue
   dif=np.diff(y[i:j+1]); mono=float(np.mean(np.sign(d)*dif>=-1.0)); travel=float(np.linalg.norm(a[j,0,[0,2]]-a[i,0,[0,2]])); dur=(j-i)/FPS
   score=abs(abs(d)-90)+50*(1-mono)+3*abs(dur-1.2)+3*travel
   if best is None or score<best[0]: best=(score,i,j,d,mono,travel)
 if best is None:
  return frames,0,len(frames)-1,float(y[-1]-y[0])
 _,st,en,deg,mono,travel=best
 # one-frame context is enough; do not add unrelated approach/exit motion.
 return frames[st:en+1],st,en,float(deg)

def facing_yaw(frame):
 p=np.asarray(frame,float); ix={j:i for i,j in enumerate(JOINTS)}; lr=p[ix['hip_r']]-p[ix['hip_l']]; f=np.cross(lr,[0,1,0]); return math.atan2(f[0],f[2])
def normalize_facing(frames):
 a=np.asarray(frames,float); src=facing_yaw(a[0]); ref=facing_yaw(np.array([RPOSE[j] for j in JOINTS],float)); ang=ref-src; c,s=math.cos(ang),math.sin(ang); R=np.array([[c,0,s],[0,1,0],[-s,0,c]],float); origin=a[0,0].copy(); out=[]
 for p in a:
  q=(p-origin)@R.T+RPOSE['root']; out.append(np.round(q,6).tolist())
 return out,float(math.degrees(src)),float(math.degrees(ref)),float(math.degrees(ang))

def compile_one(path,key,semantic,tags):
 roots=parse(path);objs=next(x for x in roots if x['name']=='Objects');con=next(x for x in roots if x['name']=='Connections')
 models={k['props'][0]:k for k in objs['kids'] if k['name']=='Model'}; acn={k['props'][0]:k for k in objs['kids'] if k['name']=='AnimationCurveNode'}; curves={k['props'][0]:k for k in objs['kids'] if k['name']=='AnimationCurve'}
 model_by_name={clean_name(k['props'][1]):i for i,k in models.items()}; parent={}
 for c in con['kids']:
  p=c['props']
  if len(p)>=3 and p[0]=='OO' and p[1] in models and p[2] in models:parent[p[1]]=p[2]
 props={};defaults={}
 for i,m in models.items():
  pr=p70(m);defaults[i]={'t':np.array((pr.get('Lcl Translation') or [0,0,0])[:3],float),'r':np.array((pr.get('Lcl Rotation') or [0,0,0])[:3],float),'s':np.array((pr.get('Lcl Scaling') or [1,1,1])[:3],float),'order':int((pr.get('RotationOrder') or [0])[0])}
 tracks=defaultdict(dict); node_targets={}
 for c in con['kids']:
  p=c['props']
  if len(p)>=4 and p[0]=='OP' and p[1] in acn and p[2] in models and p[3] in ('Lcl Translation','Lcl Rotation','Lcl Scaling'):node_targets[p[1]]=(p[2],p[3])
 for c in con['kids']:
  p=c['props']
  if len(p)>=4 and p[0]=='OP' and p[1] in curves and p[2] in node_targets and p[3] in ('d|X','d|Y','d|Z'):
   cv=curves[p[1]]; times=arr_child(cv,'KeyTime',[]);vals=arr_child(cv,'KeyValueFloat',[]); mid,prop=node_targets[p[2]];tracks[(mid,prop)][p[3][-1]]=(times,vals)
 all_times=[]
 for axes in tracks.values():
  for ts,_ in axes.values():all_times.extend(ts)
 if not all_times:raise RuntimeError(f'no animation keys {path}')
 t0=min(all_times)/FBX_TICKS;t1=max(all_times)/FBX_TICKS; dur=t1-t0; n=max(2,int(round(dur*FPS))+1);times=np.linspace(t0,t1,n)
 map_use=MAP_ALT if ('LeftThigh' in model_by_name and 'LeftUpLeg' not in model_by_name) else MAP
 needed=set(model_by_name[n] for n in map_use.values() if n in model_by_name)
 if len(needed)!=len(map_use):
  miss=[v for v in map_use.values() if v not in model_by_name];raise RuntimeError(f'missing bones {miss}')
 def eval_local(mid,t):
  d=defaults[mid];T=d['t'].copy();R=d['r'].copy();S=d['s'].copy()
  for prop,arr in [('Lcl Translation',T),('Lcl Rotation',R),('Lcl Scaling',S)]:
   axes=tracks.get((mid,prop),{})
   for ai,ax in enumerate('XYZ'):
    if ax in axes:arr[ai]=lerp_curve(*axes[ax],t,arr[ai])
  return mat(T,R,S,d['order'])
 def world_at(t):
  cache={}
  def calc(mid):
   if mid in cache:return cache[mid]
   M=eval_local(mid,t); pid=parent.get(mid);cache[mid]=M if pid is None else calc(pid)@M;return cache[mid]
  return {cj:calc(model_by_name[src])[:3,3].copy() for cj,src in map_use.items()}
 rest=world_at(times[0]);frames=[np.round(retarget(world_at(tm),rest),6).tolist() for tm in times]
 crop_meta=None
 if semantic=='turn':
  cropped,st,en,deg=trim_turn(frames);crop_meta={'sourceStartFrame':st,'sourceEndFrame':en,'yawDeltaDeg':round(deg,2)};frames=cropped
 frames,source_yaw,canonical_yaw,applied_yaw=normalize_facing(frames)
 dur=(len(frames)-1)/FPS; cts=contacts(frames); root_delta=(np.array(frames[-1][0])-np.array(frames[0][0])).tolist();yaw=float(math.degrees(yaw_series(frames)[-1]-yaw_series(frames)[0]))
 return {'duration':round(dur,6),'fps':FPS,'loop':False,'source':'Rokoko Free Mocap','sourceFile':path.name,'license':'Rokoko free resource; commercial rendered-project use per source page; raw redistribution not intended','semantic':semantic,'tags':['rokoko','captured']+tags,'times':[round(i/FPS,6) for i in range(len(frames))],'frames':frames,'rootDelta':[round(float(x),6) for x in root_delta],'contacts':cts,'yawDeltaDeg':round(yaw,2),'facingNormalization':{'sourceStartYawDeg':round(source_yaw,3),'canonicalYawDeg':round(canonical_yaw,3),'appliedYawDeg':round(applied_yaw,3)},'crop':crop_meta}

def main():
 clips={};manifest=[]
 selected=set(sys.argv[1:]) if len(sys.argv)>1 else set(SOURCES)
 for key,(fn,sem,tags) in SOURCES.items():
  if key not in selected: continue
  p=ROOT/'raw_donors'/fn
  if not p.exists():continue
  try:
   c=compile_one(p,key,sem,tags); clips[key]=c;manifest.append({'key':key,'file':fn,'semantic':sem,'duration':c['duration'],'frames':len(c['frames']),'rootDelta':c['rootDelta'],'yawDeltaDeg':c['yawDeltaDeg'],'contacts':{k:len(v) for k,v in c['contacts'].items()},'crop':c['crop'],'status':'COMPILED_QA_PENDING'})
   print('compiled',key,sem,c['duration'],'yaw',c['yawDeltaDeg'])
  except Exception as e:
   manifest.append({'key':key,'file':fn,'semantic':sem,'status':'REJECTED_IMPORT','error':repr(e)});print('REJECT',key,e)
 vault={'version':'5.0.0','source':'Selected Rokoko free mocap FBX donors','fps':FPS,'joints':JOINTS,'clips':clips}
 json.dump(vault,open(OUT/'rokoko_motion_vault_v5.json','w'),separators=(',',':'))
 with open(OUT/'nex-rokoko-motion-vault-v5.js','w') as f:f.write("(function(root){'use strict';root.NexRokokoMotionVaultV5="+json.dumps(vault,separators=(',',':'))+";})(typeof window!=='undefined'?window:globalThis);")
 json.dump({'version':'5.0.0','compiled':len(clips),'items':manifest},open(OUT/'rokoko_compile_manifest_v5.json','w'),indent=2)
 print('done',len(clips),'json_mb',round((OUT/'rokoko_motion_vault_v5.json').stat().st_size/1e6,2))

if __name__=="__main__": main()
