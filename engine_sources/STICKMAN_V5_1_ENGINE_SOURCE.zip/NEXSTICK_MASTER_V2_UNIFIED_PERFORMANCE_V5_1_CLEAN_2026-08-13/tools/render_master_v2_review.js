'use strict';
const fs=require('fs'),path=require('path');
const C=require('../cast/runtime/nexstick-cast-v2.js');
const out=path.resolve(__dirname,'../reports/render_review/svgs');fs.mkdirSync(out,{recursive:true});
const fps=24,W=720,H=720;
function morph(f){return C.derivePerformanceMorphology(f)}
function fixture(f){const m=morph(f),x=-.24*m.armScale,z=.34*m.heightScale;return {m,pick:rel=>({familyId:f,action:'pickup',floorY:0,activeHand:'right',grip:{position:[x,rel*m.heightScale,z],approachNormal:[0,0,-1],palmOffset:.075*m.handScale,object:{id:'box',shape:'box',size:[.12,.08,.10].map(v=>v*m.heightScale)},loadClass:'light'},personality:'calm'}),press:{familyId:f,action:'press',floorY:0,activeHand:'right',button:{position:[x,1.0*m.heightScale,.18*m.heightScale],normal:[0,0,-1],depth:.012*m.heightScale},personality:'calm'}}}
const f='adult_woman_tall';
const chain=[{action:'idle',transitionDuration:.18},{action:'walk',transitionDuration:.24},{action:'turn',direction:'left',transitionDuration:.22},{action:'run',transitionDuration:.28},{action:'conversation',transitionDuration:.30},{action:'high_reach',transitionDuration:.28},{action:'give_capture',transitionDuration:.28},{action:'walk',transitionDuration:.26}].map(x=>({...x,personality:'calm'}));
const smooth=C.sequence({familyId:f,steps:chain},{qa:{fps:60,maxFootSlideM:.02,maxHorizontalAccelMps2:15,maxHorizontalJerkMps3:200}});if(smooth.blocked)throw new Error('smooth blocked '+smooth.failure);
const tall=fixture('adult_woman_tall'), small=fixture('diminutive_girl');
const clips=[
 {label:'TALL LOW PICKUP',seq:C.sequence({familyId:'adult_woman_tall',steps:[tall.pick(.28)]})},
 {label:'DIMINUTIVE HIGH PICKUP',seq:C.sequence({familyId:'diminutive_girl',steps:[small.pick(1.18)]})},
 {label:'DIMINUTIVE PRESS',seq:C.sequence({familyId:'diminutive_girl',steps:[small.press]})},
 {label:'TRANSITION CHAIN',seq:smooth},
];
for(const c of clips)if(c.seq.blocked)throw new Error(c.label+' blocked '+c.seq.failure);
const gap=.20,total=clips.reduce((s,c)=>s+c.seq.duration+gap,0)-gap;let starts=[],acc=0;for(const c of clips){starts.push(acc);acc+=c.seq.duration+gap;}
function current(t){for(let i=clips.length-1;i>=0;i--)if(t>=starts[i]){let local=Math.min(clips[i].seq.duration,Math.max(0,t-starts[i]));return {clip:clips[i],local,index:i};}return {clip:clips[0],local:0,index:0}}
const frames=Math.ceil(total*fps);for(let i=0;i<=frames;i++){const t=Math.min(total,i/fps),c=current(t),r=c.clip.seq.sample(c.local);if(!r||r.blocked)throw new Error(`render state blocked frame ${i}: ${r?.failure}`);let svg=C.render(r,{width:W,height:H});svg=svg.replace('</svg>',`<rect x="14" y="14" rx="8" width="330" height="34" fill="white" fill-opacity=".88"/><text x="28" y="37" font-family="Arial,sans-serif" font-size="16" fill="#222">${c.clip.label}</text><text x="28" y="62" font-family="Arial,sans-serif" font-size="11" fill="#555">V5 debug skin · ${t.toFixed(2)}s</text></svg>`);fs.writeFileSync(path.join(out,String(i).padStart(5,'0')+'.svg'),svg);}
fs.writeFileSync(path.resolve(__dirname,'../reports/render_review/manifest.json'),JSON.stringify({fps,width:W,height:H,totalDuration:total,frames:frames+1,clips:clips.map((c,i)=>({label:c.label,start:starts[i],duration:c.seq.duration}))},null,2));
console.log(JSON.stringify({fps,W,H,total,frames:frames+1}));
