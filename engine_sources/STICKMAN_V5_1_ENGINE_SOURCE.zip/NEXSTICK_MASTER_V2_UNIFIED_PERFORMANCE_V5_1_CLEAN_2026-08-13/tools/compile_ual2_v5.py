#!/usr/bin/env python3
import json, struct, math, sys, os
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation as Rot

ROOT=Path(__file__).resolve().parents[1]
SRC=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'_ual2/UAL2_Standard_RM.glb'
OUT=ROOT/'compiled'; OUT.mkdir(parents=True,exist_ok=True)
REF=json.load(open(ROOT/'data/canonical_ref.json'))
JOINTS=REF['joints']; SEG=REF['segments']; RPOSE={k:np.array(v,float) for k,v in REF['referencePose'].items()}
FPS=30.0
NODEMAP={'root':'root','pelvis':'pelvis','spine':'spine_01','chest':'spine_03','neck':'neck_01','head':'Head',
'clavicle_l':'clavicle_l','shoulder_l':'upperarm_l','elbow_l':'lowerarm_l','wrist_l':'hand_l',
'clavicle_r':'clavicle_r','shoulder_r':'upperarm_r','elbow_r':'lowerarm_r','wrist_r':'hand_r',
'hip_l':'thigh_l','knee_l':'calf_l','ankle_l':'foot_l','toe_l':'ball_l','hip_r':'thigh_r','knee_r':'calf_r','ankle_r':'foot_r','toe_r':'ball_r'}
EXCLUDE_PREFIX=('Hit_','Melee_','Shield_','Sword_','Zombie_')
EXCLUDE={'A_TPose'}
SEMANTICS={
 'Chest_Open':'stretch_chest','ClimbUp_1m':'climb_up','Consume':'consume','Farm_Harvest':'farm_harvest','Farm_PlantSeed':'farm_plant','Farm_Watering':'farm_water',
 'Idle_FoldArms_Loop':'idle_fold_arms','Idle_Lantern_Loop':'idle_lantern','Idle_No_Loop':'idle_no','Idle_Rail_Call':'call_out','Idle_Rail_Loop':'idle_rail','Idle_TalkingPhone_Loop':'phone_talk',
 'LayToIdle':'lay_to_idle','NinjaJump_Idle_Loop':'jump_idle','NinjaJump_Land':'jump_land','NinjaJump_Start':'jump_start','OverhandThrow':'throw_overhand',
 'Slide_Exit':'slide_exit','Slide_Loop':'slide_loop','Slide_Start':'slide_start','TreeChopping_Loop':'tree_chop','Walk_Carry_Loop':'walk_carry','Yes':'nod_yes'}
LOOPS={'Idle_FoldArms_Loop','Idle_Lantern_Loop','Idle_Rail_Loop','Idle_TalkingPhone_Loop','NinjaJump_Idle_Loop','Slide_Loop','TreeChopping_Loop','Walk_Carry_Loop'}

def parse_glb(path):
    b=path.read_bytes(); magic,ver,total=struct.unpack_from('<4sII',b,0); assert magic==b'glTF'; off=12; js=None; binch=None
    while off<total:
        ln,typ=struct.unpack_from('<II',b,off); off+=8; chunk=b[off:off+ln]; off+=ln
        if typ==0x4E4F534A: js=json.loads(chunk.decode('utf8').rstrip('\0 \n\r\t'))
        elif typ==0x004E4942: binch=chunk
    return js,binch

def accessor(j,b,idx):
    a=j['accessors'][idx]; bv=j['bufferViews'][a['bufferView']]; off=bv.get('byteOffset',0)+a.get('byteOffset',0); ct=a['componentType']; typ=a['type']; n=a['count']
    dtype={5126:np.float32,5123:np.uint16,5125:np.uint32,5121:np.uint8,5122:np.int16}[ct]; comps={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[typ]
    stride=bv.get('byteStride'); item=np.dtype(dtype).itemsize*comps
    if not stride or stride==item: return np.frombuffer(b,dtype=dtype,count=n*comps,offset=off).reshape(n,comps)
    out=np.empty((n,comps),dtype=dtype)
    for i in range(n): out[i]=np.frombuffer(b,dtype=dtype,count=comps,offset=off+i*stride)
    return out

def qnorm(q):
    q=np.asarray(q,float); n=np.linalg.norm(q,axis=-1,keepdims=True); return q/np.maximum(n,1e-12)
def interp_vec(ts,vs,t):
    if len(ts)==1:return np.array(vs[0],float)
    i=max(0,min(len(ts)-2,int(np.searchsorted(ts,t,'right')-1))); a,b=float(ts[i]),float(ts[i+1]); u=0 if b==a else (t-a)/(b-a); return np.array(vs[i]*(1-u)+vs[i+1]*u,float)
def interp_quat(ts,qs,t):
    if len(ts)==1:return qnorm(qs[0])
    i=max(0,min(len(ts)-2,int(np.searchsorted(ts,t,'right')-1))); a,b=float(ts[i]),float(ts[i+1]); u=0 if b==a else (t-a)/(b-a); q0=qnorm(qs[i]); q1=qnorm(qs[i+1]);
    if np.dot(q0,q1)<0:q1=-q1
    dot=np.clip(np.dot(q0,q1),-1,1)
    if dot>.9995:return qnorm(q0*(1-u)+q1*u)
    th=math.acos(dot); s=math.sin(th); return math.sin((1-u)*th)/s*q0+math.sin(u*th)/s*q1

def local_matrix(t,q,s):
    M=np.eye(4); M[:3,:3]=Rot.from_quat(q).as_matrix()@np.diag(s); M[:3,3]=t; return M

def safe_dir(v,fallback):
    n=np.linalg.norm(v); return np.array(fallback,float) if n<1e-8 else v/n

def chain(out,parent,child,direction,length): out[child]=out[parent]+safe_dir(direction,RPOSE[child]-RPOSE[parent])*length

def retarget(world,rest,scale):
    donor_root=world['root']; donor_pel=world['pelvis']; dr=donor_root-rest['root']; root=RPOSE['root']+dr*scale
    rel=(donor_pel-donor_root)-(rest['pelvis']-rest['root']); pelvis=RPOSE['pelvis']+dr*scale+rel*scale
    out={'root':root,'pelvis':pelvis}
    chain(out,'pelvis','spine',world['spine']-world['pelvis'],SEG['pelvis->spine']); chain(out,'spine','chest',world['chest']-world['spine'],SEG['spine->chest'])
    chain(out,'chest','neck',world['neck']-world['chest'],SEG['chest->neck']); chain(out,'neck','head',world['head']-world['neck'],SEG['neck->head'])
    for side in ['l','r']:
        chain(out,'chest',f'clavicle_{side}',world[f'clavicle_{side}']-world['chest'],SEG[f'chest->clavicle_{side}'])
        chain(out,f'clavicle_{side}',f'shoulder_{side}',world[f'shoulder_{side}']-world[f'clavicle_{side}'],SEG[f'clavicle_{side}->shoulder_{side}'])
        chain(out,f'shoulder_{side}',f'elbow_{side}',world[f'elbow_{side}']-world[f'shoulder_{side}'],SEG[f'shoulder_{side}->elbow_{side}'])
        chain(out,f'elbow_{side}',f'wrist_{side}',world[f'wrist_{side}']-world[f'elbow_{side}'],SEG[f'elbow_{side}->wrist_{side}'])
        chain(out,'pelvis',f'hip_{side}',world[f'hip_{side}']-world['pelvis'],SEG[f'pelvis->hip_{side}'])
        chain(out,f'hip_{side}',f'knee_{side}',world[f'knee_{side}']-world[f'hip_{side}'],SEG[f'hip_{side}->knee_{side}'])
        chain(out,f'knee_{side}',f'ankle_{side}',world[f'ankle_{side}']-world[f'knee_{side}'],SEG[f'knee_{side}->ankle_{side}'])
        chain(out,f'ankle_{side}',f'toe_{side}',world[f'toe_{side}']-world[f'ankle_{side}'],SEG[f'ankle_{side}->toe_{side}'])
    return np.array([out[j] for j in JOINTS],float)

def contacts(frames,fps):
    arr=np.array(frames,float); ix={j:i for i,j in enumerate(JOINTS)}; result={}
    for side in ['l','r']:
        a=arr[:,ix[f'ankle_{side}'],:]; toe=arr[:,ix[f'toe_{side}'],:]; va=np.linalg.norm(np.gradient(a,axis=0)*fps,axis=1); vt=np.linalg.norm(np.gradient(toe,axis=0)*fps,axis=1)
        h=np.minimum(a[:,1],toe[:,1]); floor=np.percentile(h,5); mask=(h<floor+.055)&(np.minimum(va,vt)<.32); segs=[]; st=None
        for i,v in enumerate(mask.tolist()+[False]):
            if v and st is None: st=i
            elif not v and st is not None:
                if i-st>=2:
                    mid=(st+i-1)//2; segs.append({'start':round(st/fps,5),'end':round((i-1)/fps,5),'anchor':[round(x,6) for x in a[mid].tolist()]})
                st=None
        result[side]=segs
    return result

def features(frames,fps):
    arr=np.array(frames,float); ix={j:i for i,j in enumerate(JOINTS)}; out=[]
    for i,p in enumerate(arr):
        pel=p[ix['pelvis']]; root=p[ix['root']]; j0=max(0,i-1); j1=min(len(arr)-1,i+1); dt=max((j1-j0)/fps,1/fps); vel=(arr[j1,ix['root']]-arr[j0,ix['root']])/dt; f=[]
        for n in ['wrist_l','wrist_r','ankle_l','ankle_r','head']: f.extend((p[ix[n]]-pel).tolist())
        f.extend(vel.tolist())
        for sec in [.25,.5]:
            k=min(len(arr)-1,i+round(sec*fps)); f.extend((arr[k,ix['root']]-root).tolist())
        out.append([round(float(x),5) for x in f])
    return out

j,b=parse_glb(SRC); nodes=j['nodes']; parents=[None]*len(nodes)
for i,n in enumerate(nodes):
    for c in n.get('children',[]): parents[c]=i
base_t=[np.array(n.get('translation',[0,0,0]),float) for n in nodes]; base_q=[np.array(n.get('rotation',[0,0,0,1]),float) for n in nodes]; base_s=[np.array(n.get('scale',[1,1,1]),float) for n in nodes]
def world_from(tloc,qloc,sloc):
    W=[None]*len(nodes)
    def calc(i):
        if W[i] is not None:return W[i]
        M=local_matrix(tloc[i],qloc[i],sloc[i]); W[i]=M if parents[i] is None else calc(parents[i])@M; return W[i]
    return {k:calc(next(i for i,n in enumerate(nodes) if n.get('name')==v))[:3,3].copy() for k,v in NODEMAP.items()}
rest=world_from(base_t,base_q,base_s); scale=float(RPOSE['pelvis'][1]/max(rest['pelvis'][1]-rest['root'][1],1e-6))
clips={}; manifest=[]
for anim in j.get('animations',[]):
    name=anim.get('name','unnamed')
    if name in EXCLUDE or name.startswith(EXCLUDE_PREFIX): continue
    tracks={}; max_t=0.0
    for ch in anim['channels']:
        samp=anim['samplers'][ch['sampler']]; target=ch['target']; node=target['node']; pathn=target['path']; ts=accessor(j,b,samp['input']).reshape(-1); vals=accessor(j,b,samp['output']); max_t=max(max_t,float(ts[-1] if len(ts) else 0)); tracks[(node,pathn)]=(ts,vals)
    if max_t<=0: continue
    times=np.arange(0,max_t+.5/FPS,1/FPS); frames=[]
    for tm in times:
        tl=[x.copy() for x in base_t]; ql=[x.copy() for x in base_q]; sl=[x.copy() for x in base_s]
        for (node,pathn),(ts,vs) in tracks.items():
            if pathn=='translation':tl[node]=interp_vec(ts,vs,tm)
            elif pathn=='rotation':ql[node]=interp_quat(ts,vs,tm)
            elif pathn=='scale':sl[node]=interp_vec(ts,vs,tm)
        frames.append(np.round(retarget(world_from(tl,ql,sl),rest,scale),6).tolist())
    root_delta=(np.array(frames[-1][0])-np.array(frames[0][0])).tolist(); cts=contacts(frames,FPS)
    key='UAL2_'+name; semantic=SEMANTICS.get(name,name.lower()); tags=['ual2','cc0',semantic]
    clips[key]={'duration':round(max_t,6),'fps':FPS,'loop':name in LOOPS,'source':'Quaternius Universal Animation Library 2 Standard','license':'CC0-1.0','semantic':semantic,'tags':tags,'times':[round(i/FPS,6) for i in range(len(frames))],'frames':frames,'rootDelta':[round(float(x),6) for x in root_delta],'contacts':cts,'features':features(frames,FPS)}
    manifest.append({'key':key,'name':name,'semantic':semantic,'duration':round(max_t,4),'frames':len(frames),'loop':name in LOOPS,'rootDelta':clips[key]['rootDelta'],'contacts':{s:len(cts[s]) for s in cts}})
vault={'version':'5.0.0','source':'UAL2 Standard CC0','fps':FPS,'joints':JOINTS,'clips':clips}
json.dump(vault,open(OUT/'ual2_motion_vault_v5.json','w'),separators=(',',':'))
with open(OUT/'nex-ual2-motion-vault-v5.js','w') as f:f.write("(function(root){'use strict';root.NexUAL2MotionVaultV5="+json.dumps(vault,separators=(',',':'))+";})(typeof window!=='undefined'?window:globalThis);")
json.dump({'version':'5.0.0','source_file':str(SRC),'compiled_clips':len(manifest),'clips':manifest},open(OUT/'ual2_compile_manifest_v5.json','w'),indent=2)
print('compiled',len(manifest),'clips', 'json_mb',round((OUT/'ual2_motion_vault_v5.json').stat().st_size/1e6,2))
