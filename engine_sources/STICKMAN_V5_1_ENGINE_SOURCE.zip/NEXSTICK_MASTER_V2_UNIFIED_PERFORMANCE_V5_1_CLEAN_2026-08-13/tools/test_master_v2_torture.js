'use strict';
const C=require('../cast/runtime/nexstick-cast-v2.js');
const V=global.NexPerformanceUnifiedV5;
const families=['adult_man_average','adult_woman_average','boy','girl','adult_woman_tall','diminutive_man'];
const chain=[
 {action:'idle',personality:'calm',transitionDuration:.18},
 {action:'walk',personality:'calm',transitionDuration:.24},
 {action:'turn',direction:'left',personality:'confident',transitionDuration:.22},
 {action:'run',personality:'energetic',transitionDuration:.28},
 {action:'conversation',personality:'warm',transitionDuration:.30},
 {action:'high_reach',personality:'confident',transitionDuration:.28},
 {action:'give_capture',personality:'warm',transitionDuration:.28},
 {action:'sit',personality:'calm',transitionDuration:.32},
 {action:'stand',personality:'calm',transitionDuration:.32},
 {action:'walk',personality:'confident',transitionDuration:.26},
];
const results={version:'NEXSTICK_MASTER_V2_TORTURE_1',families:{},interaction:{},handoff:{}};
for(const f of families){
 const seq=C.sequence({familyId:f,steps:chain},{qa:{fps:60,maxFootSlideM:.025}});
 if(seq.blocked){results.families[f]={pass:false,blocked:true,failure:seq.failure,index:seq.index};continue;}
 const qa=seq.qa();
 let facing=null;const turnIdx=seq.core.plans.findIndex(p=>p.request.action==='turn');if(turnIdx>=0){const p=seq.core.plans[turnIdx],after=seq.state(Math.min(seq.duration,p.end+.08));facing=after.worldTransform?.yawDeg??after.transition?.endWorldYawDeg??p.endYawDeg;}
 results.families[f]={pass:qa.pass,duration:seq.duration,qa,facingAfterTurnDeg:facing,finalRoot:seq.state(seq.duration).pose3d.root,finalWorldYaw:seq.state(seq.duration).worldTransform?.yawDeg??seq.core.plans.at(-1).endYawDeg};
}
function interactionReq(action){
 const common={floorY:0,activeHand:'right'};
 if(action==='pickup')return {...common,action,grip:{position:[.24,.16,.34],approachNormal:[0,0,-1],palmOffset:.075,object:{id:'box',shape:'box',size:[.12,.08,.10]},loadClass:'light'}};
 if(action==='place')return {...common,action,grip:{position:[.24,.30,.34],approachNormal:[0,0,-1],palmOffset:.075,object:{id:'box',shape:'box',size:[.12,.08,.10]},loadClass:'light'}};
 if(action==='carry')return {...common,action,grip:{loadClass:'medium',object:{id:'box',shape:'box',size:[.25,.18,.18]}}};
 if(action==='press')return {...common,action,button:{position:[.28,1.00,.18],normal:[0,0,-1],depth:.012}};
 if(action==='sit'||action==='stand')return {...common,action,seat:{seatCenter:[0,.48,0],seatNormal:[0,1,0],seatForward:[0,0,1],floorY:0,depth:.44}};
 return {...common,action};
}
for(const f of families){
 results.interaction[f]={};
 for(const a of ['pickup','carry','place','press','sit','stand']){
  const req={familyId:f,personality:'calm',...interactionReq(a)},dur=Math.min(1.0,Math.max(.2,V.actionDuration({action:a, ...interactionReq(a)})));
  const times=[0,dur*.35,dur*.7,dur*.98],rows=times.map(t=>C.sample(req,t));
  const blocked=rows.find(x=>x?.blocked);
  let minFoot=Infinity,segWorst=0;for(const r of rows){if(!r?.state?.pose3d)continue;const p=r.state.pose3d;for(const j of ['ankle_l','ankle_r','toe_l','toe_r'])minFoot=Math.min(minFoot,p[j][1]);segWorst=Math.max(segWorst,r.state.adaptation?.targetSegmentError?.worst||0);}
  results.interaction[f][a]={pass:!blocked,blocked:!!blocked,failure:blocked?.failure||null,minFootY:Number.isFinite(minFoot)?minFoot:null,maxTargetSegmentResidualM:segWorst};
 }
}
for(const [g,r] of [['adult_man_average','adult_woman_average'],['adult_woman_average','boy'],['adult_woman_tall','diminutive_man']]){
 const rows=[.1,.55,.9,1.2,1.55].map(t=>C.handoffPair({giverFamilyId:g,receiverFamilyId:r,giverHand:'right',receiverHand:'left'},t));
 const bad=rows.find(x=>x?.blocked);let maxGap=0;for(const x of rows){if(x?.mixedFamilyBridge?.sharedContactGap!=null)maxGap=Math.max(maxGap,x.mixedFamilyBridge.sharedContactGap);}
 results.handoff[g+'__'+r]={pass:!bad,blocked:!!bad,failure:bad?.failure||null,maxSharedContactGapM:maxGap};
}
console.log(JSON.stringify(results,null,2));
