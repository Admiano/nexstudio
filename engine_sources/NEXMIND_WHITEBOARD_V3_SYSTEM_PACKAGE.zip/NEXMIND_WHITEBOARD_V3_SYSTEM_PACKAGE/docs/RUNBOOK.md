# Runbook

## Prerequisites

- Python 3.11+ recommended. The preserved V3 checkpoints were executed under Python 3.13.
- `ffmpeg` and `ffprobe` on PATH for encoded video workflows.
- Python package: `Pillow`.
- `pytest` for the preserved test suites.
- A modern browser/Node host only if exercising the browser SVG runtime. The native browser path does not require a CDN; DrawSVG is optional when already provided by the host.

No font files are bundled. The compatibility patch resolves system fonts on Windows, Linux or macOS and falls back safely.

## Semantic authority test path

The semantic authority CLI lives at:

`03_semantic_and_decision/WHITEBOARD_ELITE_RUNTIME/semantic_authority_v1/plan_cli.py`

Live mode requires:

```bash
export OPENAI_API_KEY='...'
export NEXMIND_WHITEBOARD_SEMANTIC_MODEL='...'
# optional
export NEXMIND_WHITEBOARD_SEMANTIC_REASONING='high'
```

Then invoke the CLI with an input JSON containing `production_id`, narration segments, capability information and optional semantic doctrine. Live mode is intentionally fail-closed when credentials/model are absent. Recorded mode requires explicit fixture responses and is test-only.

## Decision-layer tests

From `03_semantic_and_decision/WHITEBOARD_ELITE_RUNTIME`:

```bash
python -m pytest decision_layer_v1/tests/test_decision_layer.py
python -m pytest semantic_authority_v1/tests/test_semantic_authority.py
```

## Composer tests

From `04_composition_grammars/whiteboard_semantic_illustration_composer_v1_4`:

```bash
python -m pytest tests
```

The composer expects abstract semantic input rather than topic-keyword routing. The included examples show the input and blueprint contract.

## Base execution body

The core Whiteboard runtime lives under:

`01_base_execution/Whiteboard_Execution_Body_V2/explainer-motion/whiteboard-v1/`

Read in this order:

1. `README.md`
2. `docs/ELITE_WHITEBOARD_V1_SPEC.md`
3. `docs/WHITEBOARD_RUNTIME_API.md`
4. `runtime/whiteboard_compiler.py`
5. `runtime/whiteboard-runtime.js`
6. `runtime/board-world.js` and `runtime/board-camera.js`
7. stroke / pen / draw-order / connector / layout modules
8. `runtime/whiteboard_pil_adapter.py`
9. `qa/whiteboard_qa.py`

The preserved `whiteboard_adapter.py` is the production family adapter from the repository snapshot. Its three direct service dependencies (`contracts.py`, `canonical.py`, `authored_art.py`) are included in `adapter_dependencies/`.

## Production assembly gateway

`02_production_authorities/whiteboard_production_gateway.saved.py` and the Layer 0–6 source show how the recovered production authorities are chained. Some of those authorities reference broader NexMind P8/P9/P25 components; those generic systems are deliberately not duplicated into this Whiteboard-only package. See `DEPENDENCY_BOUNDARIES.md`.

## Reproducing the exact attached TEXTFIX_V2 MP4

The reference MP4 and QA still are included. The exact V3 renderer is identified by path/hash in provenance, but its standalone source and the one-off TEXTFIX_V2 patch body were not persisted. Therefore this package provides the preserved executable Whiteboard system and all saved V3 upgrades, but it cannot truthfully promise byte-identical regeneration of that exact MP4 from source alone.
