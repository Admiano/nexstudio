# Dependency Boundaries and Deliberate Exclusions

This archive is intentionally Whiteboard-only. It does not copy entire NexStudio/NexMind repositories merely because one Whiteboard adapter imported a shared contract or creative authority.

## Included shared dependencies

The direct service-layer dependencies needed to understand the preserved `whiteboard_adapter.py` are included:

- `contracts.py`
- `canonical.py`
- `authored_art.py`

## Referenced but not duplicated

The production assembly gateway references broader NexMind authorities (for example P8/P9/P25) that are not Whiteboard-specific. Their integration contracts and Whiteboard-facing layer code are present, but the entire generic NexMind runtime is not copied here. This prevents the package from becoming an unrelated multi-system dump.

## Excluded on purpose

- NexStudio website/application UI
- Paperbook / Illustrated Stories / Editorial Motion systems
- NexStick/Blender runtimes except Whiteboard-specific performer truth contained in the Whiteboard layers
- NexMarkets
- historical job outputs and duplicated compile plans
- unrelated proof videos/contact sheets
- caches (`__pycache__`, `.pytest_cache`)
- duplicate raw audio when the production 48 kHz audio is already present
- duplicate source-vector set when normalized runtime vectors are already present
- later Whiteboard authored-human packages created after the requested TEXTFIX_V2 reel

The exact requested reel and its QA still are retained because they are the provenance anchor for this package.
