# System Architecture

## 1. Semantic input and authority

The V3 semantic seam accepts aligned narration/script segments. `semantic_authority_v1` converts those segments into the strict `NexMindWhiteboardBeatSemanticsV1` contract. It may identify semantic structure—human agency, process, comparison, transformation, handoff, data, mechanism, causality, time, uncertainty, etc.—but is forbidden from choosing representation, camera, layout, style, asset IDs, coordinates or renderer.

Production live mode is fail-closed. `OPENAI_API_KEY` and `NEXMIND_WHITEBOARD_SEMANTIC_MODEL` are required by the preserved live provider. The recorded provider exists only for tests.

## 2. Variety + comprehension decision layer

`decision_layer_v1` has two jobs:

1. **Variety Director** — competes representations from abstract semantic structure, with fit guards and repetition penalties. Variety is only a tie-breaker among semantically suitable representations.
2. **Comprehension Scheduler** — schedules drawing against narration. The visual may complete early and hold; late semantic cues can reveal later elements; micro-detail can group-reveal. Narration is the timing authority rather than a fixed per-stroke duration.

The manifest adapter writes renderer timing fields such as `start_seconds` and `draw_seconds`.

## 3. Semantic illustration composition

Semantic Illustration Composer V1.4 converts the chosen representation into a governed compound illustration blueprint. Its integrated grammars cover:

- data presentation;
- metaphor realization;
- supporting characters;
- explicit composition hierarchy.

The composition contract requires a clear hero, caps supporting evidence, caps micro-annotations, keeps characters subordinate unless semantically required, and supports 16:9, 1:1 and 9:16.

## 4. Whiteboard production authorities

The preserved production assembly separates:

- Phase 0A capability routing;
- Layer 1 story/scene composition;
- Layer 2 Whiteboard performer/physical truth;
- Layer 3 environment composition;
- Layer 4 action + temporal state;
- Layer 5 cinematography and draw choreography;
- Visual Foundation asset fitness;
- Layer 6 semantic visual realization.

These are Whiteboard-specific authorities, not generic website or NexStudio UI files.

## 5. Execution body

`Whiteboard_Execution_Body_V2` contains the execution mechanics:

- `whiteboard_compiler.py`
- `whiteboard-runtime.js`
- `board-world.js`
- `board-camera.js`
- `stroke-engine.js` / `freehand-engine.js`
- `pen-tip-tracker.js` / `pen-travel-planner.js`
- `semantic-draw-order.js`
- `connector-router.js` / `diagram-layout.js`
- `annotation-engine.js` / `eraser-mask.js`
- `single-stroke-text.js`
- data/mechanism/media skins
- sound choreography
- the PIL execution adapter and deterministic benchmark renderer

The browser runtime works in a persistent board coordinate system. Camera views are board-space `{x, y, zoom}` views, allowing camera travel through one evolving world instead of replacing slides.

## 6. V3 narration-timed renderer lineage

The execution receipt identifies the V3 last-mile renderer used by this lineage as:

`/mnt/data/nexmind-runtime/candidate/NEXMIND_WHITEBOARD_ELITE_INTEGRATED_V1/WHITEBOARD_ELITE_RUNTIME/vendor/pipeline_v3_narration_timed.py`

Recorded SHA-256:

`c91f2bc50cb634c993ff307ef01bb4177d9478a290bf0b4da042adee260f9c34`

It supported the camera variants `cluster_travel` and `giant_board_journey`. The standalone source body of that exact file is the one known preservation gap.

## 7. Text system

The preserved runtime includes `single-stroke-text.js` and PIL text rendering, plus a cross-platform font patch that searches Windows/Linux/macOS system-font paths without bundling font binaries. The attached TEXTFIX_V2 test was a later text-only pass on the V3 Cluster Travel baseline. The prior run record says that V2 mechanically thickened the existing lettering; its one-off patch body was not separately saved.

## 8. QA

The package keeps executable unit/fuzz tests and QA reports rather than bulk proof media. Preserved reports record, among other things, 5,000 noun-mutation invariance cases, 5,000 scheduler fuzz cases, 100 scheduler replan faults, and the V1.4 composition hierarchy's 5,000 randomized cases / 3,000 hostile label mutations with zero policy violations/selection changes in those recorded suites.
