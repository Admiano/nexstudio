# Package Scope

The selection rule for this ZIP is: **include a file only when it is part of the Whiteboard execution path, a Whiteboard-specific creative/semantic authority, a contract/test/report that explains or verifies that path, a required local runtime asset, or the exact reference output.**

This is why the archive is much smaller than the source repositories it was recovered from. The package is meant to be inspectable and useful, not a blind archive dump.
