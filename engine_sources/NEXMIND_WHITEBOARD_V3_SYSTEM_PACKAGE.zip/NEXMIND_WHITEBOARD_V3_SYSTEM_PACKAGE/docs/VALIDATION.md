# Validation

## Exact reference identity

The packaged reference video is byte-identical to the user-provided upload.

- SHA-256: `c1144a06425d72f85320e58a93878365e6830fcc3f9c5a7e420594b28dff89a1`
- container duration: 26.12 s
- video: 1280×720, 25 fps, H.264

## Preserved active V3 component tests

Executed from this curated package on 2026-09-18:

- semantic authority + decision layer: **15 passed**
- Semantic Illustration Composer V1.4 integration suite: **29 passed**

## Historical base-engine tests

The archived V1 `test_20_families.py` is retained as historical regression evidence, but running it directly against the later semantic-execution compiler raises `WHITEBOARD_EXECUTION_AUTHORITY_REQUIRED`. That is an expected authority-boundary mismatch between the old family-selection fixture and the later execution-only compiler, not a reason to rewrite the preserved source. The package leaves both artifacts unchanged and documents the boundary rather than altering history.

## Secret scan

No private key material or concrete API credentials were intentionally included. Live semantic execution expects credentials via environment variables; no credential values are packaged.
