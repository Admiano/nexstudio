# Whiteboard V1 Integration Notes

Whiteboard V1 deliberately reuses the existing NexStudio Director, semantic-performance runtime, compiler, self-service approval flow, final encoder, captions/voice path and QA. It does not create a second application or a separate customer workflow.

## Existing source files changed

1. `explainer-motion/style-system-v1/manifests/style-profiles.json`
   - adds the three Whiteboard style IDs.
2. `explainer-motion/director-v3/runtime/director_v3.py`
   - adds Whiteboard family preference and choreography-profile support.
3. `explainer-motion/benchmarks-stress-v1/runtime/benchmark_renderer.py`
   - delegates whiteboard scene/transition frames to `whiteboard_pil_adapter.py`.
4. `explainer-motion/self-service-v1/runtime/self_service_runtime.py`
   - compiles Whiteboard metadata after Director planning;
   - recompiles after bounded style edits/semantic repair;
   - renders Whiteboard foley;
   - runs Whiteboard QA before delivery.
5. `explainer-motion/self-service-v1/schemas/self-service-intake.schema.json`
   - accepts the three Whiteboard styles.
6. `explainer-motion/self-service-v1/server/p14-integration.js`
   - exposes the three Whiteboard styles in the existing Studio selector.

## Why this merge shape

The semantic question — *what does this beat mean?* — stays with the Director. Whiteboard V1 answers a later question — *how does that already-selected meaning behave on a persistent drawn board?* This avoids rebuilding the planner and prevents the style from collapsing into clipart templates.
