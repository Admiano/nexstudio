# Whiteboard V1 Runtime API

## Python planning layer

`compile_whiteboard_plan(plan, intake)` accepts the existing NexStudio Director plan. It only activates for:

- `style.whiteboard-editorial`
- `style.whiteboard-technical`
- `style.whiteboard-brand-marker`

It adds:

- `whiteboardRuntimeVersion`
- `whiteboardRuntimeDigest`
- `whiteboardBoardWorld`
- one `whiteboardRuntime` object per scene containing family, board zones, semantic objects, draw plan, camera intent, hand policy, text policy and transition contract.

`runtime_digest(plan)` is deterministic for equivalent input.

## Browser SVG layer

```js
const engine = NexWhiteboard.create(svg, {
  seed: 42,
  ratio: '16:9',
  duration: 12,
  ink: '#171918',
  accent: '#5D6FE8'
});
```

Core methods:

- `stroke(d, spec)`
- `freehand(points, spec)`
- `roughLine(a, b, spec)`
- `roughRect(x, y, w, h, spec)`
- `roughEllipse(cx, cy, rx, ry, spec)`
- `annotation(type, bounds, spec)`
- `singleStrokeText(text, x, y, size, spec)`
- `eraseElement(element, d, spec)`
- `setCamera(view)`
- `setCameraTrack([{t, view}, ...])`
- `renderAt(seconds)` — deterministic seek
- `play(fromSeconds)` / `pause()`
- `audioEvents()`
- `snapshot()`

### Camera views

A view is `{x, y, zoom}` in board coordinates. Camera animation lives in board space, so the film travels through one persistent world rather than replacing slides.

### Hand policy

The visible tool is not the visual system. Pen-tip visibility is intended only for meaningful annotation/emphasis gestures and is capped by the scene contract.

## Delivery adapter

`whiteboard_pil_adapter.py` is wired into `benchmarks-stress-v1/runtime/benchmark_renderer.py`. When a whiteboard style reaches the existing self-service renderer, scene and transition rendering delegate to the Whiteboard treatment while preserving the rest of the production pipeline.

## Audio

`sound_choreographer.py` produces a real 48 kHz mono PCM foley bed from the semantic draw plan. It uses the local production files under `assets/audio/production` and is mixed into final delivery by `self_service_runtime.py`.
