# Whiteboard Audio Integration — Locked CC0 Source Set

Status: **READY FOR RUNTIME INTEGRATION**

The three requested BigSoundBank WAV originals have been supplied and validated.

## Locked raw sources

1. `bigsoundbank-whiteboard-marker-0807.wav`
   - Whiteboard marker writing source.
   - Mono PCM16, 48 kHz, ~31.94 s.
   - CC0 / public domain per source page.

2. `bigsoundbank-pencil-0221.wav`
   - Pencil writing/drawing source.
   - Mono PCM16, 44.1 kHz, ~32.56 s.
   - CC0 / public domain per source page.

3. `bigsoundbank-pen-cap-0054.wav`
   - Pen-cap transient source.
   - Mono PCM16, 44.1 kHz, ~2.70 s.
   - CC0 / public domain per source page.

## Canonical production derivatives

The runtime versions in `audio/production/` are mono PCM16 48 kHz WAV files. Only format canonicalization/resampling was performed. No gain normalization, denoise, compression, EQ, looping or destructive trimming was applied.

This is intentional. Whiteboard sound should be gesture-driven rather than treated as a generic ambience bed.

## Runtime rules

- Marker audio follows the actual active draw interval, not the entire scene duration.
- Gain and playback offset are selected per gesture; do not blindly loop the 31.94-second recording.
- Use short extracted regions or dynamically windowed source sections for individual strokes.
- Velocity may modulate gain and light filtering, but should not create cartoonish pitch changes.
- Pencil is an alternate style profile, not a permanent layer underneath marker scenes.
- Pen-cap audio is punctuation for meaningful tool pickup/put-down moments only.
- Eraser sound remains a separate future source or can initially be built from approved existing NexStudio foley if suitable.
- All audio events must be deterministic from scene timing and seek-safe.
- Preserve the raw CC0 WAV originals alongside any derived runtime files.

See `manifests/audio-source-audit.json` and `manifests/audio-SHA256SUMS.txt` for validation and checksums.
