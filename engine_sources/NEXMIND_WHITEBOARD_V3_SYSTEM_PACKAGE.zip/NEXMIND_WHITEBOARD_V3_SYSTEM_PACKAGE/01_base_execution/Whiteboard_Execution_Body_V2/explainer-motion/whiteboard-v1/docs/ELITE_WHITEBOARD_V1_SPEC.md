# NexStudio Elite Whiteboard V1 — Production Specification

## Product promise

Turn an explanation into a continuously evolving visual thought-space that feels hand-authored, contemporary and cinematic—without looking like a 2010-era stock hand drawing clip-art one object at a time.

## Core principles

1. **One idea per beat.**
2. **Action explains meaning.**
3. **The board is a world, not a slide.**
4. **Draw only what benefits from being drawn.**
5. **Transform existing marks rather than constantly replacing scenes.**
6. **Imperfection is controlled and deterministic.**
7. **Handwriting is an annotation layer, not the primary typography system.**
8. **The pen/hand is optional; the idea is the hero.**
9. **Visual continuity should survive with text hidden.**
10. **Every ratio is recomposed as a new board route.**

## Proposed module tree

```text
explainer-motion/
  whiteboard-v1/
    contracts/
      whiteboard-style-profile.schema.json
      board-world.schema.json
      stroke-spec.schema.json
      draw-plan.schema.json
      annotation-plan.schema.json
      erase-plan.schema.json
      whiteboard-scene.schema.json
    runtime/
      stroke-engine.ts
      freehand-engine.ts
      rough-skin.ts
      path-metrics.ts
      drawsvg-adapter.ts
      pen-tip-tracker.ts
      semantic-draw-order.ts
      pen-travel-planner.ts
      asset-normalizer.ts
      diagram-layout.ts
      connector-router.ts
      annotation-engine.ts
      single-stroke-text.ts
      eraser-mask.ts
      board-world.ts
      board-camera.ts
      whiteboard-mechanism-skin.ts
      whiteboard-data-skin.ts
      whiteboard-media-callouts.ts
      sound-choreographer.ts
    registry/
      whiteboard-style-profiles.json
      whiteboard-scene-families.json
      whiteboard-annotations.json
      whiteboard-sound-map.json
    qa/
      whiteboard-validator.ts
      stroke-sync-check.ts
      draw-order-check.ts
      board-continuity-check.ts
      deterministic-seed-check.ts
    benchmarks/
      golden-slice-01/
```

## Runtime dependency assignment

- **GSAP + DrawSVG:** deterministic line/reveal timing.
- **GSAP MorphSVG:** semantic shape mutation / redrawing without cuts.
- **GSAP MotionPath:** pen/cursor motion and object-follow-path actions.
- **Perfect Freehand:** organic variable-width marker/pen strokes.
- **Rough.js:** deterministic hand-drawn treatment of geometric primitives and selected SVG paths.
- **Rough Notation:** reference/utility for emphasis annotations; implement through the Whiteboard annotation contract so it is not tied to arbitrary DOM text.
- **svg-path-properties:** headless path length/point/tangent metrics; pen-tip tracking.
- **svg2roughjs:** candidate normalization/conversion utility for bringing selected existing SVG assets into the sketch treatment.
- **Dagre:** topology-first directed graph layout when appropriate; NexStudio remains responsible for composition, routing and art direction.
- **SVGO + svgpath:** SVG cleanup, transform normalization and path processing.
- **Phosphor Core:** broad semantic SVG vocabulary; normalize to NexStudio whiteboard stroke roles rather than display raw icons.
- **Hershey Text JS:** short single-stroke note/annotation writing only; primary typography remains NexStudio typography.

## Style profiles

Ship at least three profiles from one mechanism system:

### WB-01 Editorial Whiteboard
- white/off-white board;
- charcoal ink;
- one brand accent;
- low roughness;
- clean labels;
- subtle dry-marker texture;
- premium business/product explainers.

### WB-02 Sketchbook Technical
- warmer paper/board base;
- pencil/ink hybrid;
- light construction lines;
- slightly more roughness;
- good for education, systems, AI/technical flows.

### WB-03 Brand Marker
- white/off-white base;
- brand-led marker accents;
- thick selective strokes;
- high-energy launch/explainer moments;
- still restrained enough for premium production.

Do not create new motion logic per profile; style changes treatment parameters, typography, color, roughness, fill and sound energy.

## Stroke spec

Every generated stroke should support:

```json
{
  "tool": "marker|pen|pencil|highlighter",
  "semanticRole": "outline|connector|emphasis|annotation|construction",
  "width": 4,
  "pressureModel": "velocity|fixed|authored",
  "taperStart": 0.15,
  "taperEnd": 0.22,
  "roughness": 0.35,
  "bowing": 0.2,
  "dryness": 0.08,
  "doublePass": false,
  "seed": 104219,
  "drawDuration": 0.8,
  "soundRole": "marker.short"
}
```

Randomness must always resolve from a deterministic scene/job seed.

## Draw-plan rules

Draw order is generated from semantics, not source-file order.

Priority example:

1. hero silhouette / main structural axis;
2. most meaningful internal component;
3. secondary structure;
4. incoming connector;
5. result/outgoing connector;
6. clean label;
7. short handwritten annotation;
8. emphasis mark;
9. fill settle / accent.

For complex illustrations, create groups and reveal them as coherent passes rather than drawing hundreds of micro-paths serially.

## Pen travel

Between strokes:

- prefer nearest valid next stroke when semantic priority allows;
- lift pen for non-contiguous jumps;
- never visibly drag across unrelated objects;
- hide/ghost cursor for long board travel unless the travel itself communicates continuity;
- camera can lead the travel to the next board zone.

## Board-world contract

Every sequence owns persistent board coordinates independent of the viewport.

Each beat declares:

- active zone;
- inherited objects;
- new objects;
- context objects allowed at edge/background;
- camera target;
- continuation anchor;
- exit direction;
- ratio-specific zone mapping.

This enables a process to literally continue across scenes instead of resetting.

## Scene families

Minimum V1 families:

1. Hero concept construction
2. Process chain
3. Causal chain
4. Timeline
5. Feedback/circular loop
6. Hierarchy/tree
7. Network/relationship map
8. Funnel/pipeline
9. Compare/before-after
10. Checklist/criteria
11. Decision/branching path
12. Data sketch/chart
13. Map/spatial route
14. Product screenshot with drawn callouts
15. Payment/token/value flow
16. AI agent/tool/handoff flow
17. Human/action illustration beat
18. Transformation/state change
19. Evidence/source annotation
20. Closing synthesis / board pullback

## Transition grammar

Preferred whiteboard transitions:

- connector continues into next zone;
- board pan to spatial neighbor;
- zoom into drawn object that becomes the next world;
- object morph/redraw;
- selective erase reveals replacement;
- label becomes diagram element;
- line becomes chart axis / timeline / border;
- hero object moves and preserves identity;
- camera pullback reveals previous beats as one system.

Avoid whole-scene dissolves and arbitrary wipes.

## Characters

Use complete-action vector people as semantic actors. Suitable motion:

- draw/build reveal;
- look/attention emphasis using transform of separable head/face only if source supports it;
- object handoff;
- limited arm/object movement if separable and meaningful;
- group translation tied to a real action;
- camera relation.

No generic idle bobbing, elastic entrances or fake walking loops.

## Data

Data does not merely “draw a chart.” Sequence should show interpretation:

- axis/scale establishes context;
- meaningful data line/bar appears;
- comparison or threshold is annotated;
- camera or emphasis isolates the insight;
- consequence/next mechanism follows.

Existing NexStudio data logic remains source-of-truth; Rough.js is only a treatment.

## Product media

Screenshots should be integrated into the board:

- draw a frame/viewport around the relevant portion;
- crop/zoom to semantic area;
- annotation arrows physically connect to UI features;
- UI can hand off into a diagram/value flow;
- avoid floating screenshot card + label as default.

## Audio

Map audio to actions:

- continuous write strokes use loopable foley fitted to duration;
- underline/highlight receives a faster swipe;
- morph/transform gets a restrained tonal/physical transition;
- cap/tap only at meaningful punctuation;
- eraser rub matches mask velocity;
- no more than the perceptual scene can support under VO.

## QA hard gates

A candidate cannot be Whiteboard Certified if any of these occur:

- raw SVG path order visibly dictates animation;
- pen tip separates perceptibly from active stroke head;
- full board resets repeatedly;
- identical draw rhythm repeats across most beats;
- more than one major visual action competes at once;
- meaningless decorative arrows/connectors;
- excessive handwriting reduces readability;
- complex illustration is drawn micro-path-by-micro-path for several seconds;
- roughness is non-deterministic between render passes;
- visible hand/cursor becomes the hero instead of the concept;
- output looks like a slide deck with a sketch filter;
- any ratio is a crop of another;
- unverified third-party asset appears in commercial-certified output.

## Golden Slice requirement

Before product integration, create one 25–40 second Whiteboard Golden Slice containing:

- a persistent board-world;
- at least one process diagram;
- one character/action illustration;
- one data or comparison insight;
- one erase/redraw or morph transformation;
- one true single-stroke annotation;
- one product/media callout if the story supports it;
- one continuity transition that preserves an object;
- final pullback/synthesis;
- full VO + final foley mix;
- 16:9, 1:1 and 9:16 authored recompositions.

The Golden Slice is the gate. Do not declare Whiteboard V1 ready based on isolated component demos.
