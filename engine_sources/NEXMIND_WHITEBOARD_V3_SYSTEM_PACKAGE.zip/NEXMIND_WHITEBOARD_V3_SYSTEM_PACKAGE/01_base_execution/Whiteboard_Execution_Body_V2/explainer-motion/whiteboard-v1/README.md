# NexStudio Whiteboard V1 Engine

**Version:** 1.0.0  
**Base:** NexStudio Explainer Motion v1.6 Step C — Semantic Performance  
**Architecture:** treatment/runtime layer inside the existing NexStudio Explainer pipeline

Whiteboard V1 is not a separate template renderer. It takes the semantic scene plan already produced by NexStudio and gives it a persistent hand-drawn board world, semantic drawing order, authored camera travel, annotations, erase/redraw behavior and synchronized physical writing sound.

## What is implemented

- Persistent board-world routes for **16:9, 1:1 and 9:16**.
- Three launch profiles: **Editorial Whiteboard, Sketchbook Technical, Brand Marker**.
- Twenty registered semantic Whiteboard scene families.
- Semantic stroke planning with deterministic seeds and timing.
- Pen-travel planning and pressure-aware freehand primitives.
- Rough/sketch geometry and true path writing for short annotations.
- Underline, circle, bracket, strike, highlight and check grammar.
- Mask-based erase/redraw in the browser SVG runtime.
- Persistent-object board transitions and camera keyframes.
- Whiteboard skins for mechanisms, data and product-media callouts.
- CC0 marker, pencil and pen-cap foley with deterministic 48 kHz scheduling.
- Native seek-safe browser fallback with optional GSAP DrawSVG enhancement when present.
- Whiteboard-specific machine QA integrated into NexStudio self-service delivery.
- Three Whiteboard styles exposed through the existing style registry, intake schema and Studio selector.

## Important boundary

This package proves the **engine**. It does not self-certify that every customer film is 9/10 creative work. The engine proof and self-service proof have Technical PASS. Human creative review remains `CREATIVE_REVIEW_PENDING`. The next creative gate is a real Whiteboard Golden Slice using this engine.

## Entry points

- `runtime/whiteboard_compiler.py` — converts an existing Director plan into persistent Whiteboard runtime metadata.
- `runtime/whiteboard-runtime.js` — browser-native SVG runtime.
- `runtime/whiteboard_pil_adapter.py` — current NexStudio final-render treatment adapter.
- `runtime/sound_choreographer.py` — deterministic production foley renderer.
- `qa/whiteboard_qa.py` — Whiteboard hard gates.
- `demos/engine-proof.html` — browser-native persistent-board proof.
- `tests/` — deterministic compiler, browser and 20-family coverage tests.
- `benchmarks/engine-proof/` — actual proof artifacts.

## No external-network requirement

Runtime production does not depend on a CDN or third-party API. GSAP DrawSVG is opportunistically used if the host already provides it; the engine has a deterministic native stroke-dash fallback. The acquired CC0 SVG and audio sources are local.
