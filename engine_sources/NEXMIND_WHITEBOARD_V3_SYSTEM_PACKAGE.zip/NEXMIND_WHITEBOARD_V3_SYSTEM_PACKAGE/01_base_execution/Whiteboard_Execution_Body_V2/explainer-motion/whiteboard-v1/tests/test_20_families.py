#!/usr/bin/env python3
from __future__ import annotations
import sys,json
from pathlib import Path
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE/'runtime'));sys.path.insert(0,str(BASE/'qa'))
import whiteboard_compiler as wb, whiteboard_qa as qa
families=json.loads((BASE/'registry/whiteboard-scene-families.json').read_text())['families']; results=[]
for i,f in enumerate(families):
 scene={'sceneId':'F'+str(i),'sourceText':f['id'],'screenCopy':{'primary':f['id'].upper()},'visualVerb':'process','visualizationFamily':'family.physical-spatial-mechanism','whiteboardFamilyHint':f['id'],'heroRole':'input','supportingRoles':['process','result'],'persistentObject':{'uid':'p'},'semanticPerformanceRuntime':{'sceneDuration':3.0}}
 if f['id']=='closing-synthesis':
  plan={'briefId':f['id'],'inputDigest':'family-test','styleProfile':'style.whiteboard-editorial','durationSeconds':3,'outputRatios':['16:9'],'sceneSpecs':[scene]}
  out=wb.compile_whiteboard_plan(plan,{'ratio':'16:9'}); got=out['sceneSpecs'][0]['whiteboardRuntime']['family']
 else:
  plan={'briefId':f['id'],'inputDigest':'family-test','styleProfile':'style.whiteboard-editorial','durationSeconds':6,'outputRatios':['16:9'],'sceneSpecs':[scene,{'sceneId':'close','sourceText':'close','screenCopy':{'primary':'RESULT'},'visualVerb':'settle','visualizationFamily':'family.hero-emotional','heroRole':'result','supportingRoles':['proof'],'persistentObject':{'uid':'p'},'semanticPerformanceRuntime':{'sceneDuration':3.0}}]}
  out=wb.compile_whiteboard_plan(plan,{'ratio':'16:9'}); got=out['sceneSpecs'][0]['whiteboardRuntime']['family']
 results.append({'requested':f['id'],'compiled':got,'pass':got==f['id']})
failed=[r for r in results if not r['pass']];print(json.dumps({'status':'PASS' if not failed else 'FAIL','count':len(results),'failed':failed},indent=2));raise SystemExit(1 if failed else 0)
