#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'runtime')); sys.path.insert(0,str(HERE/'qa'))
import whiteboard_compiler as wb
import whiteboard_qa as qa

def fixture(style='style.whiteboard-editorial'):
 scenes=[]
 for i,(verb,mech,fam) in enumerate([('receive','U06','family.human-action'),('split','U10','family.spatial-system'),('validate','A07','family.comparison-decision'),('settle','U01','family.hero-emotional')]):
  scenes.append({'sceneId':f'T.S{i+1:02d}','sourceText':f'Beat {i+1}','screenCopy':{'primary':f'BEAT {i+1}'},'visualVerb':verb,'mechanismId':mech,'visualizationFamily':fam,'heroRole':'input','supportingRoles':['processor','result'],'supportingObjectBudget':3,'persistentObject':{'uid':'work-record','label':'work'},'transitionContinuity':{'type':'meaning-continuity'},'semanticPerformanceRuntime':{'sceneDuration':3.0}})
 return {'briefId':'T','inputDigest':'fixture','styleProfile':style,'durationSeconds':12,'outputRatios':['16:9'],'sceneSpecs':scenes}

def main():
 p=wb.compile_whiteboard_plan(fixture(),{'ratio':'16:9'}); d1=wb.runtime_digest(p); p2=wb.compile_whiteboard_plan(fixture(),{'ratio':'16:9'}); d2=wb.runtime_digest(p2)
 assert d1==d2, (d1,d2)
 assert p['whiteboardBoardWorld']['routes']['16:9'] != p['whiteboardBoardWorld']['routes']['9:16']
 assert p['sceneSpecs'][-1]['whiteboardRuntime']['family']=='closing-synthesis'
 r=qa.evaluate(p,HERE/'assets/audio/production');assert r['status']=='PASS',r
 print(json.dumps({'status':'PASS','digest':d1,'qaFingerprint':r['fingerprint'],'sceneCount':len(p['sceneSpecs'])},indent=2))
if __name__=='__main__':main()
