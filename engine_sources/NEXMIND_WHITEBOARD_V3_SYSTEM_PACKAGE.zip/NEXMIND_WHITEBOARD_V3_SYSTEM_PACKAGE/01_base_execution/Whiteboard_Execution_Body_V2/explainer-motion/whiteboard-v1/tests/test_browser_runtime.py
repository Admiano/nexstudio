#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import hashlib,json,re,shutil,sys
try:
 from playwright.sync_api import sync_playwright
except Exception as e:
 print(json.dumps({'status':'BLOCKED_REQUIRED_BROWSER_EVIDENCE','reason':f'playwright unavailable: {e}'}));raise SystemExit(2)
BASE=Path(__file__).resolve().parents[1]; demo=BASE/'demos/engine-proof.html';html=demo.read_text()
html=re.sub(r'<script src="([^"]+)"></script>',lambda m:'<script>'+((demo.parent/m.group(1)).resolve()).read_text()+'</script>',html)
chrome=shutil.which('chromium') or shutil.which('google-chrome') or shutil.which('chromium-browser')
if not chrome:
 print(json.dumps({'status':'BLOCKED_REQUIRED_BROWSER_EVIDENCE','reason':'Chromium not installed'}));raise SystemExit(2)
report={'errors':[]}
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path=chrome,args=['--no-sandbox']);p=b.new_page(viewport={'width':1400,'height':900})
 p.on('pageerror',lambda e:report['errors'].append(str(e)));p.on('console',lambda m:report['errors'].append('console:'+m.text) if m.type=='error' else None);p.set_content(html,wait_until='load')
 report['capabilities']=p.evaluate('NexWhiteboard.DrawAdapter.capabilities()')
 p.evaluate('render(12.4)');a=p.locator('#board').evaluate('(e)=>e.outerHTML');p.evaluate('render(3.0)');p.evaluate('render(12.4)');c=p.locator('#board').evaluate('(e)=>e.outerHTML')
 report['seekDeterministic']=hashlib.sha256(a.encode()).hexdigest()==hashlib.sha256(c.encode()).hexdigest()
 p.evaluate('render(15.8)');snap=p.evaluate('window.__wbProof');report['snapshot']={k:snap[k] for k in ('version','time','itemCount','annotationCount','textStrokeCount','eraseCount','cameraKeyframes')};report['audioEventCount']=len(snap['audioEvents'])
 b.close()
report['status']='PASS' if not report['errors'] and report['seekDeterministic'] and report['snapshot']['eraseCount']>0 and report['snapshot']['cameraKeyframes']>=3 else 'FAIL'
print(json.dumps(report,indent=2));raise SystemExit(0 if report['status']=='PASS' else 1)
