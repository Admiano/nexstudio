#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, wave
from pathlib import Path
from typing import Any

ALLOWED_FAMILIES={
'hero-concept','process-chain','causal-chain','payment-value-flow','timeline','feedback-loop','network','hierarchy','decision-branches','funnel-pipeline','compare-before-after','checklist','data-sketch','map-route','product-media-callout','human-action','state-transformation','evidence-annotation','ai-agent-tool-handoff','closing-synthesis'
}
ALLOWED_TRANSITIONS={'board-establish','object-preserving-pan','erase-redraw','connector-continuation','board-pan'}
RATIOS=('16:9','1:1','9:16')

def stable(obj:Any)->str:
 return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

def evaluate(plan:dict,audio_root:Path|None=None)->dict:
 failures=[];warnings=[];scenes=plan.get('sceneSpecs') or [];world=plan.get('whiteboardBoardWorld') or {}
 def fail(code,detail=None):failures.append({'code':code,'detail':detail})
 if plan.get('executionMode')!='WHITEBOARD_SEMANTIC_GRAPH':fail('EXECUTION_AUTHORITY_INVALID',plan.get('executionMode'))
 if plan.get('whiteboardRuntimeVersion')!='2.0.0':fail('WB_VERSION_MISSING_OR_UNKNOWN',plan.get('whiteboardRuntimeVersion'))
 if not world.get('persistent'):fail('BOARD_NOT_PERSISTENT')
 routes=world.get('routes') or {}
 for ratio in RATIOS:
  if ratio not in routes or len(routes.get(ratio) or [])!=len(scenes):fail('RATIO_ROUTE_INCOMPLETE',ratio)
 for scene in scenes:
  if scene.get('executionMode')!='WHITEBOARD_SEMANTIC_GRAPH':fail('SCENE_EXECUTION_AUTHORITY_INVALID',scene.get('sceneId'))
  wb=scene.get('whiteboardRuntime') or {}
  if wb.get('executionMode')!='WHITEBOARD_SEMANTIC_GRAPH':fail('SCENE_RUNTIME_AUTHORITY_INVALID',scene.get('sceneId'))
  hero=str(scene.get('heroRole') or '').strip();objs=wb.get('objects') or []
  if not hero:fail('HERO_IDENTITY_MISSING',scene.get('sceneId'))
  bound={str(o.get('semanticEntityId') or '').strip().lower() for o in objs}
  required=[hero,*[str(x).strip() for x in scene.get('supportingRoles') or [] if str(x).strip()]]
  missing=[x for x in required if x.lower() not in bound]
  if missing:fail('SCENE_SEMANTIC_BINDING_INCOMPLETE',{'scene':scene.get('sceneId'),'missing':missing})
  actions=scene.get('p8MotionActions') or [];runtime_actions=wb.get('p8MotionActions') or []
  if stable(actions)!=stable(runtime_actions):fail('P8_ACTION_SEQUENCE_NOT_PRESERVED',scene.get('sceneId'))
  if not actions:fail('P8_ACTION_SEQUENCE_EMPTY',scene.get('sceneId'))
  camera=scene.get('cameraAtom') or {};runtime_camera=((wb.get('camera') or {}).get('cameraAtom') or {})
  if not camera or stable(camera)!=stable(runtime_camera):fail('P8_CAMERA_ATOM_NOT_PRESERVED',scene.get('sceneId'))
  if stable(scene.get('brandExecution') or {})!=stable(wb.get('brandExecution') or {}):fail('BRAND_EXECUTION_NOT_PRESERVED',scene.get('sceneId'))
  dp=wb.get('drawPlan') or []
  if not dp:fail('DRAW_SCHEDULE_EMPTY',scene.get('sceneId'))
  prev=-1.0
  for item in dp:
   st=float(item.get('start',0));en=float(item.get('end',0))
   if en<=st:fail('DRAW_TIMING_INVALID',{'scene':scene.get('sceneId'),'id':item.get('id')})
   if st<prev-.02:fail('UNDECLARED_DRAW_OVERLAP',{'scene':scene.get('sceneId'),'id':item.get('id')})
   prev=max(prev,en)
 # Audio is a technical dependency, not a creative score.
 audio_checks=[]
 if audio_root:
  for name in ('whiteboard-marker-bed-48k.wav','pencil-bed-48k.wav','pen-cap-48k.wav'):
   q=Path(audio_root)/name; rec={'file':name,'exists':q.exists()}
   if not q.exists():fail('AUDIO_SOURCE_MISSING',name)
   else:
    try:
     with wave.open(str(q),'rb') as w:
      rec.update({'rate':w.getframerate(),'channels':w.getnchannels(),'sampleWidth':w.getsampwidth(),'frames':w.getnframes()})
      if w.getframerate()!=48000 or w.getsampwidth()!=2:fail('AUDIO_FORMAT_INVALID',rec)
    except Exception as e:fail('AUDIO_READ_FAIL',{'file':name,'error':str(e)})
   audio_checks.append(rec)
 metrics={'sceneCount':len(scenes),'executionMode':plan.get('executionMode'),'audio':audio_checks}
 return {'status':'PASS' if not failures else 'FAIL','hardFailures':failures,'warnings':warnings,'metrics':metrics,'commercialScore':None,'authority':'StudioFamilyExecutionFidelityV1','fingerprint':stable({'f':failures,'w':warnings,'m':metrics})}

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('plan');ap.add_argument('--audio-root');ap.add_argument('--out');args=ap.parse_args()
 plan=json.loads(Path(args.plan).read_text());r=evaluate(plan,Path(args.audio_root) if args.audio_root else None)
 txt=json.dumps(r,indent=2)+'\n';Path(args.out).write_text(txt) if args.out else print(txt,end='')
 raise SystemExit(0 if r['status']=='PASS' else 1)
