#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, math, re
from pathlib import Path
from typing import Any

VERSION='1.0.0'
EXECUTION_MODE='WHITEBOARD_SEMANTIC_GRAPH'
ROLE_PRIORITY={'hero':0,'object':2,'connector':4,'label':6,'context':8}

def _stable_seed(*parts:Any)->int:
    raw='|'.join(str(x) for x in parts).encode('utf-8')
    return int(hashlib.sha256(raw).hexdigest()[:8],16)

def _slug(s:str)->str:
    return re.sub(r'[^a-z0-9]+','-',str(s).lower()).strip('-') or 'item'

def is_whiteboard_style(style_id:str|None)->bool:
    # Retained only as a backwards-compatible renderer helper. Style names are
    # never execution authority.
    return False

def _semantic_seed(scene:dict)->int:
    return _stable_seed(scene.get('sceneId'), scene.get('heroRole'), scene.get('supportingRoles'), scene.get('semanticRelationships'))

def _routes(total:int)->dict:
    routes={}
    # 16:9: lateral editorial route with a restrained second row.
    pts=[]
    for i in range(total):
        row=i//4; col=i%4; x=col*1180 + (100 if row%2 else 0); y=row*760 + (80 if col%2 else 0)
        pts.append({'x':x,'y':y,'w':1040,'h':620,'routeIndex':i})
    routes['16:9']=pts
    # 1:1: compact serpentine 3-column board.
    pts=[]
    for i in range(total):
        row=i//3; col=i%3; c=col if row%2==0 else 2-col
        pts.append({'x':c*860,'y':row*820,'w':720,'h':700,'routeIndex':i})
    routes['1:1']=pts
    # 9:16: primarily vertical travel; small lateral offsets keep silhouettes from repeating.
    pts=[]
    for i in range(total):
        pts.append({'x':(i%3-1)*260,'y':i*1040,'w':520,'h':900,'routeIndex':i})
    routes['9:16']=pts
    return routes

def _screen_copy(scene:dict)->tuple[str,str]:
    sc=scene.get('screenCopy') or {}
    primary=str(sc.get('primary') or scene.get('sourceText') or '').strip()
    secondary=str(sc.get('secondary') or '').strip()
    return primary,secondary

def _semantic_objects(scene:dict, family:str, seed:int)->list[dict]:
    primary,secondary=_screen_copy(scene)
    pid=((scene.get('persistentObject') or {}).get('semanticEntityId') or (scene.get('persistentObject') or {}).get('uid') or 'narrative-object')
    mech=str(scene.get('mechanismId') or '')
    objects=[
        {'id':f'{_slug(pid)}.hero','role':'hero','kind':'hero','semanticEntityId':pid,'label':(scene.get('persistentObject') or {}).get('label') or pid},
    ]
    # P8_CANONICAL is transport metadata, not a drawable visual object. Only real
    # mechanism identities become Whiteboard semantic objects.
    if mech and mech not in {'P8_CANONICAL','mechanism'}:
        objects.append({'id':f'{_slug(mech)}.mechanism','role':'mechanism','kind':'mechanism','semanticEntityId':mech,'label':mech})
    seen={str(pid).strip().lower()}
    for i,label in enumerate(scene.get('supportingRoles') or []):
        label=str(label).strip()
        key=label.lower()
        if not label or key in seen: continue
        seen.add(key)
        objects.append({'id':f'support.{i+1}.{_slug(label)}','role':'object','kind':'semantic-support','semanticEntityId':label,'label':label})
    if family in {'human-action','ai-agent-tool-handoff'} and not any(o.get('role')=='actor' for o in objects):
        objects.append({'id':'actor.primary','role':'actor','kind':'actor','semanticEntityId':'actor','label':'actor'})
    if family in {'data-sketch','compare-before-after','evidence-annotation'} and secondary:
        objects.append({'id':'evidence.primary','role':'object','kind':'evidence','semanticEntityId':secondary,'label':secondary})
    if family=='product-media-callout':
        objects.append({'id':'product.media','role':'object','kind':'media','semanticEntityId':'product media','label':'product media'})
    if primary:
        objects.append({'id':'label.primary','role':'label','kind':'type','label':primary[:120]})
    return objects

def _stroke(kind:str, role:str, order:int, seed:int, duration:float, tool:str='marker', width:float=4.0, sound='marker.short', group='main')->dict:
    return {
        'id':f'stroke.{order:02d}.{_slug(role)}','kind':kind,'semanticRole':role,'priority':ROLE_PRIORITY.get(role,5),
        'tool':tool,'width':width,'pressureModel':'velocity' if tool in {'marker','pen','pencil'} else 'fixed',
        'taperStart':0.12 if tool!='highlighter' else 0,'taperEnd':0.18 if tool!='highlighter' else 0,
        'roughness':0.24 if tool=='marker' else 0.42 if tool=='pencil' else 0.18,'bowing':0.14,'dryness':0.06 if tool=='marker' else 0.02,
        'doublePass':False,'seed':(seed+order*7919)&0xffffffff,'drawDuration':round(duration,3),'soundRole':sound,'groupId':group
    }

def _draw_plan(scene:dict, seed:int, scene_duration:float)->list[dict]:
    """Schedule one drawable pass for every P8-authored semantic entity/relationship.

    No named scene family, positional recipe, or house composition participates.
    Geometry is produced by the semantic renderer from the exact entity graph.
    """
    roles=['hero']+['object']*len(scene.get('supportingRoles') or [])
    rels=scene.get('semanticRelationships') or []
    roles += ['connector']*len([r for r in rels if isinstance(r,dict)])
    actions=scene.get('p8MotionActions') or []
    roles += ['connector']*len([a for a in actions if isinstance(a,dict)])
    if not roles: roles=['hero']
    budget=max(.8,scene_duration*.72); slot=budget/max(1,len(roles)); cursor=0.0; out=[]
    for i,role in enumerate(roles,1):
        dur=max(.16,min(.85,slot*.82))
        item=_stroke('semantic-pass',role,i,seed,dur,'marker',4,'marker.short','semantic')
        item['start']=round(cursor,3); item['end']=round(cursor+dur,3); cursor=item['end']+min(.10,dur*.12); out.append(item)
    return out

def _transition(prev:dict|None, scene:dict, idx:int)->dict:
    if prev is None: return {'type':'board-establish','enabled':False,'duration':0.0}
    prev_pid=(prev.get('persistentObject') or {}).get('semanticEntityId') or (prev.get('persistentObject') or {}).get('uid')
    cur_pid=(scene.get('persistentObject') or {}).get('semanticEntityId') or (scene.get('persistentObject') or {}).get('uid')
    declared=((scene.get('transitionContinuity') or {}).get('type') or '')
    if prev_pid and prev_pid==cur_pid:
        typ='object-preserving-pan'
    elif declared in {'object-continuity','meaning-continuity','motion-continuity'}: typ='connector-continuation'
    else: typ='board-pan'
    return {'type':typ,'enabled':True,'duration':.58 if typ!='erase-redraw' else .72,'preserveEntityId':cur_pid if prev_pid==cur_pid else None,'declaredSource':declared or None}

def compile_whiteboard_plan(plan:dict, intake:dict|None=None)->dict:
    if str(plan.get('executionMode') or '') != EXECUTION_MODE:
        raise ValueError('WHITEBOARD_EXECUTION_AUTHORITY_REQUIRED')
    p=json.loads(json.dumps(plan)); scenes=p.get('sceneSpecs') or []
    if not scenes: raise ValueError('WHITEBOARD_SCENES_REQUIRED')
    routes=_routes(len(scenes)); base_seed=_stable_seed(p.get('briefId'),p.get('inputDigest'),EXECUTION_MODE)
    for i,scene in enumerate(scenes):
        if str(scene.get('executionMode') or '') != EXECUTION_MODE: raise ValueError('WHITEBOARD_SCENE_EXECUTION_AUTHORITY_REQUIRED')
        seed=_semantic_seed(scene); dur=float((scene.get('semanticPerformanceRuntime') or {}).get('sceneDuration') or scene.get('timingOverrideSeconds') or p.get('durationSeconds',30)/max(1,len(scenes)))
        ratio_routes={r:routes[r][i] for r in routes}
        scene['whiteboardRuntime']={
            'version':'2.0.0','executionMode':EXECUTION_MODE,'seed':seed,'sceneIndex':i,'sceneDuration':dur,
            'boardZone':ratio_routes.get((intake or {}).get('ratio') or (p.get('outputRatios') or ['16:9'])[0],ratio_routes['16:9']),
            'ratioZones':ratio_routes,'objects':_semantic_objects(scene,'semantic-graph',seed),
            'drawPlan':_draw_plan(scene,seed,dur),'transitionIn':_transition(scenes[i-1] if i else None,scene,i),
            'camera':{'authority':'P8_CAMERA_ATOM','cameraAtom':json.loads(json.dumps(scene.get('cameraAtom') or {})),'semanticTarget':json.loads(json.dumps(scene.get('cameraTarget')))},
            'artExecutionDirectives':json.loads(json.dumps(scene.get('artExecutionDirectives') or {})),
            'semanticRelationships':json.loads(json.dumps(scene.get('semanticRelationships') or [])),
            'p8MotionActions':json.loads(json.dumps(scene.get('p8MotionActions') or [])),
            'brandExecution':json.loads(json.dumps(scene.get('brandExecution') or p.get('brandExecution') or {})),
            'handPolicy':{'visibleDefault':False,'showOnlyFor':['annotation','emphasis'],'maxVisibleShare':0.18},
            'textPolicy':{'primaryTypography':'P8_AUTHORED_COPY_ONLY','singleStrokeAnnotationOnly':True},
        }
        scene['whiteboardCertifiedCandidate']=True
    p['whiteboardRuntimeVersion']='2.0.0'; p['whiteboardMode']='semantic-execution'
    p['whiteboardBoardWorld']={'persistent':True,'routes':routes,'seed':base_seed,'ratios':['16:9','1:1','9:16'],'resetPolicy':'never-between-adjacent-beats'}
    return p

def runtime_digest(plan:dict)->str:
    wb={
        'version':plan.get('whiteboardRuntimeVersion'),
        'world':plan.get('whiteboardBoardWorld'),
        'scenes':[s.get('whiteboardRuntime') for s in plan.get('sceneSpecs',[])],
    }
    return hashlib.sha256(json.dumps(wb,sort_keys=True,separators=(',',':')).encode()).hexdigest()

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('plan');ap.add_argument('out');ap.add_argument('--ratio',default='16:9');a=ap.parse_args()
    src=json.loads(Path(a.plan).read_text()); out=compile_whiteboard_plan(src,{'ratio':a.ratio}); out['whiteboardRuntimeDigest']=runtime_digest(out)
    Path(a.out).write_text(json.dumps(out,indent=2)+'\n')
