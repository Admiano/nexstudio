(function(g){
  const N=g.NexWhiteboard=g.NexWhiteboard||{},NS='http://www.w3.org/2000/svg';
  const clamp=x=>Math.max(0,Math.min(1,x));
  const ease=p=>{p=clamp(p);return p*p*(3-2*p)};
  class Engine{
    constructor(svg,opts={}){
      if(!svg)throw new Error('Whiteboard Engine requires an SVG root');
      this.svg=svg;this.opts=opts;this.seed=opts.seed||1;this.ratio=opts.ratio||'16:9';this.duration=opts.duration||6;
      this.items=[];this.annotations=[];this.textStrokes=[];this.erasures=[];this.cameraTrack=[];
      this.group=document.createElementNS(NS,'g');this.group.dataset.whiteboardWorld='true';svg.appendChild(this.group);
      this.tip=N.PenTip.create(svg,opts.ink||'#171918');this.view={x:0,y:0,zoom:1};this._raf=0;this._start=0;this._playing=false;this._eraseCount=0;
    }
    stroke(d,spec={}){
      let st=N.StrokeEngine.create(this.group,Object.assign({d,color:this.opts.ink||'#171918',width:4},spec));
      this.items.push({type:'stroke',obj:st,start:spec.start||0,end:spec.end??((spec.start||0)+(spec.drawDuration||.7)),role:spec.semanticRole||'object',showTip:spec.showTip??['annotation','emphasis'].includes(spec.semanticRole),soundRole:spec.soundRole||'marker.short'});return st;
    }
    freehand(points,spec={}){
      let poly=N.Freehand.outline(points,{size:spec.width||5,thinning:spec.thinning??.45,streamline:spec.streamline??.5});
      let d=N.Freehand.toPath(poly),p=document.createElementNS(NS,'path');p.setAttribute('d',d);p.setAttribute('fill',spec.color||this.opts.ink||'#171918');p.setAttribute('stroke','none');this.group.appendChild(p);
      this.items.push({type:'opacity',obj:{el:p},start:spec.start||0,end:spec.end??((spec.start||0)+.45),role:spec.semanticRole||'annotation',soundRole:spec.soundRole||'marker.short'});return p;
    }
    roughLine(a,b,spec={}){return this.stroke(N.RoughSkin.line(a,b,spec.seed||N.hashSeed(this.seed+':'+this.items.length),spec.roughness??.3,spec.width||4),spec)}
    roughRect(x,y,w,h,spec={}){return this.stroke(N.RoughSkin.rect(x,y,w,h,spec.seed||N.hashSeed(this.seed+':'+this.items.length),spec.roughness??.3,spec.width||4),spec)}
    roughEllipse(cx,cy,rx,ry,spec={}){return this.stroke(N.RoughSkin.ellipse(cx,cy,rx,ry,spec.seed||N.hashSeed(this.seed+':'+this.items.length),spec.roughness??.3,spec.width||4),spec)}
    annotation(type,b,spec={}){
      let a=N.Annotation.create(this.group,type,b,{color:spec.color||this.opts.accent||'#E05A47',width:spec.width||5},spec.seed||N.hashSeed(this.seed+':ann:'+this.annotations.length));
      this.annotations.push({type:'annotation',obj:a,start:spec.start||0,end:spec.end??((spec.start||0)+.45),role:'emphasis',soundRole:spec.soundRole||'marker.swipe'});return a;
    }
    singleStrokeText(text,x,y,size,spec={}){
      let arr=N.SingleStrokeText.render(this.group,text,x,y,size,{color:spec.color||this.opts.ink||'#171918',width:spec.width||2.5},spec.seed||N.hashSeed(this.seed+':txt:'+this.textStrokes.length));
      let start=spec.start||0,total=spec.duration||Math.max(.35,text.length*.055),each=total/Math.max(1,arr.length);
      arr.forEach((obj,i)=>this.textStrokes.push({type:'stroke',obj,start:start+i*each,end:start+(i+1)*each,role:'annotation',showTip:false,soundRole:spec.soundRole||'marker.short'}));return arr;
    }
    eraseElement(el,d,spec={}){
      if(!el)throw new Error('eraseElement requires an SVG element');
      let id='wb-erase-'+(++this._eraseCount),mask=N.Eraser.create(this.svg,id),er=N.Eraser.stroke(mask,d,spec.width||42);el.setAttribute('mask','url(#'+id+')');
      let item={type:'erase',obj:er,start:spec.start||0,end:spec.end??((spec.start||0)+.65),role:'emphasis',soundRole:spec.soundRole||'eraser.rub'};this.erasures.push(item);return er;
    }
    setCamera(view){this.view=view;N.BoardCamera.apply(this.group,view,{w:Number(this.svg.getAttribute('width'))||1280,h:Number(this.svg.getAttribute('height'))||720,ratio:this.ratio});return this}
    setCameraTrack(points){this.cameraTrack=(points||[]).slice().sort((a,b)=>a.t-b.t);return this}
    cameraAt(t){
      if(!this.cameraTrack.length)return this.view;
      if(t<=this.cameraTrack[0].t)return this.cameraTrack[0].view;
      let last=this.cameraTrack[this.cameraTrack.length-1];if(t>=last.t)return last.view;
      for(let i=1;i<this.cameraTrack.length;i++){let b=this.cameraTrack[i],a=this.cameraTrack[i-1];if(t<=b.t){let p=ease((t-a.t)/Math.max(.0001,b.t-a.t));return{x:a.view.x+(b.view.x-a.view.x)*p,y:a.view.y+(b.view.y-a.view.y)*p,zoom:a.view.zoom+(b.view.zoom-a.view.zoom)*p}}}
      return last.view;
    }
    renderAt(t){
      t=Math.max(0,Math.min(this.duration,t));let active=null;
      this.setCamera(this.cameraAt(t));
      for(let item of [...this.items,...this.annotations,...this.textStrokes,...this.erasures]){
        let p=ease(clamp((t-item.start)/Math.max(.0001,item.end-item.start)));
        if(item.type==='stroke'){let pos=N.DrawAdapter.render(item.obj,p);if(t>=item.start&&t<=item.end&&item.showTip)active=pos}
        else if(item.type==='opacity')item.obj.el.style.opacity=String(p);
        else if(item.type==='annotation')N.Annotation.render(item.obj,p);
        else if(item.type==='erase')N.Eraser.render(item.obj,p);
      }
      if(active)N.PenTip.place(this.tip,active,true);else N.PenTip.place(this.tip,{x:0,y:0,angle:0},false);
      this.svg.dataset.time=t.toFixed(3);return{time:t,duration:this.duration,activeTip:active,view:this.cameraAt(t)};
    }
    play(from=0){cancelAnimationFrame(this._raf);this._playing=true;this._start=performance.now()-from*1000;let tick=now=>{let t=(now-this._start)/1000;if(t>=this.duration){this.renderAt(this.duration);this._playing=false;return}this.renderAt(t);this._raf=requestAnimationFrame(tick)};this._raf=requestAnimationFrame(tick);return this}
    pause(){this._playing=false;cancelAnimationFrame(this._raf);return Number(this.svg.dataset.time||0)}
    audioEvents(){return N.Sound.events([...this.items,...this.annotations,...this.textStrokes,...this.erasures].map(x=>({start:x.start,end:x.end,soundRole:x.soundRole})),this.seed)}
    snapshot(){return{version:N.version,time:Number(this.svg.dataset.time||0),ratio:this.ratio,duration:this.duration,itemCount:this.items.length,annotationCount:this.annotations.length,textStrokeCount:this.textStrokes.length,eraseCount:this.erasures.length,cameraKeyframes:this.cameraTrack.length,audioEvents:this.audioEvents()}}
    destroy(){cancelAnimationFrame(this._raf);this.group.remove();this.tip.remove()}
  }
  N.Engine=Engine;N.version='1.0.0';N.create=(svg,opts)=>new Engine(svg,opts);
})(window);
