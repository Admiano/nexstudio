#!/usr/bin/env python3
from __future__ import annotations
from PIL import Image,ImageDraw,ImageFont,ImageOps
from pathlib import Path
import json, math, random, re, os

ROOT=Path(__file__).resolve().parents[3]
RATIO_SIZES={'16:9':(1280,720),'1:1':(720,720),'9:16':(540,960)}
def _first_font(*candidates):
 for raw in candidates:
  if not raw: continue
  p=Path(raw)
  if p.exists(): return str(p)
 return None

_WINDIR=Path(os.environ.get('WINDIR', r'C:\\Windows'))
FONT=_first_font(
 _WINDIR/'Fonts'/'segoeui.ttf',
 _WINDIR/'Fonts'/'arial.ttf',
 _WINDIR/'Fonts'/'calibri.ttf',
 '/usr/share/fonts/truetype/arimo/Arimo-Regular.ttf',
 '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
 '/System/Library/Fonts/Supplemental/Arial.ttf',
)
FONT_B=_first_font(
 _WINDIR/'Fonts'/'segoeuib.ttf',
 _WINDIR/'Fonts'/'arialbd.ttf',
 _WINDIR/'Fonts'/'calibrib.ttf',
 '/usr/share/fonts/truetype/arimo/Arimo-Bold.ttf',
 '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
 '/System/Library/Fonts/Supplemental/Arial Bold.ttf',
) or FONT
BRANDS={}
def _hex(h,alpha=255):
 h=h.lstrip('#'); return tuple(int(h[i:i+2],16) for i in (0,2,4))+(alpha,)
def _mix(a,b,t): return tuple(int(a[i]*(1-t)+b[i]*t) for i in range(4))
def _clamp(x,a=0,b=1): return max(a,min(b,float(x)))
def _ease(p): p=_clamp(p); return p*p*(3-2*p)
def _font(sz,b=False):
 size=max(8,int(sz))
 path=FONT_B if b else FONT
 if path:
  try: return ImageFont.truetype(path,size)
  except OSError: pass
 return ImageFont.load_default()
def _wrap(draw,text,fnt,width,max_lines=3):
 words=re.sub(r'\s+',' ',str(text)).strip().split(); lines=[]; cur=''
 for w in words:
  test=(cur+' '+w).strip()
  if not cur or draw.textbbox((0,0),test,font=fnt)[2]<=width: cur=test
  else: lines.append(cur);cur=w
 if cur:lines.append(cur)
 return lines[:max_lines]

def _find_hexes(value,out):
 if isinstance(value,dict):
  for k,v in value.items():
   key=str(k).lower(); text=str(v or '').strip()
   if re.fullmatch(r'#[0-9A-Fa-f]{6}',text) and key in {'background','bg','ink','text','surface','primary','accent','secondary','muted'}: out.setdefault(key,text)
   _find_hexes(v,out)
 elif isinstance(value,list):
  for v in value:_find_hexes(v,out)

def _pal(plan):
 brand=plan.get('brandExecution') if isinstance(plan.get('brandExecution'),dict) else {}
 found={};_find_hexes(brand.get('brandAuthority'),found);_find_hexes(brand.get('productionBrandContext'),found)
 # Neutral paper/ink is the only fallback. It is deliberately not a fictional Brand.
 vals={'bg':found.get('background') or found.get('bg') or '#FFFFFF','ink':found.get('ink') or found.get('text') or '#111111','accent':found.get('accent') or found.get('primary') or '#333333','secondary':found.get('secondary') or found.get('muted') or '#666666','rough':.28,'stroke':4,'texture':.035}
 return {**vals,'bgc':_hex(vals['bg']),'inkc':_hex(vals['ink']),'accentc':_hex(vals['accent']),'secondaryc':_hex(vals['secondary'])}

def _zone(scene,ratio):
 wb=scene.get('whiteboardRuntime') or {}; return (wb.get('ratioZones') or {}).get(ratio) or wb.get('boardZone') or {'x':0,'y':0,'w':1040,'h':620}
def _camera(scene,ratio):
 z=_zone(scene,ratio); return z['x']+z['w']/2,z['y']+z['h']/2

def _map_point(pt,cam,ratio,zoom=1.0):
 w,h=RATIO_SIZES[ratio]; scale=(min(w,h)/(650 if ratio!='9:16' else 760))*zoom
 return w/2+(pt[0]-cam[0])*scale,h/2+(pt[1]-cam[1])*scale

def _rough_points(points,seed,amount=1.6):
 rnd=random.Random(int(seed)&0xffffffff); out=[]
 for i,(x,y) in enumerate(points):
  edge=i in (0,len(points)-1)
  f=.35 if edge else 1.0
  out.append((x+rnd.uniform(-amount,amount)*f,y+rnd.uniform(-amount,amount)*f))
 return out

def _poly_len(points): return sum(math.hypot(points[i+1][0]-points[i][0],points[i+1][1]-points[i][1]) for i in range(len(points)-1))
def _partial(points,p):
 p=_clamp(p)
 if p<=0 or len(points)<2:return []
 if p>=1:return points
 target=_poly_len(points)*p; acc=0; out=[points[0]]
 for a,b in zip(points,points[1:]):
  d=math.hypot(b[0]-a[0],b[1]-a[1])
  if acc+d>=target:
   q=(target-acc)/max(.001,d);out.append((a[0]+(b[0]-a[0])*q,a[1]+(b[1]-a[1])*q));break
  out.append(b);acc+=d
 return out

def _line(layer,pts,color,width,seed,rough=.3,p=1.0,double=False):
 d=ImageDraw.Draw(layer,'RGBA'); pts=_partial(pts,p)
 if len(pts)<2:return
 amt=max(.25,width*rough*.46); rpts=_rough_points(pts,seed,amt)
 d.line([(int(x),int(y)) for x,y in rpts],fill=color,width=max(1,int(width)),joint='curve')
 # rounded caps
 rr=max(1,width/2)
 for x,y in (rpts[0],rpts[-1]): d.ellipse((x-rr,y-rr,x+rr,y+rr),fill=color)
 if double and p>.35:
  r2=_rough_points(pts,seed+17,amt*.65); d.line([(int(x),int(y)) for x,y in r2],fill=(color[0],color[1],color[2],max(40,int(color[3]*.32))),width=max(1,int(width*.55)))

def _ellipse_points(cx,cy,rx,ry,n=44):
 return [(cx+math.cos(i/(n-1)*math.tau)*rx,cy+math.sin(i/(n-1)*math.tau)*ry) for i in range(n)]
def _rect_points(x0,y0,x1,y1): return [(x0,y0),(x1,y0),(x1,y1),(x0,y1),(x0,y0)]
def _arrow(layer,a,b,color,width,seed,p=1.0,rough=.3):
 _line(layer,[a,b],color,width,seed,rough,p)
 if p>.85:
  ang=math.atan2(b[1]-a[1],b[0]-a[0]); L=12+width*1.2
  q=_clamp((p-.85)/.15)
  for s in (-1,1):
   end=(b[0]-math.cos(ang+s*.52)*L,b[1]-math.sin(ang+s*.52)*L)
   _line(layer,[b,end],color,width,seed+91+s,rough,q)

def _context_label(layer,xy,text,pal,size=14,alpha=120):
 d=ImageDraw.Draw(layer,'RGBA');d.text(xy,text,font=_font(size,True),fill=(pal['inkc'][0],pal['inkc'][1],pal['inkc'][2],alpha))

def _semantic_prim(pos,size,concept,show_label=True):
 # The low-level body deliberately does not guess what a noun "looks like".
 # Complex/literal illustration is supplied by the authored-art plate.
 return ('semantic',pos,size,str(concept),'object',bool(show_label))

def _primitive_set(scene,ratio):
 wb=scene.get('whiteboardRuntime') or {}; z=_zone(scene,ratio); x,y,w,h=z['x'],z['y'],z['w'],z['h']
 hero=str(scene.get('heroRole') or '').strip(); supports=[str(v).strip() for v in (scene.get('supportingRoles') or []) if str(v).strip()]
 if not hero:return []
 P=lambda u,v:(x+u*w,y+v*h)
 # Board geography is derived from content cardinality and stable semantic order,
 # not a named layout/family recipe.
 n=len(supports); portrait=ratio=='9:16'
 hero_pos=P(.50,.42 if portrait else .50); hero_size=(w*.25,h*.15) if portrait else (w*.20,h*.22)
 prims=[_semantic_prim(hero_pos,hero_size,hero)]
 positions=[]
 if supports:
  if portrait:
   for i in range(n):
    col=-1 if i%2==0 else 1; row=i//2; positions.append(P(.50+col*.24,.66+row*.15))
  else:
   for i in range(n):
    ang=(-.86 + (1.72*i/max(1,n-1))) if n>1 else 0.0
    positions.append(P(.50+.34*math.cos(ang),.50+.34*math.sin(ang)))
  for label,pos in zip(supports,positions):
   prims.append(('arrow',hero_pos,pos));prims.append(_semantic_prim(pos,(w*.13,h*.13),label))
 # Explicit P8 relationships override/add semantic connections where source/target
 # labels can be resolved. Unknown endpoints are not invented.
 loc={hero.lower():hero_pos,**{label.lower():pos for label,pos in zip(supports,positions)}}
 for rel in scene.get('semanticRelationships') or []:
  if not isinstance(rel,dict):continue
  src=str(rel.get('source') or rel.get('from') or rel.get('actor') or '').strip().lower(); dst=str(rel.get('target') or rel.get('to') or rel.get('object') or '').strip().lower()
  if src in loc and dst in loc: prims.append(('arrow',loc[src],loc[dst]))
 # Explicit P8 action bindings may add direction only between already-authored entities.
 for act in scene.get('p8MotionActions') or []:
  if not isinstance(act,dict):continue
  src=str(act.get('actor') or '').strip().lower(); dst=str(act.get('target') or '').strip().lower()
  if src in loc and dst in loc: prims.append(('routepath',[loc[src],loc[dst]]))
 copy=scene.get('screenCopy') or {}; primary=str(copy.get('primary') or '').strip()
 if primary:prims.append(('type',P(.12,.13),primary))
 return prims

def _draw_primitive(layer,prim,p,seed,pal,opacity=255):
 kind=prim[0]; color=(pal['inkc'][0],pal['inkc'][1],pal['inkc'][2],int(opacity)); acc=(pal['accentc'][0],pal['accentc'][1],pal['accentc'][2],int(opacity)); sec=(pal['secondaryc'][0],pal['secondaryc'][1],pal['secondaryc'][2],int(opacity)); rough=pal['rough']; width=pal['stroke']
 d=ImageDraw.Draw(layer,'RGBA')
 if kind=='line': _line(layer,prim[1],color,width,seed,rough,p)
 elif kind=='routepath': _line(layer,prim[1],acc,width+2,seed,rough,p,True)
 elif kind=='arrow': _arrow(layer,prim[1],prim[2],acc,width,seed,p,rough)
 elif kind=='ellipse' or kind=='circle':
  c=prim[1];sz=prim[2]; pts=_ellipse_points(c[0],c[1],sz[0],sz[1]);_line(layer,pts,color,width,seed,rough,p,True)
 elif kind=='rect':
  a,b=prim[1],prim[2];_line(layer,_rect_points(a[0],a[1],b[0],b[1]),color,width,seed,rough,p,True)
 elif kind=='node':
  c=prim[1];txt=prim[2]; rx=72;ry=42; pts=_ellipse_points(c[0],c[1],rx,ry);_line(layer,pts,acc,width+1,seed,rough,p,True)
  if p>.76:
   q=_clamp((p-.76)/.24);f=_font(15,True);bb=d.textbbox((0,0),txt,font=f);d.text((c[0]-(bb[2]-bb[0])/2,c[1]-(bb[3]-bb[1])/2),txt,font=f,fill=(color[0],color[1],color[2],int(opacity*q)))
 elif kind=='roundrect':
  a,b,txt=prim[1],prim[2],prim[3]; pts=_rect_points(a[0],a[1],b[0],b[1]);_line(layer,pts,color,width,seed,rough,p,True)
  if p>.72:
   q=_clamp((p-.72)/.28);f=_font(14,True);bb=d.textbbox((0,0),txt,font=f);d.text(((a[0]+b[0])/2-(bb[2]-bb[0])/2,(a[1]+b[1])/2-(bb[3]-bb[1])/2),txt,font=f,fill=(color[0],color[1],color[2],int(opacity*q)))
 elif kind=='diamond':
  c,sz,txt=prim[1],prim[2],prim[3];pts=[(c[0],c[1]-sz[1]),(c[0]+sz[0],c[1]),(c[0],c[1]+sz[1]),(c[0]-sz[0],c[1]),(c[0],c[1]-sz[1])];_line(layer,pts,acc,width+1,seed,rough,p,True)
  if p>.72:
   q=_clamp((p-.72)/.28);f=_font(13,True);bb=d.textbbox((0,0),txt,font=f);d.text((c[0]-(bb[2]-bb[0])/2,c[1]-(bb[3]-bb[1])/2),txt,font=f,fill=(color[0],color[1],color[2],int(opacity*q)))
 elif kind=='orbit':
  c,sz=prim[1],prim[2];pts=_ellipse_points(c[0],c[1],sz[0],sz[1]);_line(layer,pts,sec,max(2,width-1),seed,rough,p,False)
  if p>.62:
   for ang in (-.45,.72,2.35):
    x=c[0]+math.cos(ang)*sz[0];y=c[1]+math.sin(ang)*sz[1];rr=5;d.ellipse((x-rr,y-rr,x+rr,y+rr),fill=acc)
 elif kind=='flowdot':
  c=prim[1];rr=6;d.ellipse((c[0]-rr,c[1]-rr,c[0]+rr,c[1]+rr),fill=(acc[0],acc[1],acc[2],int(opacity*p)))
 elif kind=='bracket':
  a,b=prim[1],prim[2];pts=[(a[0]+18,a[1]),a,(a[0],b[1]),(a[0]+18,b[1]),(b[0]-18,b[1]),b,(b[0],a[1]),(b[0]-18,a[1])];_line(layer,pts,sec,max(2,width-1),seed,rough,p)
 elif kind=='note':
  if p>.08:
   q=_clamp(p/.62);txt=prim[2];f=_font(14,True);d.text(prim[1],txt,font=f,fill=(acc[0],acc[1],acc[2],int(opacity*q)))
 elif kind=='stamp':
  c,txt=prim[1],prim[2];rx,ry=58,25;pts=_ellipse_points(c[0],c[1],rx,ry);_line(layer,pts,acc,width+1,seed,rough,p,True)
  if p>.68:
   q=_clamp((p-.68)/.32);f=_font(12,True);bb=d.textbbox((0,0),txt,font=f);d.text((c[0]-(bb[2]-bb[0])/2,c[1]-(bb[3]-bb[1])/2),txt,font=f,fill=(acc[0],acc[1],acc[2],int(opacity*q)))
 elif kind=='mini':
  c,txt=prim[1],prim[2]; pts=_rect_points(c[0]-55,c[1]-28,c[0]+55,c[1]+28);_line(layer,pts,sec,max(2,width-1),seed,rough,p,True)
  if p>.7:_context_label(layer,(c[0]-36,c[1]-7),txt,pal,11,int(opacity*_clamp((p-.7)/.3)))
 elif kind=='uirow':
  c=prim[1];_line(layer,[(c[0],c[1]),(c[0]+170,c[1])],sec,max(2,width-1),seed,rough,p);_line(layer,[(c[0],c[1]+18),(c[0]+115,c[1]+18)],color,max(1,width-2),seed+4,rough,p)
 elif kind=='motion':
  c=prim[1];
  for j,dy in enumerate((-26,0,26)):_line(layer,[(c[0]-75,c[1]+dy),(c[0]-40,c[1]+dy-6)],sec,max(2,width-1),seed+j,rough,_clamp(p*1.2))
 elif kind=='tick':
  c=prim[1]; _line(layer,[(c[0],c[1]-18),(c[0],c[1]+18)],color,width,seed,rough,p)
  if p>.72:_context_label(layer,(c[0]-5,c[1]+24),prim[2],pal,12,int(opacity*_clamp((p-.72)/.28)))
 elif kind=='type' or kind=='textrow':
  if p>.05:
   q=_clamp(p/.65); txt=prim[2]; f=_font(20 if kind=='type' else 16,True); maxchars=max(1,int(len(txt)*q)); d.text(prim[1],txt[:maxchars],font=f,fill=(color[0],color[1],color[2],int(opacity*q)))
 elif kind=='underline': _line(layer,prim[1],acc,width+2,seed,rough,p)
 elif kind=='check':
  c=prim[1]; pts=[(c[0]-18,c[1]),(c[0]-5,c[1]+13),(c[0]+23,c[1]-19)];_line(layer,pts,acc,width+2,seed,rough,p)
 elif kind=='axes':
  a,b=prim[1],prim[2]; corner=(a[0],b[1]); q=min(1,p*1.55);_line(layer,[a,corner],color,width,seed,rough,q);_line(layer,[corner,(b[0],a[1])],color,width,seed+3,rough,max(0,(p-.35)/.65))
 elif kind=='data': _line(layer,prim[1],acc,width+2,seed,rough,p,True)
 elif kind=='threshold': _line(layer,prim[1],sec,max(2,width-1),seed,rough,p)
 elif kind=='funnel':
  c=prim[1];sz=prim[2];pts=[(c[0]-sz[0],c[1]-sz[1]),(c[0]+sz[0],c[1]-sz[1]),(c[0]+sz[0]*.28,c[1]+sz[1]),(c[0]-sz[0]*.28,c[1]+sz[1]),(c[0]-sz[0],c[1]-sz[1])];_line(layer,pts,color,width,seed,rough,p,True)
 elif kind=='room':
  c,sz,theme=prim[1],prim[2],prim[3];density=prim[4] if len(prim)>4 else 'MINIMAL';x,y=c;sw,sh=sz;q=p
  roomc=(color[0],color[1],color[2],int(opacity*.46)); roomc_soft=(color[0],color[1],color[2],int(opacity*.24))
  # Perspective-aware continuous room shell: back wall, floor plane, window,
  # baseboard and a few contextual marks. These are context, not creative authority.
  left=x-sw*.48;right=x+sw*.48;top=y-sh*.47;floor=y+sh*.28
  _line(layer,[(left,top),(right,top)],roomc,max(2,width-1),seed,rough,q)
  _line(layer,[(left,top),(left,floor)],roomc,max(2,width-1),seed+1,rough,q)
  _line(layer,[(right,top),(right,floor)],roomc,max(2,width-1),seed+2,rough,q)
  _line(layer,[(left,floor),(right,floor)],roomc,max(2,width-1),seed+3,rough,q)
  # floor perspective lines give a real spatial plane without dominating the drawing.
  for j,xx in enumerate((-.30,.05,.34)):
   _line(layer,[(x+sw*xx,floor),(x+sw*xx*.58,y+sh*.47)],roomc_soft,max(1,width-2),seed+10+j,rough,_clamp((q-.18)/.82))
  # window / wall frame
  wx=x-sw*.34;wy=y-sh*.30;ww=sw*.17;wh=sh*.18
  _line(layer,_rect_points(wx-ww,wy-wh,wx+ww,wy+wh),roomc,max(2,width-1),seed+20,rough,_clamp((q-.10)/.9),True)
  _line(layer,[(wx-ww,wy),(wx+ww,wy)],roomc_soft,max(1,width-2),seed+21,rough,_clamp((q-.18)/.82));_line(layer,[(wx,wy-wh),(wx,wy+wh)],roomc_soft,max(1,width-2),seed+22,rough,_clamp((q-.18)/.82))
  # small wall notice and plant silhouette balance the scene.
  nx=x+sw*.08;ny=y-sh*.31;_line(layer,_rect_points(nx-sw*.06,ny-sh*.07,nx+sw*.06,ny+sh*.07),roomc_soft,max(1,width-2),seed+24,rough,_clamp((q-.25)/.75),True)
  px=x-sw*.43;py=floor-sh*.02
  _line(layer,[(px,py),(px-sw*.03,py-sh*.13)],roomc,max(2,width-1),seed+26,rough,_clamp((q-.35)/.65));_line(layer,[(px,py),(px+sw*.04,py-sh*.16)],roomc,max(2,width-1),seed+27,rough,_clamp((q-.35)/.65));_line(layer,[(px-sw*.05,py),(px+sw*.05,py),(px+sw*.03,py+sh*.09),(px-sw*.03,py+sh*.09),(px-sw*.05,py)],roomc,max(2,width-1),seed+28,rough,_clamp((q-.35)/.65),True)
  if density in {'CONTEXTUAL','LIVED_IN'}:
   # Context planes are deliberately non-semantic: they increase spatial authorship
   # without introducing new story objects.
   _line(layer,[(x-sw*.10,floor),(x+sw*.12,floor),(x+sw*.17,y+sh*.42),(x-sw*.16,y+sh*.42),(x-sw*.10,floor)],roomc,max(1,width-2),seed+31,rough,_clamp((q-.32)/.68),True)
   _line(layer,[(x+sw*.29,y-sh*.20),(x+sw*.43,y-sh*.20),(x+sw*.43,y+sh*.06),(x+sw*.29,y+sh*.06),(x+sw*.29,y-sh*.20)],roomc_soft,max(1,width-2),seed+32,rough,_clamp((q-.38)/.62),True)
  if density=='LIVED_IN':
   # Additional architectural/material marks only; no narrative labels/icons.
   for j,yy in enumerate((.03,.13,.23)):
    _line(layer,[(x+sw*.31,y+sh*yy),(x+sw*.42,y+sh*yy)],roomc_soft,max(1,width-2),seed+40+j,rough,_clamp((q-.45)/.55))
   _line(layer,[(x-sw*.08,y+sh*.40),(x+sw*.08,y+sh*.40)],roomc_soft,max(1,width-2),seed+44,rough,_clamp((q-.5)/.5))
 elif kind=='foreground-depth':
  pts=prim[1]; _line(layer,pts,(color[0],color[1],color[2],int(opacity*.40)),max(3,width+1),seed,rough,p,True)
 elif kind=='semantic':
  c,sz,txt,sk=prim[1],prim[2],prim[3],prim[4]; show_label=prim[5] if len(prim)>5 else True; q=p
  x,y=c; sw,sh=sz; ink=color; hi=acc; pale=sec
  if sk=='package':
   pts=[(x-sw*.45,y-sh*.30),(x+sw*.28,y-sh*.30),(x+sw*.45,y-sh*.10),(x+sw*.45,y+sh*.34),(x-sw*.45,y+sh*.34),(x-sw*.45,y-sh*.30)]
   _line(layer,pts,ink,width,seed,rough,q,True);_line(layer,[(x+sw*.28,y-sh*.30),(x+sw*.28,y+sh*.34)],ink,max(2,width-1),seed+1,rough,q);_line(layer,[(x-sw*.12,y-sh*.30),(x+sw*.05,y-sh*.08),(x+sw*.28,y-sh*.30)],hi,max(2,width-1),seed+2,rough,q)
  elif sk=='desk':
   _line(layer,[(x-sw*.48,y),(x+sw*.48,y)],ink,width+1,seed,rough,q,True);_line(layer,[(x-sw*.38,y),(x-sw*.32,y+sh*.42)],ink,width,seed+1,rough,q);_line(layer,[(x+sw*.38,y),(x+sw*.32,y+sh*.42)],ink,width,seed+2,rough,q)
   # monitor + keyboard make it read as an office workstation, not a table glyph.
   _line(layer,_rect_points(x-sw*.16,y-sh*.38,x+sw*.16,y-sh*.09),pale,max(2,width-1),seed+3,rough,q,True);_line(layer,[(x,y-sh*.09),(x,y-sh*.01)],pale,max(2,width-1),seed+4,rough,q);_line(layer,[(x-sw*.12,y-sh*.01),(x+sw*.12,y-sh*.01)],pale,max(2,width-1),seed+5,rough,q)
  elif sk=='doorway':
   _line(layer,_rect_points(x-sw*.34,y-sh*.48,x+sw*.34,y+sh*.46),ink,width,seed,rough,q,True);_line(layer,[(x-sw*.26,y+sh*.38),(x+sw*.20,y+sh*.22),(x+sw*.20,y-sh*.37),(x-sw*.26,y-sh*.23),(x-sw*.26,y+sh*.38)],pale,max(2,width-1),seed+1,rough,q,True); d.ellipse((x+sw*.12-3,y+sh*.03-3,x+sw*.12+3,y+sh*.03+3),fill=hi)
  elif sk=='person':
   # Authored editorial human silhouette: face plane, neck, jacket mass, articulated
   # arms/legs, hands and shoes. Still whiteboard line art, but not a stick skeleton.
   head=_ellipse_points(x,y-sh*.33,sw*.15,sw*.16,30);_line(layer,head,ink,width,seed,rough,min(1,q*1.5),True)
   # hair arc + face/gaze marks
   _line(layer,[(x-sw*.12,y-sh*.40),(x-sw*.02,y-sh*.47),(x+sw*.11,y-sh*.41)],ink,max(2,width-1),seed+1,rough,_clamp((q-.08)/.75))
   if q>.38:
    d.ellipse((x-sw*.055-2,y-sh*.34-2,x-sw*.055+2,y-sh*.34+2),fill=ink);d.ellipse((x+sw*.055-2,y-sh*.34-2,x+sw*.055+2,y-sh*.34+2),fill=ink)
   _line(layer,[(x-sw*.045,y-sh*.27),(x+sw*.045,y-sh*.27)],pale,max(1,width-2),seed+2,rough,_clamp((q-.25)/.75))
   # neck and jacket/body mass
   _line(layer,[(x-sw*.055,y-sh*.18),(x-sw*.055,y-sh*.11)],ink,max(2,width-1),seed+3,rough,_clamp((q-.10)/.80));_line(layer,[(x+sw*.055,y-sh*.18),(x+sw*.055,y-sh*.11)],ink,max(2,width-1),seed+4,rough,_clamp((q-.10)/.80))
   torso=[(x-sw*.22,y-sh*.10),(x-sw*.16,y+sh*.18),(x+sw*.18,y+sh*.18),(x+sw*.22,y-sh*.10),(x+sw*.07,y-sh*.16),(x,y-sh*.07),(x-sw*.07,y-sh*.16),(x-sw*.22,y-sh*.10)];_line(layer,torso,ink,width,seed+5,rough,_clamp((q-.08)/.82),True)
   # sleeves/arms with small hand circles
   arms=[[(x-sw*.19,y-sh*.06),(x-sw*.34,y+sh*.06),(x-sw*.40,y+sh*.18)],[(x+sw*.19,y-sh*.06),(x+sw*.34,y+sh*.01),(x+sw*.42,y-sh*.03)]]
   for j,ln in enumerate(arms):
    _line(layer,ln,ink,width,seed+10+j,rough,_clamp((q-.18)/.72));hx,hy=ln[-1];d.ellipse((hx-4,hy-4,hx+4,hy+4),outline=ink,width=max(1,width-1)) if q>.55 else None
   # trousers as two narrow polygons, not single lines; shoes ground the figure.
   legs=[[(x-sw*.13,y+sh*.18),(x-sw*.17,y+sh*.42),(x-sw*.08,y+sh*.43),(x-sw*.03,y+sh*.18)],[(x+sw*.03,y+sh*.18),(x+sw*.10,y+sh*.43),(x+sw*.19,y+sh*.42),(x+sw*.13,y+sh*.18)]]
   for j,poly in enumerate(legs):_line(layer,[*poly,poly[0]],ink,max(2,width-1),seed+14+j,rough,_clamp((q-.25)/.70),True)
   _line(layer,[(x-sw*.18,y+sh*.44),(x-sw*.05,y+sh*.44)],ink,width+1,seed+16,rough,_clamp((q-.38)/.62));_line(layer,[(x+sw*.09,y+sh*.44),(x+sw*.23,y+sh*.44)],ink,width+1,seed+17,rough,_clamp((q-.38)/.62))
   if any(k in txt.lower() for k in ('courier','delivery','worker','operator')):
    # shoulder strap + satchel communicates role without a text-only badge.
    _line(layer,[(x-sw*.14,y-sh*.12),(x+sw*.21,y+sh*.14)],hi,max(2,width-1),seed+20,rough,_clamp((q-.35)/.65));_line(layer,_rect_points(x+sw*.12,y+sh*.08,x+sw*.40,y+sh*.27),hi,max(2,width-1),seed+21,rough,_clamp((q-.42)/.58),True)
  elif sk=='screen':
   _line(layer,_rect_points(x-sw*.42,y-sh*.36,x+sw*.42,y+sh*.18),ink,width,seed,rough,q,True);_line(layer,[(x,y+sh*.18),(x,y+sh*.34)],ink,width,seed+1,rough,q);_line(layer,[(x-sw*.22,y+sh*.34),(x+sw*.22,y+sh*.34)],ink,width,seed+2,rough,q);_line(layer,[(x-sw*.28,y-sh*.18),(x+sw*.16,y-sh*.18)],pale,max(2,width-1),seed+3,rough,q)
  elif sk=='phone':
   _line(layer,_rect_points(x-sw*.22,y-sh*.47,x+sw*.22,y+sh*.47),ink,width,seed,rough,q,True);d.ellipse((x-3,y+sh*.35-3,x+3,y+sh*.35+3),fill=hi)
  elif sk=='wallet':
   _line(layer,_rect_points(x-sw*.42,y-sh*.25,x+sw*.42,y+sh*.25),ink,width,seed,rough,q,True);_line(layer,[(x+sw*.05,y-sh*.08),(x+sw*.42,y-sh*.08)],hi,width,seed+1,rough,q)
  elif sk=='cup':
   _line(layer,[(x-sw*.30,y-sh*.30),(x-sw*.22,y+sh*.30),(x+sw*.20,y+sh*.30),(x+sw*.28,y-sh*.30),(x-sw*.30,y-sh*.30)],ink,width,seed,rough,q,True);_line(layer,_ellipse_points(x+sw*.31,y,sw*.16,sh*.16,24),ink,width,seed+1,rough,q)
  elif sk=='bottle':
   pts=[(x-sw*.12,y-sh*.48),(x+sw*.12,y-sh*.48),(x+sw*.14,y-sh*.25),(x+sw*.28,y-sh*.12),(x+sw*.25,y+sh*.46),(x-sw*.25,y+sh*.46),(x-sw*.28,y-sh*.12),(x-sw*.14,y-sh*.25),(x-sw*.12,y-sh*.48)];_line(layer,pts,ink,width,seed,rough,q,True)
  elif sk=='chair':
   _line(layer,_rect_points(x-sw*.28,y-sh*.14,x+sw*.28,y+sh*.15),ink,width,seed,rough,q,True);_line(layer,[(x-sw*.24,y+sh*.15),(x-sw*.30,y+sh*.45)],ink,width,seed+1,rough,q);_line(layer,[(x+sw*.24,y+sh*.15),(x+sw*.30,y+sh*.45)],ink,width,seed+2,rough,q);_line(layer,[(x-sw*.28,y-sh*.14),(x-sw*.28,y-sh*.43)],ink,width,seed+3,rough,q)
  elif sk=='shelf':
   _line(layer,_rect_points(x-sw*.43,y-sh*.45,x+sw*.43,y+sh*.45),ink,width,seed,rough,q,True)
   for j,yy in enumerate((-.18,.10)):_line(layer,[(x-sw*.40,y+sh*yy),(x+sw*.40,y+sh*yy)],pale,max(2,width-1),seed+2+j,rough,q)
  elif sk=='document':
   _line(layer,_rect_points(x-sw*.34,y-sh*.44,x+sw*.34,y+sh*.44),ink,width,seed,rough,q,True)
   for j,yy in enumerate((-.20,-.03,.14)):_line(layer,[(x-sw*.22,y+sh*yy),(x+sw*.18,y+sh*yy)],pale,max(2,width-1),seed+4+j,rough,q)
  else:
   # Unknown semantic entities stay literal-labelled objects rather than silently
   # becoming a generic icon with invented meaning.
   _line(layer,_rect_points(x-sw*.40,y-sh*.28,x+sw*.40,y+sh*.28),ink,width,seed,rough,q,True)
  if show_label and p>.72 and txt:
   qtxt=_clamp((p-.72)/.28);f=_font(12,True);label=re.sub(r'\s+',' ',txt.upper()).strip(); label=label if len(label)<=18 else label[:17]+'…';bb=d.textbbox((0,0),label,font=f);d.text((x-(bb[2]-bb[0])/2,y+sh*.55),label,font=f,fill=(ink[0],ink[1],ink[2],int(opacity*qtxt)))
 elif kind=='ground':
  _line(layer,prim[1],sec,max(2,width-1),seed,rough,p)
 elif kind=='person':
  c=prim[1]; sz=prim[2]; q=p
  # coherent passes instead of micro-path serial drawing.
  head=_ellipse_points(c[0],c[1]-sz[1]*.35,sz[0]*.19,sz[0]*.19,28); _line(layer,head,color,width,seed,rough,min(1,q*1.8))
  torso=[(c[0],c[1]-sz[1]*.14),(c[0],c[1]+sz[1]*.18)];_line(layer,torso,color,width+1,seed+1,rough,_clamp((q-.15)/.55))
  arms=[[(c[0],c[1]-sz[1]*.04),(c[0]-sz[0]*.45,c[1]+sz[1]*.05)],[(c[0],c[1]-sz[1]*.04),(c[0]+sz[0]*.48,c[1]-sz[1]*.13)]]
  legs=[[(c[0],c[1]+sz[1]*.18),(c[0]-sz[0]*.32,c[1]+sz[1]*.48)],[(c[0],c[1]+sz[1]*.18),(c[0]+sz[0]*.31,c[1]+sz[1]*.48)]]
  for j,ln in enumerate(arms+legs):_line(layer,ln,color,width,seed+10+j,rough,_clamp((q-.28)/.6))
 elif kind=='erase':
  # board-colored rub passes remove an old-state diagonal in the active scene.
  pts=prim[1]; bg=(pal['bgc'][0],pal['bgc'][1],pal['bgc'][2],int(opacity));_line(layer,pts,bg,22,seed,.22,p,True)

def _scene_layer(scene,plan,ratio,cam,scene_time,active=True,opacity=255):
 size=RATIO_SIZES[ratio]; layer=Image.new('RGBA',size,(0,0,0,0)); pal=_pal(plan); wb=scene.get('whiteboardRuntime') or {}; dur=float(wb.get('sceneDuration') or 1.0); prims=_primitive_set(scene,ratio); drawplan=wb.get('drawPlan') or []
 # draw using board-space primitives mapped to screen-space.
 zoom=1.0 if ratio!='9:16' else .86
 for i,prim in enumerate(prims):
  item=drawplan[i] if i<len(drawplan) else {'start':i*.2,'end':i*.2+.4,'seed':wb.get('seed',1)+i}
  p=1.0 if not active else _ease(_clamp((scene_time-float(item.get('start',0)))/max(.001,float(item.get('end',.4))-float(item.get('start',0)))))
  if p<=0: continue
  def mp(v): return _map_point(v,cam,ratio,zoom)
  k=prim[0]
  if k in {'line','ground','data','threshold','underline','erase','routepath','foreground-depth'}: mapped=(k,[mp(x) for x in prim[1]],*prim[2:])
  elif k in {'arrow'}: mapped=(k,mp(prim[1]),mp(prim[2]),*prim[3:])
  elif k in {'ellipse','circle','person','semantic','room','funnel','diamond','orbit'}:
   c=mp(prim[1]); scale=min(size)/(650 if ratio!='9:16' else 760)*zoom; sz=(prim[2][0]*scale,prim[2][1]*scale);mapped=(k,c,sz,*prim[3:])
  elif k in {'rect','axes','roundrect','bracket'}: mapped=(k,mp(prim[1]),mp(prim[2]),*prim[3:])
  elif k in {'node','tick','type','textrow','check','flowdot','note','stamp','mini','uirow','motion'}: mapped=(k,mp(prim[1]),*prim[2:])
  else: mapped=prim
  _draw_primitive(layer,mapped,p,int(item.get('seed',wb.get('seed',1)+i)),pal,opacity)
 return layer

def _paper_texture(im,pal,seed):
 rnd=random.Random(seed);d=ImageDraw.Draw(im,'RGBA');w,h=im.size;count=max(120,int(w*h/8000))
 for _ in range(count):
  x=rnd.randrange(w);y=rnd.randrange(h);a=rnd.randrange(4,12);d.point((x,y),fill=(20,20,18,a))

def _authored_plate(scene,progress,size):
 plate=scene.get('authoredScenePlate') or {}; files=plate.get('stage_files') or []
 if not files: return None
 idx=min(len(files)-1,max(0,int(round(_clamp(progress)*(len(files)-1)))))
 path=Path(str(files[idx]))
 if not path.exists(): return None
 try:
  im=Image.open(path).convert('RGBA')
  if im.size!=size: im=ImageOps.fit(im,size,method=Image.Resampling.LANCZOS)
  return im
 except Exception:
  return None

def render_scene(scene,plan,ratio='16:9',progress=.9,hide_text=False,scene_time=None,reduced_motion=False,camera_enabled=True):
 size=RATIO_SIZES[ratio];pal=_pal(plan); im=Image.new('RGBA',size,pal['bgc']);_paper_texture(im,pal,int((scene.get('whiteboardRuntime') or {}).get('seed',7)))
 authored=_authored_plate(scene,progress,size)
 if authored is not None:
  im.alpha_composite(authored)
  return im.convert('RGB')
 scenes=plan.get('sceneSpecs') or [scene]; idx=next((i for i,s in enumerate(scenes) if s.get('sceneId')==scene.get('sceneId')),0)
 wb=scene.get('whiteboardRuntime') or {}; dur=float(wb.get('sceneDuration') or 1.0); scene_time=_clamp(progress)*dur if scene_time is None else _clamp(scene_time,0,dur)
 cam=_camera(scene,ratio)
 # Nearby completed zones remain as low-opacity board memory when they fall in/near the viewport.
 for j in range(max(0,idx-2),idx):
  layer=_scene_layer(scenes[j],plan,ratio,cam,999,False,opacity=42 if j<idx-1 else 70); im.alpha_composite(layer)
 active=_scene_layer(scene,plan,ratio,cam,scene_time,True,255);im.alpha_composite(active)
 if not hide_text:
  d=ImageDraw.Draw(im,'RGBA');sc=scene.get('screenCopy') or {};primary=str(sc.get('primary') or '').strip();secondary=str(sc.get('secondary') or '').strip(); w,h=size
  if primary:
   fs=34 if ratio=='16:9' else 28 if ratio=='1:1' else 25; f=_font(fs,True); maxw=int(w*.80); lines=_wrap(d,primary,f,maxw,2); yy=int(h*.075)
   for ln in lines:d.text((int(w*.10),yy),ln,font=f,fill=pal['inkc']);yy+=int(fs*1.08)
  if secondary:
   f=_font(14,True);d.text((int(w*.10),int(h*.19)),secondary[:86],font=f,fill=(pal['secondaryc'][0],pal['secondaryc'][1],pal['secondaryc'][2],210))
 # tiny physical tool indicator only while active draw is happening; never the hero.
 cur=next((x for x in wb.get('drawPlan',[]) if x.get('start',0)<=scene_time<=x.get('end',0)),None)
 if cur and cur.get('semanticRole') in {'annotation','emphasis'} and not reduced_motion:
  d=ImageDraw.Draw(im,'RGBA');w,h=size;x=int(w*.92);y=int(h*.86);d.rounded_rectangle((x-34,y-5,x+28,y+5),radius=4,fill=pal['accentc']);d.ellipse((x+22,y-5,x+34,y+5),fill=pal['inkc'])
 return im.convert('RGB')

def render_transition_frame(prev_scene,scene,plan,ratio,progress,hide_text=False,reduced_motion=False):
 p=_ease(progress); a=_camera(prev_scene,ratio);b=_camera(scene,ratio);cam=(a[0]+(b[0]-a[0])*p,a[1]+(b[1]-a[1])*p);size=RATIO_SIZES[ratio];pal=_pal(plan);im=Image.new('RGBA',size,pal['bgc']);_paper_texture(im,pal,int((scene.get('whiteboardRuntime') or {}).get('seed',9)))
 prev_plate=_authored_plate(prev_scene,1.0,size); next_plate=_authored_plate(scene,min(1.0,p*.35),size)
 if prev_plate is not None or next_plate is not None:
  if prev_plate is not None:
   prev_plate.putalpha(int(255*(1-p))); im.alpha_composite(prev_plate)
  if next_plate is not None:
   next_plate.putalpha(int(255*p)); im.alpha_composite(next_plate)
  return im.convert('RGB')
 # outgoing completed marks remain physically on the same board as the camera travels.
 im.alpha_composite(_scene_layer(prev_scene,plan,ratio,cam,999,False,opacity=int(255*(1-.25*p))))
 # incoming zone begins to construct only during the latter part of travel.
 incoming_time=max(0,(p-.42)/.58)*float((scene.get('whiteboardRuntime') or {}).get('sceneDuration') or 1.0)*.18
 im.alpha_composite(_scene_layer(scene,plan,ratio,cam,incoming_time,True,opacity=int(120+135*p)))
 return im.convert('RGB')

__all__=['render_scene','render_transition_frame','PROFILES','RATIO_SIZES']
