#!/usr/bin/env python3
from __future__ import annotations
from array import array
from pathlib import Path
import hashlib, math, random, wave

HERE=Path(__file__).resolve().parents[1]
AUDIO=HERE/'assets/audio/production'
ROLE_FILE={
 'marker.short':'whiteboard-marker-bed-48k.wav','marker.swipe':'whiteboard-marker-bed-48k.wav',
 'pencil.short':'pencil-bed-48k.wav','eraser.rub':'pencil-bed-48k.wav','cap':'pen-cap-48k.wav'}
ROLE_GAIN={'marker.short':.14,'marker.swipe':.17,'pencil.short':.12,'eraser.rub':.09,'cap':.34}

def _seed(*parts): return int(hashlib.sha256('|'.join(map(str,parts)).encode()).hexdigest()[:8],16)
def _read(name):
 p=AUDIO/name
 with wave.open(str(p),'rb') as w:
  assert w.getnchannels()==1 and w.getsampwidth()==2 and w.getframerate()==48000
  return array('h',w.readframes(w.getnframes()))
_CACHE={}
def src(name):
 if name not in _CACHE:_CACHE[name]=_read(name)
 return _CACHE[name]

def events(plan):
 out=[]; base=0.0
 scenes=plan.get('sceneSpecs') or []
 for si,s in enumerate(scenes):
  wb=s.get('whiteboardRuntime') or {}; dur=float(wb.get('sceneDuration') or 1)
  for i,st in enumerate(wb.get('drawPlan') or []):
   role=st.get('soundRole')
   if not role:continue
   start=base+float(st.get('start',0)); length=max(.07,float(st.get('end',0))-float(st.get('start',0)))
   rnd=random.Random(_seed(wb.get('seed'),st.get('id'),role))
   out.append({'role':role,'file':ROLE_FILE.get(role,ROLE_FILE['marker.short']),'start':start,'duration':length,'offset':rnd.random()*4.8,'gain':ROLE_GAIN.get(role,.12),'seed':_seed(si,i,role)})
  base+=dur
 # meaningful physical punctuation only at sequence boundaries.
 if scenes:
  out.append({'role':'cap','file':ROLE_FILE['cap'],'start':.04,'duration':.23,'offset':.15,'gain':ROLE_GAIN['cap'],'seed':_seed('cap','open')})
  out.append({'role':'cap','file':ROLE_FILE['cap'],'start':max(.05,base-.28),'duration':.24,'offset':1.28,'gain':ROLE_GAIN['cap']*.8,'seed':_seed('cap','close')})
 return sorted(out,key=lambda x:(x['start'],x['role']))

def render(plan,duration,out_path:Path):
 rate=48000;n=max(1,int(math.ceil(duration*rate)));mix=array('f',[0.0])*n
 evs=events(plan)
 for ev in evs:
  a=src(ev['file']);start=max(0,int(ev['start']*rate));count=max(1,int(ev['duration']*rate));off=int(ev['offset']*rate)%max(1,len(a))
  gain=float(ev['gain']); fade=max(1,min(int(.018*rate),count//4))
  for j in range(count):
   if start+j>=n:break
   sample=a[(off+j)%len(a)]/32768.0
   env=min(1,j/fade,(count-1-j)/fade) if count>fade*2 else math.sin(math.pi*j/max(1,count-1))
   mix[start+j]+=sample*gain*max(0,env)
 peak=max((abs(x) for x in mix),default=1);scale=min(1,.82/max(.0001,peak))
 pcm=array('h',(int(max(-1,min(1,x*scale))*32767) for x in mix))
 out_path=Path(out_path);out_path.parent.mkdir(parents=True,exist_ok=True)
 with wave.open(str(out_path),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(pcm.tobytes())
 return {'path':str(out_path),'events':evs,'eventCount':len(evs),'peakBeforeLimit':round(peak,6),'limiterScale':round(scale,6),'duration':duration,'sampleRate':rate}

__all__=['events','render']
