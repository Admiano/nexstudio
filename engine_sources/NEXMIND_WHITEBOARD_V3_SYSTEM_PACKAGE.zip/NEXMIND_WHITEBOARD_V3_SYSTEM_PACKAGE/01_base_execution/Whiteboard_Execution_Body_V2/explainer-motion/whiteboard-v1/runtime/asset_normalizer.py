#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
from xml.etree import ElementTree as ET
import hashlib,json,re,shutil

HERE=Path(__file__).resolve().parents[1]
SRC=HERE/'assets/vectors'; OUT=HERE/'assets/normalized'; OUT.mkdir(parents=True,exist_ok=True)
DRAW_TAGS={'path','line','polyline','polygon','rect','circle','ellipse'}

def local(tag): return tag.rsplit('}',1)[-1]
def norm_id(name): return re.sub(r'[^a-z0-9]+','-',name.lower()).strip('-')

def inspect(path:Path)->dict:
    root=ET.parse(path).getroot(); els=[x for x in root.iter() if local(x.tag) in DRAW_TAGS]
    images=[x for x in root.iter() if local(x.tag)=='image']; texts=[x for x in root.iter() if local(x.tag)=='text']
    groups=[]
    for i,e in enumerate(els):
        tag=local(e.tag); role='hero' if i==0 else ('connector-out' if tag in {'line','polyline'} else 'object')
        groups.append({'sourceIndex':i,'sourceTag':tag,'sourceId':e.attrib.get('id'),'semanticRole':role,'drawGroup':0 if i<max(1,len(els)//4) else min(3,1+i*4//max(1,len(els)))})
    return {'file':path.name,'id':'wb.vector.'+norm_id(path.stem),'pathCount':len(els),'embeddedImages':len(images),'textElements':len(texts),'drawRegime':'build' if len(els)>24 else 'draw','serialPathCap':12,'groups':groups,'commercialStatus':'CC0-source-promotable-after-visual-review'}

def main():
    manifest={'version':'1.0.0','policy':'semantic-grouping-not-source-dom-order','assets':[]}
    for p in sorted(SRC.glob('*.svg')):
        rec=inspect(p); manifest['assets'].append(rec)
        shutil.copy2(p,OUT/p.name)
    raw=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode();manifest['digest']=hashlib.sha256(raw).hexdigest()
    (OUT/'normalized-vector-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'assets':len(manifest['assets']),'paths':sum(x['pathCount'] for x in manifest['assets']),'digest':manifest['digest']},indent=2))
if __name__=='__main__':main()
