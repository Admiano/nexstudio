#!/usr/bin/env python3
from __future__ import annotations
import json, math, hashlib, re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
VERSION='1.0.0-step-c'

def _load(rel):
    return json.loads((ROOT/rel).read_text())

ACTIONS={x['id']:x for x in _load('explainer-motion/choreography-runtime-v1/manifests/action-grammar.json')['actions']}
PROFILES={x['id']:x for x in _load('explainer-motion/choreography-runtime-v1/manifests/choreography-profiles.json')['profiles']}
CAMERAS={x['id']:x for x in _load('explainer-motion/camera-continuity-v1/manifests/camera-intents.json')['intents']}
TRANSITIONS=_load('explainer-motion/camera-continuity-v1/manifests/transition-contracts.json')['transitions']
TRANSITION_BY_TYPE={}
for t in TRANSITIONS:
    TRANSITION_BY_TYPE.setdefault(t.get('continuityType'),t)

OWNERSHIP_FINAL={'receive':'actor','assign':'target','route':'target','carry-transfer':'target','dock':'target','deliver':'recipient'}
PROFILE_BY_ACTION={
 'receive':'character-natural','reveal':'editorial-soft','inspect':'character-natural','point-focus':'editorial-confident',
 'assign':'mechanism-light','split':'mechanism-light','route':'mechanism-light','carry-transfer':'character-natural',
 'dock':'mechanism-heavy','process':'mechanism-light','transform':'editorial-confident','merge':'mechanism-light',
 'compare':'data-resolve','validate':'mechanism-heavy','approve':'product-precise','reject':'mechanism-heavy',
 'retry-repair':'mechanism-light','accumulate':'data-resolve','distribute':'mechanism-light','activate-unlock':'mechanism-heavy',
 'package':'editorial-confident','deliver':'character-natural','settle':'mechanism-heavy','prove-resolve':'data-resolve'
}

def clamp(x,a=0.0,b=1.0): return max(a,min(b,float(x)))
def lerp(a,b,p): return a+(b-a)*clamp(p)
def smooth(p): p=clamp(p); return p*p*(3-2*p)
def ease_out(p,n=4): return 1-(1-clamp(p))**n
def ease_in_out(p):
    p=clamp(p)
    return 4*p*p*p if p<.5 else 1-((-2*p+2)**3)/2

def stable(obj): return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def _concepts(scene):
    vals=[]
    for sh in scene.get('shots',[]): vals += list(sh.get('requiredVisibleConcepts') or [])
    vals += [str(x.get('concept','')) for x in (scene.get('semanticNeeds') or {}).get('objectNeeds',[]) if isinstance(x,dict)]
    vals += [str(x.get('concept','')) for x in (scene.get('semanticNeeds') or {}).get('actorNeeds',[]) if isinstance(x,dict)]
    out=[]
    for v in vals:
        v=str(v).strip().lower()
        if v and v not in out: out.append(v)
    return out

def _node(node_id, role, label, parent='scene-root', z='hero', anchors=None):
    return {'id':node_id,'role':role,'label':label,'parent':parent,'children':[],'zRole':z,
            'anchors':anchors or {'center':[.5,.5]},'state':'idle','owner':None,'visible':True}

def compile_scene_graph(scene:dict)->dict:
    sid=scene['sceneId']
    persistent=(scene.get('persistentObject') or {})
    pid=persistent.get('semanticEntityId') or 'persistent-object'
    nodes=[_node('scene-root','world','scene world',parent=None,z='background',anchors={'center':[.5,.55]})]
    nodes.append(_node(pid,'persistent',persistent.get('label') or pid,z='hero'))
    nodes.append(_node(f'{sid}.mechanism','mechanism',scene.get('mechanismId','mechanism'),z='hero'))
    concepts=_concepts(scene)
    actor_words={'human-operator','operator','human','reviewer','recipient','customer','agent','robot'}
    evidence_words={'value','revenue','training-data','evidence','metric','jobs'}
    for i,c in enumerate(concepts):
        if c in (pid,persistent.get('label','').lower()): continue
        role='actor' if c in actor_words else ('evidence' if c in evidence_words else 'object')
        z='actor' if role=='actor' else ('foreground' if role=='evidence' else 'midground')
        nodes.append(_node(f'{sid}.{re.sub("[^a-z0-9]+","-",c).strip("-") or "concept"}-{i+1:02d}',role,c,z=z))
    # Common semantic runtime targets are always addressable even when renderer art is generic.
    for rid,label,role in [('source-zone','source zone','zone'),('target-zone','target zone','zone'),('result-zone','result zone','zone'),('evidence-zone','evidence zone','zone')]:
        nodes.append(_node(f'{sid}.{rid}',role,label,z='midground'))
    # parent/child links
    by={n['id']:n for n in nodes}
    for n in nodes:
        par=n.get('parent')
        if par in by: by[par]['children'].append(n['id'])
    return {'sceneId':sid,'rootId':'scene-root','persistentEntityId':pid,'nodes':nodes,'nodeCount':len(nodes)}

EXECUTION_BINDINGS={
    'HOLD':'settle','LOOK':'inspect','WALK':'deliver','RUN':'deliver','SIT':'settle','STAND':'reveal',
    'REACH':'receive','PRESENT':'reveal','PRESS':'activate-unlock','PICKUP':'receive','PLACE':'deliver',
    'CARRY_LIGHT':'carry-transfer','HANDOFF_DIRECT':'carry-transfer','HANDOFF_PLACE_AND_TAKE':'carry-transfer',
    'TYPE':'reveal','PHONE_HOLD':'reveal','DANCE':'reveal','REVEAL':'reveal','HIGHLIGHT':'point-focus',
    'DE_EMPHASIZE':'settle','TRACE_FLOW':'route','TRANSFORM':'transform','OBJECT_MOVE':'route',
    'TYPE_REVEAL':'reveal','SETTLE':'settle','DRAW':'reveal','ANNOTATE':'inspect','ERASE':'retry-repair',
    'REFRAME_CONTENT':'transform','SCROLL':'route','STATE_CHANGE':'transform',
}

def _canonical_action(raw):
    """Bind an explicit P8 execution token; never infer an action from prose."""
    if isinstance(raw,dict):
        token=str(raw.get('resolvedVerb') or (raw.get('execution') or {}).get('resolved_verb') or '').strip().upper()
    else:
        token=str(raw or '').strip().upper()
    if not token:
        raise ValueError('WHITEBOARD_EXPLICIT_MOTION_BINDING_REQUIRED')
    if token in EXECUTION_BINDINGS:
        return EXECUTION_BINDINGS[token]
    low=token.lower()
    if low in ACTIONS:
        return low
    aliases={'POINT':'point-focus','FOCUS':'point-focus','RETRY':'retry-repair','REPAIR':'retry-repair','ACTIVATE':'activate-unlock','UNLOCK':'activate-unlock','PROVE':'prove-resolve'}
    if token in aliases:
        return aliases[token]
    raise ValueError(f'WHITEBOARD_UNSUPPORTED_EXECUTION_BINDING:{token}')

def _role_bindings(scene, action, graph):
    pid=graph['persistentEntityId']; sid=scene['sceneId']; concepts=_concepts(scene)
    actor=next((n['id'] for n in graph['nodes'] if n['role']=='actor' and 'robot' not in n['label']), None)
    robot=next((n['id'] for n in graph['nodes'] if n['role']=='actor' and 'robot' in n['label']), None)
    evidence=next((n['id'] for n in graph['nodes'] if n['role']=='evidence'), None)
    mechanism=f'{sid}.mechanism'; src=f'{sid}.source-zone'; tgt=f'{sid}.target-zone'; result=f'{sid}.result-zone'
    if scene.get('mechanismId')=='A11':
        actor=actor or pid; tgt=robot or tgt
    if scene.get('mechanismId')=='A12':
        actor=actor or next((n['id'] for n in graph['nodes'] if 'operator' in n['label']),None); tgt=robot or tgt
    b={'subjectId':actor or pid,'propId':pid,'sourceId':src,'targetId':tgt,'mechanismId':mechanism,'resultId':result,'evidenceId':evidence}
    if action=='accumulate': b['subjectId']=evidence or pid; b['targetId']=pid
    if action=='distribute': b['sourceId']=pid; b['targetId']=result
    if action=='compare': b['subjectId']=evidence or pid; b['targetId']=result
    if action in ('process','transform','settle','reveal','prove-resolve'): b['subjectId']=pid
    return b

def compile_action_schedule(scene:dict, graph:dict)->list:
    shots=scene.get('shots') or []
    scene_duration=float(scene.get('timingOverrideSeconds') or 1.0)
    scene_abs_start=min([float(s.get('start',0)) for s in shots], default=0.0)
    out=[]; order=0
    for sh in shots:
        ss=max(0.0,float(sh.get('start',scene_abs_start))-scene_abs_start); ee=max(ss+0.05,float(sh.get('end',scene_abs_start+scene_duration))-scene_abs_start)
        declared=(sh.get('actions') or [])
        if not declared:
            declared=scene.get('p8MotionActions') or scene.get('narrativeRequiredActions') or scene.get('actionSequence') or []
        acts=[_canonical_action(x) for x in declared]
        if not acts:
            raise ValueError(f'WHITEBOARD_P8_MOTION_ACTION_REQUIRED:{scene.get("sceneId")}')
        n=len(acts); overlap=.12 if n>1 else 0.0
        unit=(ee-ss)/(n-(n-1)*overlap)
        cur=ss
        for j,a in enumerate(acts):
            st=cur; en=min(ee,st+unit); cur=en-unit*overlap
            profile=PROFILE_BY_ACTION.get(a,scene.get('choreographyProfile','mechanism-light'))
            out.append({'actionId':f'{scene["sceneId"]}.A{order+1:02d}','verb':a,'shotId':sh.get('shotId'),'start':round(st,4),'end':round(en,4),'duration':round(en-st,4),
                        'profileId':profile,'bindings':_role_bindings(scene,a,graph),'ownershipChanging':bool(ACTIONS[a].get('ownershipChanging')),
                        'motionSampling':'native-smooth' if a in {'carry-transfer','dock','route','deliver','transform','follow-object'} else 'authored-stepped',
                        'soundTags':[a] if a not in {'settle'} else []})
            order+=1
    # Do not append undeclared lifecycle actions; P8 owns the action sequence.
    return out

def _transition_type(scene):
    t=(scene.get('transitionContinuity') or {}).get('type','clean-cut')
    if t=='clean-cut': return 'clean-cut'
    return t

def compile_transition_runtime(prev_scene, scene, narrative_graph):
    if not prev_scene: return {'type':'clean-cut','enabled':False,'duration':0.0}
    declared=_transition_type(scene)
    prev_pid=(prev_scene.get('persistentObject') or {}).get('semanticEntityId')
    cur_pid=(scene.get('persistentObject') or {}).get('semanticEntityId')
    transform=None
    for tr in (narrative_graph or {}).get('transformations',[]):
        if tr.get('sceneId') in {scene['sceneId'].replace(scene['sceneId'].split('.')[0]+'.',''), scene['sceneId'].split('.')[-1]} or (tr.get('fromEntity')==prev_pid and tr.get('toEntity')==cur_pid):
            transform=tr; break
    if prev_pid==cur_pid and prev_pid: continuity='object-continuity'
    elif transform: continuity='meaning-continuity'
    else:
        # Do not force a continuity effect between unrelated narrative entities merely because Step B suggested one.
        return {'type':'clean-cut','enabled':False,'duration':0.0,'declaredType':declared,'downgradeReason':'no adjacent narrative identity or declared semantic transformation to preserve',
                'outgoingEntityId':prev_pid,'incomingEntityId':cur_pid,'identityPolicy':'no-false-continuity'}
    template=TRANSITION_BY_TYPE.get(continuity) or TRANSITION_BY_TYPE.get('object-continuity')
    duration=.46 if continuity in {'object-continuity','motion-continuity','world-geometry-continuity'} else .56
    return {'type':continuity,'enabled':True,'duration':duration,'templateId':template.get('id') if template else None,
            'outgoingEntityId':prev_pid,'incomingEntityId':cur_pid,'persistentSemanticId':prev_pid if prev_pid==cur_pid else None,
            'semanticTransformation':transform or {'fromEntity':prev_pid,'toEntity':cur_pid,'relationship':(scene.get('transitionContinuity') or {}).get('motivation')},
            'anchorRelationship':(template or {}).get('anchorRelationship','semantic-centre-to-centre'),
            'scaleRelationship':(template or {}).get('scaleRelationship',{'incomingToOutgoing':1.0,'bounded':True}),
            'transformOrigin':(template or {}).get('transformOrigin','semantic-object-centre'),
            'objectDirection':(template or {}).get('objectDirection','right'),'settle':(template or {}).get('settle','incoming state settles'),
            'identityPolicy':'same-semantic-id-survives' if prev_pid==cur_pid else 'declared-semantic-transformation'}

def compile_plan_runtime(plan:dict)->dict:
    ng=(plan.get('narrativePlan') or {}).get('narrativeStateGraph') or {}
    scenes=plan.get('sceneSpecs',[]); prev=None; compiled=[]
    for scene in scenes:
        graph=compile_scene_graph(scene); actions=compile_action_schedule(scene,graph)
        tr=compile_transition_runtime(prev,scene,ng)
        duration=float(scene.get('timingOverrideSeconds') or 1.0)
        runtime={'version':VERSION,'sceneGraph':graph,'actions':actions,'transitionIn':tr,
                 'sceneDuration':duration,'nativeSmoothRequired':any(a['motionSampling']=='native-smooth' for a in actions),
                 'digest':None}
        runtime['digest']=stable({k:v for k,v in runtime.items() if k!='digest'})
        scene['semanticPerformanceRuntime']=runtime
        compiled.append(runtime); prev=scene
    plan['semanticPerformanceVersion']=VERSION
    plan['semanticPerformanceSummary']={'sceneCount':len(compiled),'nodeCount':sum(x['sceneGraph']['nodeCount'] for x in compiled),
        'actionCount':sum(len(x['actions']) for x in compiled),'transitionCount':sum(1 for x in compiled if x['transitionIn'].get('enabled')),
        'nativeSmoothSceneCount':sum(1 for x in compiled if x['nativeSmoothRequired'])}
    return plan

def _phase(p):
    if p<.14:return 'anticipation'
    if p<.72:return 'active'
    if p<.9:return 'result'
    return 'settled'

def _action_progress(a,t):
    st, en=float(a['start']),float(a['end'])
    return clamp((t-st)/max(.001,en-st))

def _active_shot(scene,t):
    shots=scene.get('shots') or []
    if not shots: return None
    abs0=min(float(s.get('start',0)) for s in shots)
    for sh in shots:
        st=float(sh.get('start',abs0))-abs0; en=float(sh.get('end',abs0))-abs0
        if st<=t<en or (sh is shots[-1] and t>=st): return sh
    return shots[0]

def _layout_point(scene, semantic_target, action_state=None):
    mech=scene.get('mechanismId',''); target=str(semantic_target or '').lower(); p=clamp((action_state or {}).get('progress',0.5))
    # semantic target positions approximate the actual current renderer's scene geometry.
    if mech=='U20':
        if target in {'persistent-object','agent','digital agent/core'} or 'agent' in target: return (.22+.58*p,.56)
        return (.52,.55)
    if mech=='U08':
        if target in {'persistent-object','work','job'} or 'work' in target: return (.20+.62*p,.59)
        if 'evidence' in target or 'detail' in target or 'value' in target: return (.72,.53)
        return (.52,.58)
    if mech=='U07':
        if target in {'persistent-object','agent','rail'} or 'agent' in target: return (.18+.64*p,.60)
        return (.52,.58)
    if mech=='A11':
        if target in {'persistent-object','transforming-object','agent'}: return (.26+.42*p,.55)
        if 'robot' in target or 'consequence' in target: return (.68,.55)
        return (.54,.55)
    if mech=='A12':
        if 'operator' in target or target=='actor': return (.22,.58)
        if 'robot' in target or target=='persistent-object': return (.52+.08*p,.58)
        if 'fleet' in target or 'consequence' in target or 'ecosystem' in target: return (.77,.56)
        if 'data' in target or 'evidence' in target: return (.65,.44)
        return (.52,.55)
    if mech=='C12':
        if 'rail' in target or target=='persistent-object' or 'transforming' in target: return (.28+.42*p,.58)
        if 'ecosystem' in target or 'consequence' in target:return (.68,.54)
        return (.54,.56)
    if mech=='U30':
        if 'valuation' in target or 'consequence' in target:return (.56,.55)
        return (.52,.55)
    if target in {'scene-world','system-context','ecosystem','consequence-world'}: return (.5,.55)
    if target in {'actor','human','human-operator'}: return (.25,.60)
    if target in {'evidence-or-detail','new-focus-plane'}: return (.67,.48)
    return (.52,.56)

def runtime_state(scene:dict, scene_time:float)->dict:
    rt=scene.get('semanticPerformanceRuntime') or {'actions':[],'sceneDuration':float(scene.get('timingOverrideSeconds') or 1)}
    duration=max(.001,float(rt.get('sceneDuration') or 1)); t=max(0,min(duration,float(scene_time)))
    active=[]; completed=[]
    for a in rt.get('actions',[]):
        p=_action_progress(a,t)
        state=dict(a); state['progress']=p; state['phase']=_phase(p)
        if t>=float(a['end']): completed.append(state)
        if float(a['start'])<=t<=float(a['end']): active.append(state)
    current=active[-1] if active else (completed[-1] if completed else (rt.get('actions') or [None])[0])
    if current and 'progress' not in current:
        current=dict(current); current['progress']=0.0; current['phase']='idle'
    # ownership/contact truth derived from ownership-changing action timeline
    owners={rt.get('sceneGraph',{}).get('persistentEntityId'):'source'}
    contact=None
    for a in rt.get('actions',[]):
        if not a.get('ownershipChanging') or t<float(a['start']): continue
        p=_action_progress(a,t); pid=a['bindings'].get('propId')
        final=OWNERSHIP_FINAL.get(a['verb'],'target')
        if p<.15: owner='source'
        elif p<.86: owner='in-transfer'
        else: owner=final
        owners[pid]=owner
        if .68<=p<=.88: contact={'actionId':a['actionId'],'propId':pid,'targetId':a['bindings'].get('targetId'),'contactStrength':round(math.sin((p-.68)/.20*math.pi),4)}
    # Persistent-object movement has one continuous trajectory even when local actions change.
    moving=[a for a in rt.get('actions',[]) if a.get('verb') in {'route','carry-transfer','dock','deliver','assign','receive','transform'}]
    if moving:
        mv_start=min(float(a['start']) for a in moving); mv_end=max(float(a['end']) for a in moving); movement_p=clamp((t-mv_start)/max(.001,mv_end-mv_start))
    else: movement_p=clamp(t/duration)
    sh=_active_shot(scene,t)
    cam_intent=(sh or {}).get('cameraIntent') or scene.get('cameraIntent','establish')
    contract_target=CAMERAS.get(cam_intent,{}).get('target','scene-world')
    if cam_intent in {'follow-object','track-transformation'}: semantic_target='persistent-object'
    elif cam_intent=='follow-actor': semantic_target='actor'
    elif cam_intent in {'establish','reveal-ecosystem','context-pull-back'}: semantic_target=contract_target
    else: semantic_target=(sh or {}).get('semanticTarget') or scene.get('cameraTarget') or contract_target
    target_xy=_layout_point(scene,semantic_target,{'progress':movement_p})
    return {'sceneTime':round(t,4),'sceneProgress':round(t/duration,6),'movementProgress':round(movement_p,6),'activeShotId':(sh or {}).get('shotId'),'cameraIntent':cam_intent,
            'semanticTarget':semantic_target,'targetPoint':target_xy,'activeActions':active,'currentAction':current,'owners':owners,'contact':contact,
            'lifecycleState':_phase(t/duration),'actionCount':len(rt.get('actions',[]))}

def camera_state(scene, scene_time, ratio='16:9', reduced_motion=False):
    perf=runtime_state(scene,scene_time); intent=perf['cameraIntent']; c=CAMERAS.get(intent,CAMERAS['establish'])
    p=smooth(perf['sceneProgress']); start=c.get('start',{}); end=c.get('end',{})
    if reduced_motion:
        scale=float(c.get('reducedMotion',{}).get('scale',1)); x=y=0.0
    else:
        scale=lerp(float(start.get('scale',1)),float(end.get('scale',1)),p)
        tx,ty=perf['targetPoint']
        # Real target-aware framing: camera offset is derived from target location, then bounded by the contract.
        desired_x=(.5-tx)*100.0; desired_y=(.52-ty)*100.0
        max_travel=float(c.get('maxTravelPct',6))
        x=max(-max_travel,min(max_travel,desired_x))+lerp(float(start.get('x',0)),float(end.get('x',0)),p)*.20
        y=max(-max_travel,min(max_travel,desired_y))+lerp(float(start.get('y',0)),float(end.get('y',0)),p)*.20
        scale=min(float(c.get('maxScale',1.2)),max(.86,scale))
    return {'intent':intent,'target':perf['semanticTarget'],'targetPoint':perf['targetPoint'],'xPct':round(x,4),'yPct':round(y,4),'scale':round(scale,5),'purpose':c.get('storyPurpose'),'performance':perf}

def transition_state(prev_scene, scene, progress):
    rt=(scene.get('semanticPerformanceRuntime') or {}).get('transitionIn') or {'enabled':False,'type':'clean-cut'}; p=clamp(progress)
    if not rt.get('enabled'): return {'enabled':False,'type':'clean-cut','progress':p}
    continuity=rt.get('type'); q=smooth(p)
    # Scene switch occurs at midpoint, while the semantic continuity object remains continuously interpolated above the base scene.
    out_pt=_layout_point(prev_scene,'persistent-object',{'progress':1.0})
    in_pt=_layout_point(scene,'persistent-object',{'progress':0.0})
    x=lerp(out_pt[0],in_pt[0],q); y=lerp(out_pt[1],in_pt[1],q)
    scale_to=float((rt.get('scaleRelationship') or {}).get('incomingToOutgoing',1.0)); scale=lerp(1.0,scale_to,q)
    shape='capsule'; shape_mix=0.0
    if continuity=='shape-continuity': shape='morph'; shape_mix=q
    elif continuity=='media-continuity': shape='frame'; shape_mix=q
    elif continuity=='typography-continuity': shape='type-marker'; shape_mix=q
    elif continuity=='world-geometry-continuity': shape='rail'; shape_mix=q
    elif continuity=='motion-continuity': shape='moving-object'
    elif continuity=='meaning-continuity': shape='semantic-transform'; shape_mix=q
    return {'enabled':True,'type':continuity,'progress':p,'eased':q,'baseScene':'outgoing' if p<.5 else 'incoming','x':x,'y':y,'scale':scale,'shape':shape,'shapeMix':shape_mix,
            'semanticId':rt.get('persistentSemanticId') or f"{rt.get('outgoingEntityId')}→{rt.get('incomingEntityId')}",
            'outgoingEntityId':rt.get('outgoingEntityId'),'incomingEntityId':rt.get('incomingEntityId'),'identityPolicy':rt.get('identityPolicy'),'settled':p>=.92}

def plan_semantic_frame_rate(plan,default=12):
    return 24 if any((s.get('semanticPerformanceRuntime') or {}).get('nativeSmoothRequired') for s in plan.get('sceneSpecs',[])) else default
