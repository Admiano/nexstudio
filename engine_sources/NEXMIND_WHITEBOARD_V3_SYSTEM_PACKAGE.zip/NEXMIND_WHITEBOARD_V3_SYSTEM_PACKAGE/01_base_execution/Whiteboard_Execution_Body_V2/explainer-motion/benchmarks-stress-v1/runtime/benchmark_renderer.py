#!/usr/bin/env python3
from __future__ import annotations
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
import sys as _sys
_SP=Path(__file__).resolve().parents[2]/'semantic-performance-v1'/'runtime'
if str(_SP) not in _sys.path: _sys.path.insert(0,str(_SP))
import semantic_performance as sp
_WB=Path(__file__).resolve().parents[2]/'whiteboard-v1'/'runtime'
if str(_WB) not in _sys.path: _sys.path.insert(0,str(_WB))
try:
 import whiteboard_pil_adapter as wb_pil
except Exception:
 wb_pil=None
import json, math, re, textwrap, hashlib, random, io, os
from functools import lru_cache
try:
 import cairosvg
except Exception:
 cairosvg=None

ROOT=Path(__file__).resolve().parents[3]
STYLE=json.loads((ROOT/'explainer-motion/style-system-v1/manifests/style-profiles.json').read_text())['profiles']
BRANDS=json.loads((ROOT/'explainer-motion/brand-audio-finish-v1/manifests/brand-profiles.json').read_text())['profiles']
RIGS=json.loads((ROOT/'explainer-motion/mechanism-coverage-v1/manifests/certified-rig-registry.json').read_text())['rigs']
STYLE={x['id']:x for x in STYLE}; BRANDS={x['id']:x for x in BRANDS}; RIGS={x['mechanismId']:x for x in RIGS if x['rigId'].endswith('.primary')}
RATIO_SIZES={'16:9':(1280,720),'1:1':(720,720),'9:16':(540,960)}
# Pre-freeze visual hardening contracts. These are deliberately renderer-level so every
# Director plan receives the same layering, typography and asset-integration rules.
VISUAL_HARDENING_VERSION='prefreeze-1.4.0-orchestration-hardening'
CHARACTER_LAYER_ORDER=('ground-shadow','rear-limbs','torso','head','face-detail')
DECORATION_PROFILE='authored-editorial-world-v3'
HEADLINE_POLICY='fit-full-copy-no-ellipsis-v1'
TRANSITION_POLICY='exclusive-scene-lifecycle-v1'
DEBUG_OVERLAYS_DEFAULT=False
_BACKGROUND_CACHE={}
_FIT_CACHE={}
_SVG_ASSET_CACHE={}
def _first_font(*candidates):
 for raw in candidates:
  if not raw: continue
  p=Path(raw)
  if p.exists(): return str(p)
 return None

_WINDIR=Path(os.environ.get('WINDIR', r'C:\\Windows'))
FONT_SANS=_first_font(
 _WINDIR/'Fonts'/'segoeui.ttf',
 _WINDIR/'Fonts'/'arial.ttf',
 _WINDIR/'Fonts'/'calibri.ttf',
 '/usr/share/fonts/truetype/arimo/Arimo-Regular.ttf',
 '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
 '/System/Library/Fonts/Supplemental/Arial.ttf',
)
FONT_SANS_B=_first_font(
 _WINDIR/'Fonts'/'segoeuib.ttf',
 _WINDIR/'Fonts'/'arialbd.ttf',
 _WINDIR/'Fonts'/'calibrib.ttf',
 '/usr/share/fonts/truetype/arimo/Arimo-Bold.ttf',
 '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
 '/System/Library/Fonts/Supplemental/Arial Bold.ttf',
) or FONT_SANS
FONT_SERIF=_first_font(
 _WINDIR/'Fonts'/'times.ttf',
 _WINDIR/'Fonts'/'georgia.ttf',
 '/usr/share/fonts/truetype/noto/NotoSerif-Regular.ttf',
 '/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf',
 '/System/Library/Fonts/Supplemental/Times New Roman.ttf',
) or FONT_SANS
FONT_SERIF_B=_first_font(
 _WINDIR/'Fonts'/'timesbd.ttf',
 _WINDIR/'Fonts'/'georgiab.ttf',
 '/usr/share/fonts/truetype/noto/NotoSerif-Bold.ttf',
 '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf',
 '/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf',
) or FONT_SERIF

def C(hexv,alpha=255):
 h=hexv.lstrip('#');
 if len(h)==3:h=''.join(x*2 for x in h)
 return tuple(int(h[i:i+2],16) for i in (0,2,4))+(alpha,)
def mix(a,b,t): return tuple(int(a[i]*(1-t)+b[i]*t) for i in range(4))
def ease(t): return 3*t*t-2*t*t*t
def clamp(x,a=0,b=1): return max(a,min(b,x))
@lru_cache(maxsize=256)
def font(sz,bold=False,serif=False):
 size=max(8,int(sz))
 path=(FONT_SERIF_B if bold else FONT_SERIF) if serif else (FONT_SANS_B if bold else FONT_SANS)
 if path:
  try: return ImageFont.truetype(path,size)
  except OSError: pass
 return ImageFont.load_default()
def rounded(draw,box,r,fill,outline=None,width=1): draw.rounded_rectangle(tuple(map(int,box)),radius=max(1,int(r)),fill=fill,outline=outline,width=max(1,int(width)))
def line(draw,pts,fill,width): draw.line([(int(x),int(y)) for x,y in pts],fill=fill,width=max(1,int(width)),joint='curve')
def ellipse(draw,box,fill,outline=None,width=1): draw.ellipse(tuple(map(int,box)),fill=fill,outline=outline,width=max(1,int(width)))
def rgba_tuple(x): return x if len(x)==4 else x+(255,)

def palette(plan):
 b=BRANDS.get(plan.get('brand'),next(iter(BRANDS.values())))
 p=b['palette']
 return {'bg':C(p['background']),'surface':C(p['surface']),'ink':C(p['ink']),'primary':C(p['primary']),'secondary':C(p['secondary']),'accent':C(p['accent']),'muted':C(p['muted'])}

def wrap_text_full(draw,txt,fnt,maxw):
 txt=re.sub(r'\s+',' ',str(txt)).strip()
 words=txt.split(); lines=[]; cur=''
 for w in words:
  test=(cur+' '+w).strip()
  if not cur or draw.textbbox((0,0),test,font=fnt)[2] <= maxw:
   cur=test
  else:
   lines.append(cur); cur=w
 if cur: lines.append(cur)
 return lines

def fit_text(draw,txt,maxw,maxh,start_size,min_size=20,max_lines=4,bold=True,serif=False):
 # Text geometry is invariant across frames; cache it per copy/layout so animation does not re-measure glyphs.
 key=(str(txt),int(maxw),int(maxh),int(start_size),int(min_size),int(max_lines),bool(bold),bool(serif))
 if key in _FIT_CACHE:
  sz,lines,line_h=_FIT_CACHE[key]; return font(sz,bold=bold,serif=serif),list(lines),line_h
 # Never truncate display copy. Shrink and reflow until the complete sentence fits.
 for sz in range(int(start_size),int(min_size)-1,-1):
  f=font(sz,bold=bold,serif=serif); lines=wrap_text_full(draw,txt,f,maxw)
  line_h=max(1,int(sz*1.04))
  if len(lines)<=max_lines and len(lines)*line_h<=maxh:
   _FIT_CACHE[key]=(sz,tuple(lines),line_h); return f,lines,line_h
 # Absolute fallback still keeps every word; it may use one extra line rather than ellipsis.
 sz=int(min_size); f=font(sz,bold=bold,serif=serif); lines=wrap_text_full(draw,txt,f,maxw); line_h=max(1,int(sz*1.04)); _FIT_CACHE[key]=(sz,tuple(lines),line_h); return f,lines,line_h

def _local_blur_composite(im,box,paint,blur):
 # Blur only the local affected rectangle rather than the full video frame.
 x0,y0,x1,y1=map(float,box); pad=max(4,int(blur*2.4)); W,H=im.size
 ix0=max(0,int(math.floor(x0-pad))); iy0=max(0,int(math.floor(y0-pad))); ix1=min(W,int(math.ceil(x1+pad))); iy1=min(H,int(math.ceil(y1+pad)))
 if ix1<=ix0 or iy1<=iy0: return
 layer=Image.new('RGBA',(ix1-ix0,iy1-iy0),(0,0,0,0)); d=ImageDraw.Draw(layer,'RGBA'); paint(d,-ix0,-iy0)
 if blur>0: layer=layer.filter(ImageFilter.GaussianBlur(max(1,int(blur))))
 im.alpha_composite(layer,(ix0,iy0))

def soft_blob(im,box,fill,blur=24,irregularity=.12):
 x0,y0,x1,y1=box; bw=x1-x0; bh=y1-y0; base=rgba_tuple(fill); alpha=min(base[3],92)
 def paint(d,ox,oy):
  d.ellipse(tuple(map(int,(x0+ox,y0+oy,x1+ox,y1+oy))),fill=base[:3]+(alpha,))
  d.ellipse(tuple(map(int,(x0-bw*.05+ox,y0+bh*.12+oy,x1-bw*.10+ox,y1+bh*.07+oy))),fill=base[:3]+(int(alpha*.34),))
  d.ellipse(tuple(map(int,(x0+bw*.11+ox,y0-bh*.035+oy,x1+bw*.04+ox,y1-bh*.10+oy))),fill=base[:3]+(int(alpha*.28),))
 _local_blur_composite(im,box,paint,max(6,int(blur)))

def soft_shadow(im,box,alpha=34,blur=12):
 # Lightweight stepped feather. Keeps grounding subtle without a hard black oval or per-frame Gaussian cost.
 x0,y0,x1,y1=map(float,box); W,H=im.size; pad=max(2,int((y1-y0)*.45))
 ix0=max(0,int(x0-pad)); iy0=max(0,int(y0-pad)); ix1=min(W,int(x1+pad)); iy1=min(H,int(y1+pad))
 if ix1<=ix0 or iy1<=iy0:return
 layer=Image.new('RGBA',(ix1-ix0,iy1-iy0),(0,0,0,0)); d=ImageDraw.Draw(layer,'RGBA')
 for frac,a in ((1.0,.18),(.72,.22),(.45,.25)):
  cx=(x0+x1)/2-ix0; cy=(y0+y1)/2-iy0; rx=(x1-x0)/2*(1+.32*frac); ry=(y1-y0)/2*(1+.22*frac)
  d.ellipse((int(cx-rx),int(cy-ry),int(cx+rx),int(cy+ry)),fill=(0,0,0,int(alpha*a)))
 im.alpha_composite(layer,(ix0,iy0))

def draw_background(im,draw,plan,ratio,progress):
 pal=palette(plan); style=plan.get('styleProfile','')
 draw.rectangle((0,0,*im.size),fill=pal['bg'])
 w,h=im.size
 if 'spatial' in style:
  step=max(42,int(min(w,h)*.085)); col=mix(pal['bg'],pal['primary'],.095)
  for x in range(-step,w+step,step): line(draw,[(x,0),(x,h)],col,1)
  for y in range(-step,h+step,step): line(draw,[(0,y),(w,y)],col,1)
  # depth plane is low contrast and belongs behind the mechanism
  plane=Image.new('RGBA',im.size,(0,0,0,0)); pd=ImageDraw.Draw(plane,'RGBA')
  pd.polygon([(0,int(h*.82)),(w,int(h*.69)),(w,h),(0,h)],fill=mix(pal['bg'],pal['surface'],.28))
  im.alpha_composite(plane)
 elif 'illustrated' in style:
  # Editorial atmosphere: soft, irregular, feathered masses. No hard clipped circles.
  q=mix(pal['bg'],pal['secondary'],.15); a=mix(pal['bg'],pal['accent'],.18)
  soft_blob(im,(-w*.17,-h*.23,w*.36,h*.50),q,blur=max(24,int(min(w,h)*.045)))
  soft_blob(im,(w*.72,h*.67,w*1.08,h*1.04),a,blur=max(22,int(min(w,h)*.04)))
 elif 'product' in style:
  draw.rectangle((0,int(h*.84),w,h),fill=mix(pal['bg'],pal['primary'],.028))
  # tiny ambient lights are intentionally subordinate to the product surface
  for i in range(4):
   x=int(w*(.79+i*.045)); y=int(h*.085); ellipse(draw,(x,y,x+3,y+3),mix(pal['bg'],pal['primary'],.18))

def layout(im,ratio):
 w,h=im.size
 # More canvas is allocated to the mechanism; the headline supports rather than dominates it.
 if ratio=='16:9': return {'margin':int(w*.055),'headline':(int(w*.055),int(h*.055),int(w*.91),int(h*.235)),'stage':(int(w*.045),int(h*.245),int(w*.955),int(h*.925)),'footer_y':int(h*.955)}
 if ratio=='1:1': return {'margin':int(w*.065),'headline':(int(w*.065),int(h*.05),int(w*.935),int(h*.235)),'stage':(int(w*.055),int(h*.245),int(w*.945),int(h*.91)),'footer_y':int(h*.95)}
 return {'margin':int(w*.075),'headline':(int(w*.075),int(h*.045),int(w*.925),int(h*.215)),'stage':(int(w*.06),int(h*.225),int(w*.94),int(h*.90)),'footer_y':int(h*.94)}

def headline(im,draw,scene,plan,ratio,hide_text=False):
 if hide_text:return
 pal=palette(plan); L=layout(im,ratio); x0,y0,x1,y1=L['headline']; w,h=im.size
 has_copy='screenCopy' in scene; copy=scene.get('screenCopy') or {}; mode=copy.get('mode','')
 primary=copy.get('primary'); secondary=copy.get('secondary')
 if has_copy and not primary and not secondary:return
 if mode in ('silent','minimal') and not primary and not secondary:return
 if not primary and not secondary:
  # legacy-plan compatibility only; new orchestration plans never use VO as a headline.
  primary=re.sub(r'\s+',' ',scene.get('sourceText','')).strip()
 serif='illustrated' in plan.get('styleProfile','')
 start_size=(58 if ratio=='16:9' else 46 if ratio=='1:1' else 40)
 start_size*=w/1280 if ratio=='16:9' else w/720 if ratio=='1:1' else w/540
 start_size=max(26,start_size)
 yy=y0
 if primary:
  f,lines,line_h=fit_text(draw,primary,x1-x0,(y1-y0)*.58,start_size,max(22,int(start_size*.66)),2,bold=True,serif=serif)
  for ln in lines: draw.text((x0,yy),ln,font=f,fill=pal['ink']); yy+=line_h
 if secondary:
  sf_size=max(14,int(start_size*.40)); sf=font(sf_size,bold=True,serif=False)
  lines=wrap_text_full(draw,secondary,sf,x1-x0)
  yy=max(yy,y0+int((y1-y0)*.50))
  for ln in lines[:2]: draw.text((x0,yy),ln,font=sf,fill=mix(pal['primary'],pal['ink'],.16)); yy+=int(sf_size*1.10)

def footer(im,draw,scene,plan,ratio,hide_text=False):
 # Beat IDs and renderer state are production-debug metadata, not customer-facing design.
 if hide_text or not plan.get('_debugOverlays',DEBUG_OVERLAYS_DEFAULT): return
 pal=palette(plan); L=layout(im,ratio); y=L['footer_y']; m=L['margin']; w,h=im.size
 f=font(max(9,int(min(w,h)*.014)),bold=True)
 tag=f"{scene.get('visualVerb','').upper()}  ·  {scene.get('beatId','')}"
 draw.text((m,y),tag,font=f,fill=mix(pal['ink'],pal['bg'],.58))

def _round_line(draw,a,b,fill,width):
 # A capsule-like stroke keeps limbs/material rails from reading as bare vector wires.
 width=max(2,int(width)); draw.line([(int(a[0]),int(a[1])),(int(b[0]),int(b[1]))],fill=fill,width=width)
 rr=width/2
 for x,y in (a,b): draw.ellipse((int(x-rr),int(y-rr),int(x+rr),int(y+rr)),fill=fill)

def person(draw,cx,cy,scale,pal,gesture=0,secondary=False,im=None):
 # Premium semantic Z-order: ground -> rear legs/arms -> torso/clothes -> neck/head/hair -> face.
 # Rear limbs remain behind the body/head, but the rig has enough material construction to feel illustrated rather than assembled.
 ink=mix(pal['ink'],pal['bg'],.08); skin=mix(pal['accent'],pal['surface'],.36) if not secondary else mix(pal['secondary'],pal['surface'],.30)
 body=pal['primary'] if not secondary else pal['secondary']; trouser=mix(ink,body,.14); shoe=mix(ink,pal['bg'],.04)
 lw=max(5,int(scale*.052)); armw=max(5,int(scale*.058)); r=scale*.112
 if im is not None:
  soft_shadow(im,(cx-scale*.25,cy+scale*.40,cx+scale*.25,cy+scale*.49),alpha=24,blur=max(5,int(scale*.045)))
 # REAR legs: upper/lower strokes plus shoes, always behind torso.
 hipL=(cx-scale*.075,cy+scale*.08); hipR=(cx+scale*.075,cy+scale*.08)
 kneeL=(cx-scale*.12,cy+scale*.25); kneeR=(cx+scale*.11,cy+scale*.25)
 footL=(cx-scale*.18,cy+scale*.43); footR=(cx+scale*.18,cy+scale*.43)
 _round_line(draw,hipL,kneeL,trouser,lw); _round_line(draw,kneeL,footL,trouser,lw)
 _round_line(draw,hipR,kneeR,trouser,lw); _round_line(draw,kneeR,footR,trouser,lw)
 fw=max(5,int(scale*.040))
 rounded(draw,(footL[0]-fw*1.6,footL[1]-fw*.42,footL[0]+fw*1.7,footL[1]+fw*.50),fw*.55,shoe)
 rounded(draw,(footR[0]-fw*1.5,footR[1]-fw*.42,footR[0]+fw*1.8,footR[1]+fw*.50),fw*.55,shoe)
 # REAR arms: sleeves connect naturally into forearms/hands. Gesture changes the working arm only.
 shoulderL=(cx-scale*.13,cy-scale*.18); shoulderR=(cx+scale*.13,cy-scale*.18)
 ang=-.62 + gesture*.78
 elbowR=(cx+math.cos(ang)*scale*.22,cy-scale*.17+math.sin(ang)*scale*.20)
 handR=(cx+math.cos(ang)*scale*.36,cy-scale*.17+math.sin(ang)*scale*.34)
 elbowL=(cx-scale*.24,cy-scale*.04); handL=(cx-scale*.31,cy+scale*.04)
 _round_line(draw,shoulderR,elbowR,mix(body,ink,.06),armw); _round_line(draw,elbowR,handR,skin,max(4,int(armw*.72)))
 _round_line(draw,shoulderL,elbowL,mix(body,ink,.06),armw); _round_line(draw,elbowL,handL,skin,max(4,int(armw*.72)))
 hr=max(3,int(scale*.030))
 for hx,hy in (handR,handL): ellipse(draw,(hx-hr,hy-hr,hx+hr,hy+hr),skin)
 # TORSO: slightly tapered jacket/shirt silhouette instead of a generic rounded block.
 top=cy-scale*.31; bot=cy+scale*.16; half_top=scale*.17; half_bot=scale*.145
 draw.polygon([(int(cx-half_top),int(top+scale*.06)),(int(cx-half_bot),int(bot)),(int(cx+half_bot),int(bot)),(int(cx+half_top),int(top+scale*.06))],fill=body)
 rounded(draw,(cx-half_top,top,cx+half_top,bot),scale*.105,body,mix(body,pal['ink'],.12),max(1,int(scale*.012)))
 # collar/seam and tiny pocket give the flat shape intentional clothing construction.
 seam=mix(body,pal['surface'],.22); line(draw,[(cx,top+scale*.06),(cx,bot-scale*.04)],seam,max(1,int(scale*.010)))
 rounded(draw,(cx+scale*.055,cy-scale*.055,cx+scale*.115,cy-scale*.010),scale*.012,mix(body,pal['surface'],.17))
 # Neck + head occlude all upper limb roots.
 rounded(draw,(cx-scale*.046,cy-scale*.36,cx+scale*.046,cy-scale*.27),scale*.028,skin)
 ellipse(draw,(cx-r,cy-scale*.43-r,cx+r,cy-scale*.43+r),skin,mix(skin,pal['ink'],.12),max(1,int(scale*.010)))
 # Back/top hair mass sits on the head, not as a detached circle.
 hair=mix(ink,body,.08); hb=(cx-r*.98,cy-scale*.43-r*.98,cx+r*.98,cy-scale*.43+r*.22)
 draw.pieslice(tuple(map(int,hb)),180,355,fill=hair)
 # Ear + face marks establish orientation and warmth without requiring a detailed face asset.
 earx=cx-r*.94; eary=cy-scale*.43; er=max(2,int(scale*.020)); ellipse(draw,(earx-er,eary-er,earx+er,eary+er),skin)
 eye_r=max(1,int(scale*.010)); ex=cx+r*.34; ey=cy-scale*.455
 ellipse(draw,(ex-eye_r,ey-eye_r,ex+eye_r,ey+eye_r),mix(pal['ink'],skin,.08))
 line(draw,[(cx+r*.30,cy-scale*.405),(cx+r*.48,cy-scale*.398)],mix(pal['ink'],skin,.22),max(1,int(scale*.008)))

def token(draw,x,y,r,pal,label='',active=False,im=None):
 # Persistent semantic objects use a small document/package capsule rather than a pasted circle.
 # Numeric branch particles and check markers remain compact nodes.
 fill=pal['accent'] if active else pal['primary']; rim=mix(fill,pal['ink'],.22)
 lab=str(label or '').strip(); particle=(not lab) or lab.isdigit() or lab in ('✓','+','•')
 if particle:
  if im is not None: soft_shadow(im,(x-r*.82,y+r*.58,x+r*.82,y+r*1.02),alpha=20,blur=max(4,int(r*.26)))
  ellipse(draw,(x-r,y-r,x+r,y+r),fill,rim,max(1,int(r*.045)))
  ellipse(draw,(x-r*.48,y-r*.54,x+r*.14,y+r*.06),mix(fill,pal['surface'],.18))
  if lab:
   f=font(max(8,int(r*.42)),bold=True); bb=draw.textbbox((0,0),lab,font=f); draw.text((x-(bb[2]-bb[0])/2,y-(bb[3]-bb[1])/2-1),lab,font=f,fill=mix(pal['ink'],fill,.08))
  return
 # Document/package object: stable identity across scenes, with folded corner and state stripe.
 ww=r*2.65; hh=r*1.72
 if im is not None: soft_shadow(im,(x-ww*.44,y+hh*.35,x+ww*.44,y+hh*.58),alpha=22,blur=max(4,int(r*.24)))
 base=mix(pal['surface'],fill,.075)
 rounded(draw,(x-ww*.5,y-hh*.5,x+ww*.5,y+hh*.5),r*.34,base,rim,max(1,int(r*.060)))
 # left semantic state stripe + two content lines
 rounded(draw,(x-ww*.41,y-hh*.34,x-ww*.31,y+hh*.34),r*.055,fill)
 for i,wf in enumerate((.52,.38)):
  yy=y-hh*.18+i*hh*.25
  rounded(draw,(x-ww*.20,yy-r*.055,x-ww*.20+ww*wf,yy+r*.055),r*.055,mix(pal['muted'],pal['surface'],.38))
 # quiet active seal on the trailing corner; behind-text capsule avoids icon/sticker feel.
 if active:
  sr=r*.20; sx=x+ww*.31; sy=y+hh*.24; ellipse(draw,(sx-sr,sy-sr,sx+sr,sy+sr),fill)


def paper_sheet(draw,x,y,w,h,pal,accent=None,tilt=0,im=None,active=1.0):
 # Compact evidence/document primitive with visible material hierarchy.
 accent=accent or pal['primary']
 if im is not None: soft_shadow(im,(x-w*.42,y+h*.36,x+w*.42,y+h*.55),alpha=16,blur=max(4,int(min(w,h)*.12)))
 base=mix(pal['surface'],accent,.045)
 rounded(draw,(x-w*.5,y-h*.5,x+w*.5,y+h*.5),min(w,h)*.12,base,mix(accent,pal['ink'],.14),max(1,int(min(w,h)*.025)))
 # folded corner / state flag
 fc=min(w,h)*.18
 draw.polygon([(int(x+w*.5-fc),int(y-h*.5)),(int(x+w*.5),int(y-h*.5+fc)),(int(x+w*.5),int(y-h*.5))],fill=mix(accent,pal['surface'],.28))
 for i,wf in enumerate((.62,.78,.45)):
  yy=y-h*.20+i*h*.19
  rounded(draw,(x-w*.29,yy-h*.025,x-w*.29+w*.58*wf,yy+h*.025),h*.022,mix(pal['muted'],pal['surface'],.42))
 if active>.65:
  rr=min(w,h)*.085; ellipse(draw,(x+w*.30-rr,y+h*.28-rr,x+w*.30+rr,y+h*.28+rr),accent)

def role_station(draw,x,y,w,h,pal,accent,kind='work',im=None,active=.5):
 # A small physical workstation—not a dashboard card—used as a causal anchor.
 if im is not None: soft_shadow(im,(x-w*.45,y+h*.37,x+w*.45,y+h*.55),alpha=15,blur=max(4,int(h*.11)))
 rounded(draw,(x-w*.5,y-h*.5,x+w*.5,y+h*.5),h*.15,mix(pal['surface'],accent,.055),mix(accent,pal['ink'],.13),2)
 # work surface / screen well
 rounded(draw,(x-w*.34,y-h*.28,x+w*.34,y+h*.06),h*.09,mix(pal['bg'],accent,.055),mix(pal['muted'],pal['bg'],.18),1)
 # semantic glyphs: search lens / bars / validation ticks, kept icon-light and embedded in apparatus.
 if kind=='search':
  rr=h*.10; ellipse(draw,(x-rr*1.3,y-rr*1.2,x+rr*.7,y+rr*.8),None,accent,max(2,int(h*.035))); line(draw,[(x+rr*.45,y+rr*.55),(x+rr*1.25,y+rr*1.35)],accent,max(2,int(h*.035)))
 elif kind=='data':
  for i,v in enumerate((.34,.62,.86)):
   bw=w*.08; xx=x-w*.15+i*w*.14; draw.rectangle((int(xx),int(y+h*.02-h*.22*v),int(xx+bw),int(y+h*.02)),fill=accent)
 elif kind=='review':
  for i in range(3):
   yy=y-h*.17+i*h*.14; line(draw,[(x-w*.16,yy),(x-w*.08,yy+h*.05),(x+w*.16,yy-h*.04)],accent,max(2,int(h*.025)))
 else:
  for i in range(3):
   xx=x-w*.17+i*w*.17; rr=h*.045; ellipse(draw,(xx-rr,y-rr,xx+rr,y+rr),accent if active>(i+1)*.22 else mix(pal['muted'],pal['surface'],.34))
 # under-shelf gives weight / place
 line(draw,[(x-w*.40,y+h*.32),(x+w*.40,y+h*.32)],mix(pal['ink'],pal['bg'],.72),max(2,int(h*.035)))

def semantic_environment(im,draw,scene,plan,ratio,box,active):
 # Story-world context lives behind the main mechanism. It is intentionally low-contrast,
 # but gives each domain a place, scale and material language instead of floating diagrams.
 pal=palette(plan); x0,y0,x1,y1,sw,sh=stage_coords(box); style=plan.get('styleProfile',''); mech=scene.get('mechanismId',''); fam=scene.get('visualizationFamily','')
 # common floor horizon / staging plane
 horizon=y0+sh*(.84 if ratio!='9:16' else .89)
 col=mix(pal['bg'],pal['ink'],.08 if 'spatial' not in style else .12)
 line(draw,[(x0+sw*.03,horizon),(x1-sw*.03,horizon)],col,max(1,int(min(sw,sh)*.003)))
 # AI/editorial: research-studio backdrop with shelves/evidence rails, deliberately asymmetric.
 if mech.startswith('A') or ('illustrated' in style and 'product' not in fam):
  shelf_y=y0+sh*.18
  line(draw,[(x0+sw*.04,shelf_y),(x0+sw*.31,shelf_y)],mix(pal['ink'],pal['bg'],.84),max(1,int(sw*.002)))
  for i in range(4):
   xx=x0+sw*(.06+i*.055); hh=sh*(.045+.012*(i%2)); rounded(draw,(xx,shelf_y-hh,xx+sw*.022,shelf_y),max(2,int(sw*.004)),mix(pal['surface'],[pal['secondary'],pal['primary'],pal['accent']][i%3],.12))
  # evidence pin rail on far right creates continuity across scenes
  rx=x1-sw*.055
  line(draw,[(rx,y0+sh*.23),(rx,y0+sh*.70)],mix(pal['ink'],pal['bg'],.88),max(1,int(sw*.002)))
  for j in range(3):
   yy=y0+sh*(.30+j*.14); rr=max(2,int(min(sw,sh)*.008)); ellipse(draw,(rx-rr,yy-rr,rx+rr,yy+rr),mix(pal['accent'],pal['surface'],.22))
 # Crypto/spatial: ledger floor + block ticks; richer than an empty grid but still subordinate.
 if mech.startswith('C') or 'spatial' in style:
  ly=y0+sh*.77
  line(draw,[(x0+sw*.05,ly),(x1-sw*.05,ly)],mix(pal['primary'],pal['bg'],.68),max(2,int(sw*.003)))
  for i in range(8):
   xx=x0+sw*(.07+i*.11); hh=sh*(.018 if i%2 else .028); draw.rectangle((int(xx),int(ly-hh),int(xx+sw*.018),int(ly+hh)),fill=mix(pal['primary'],pal['bg'],.62))
 # Product story: stage reads as a service environment with product and customer zones.
 if 'product' in style:
  # vertical product spine at left, customer outcome rail at right
  line(draw,[(x0+sw*.035,y0+sh*.14),(x0+sw*.035,y0+sh*.72)],mix(pal['primary'],pal['bg'],.84),max(1,int(sw*.002)))
  line(draw,[(x1-sw*.035,y0+sh*.42),(x1-sw*.035,y0+sh*.72)],mix(pal['accent'],pal['bg'],.84),max(1,int(sw*.002)))


# --- Creative Finish v1.3 -------------------------------------------------
# The following primitives deliberately replace the earlier geometric-vocabulary
# ceiling with authored-looking editorial material, depth and role-specific props.
# They remain deterministic and shared across Director plans.

def _poly(draw, pts, fill, outline=None, width=1):
 draw.polygon([(int(x),int(y)) for x,y in pts],fill=fill)
 if outline:
  draw.line([(int(x),int(y)) for x,y in pts+[pts[0]]],fill=outline,width=max(1,int(width)),joint='curve')

def iso_block(draw,x,y,w,h,depth,pal,accent,im=None,active=.7):
 """Small isometric material block used for crypto/product infrastructure."""
 if im is not None: soft_shadow(im,(x-w*.55,y+h*.48,x+w*.75,y+h*.75),alpha=18,blur=max(4,int(h*.10)))
 top=mix(pal['surface'],accent,.11); side=mix(pal['bg'],accent,.13); front=mix(pal['surface'],accent,.055); edge=mix(accent,pal['ink'],.16)
 _poly(draw,[(x-w*.5,y-h*.45),(x+w*.32,y-h*.45),(x+w*.5,y-h*.45+depth),(x-w*.32,y-h*.45+depth)],top,edge,1)
 _poly(draw,[(x+w*.32,y-h*.45),(x+w*.5,y-h*.45+depth),(x+w*.5,y+h*.45),(x+w*.32,y+h*.45-depth)],side,edge,1)
 _poly(draw,[(x-w*.5,y-h*.45),(x+w*.32,y-h*.45),(x+w*.32,y+h*.45-depth),(x-w*.5,y+h*.45)],front,edge,1)
 # embedded state aperture
 aw=w*.36; ah=h*.12
 rounded(draw,(x-w*.30,y-h*.02,x-w*.30+aw,y-h*.02+ah),ah*.45,accent if active>.55 else mix(pal['muted'],pal['surface'],.35))

def desk(draw,x,y,w,h,pal,accent,im=None,active=.7,kind='research'):
 """Editorial workbench with material objects rather than a floating UI card."""
 if im is not None: soft_shadow(im,(x-w*.53,y+h*.28,x+w*.53,y+h*.54),alpha=20,blur=max(5,int(h*.10)))
 wood=mix(pal['surface'],pal['ink'],.035); edge=mix(pal['ink'],pal['bg'],.70)
 rounded(draw,(x-w*.52,y-h*.02,x+w*.52,y+h*.12),h*.07,wood,edge,1)
 # legs recede behind desktop
 lw=max(3,int(h*.045)); line(draw,[(x-w*.42,y+h*.10),(x-w*.37,y+h*.50)],edge,lw); line(draw,[(x+w*.42,y+h*.10),(x+w*.37,y+h*.50)],edge,lw)
 # monitor / physical tool frame
 mw=w*.42; mh=h*.46; mx=x-w*.05; my=y-h*.30
 rounded(draw,(mx-mw*.5,my-mh*.5,mx+mw*.5,my+mh*.5),h*.08,mix(pal['bg'],accent,.055),mix(accent,pal['ink'],.18),max(1,int(h*.025)))
 rounded(draw,(mx-mw*.40,my-mh*.34,mx+mw*.40,my+mh*.22),h*.045,mix(pal['surface'],accent,.035))
 line(draw,[(mx,my+mh*.22),(mx,my+mh*.48)],edge,max(2,int(h*.025))); line(draw,[(mx-mw*.16,my+mh*.48),(mx+mw*.16,my+mh*.48)],edge,max(2,int(h*.025)))
 # role-specific visual content
 if kind=='research':
  rr=h*.055; ellipse(draw,(mx-rr*1.7,my-rr*1.55,mx+rr*.3,my+rr*.45),None,accent,max(2,int(h*.026))); line(draw,[(mx+rr*.05,my+rr*.20),(mx+rr*1.25,my+rr*1.35)],accent,max(2,int(h*.026)))
 elif kind=='data':
  for i,v in enumerate((.35,.62,.88,.70)):
   bw=mw*.09; xx=mx-mw*.25+i*mw*.16; draw.rectangle((int(xx),int(my+mh*.13-mh*.34*v),int(xx+bw),int(my+mh*.13)),fill=accent)
 elif kind=='review':
  for i in range(3):
   yy=my-mh*.19+i*mh*.17; line(draw,[(mx-mw*.20,yy),(mx-mw*.12,yy+mh*.06),(mx+mw*.20,yy-mh*.04)],accent,max(2,int(h*.022)))
 else:
  for i in range(3):
   xx=mx-mw*.20+i*mw*.20; rr=h*.035; ellipse(draw,(xx-rr,my-rr,xx+rr,my+rr),accent if active>(i+1)*.20 else mix(pal['muted'],pal['surface'],.34))
 # tangible notes / mug
 paper_sheet(draw,x+w*.30,y-h*.05,w*.20,h*.24,pal,accent,im=im,active=active)
 mugx=x-w*.34; mugy=y-h*.05; rr=h*.055; ellipse(draw,(mugx-rr,mugy-rr,mugx+rr,mugy+rr),mix(pal['surface'],accent,.12),accent,1); ellipse(draw,(mugx+rr*.55,mugy-rr*.55,mugx+rr*1.45,mugy+rr*.55),None,accent,max(1,int(h*.02)))

def paper_sheet(draw,x,y,w,h,pal,accent=None,tilt=0,im=None,active=1.0):
 """Authored evidence sheet with layered paper edge, fold and handwritten-like marks."""
 accent=accent or pal['primary']
 if im is not None: soft_shadow(im,(x-w*.44,y+h*.37,x+w*.44,y+h*.60),alpha=18,blur=max(4,int(min(w,h)*.11)))
 edge=mix(accent,pal['ink'],.16); back=mix(pal['surface'],accent,.025); base=mix(pal['surface'],accent,.055)
 rounded(draw,(x-w*.48+3,y-h*.48+4,x+w*.52+3,y+h*.52+4),min(w,h)*.10,back,mix(pal['muted'],pal['bg'],.20),1)
 rounded(draw,(x-w*.5,y-h*.5,x+w*.5,y+h*.5),min(w,h)*.11,base,edge,max(1,int(min(w,h)*.022)))
 fc=min(w,h)*.18
 _poly(draw,[(x+w*.5-fc,y-h*.5),(x+w*.5,y-h*.5+fc),(x+w*.5,y-h*.5)],mix(accent,pal['surface'],.26))
 # title band + varied ink strokes
 rounded(draw,(x-w*.32,y-h*.30,x+w*.12,y-h*.21),h*.025,mix(pal['ink'],pal['surface'],.78))
 for i,wf in enumerate((.76,.58,.82,.42)):
  yy=y-h*.08+i*h*.15
  rounded(draw,(x-w*.31,yy-h*.020,x-w*.31+w*.60*wf,yy+h*.020),h*.018,mix(pal['muted'],pal['surface'],.44))
 if active>.56:
  sx=x+w*.30; sy=y+h*.27; sr=min(w,h)*.092; ellipse(draw,(sx-sr,sy-sr,sx+sr,sy+sr),accent)
  if active>.76: line(draw,[(sx-sr*.45,sy),(sx-sr*.10,sy+sr*.32),(sx+sr*.52,sy-sr*.40)],pal['surface'],max(1,int(sr*.18)))

def role_station(draw,x,y,w,h,pal,accent,kind='work',im=None,active=.5):
 """Role station becomes a small authored workspace with desk, monitor and material evidence."""
 desk(draw,x,y,w,h,pal,accent,im=im,active=active,kind={'search':'research','data':'data','review':'review'}.get(kind,'work'))

def person(draw,cx,cy,scale,pal,gesture=0,secondary=False,im=None):
 """Editorial character v3: proportioned silhouette, layered limbs, clothing construction and readable face direction."""
 ink=mix(pal['ink'],pal['bg'],.06); skin=mix(pal['accent'],pal['surface'],.34) if not secondary else mix(pal['secondary'],pal['surface'],.32)
 coat=pal['primary'] if not secondary else pal['secondary']; coat_dark=mix(coat,ink,.16); pants=mix(ink,coat,.10); shoe=mix(ink,pal['bg'],.02)
 S=float(scale); head_r=S*.102; torso_h=S*.37; shoulder=S*.145; hip=S*.115
 if im is not None: soft_shadow(im,(cx-S*.23,cy+S*.41,cx+S*.24,cy+S*.50),alpha=28,blur=max(5,int(S*.04)))
 # rear legs with trousers as tapered polygons (not sticks)
 hipy=cy+S*.10; knee_y=cy+S*.25; foot_y=cy+S*.43
 for side in (-1,1):
  hx=cx+side*S*.065; kx=cx+side*S*(.10+.018*(1-gesture)); fx=cx+side*S*(.15+.018*gesture)
  _poly(draw,[(hx-side*S*.035,hipy),(hx+side*S*.035,hipy),(kx+side*S*.030,knee_y),(kx-side*S*.030,knee_y)],pants)
  _poly(draw,[(kx-side*S*.030,knee_y),(kx+side*S*.030,knee_y),(fx+side*S*.025,foot_y),(fx-side*S*.035,foot_y)],pants)
  rounded(draw,(fx-S*.050,foot_y-S*.016,fx+S*.062,foot_y+S*.025),S*.022,shoe)
 # rear arms: sleeve then forearm, hands remain behind torso/head
 sh_y=cy-S*.17
 arm_swing=(gesture-.5)*S*.16
 left_sh=(cx-shoulder,sh_y); left_el=(cx-S*.23,cy-S*.03-arm_swing*.18); left_hand=(cx-S*.31,cy+S*.035-arm_swing*.35)
 right_sh=(cx+shoulder,sh_y); right_el=(cx+S*.22,cy-S*.05-arm_swing*.75); right_hand=(cx+S*.31,cy-S*.01-arm_swing*1.15)
 for a,b,c in ((left_sh,left_el,left_hand),(right_sh,right_el,right_hand)):
  _round_line(draw,a,b,coat_dark,max(6,int(S*.055))); _round_line(draw,b,c,skin,max(5,int(S*.043)))
  rr=S*.028; ellipse(draw,(c[0]-rr,c[1]-rr,c[0]+rr,c[1]+rr),skin)
 # torso / jacket with shoulder shape and subtle lapel
 top=cy-S*.29; bot=cy+S*.14
 _poly(draw,[(cx-shoulder,top+S*.05),(cx-S*.11,bot),(cx+S*.11,bot),(cx+shoulder,top+S*.05),(cx+S*.09,top-S*.01),(cx-S*.09,top-S*.01)],coat,mix(coat,ink,.12),1)
 # shirt/lapel wedge and seam
 shirt=mix(pal['surface'],skin,.02); _poly(draw,[(cx-S*.050,top+S*.02),(cx,top+S*.13),(cx+S*.050,top+S*.02)],shirt)
 line(draw,[(cx,top+S*.12),(cx,bot-S*.025)],mix(coat,pal['surface'],.22),max(1,int(S*.008)))
 rounded(draw,(cx+S*.045,cy-S*.035,cx+S*.100,cy+S*.005),S*.010,mix(coat,pal['surface'],.20))
 # neck then head
 rounded(draw,(cx-S*.038,cy-S*.35,cx+S*.038,cy-S*.27),S*.026,skin)
 hy=cy-S*.43; ellipse(draw,(cx-head_r,hy-head_r,cx+head_r,hy+head_r),skin,mix(skin,ink,.15),max(1,int(S*.008)))
 # hair with asymmetric editorial silhouette
 hair=mix(ink,coat,.06); _poly(draw,[(cx-head_r*.98,hy-head_r*.26),(cx-head_r*.76,hy-head_r*.90),(cx+head_r*.16,hy-head_r*1.02),(cx+head_r*.94,hy-head_r*.48),(cx+head_r*.78,hy-head_r*.18),(cx-head_r*.70,hy-head_r*.10)],hair)
 # ear, eye, nose, brow, smile
 er=S*.018; ellipse(draw,(cx-head_r*.98-er,hy-er,cx-head_r*.98+er,hy+er),skin)
 eye=(cx+head_r*.33,hy-head_r*.08); rr=max(1,int(S*.008)); ellipse(draw,(eye[0]-rr,eye[1]-rr,eye[0]+rr,eye[1]+rr),ink)
 line(draw,[(cx+head_r*.22,hy-head_r*.25),(cx+head_r*.50,hy-head_r*.23)],mix(ink,skin,.10),max(1,int(S*.007)))
 line(draw,[(cx+head_r*.51,hy+head_r*.02),(cx+head_r*.60,hy+head_r*.11)],mix(ink,skin,.18),max(1,int(S*.006)))
 line(draw,[(cx+head_r*.27,hy+head_r*.38),(cx+head_r*.52,hy+head_r*.34)],mix(ink,skin,.22),max(1,int(S*.007)))
 # small badge gives role specificity
 br=S*.018; ellipse(draw,(cx-S*.075-br,cy-S*.08-br,cx-S*.075+br,cy-S*.08+br),pal['accent'] if not secondary else pal['primary'])

def _rgb_hex(c):
 try:return '#%02x%02x%02x'%tuple(int(max(0,min(255,v))) for v in c[:3])
 except Exception:return '#ffffff'

def _source_asset_image(binding,width,height,pal=None):
 path=ROOT/str(binding.get('sourcePath') or '')
 if not binding.get('sourceBacked') or not path.exists() or path.suffix.lower()!='.svg' or cairosvg is None:return None
 pkey=tuple(_rgb_hex(pal[k]) for k in ('surface','ink','primary','secondary','accent') if pal and k in pal)
 key=(str(path),int(width),int(height),pkey)
 if key in _SVG_ASSET_CACHE:return _SVG_ASSET_CACHE[key].copy()
 try:
  # The recovered master icons use CSS variables. Bind those variables to the active
  # Explainer palette while preserving the original SVG geometry and layers.
  if 'registry-icons' in str(path) and pal:
   svg=path.read_text()
   repl={
    'var(--paper-surface)':_rgb_hex(pal['surface']),
    'var(--ink)':_rgb_hex(pal['ink']),
    'var(--primary)':_rgb_hex(pal['primary']),
    'var(--secondary)':_rgb_hex(pal['secondary']),
    'var(--accent)':_rgb_hex(pal['accent']),
    'var(--highlight)':_rgb_hex(mix(pal['secondary'],pal['surface'],.25)),
   }
   for a,b in repl.items():svg=svg.replace(a,b)
   png=cairosvg.svg2png(bytestring=svg.encode(),output_width=max(96,int(width*1.6)),output_height=max(96,int(height*1.6)))
  else:
   png=cairosvg.svg2png(url=str(path),output_width=max(96,int(width*1.6)),output_height=max(96,int(height*1.6)))
  raw=Image.open(io.BytesIO(png)).convert('RGBA')
  # Remove exporter/viewBox dead space so authored assets occupy their intended hero/support area.
  alpha=raw.getchannel('A'); bbox=alpha.getbbox()
  if bbox:raw=raw.crop(bbox)
  scale=min(float(width)/max(1,raw.width),float(height)/max(1,raw.height))
  nw=max(1,int(raw.width*scale)); nh=max(1,int(raw.height*scale))
  asset=raw.resize((nw,nh),Image.Resampling.LANCZOS)
  _SVG_ASSET_CACHE[key]=asset.copy();return asset
 except Exception:return None

def _render_binding_at(im,draw,x,y,size,pal,binding,accent=None):
 asset=_source_asset_image(binding,size,size,pal)
 if asset is not None:
  im.alpha_composite(asset,(int(x-asset.width/2),int(y-asset.height/2)))
  return True
 _asset_glyph(draw,x,y,size,pal,binding,accent)
 return False

def _composite_source_binding(im,scene,box,active,preferred_id=None):
 pal=scene.get('_runtimePalette')
 bindings=[b for b in (scene.get('assetResolution') or {}).get('bindings',[]) if b.get('sourceBacked')]
 if preferred_id:
  exact=[b for b in bindings if preferred_id in str(b.get('selectedAsset',''))]
  if exact:bindings=exact
 if not bindings:return False
 b=bindings[0]; x0,y0,x1,y1,sw,sh=stage_coords(box)
 tw=sw*(.62 if scene.get('world',{}).get('archetype')!='world.teleop-workshop' else .72); th=tw*.625
 asset=_source_asset_image(b,tw,th,pal)
 if asset is None:return False
 # causal entrance into the selected world, not idle bobbing
 dx=int((1-ease(clamp(active)))*sw*.08); cx=int(x0+sw*.55+dx); cy=int(y0+sh*.51)
 x=cx-asset.width//2; y=cy-asset.height//2
 # a little grounding shadow belongs to the world surface
 soft_shadow(im,(cx-asset.width*.36,y+asset.height*.78,cx+asset.width*.36,y+asset.height*.92),alpha=24,blur=max(5,int(asset.height*.045)))
 im.alpha_composite(asset,(int(x),int(y)))
 return True

def _asset_concept(binding):
 return str(binding.get('need') or binding.get('selectedAsset') or '').lower()

def _asset_glyph(draw,x,y,size,pal,binding,accent=None):
 """Explainer-native semantic renderer for a registered asset binding.
 It uses the selected registry semantic ID; when RC3 lacks the original component bytes,
 this is recorded as registered-semantic-renderer rather than source-backed reuse.
 """
 accent=accent or pal['primary']; c=_asset_concept(binding); s=float(size); edge=mix(accent,pal['ink'],.18); fill=mix(pal['surface'],accent,.06)
 # base is embedded material, not a floating badge
 rounded(draw,(x-s*.50,y-s*.38,x+s*.50,y+s*.38),s*.13,fill,edge,max(1,int(s*.025)))
 if 'wallet' in c:
  rounded(draw,(x-s*.31,y-s*.18,x+s*.30,y+s*.18),s*.06,None,accent,max(2,int(s*.045))); rounded(draw,(x+s*.06,y-s*.08,x+s*.34,y+s*.08),s*.04,accent); ellipse(draw,(x+s*.17-s*.025,y-s*.025,x+s*.17+s*.025,y+s*.025),pal['surface'])
 elif 'identity' in c or 'passport' in c:
  ellipse(draw,(x-s*.20,y-s*.20,x+s*.02,y+s*.02),accent); line(draw,[(x-s*.28,y+s*.18),(x+s*.26,y+s*.18)],accent,max(2,int(s*.04))); line(draw,[(x+s*.10,y-s*.15),(x+s*.28,y-s*.15),(x+s*.28,y+s*.06)],accent,max(2,int(s*.035)))
 elif 'payment' in c or 'transaction' in c:
  line(draw,[(x-s*.30,y),(x+s*.24,y)],accent,max(3,int(s*.06))); draw.polygon([(int(x+s*.24),int(y-s*.11)),(int(x+s*.38),int(y)),(int(x+s*.24),int(y+s*.11))],fill=accent); ellipse(draw,(x-s*.31,y-s*.18,x-s*.03,y+s*.10),None,accent,max(2,int(s*.035)))
 elif 'market' in c or 'stock' in c:
  pts=[(x-s*.31,y+s*.16),(x-s*.10,y-s*.02),(x+s*.05,y+s*.04),(x+s*.29,y-s*.20)]; line(draw,pts,accent,max(3,int(s*.045))); forx=[]
  for px,py in pts: ellipse(draw,(px-s*.035,py-s*.035,px+s*.035,py+s*.035),accent)
 elif 'receipt' in c or 'record' in c:
  rounded(draw,(x-s*.22,y-s*.25,x+s*.22,y+s*.25),s*.04,None,accent,max(2,int(s*.035)))
  for i in range(3): line(draw,[(x-s*.13,y-s*.12+i*s*.12),(x+s*.13,y-s*.12+i*s*.12)],accent,max(1,int(s*.025)))
 elif 'robot' in c or 'machine' in c:
  rounded(draw,(x-s*.23,y-s*.19,x+s*.23,y+s*.20),s*.07,None,accent,max(2,int(s*.04))); ellipse(draw,(x-s*.13,y-s*.06,x-s*.05,y+s*.02),accent); ellipse(draw,(x+s*.05,y-s*.06,x+s*.13,y+s*.02),accent); line(draw,[(x,y-s*.19),(x,y-s*.30)],accent,max(2,int(s*.035))); ellipse(draw,(x-s*.035,y-s*.34,x+s*.035,y-s*.27),accent)
 elif 'chain' in c or 'bridge' in c:
  ellipse(draw,(x-s*.30,y-s*.10,x-s*.02,y+s*.18),None,accent,max(3,int(s*.045))); ellipse(draw,(x+s*.02,y-s*.18,x+s*.30,y+s*.10),None,accent,max(3,int(s*.045))); line(draw,[(x-s*.08,y+s*.03),(x+s*.08,y-s*.03)],accent,max(3,int(s*.04)))
 elif 'data' in c:
  for i,v in enumerate((.35,.62,.86)):
   xx=x-s*.24+i*s*.20; draw.rectangle((int(xx),int(y+s*.18-s*.42*v),int(xx+s*.10),int(y+s*.18)),fill=accent)
 elif 'job' in c or 'task' in c:
  paper_sheet(draw,x,y,s*.55,s*.43,pal,accent,im=None,active=1)
 elif 'rwa' in c or 'real-world' in c or 'asset' in c:
  _poly(draw,[(x-s*.28,y+s*.16),(x,y-s*.22),(x+s*.28,y+s*.16)],None if False else fill,edge,2); line(draw,[(x-s*.20,y+s*.17),(x+s*.20,y+s*.17)],accent,max(2,int(s*.035)))
 else:
  ellipse(draw,(x-s*.15,y-s*.15,x+s*.15,y+s*.15),accent)

def _world_environment(im,draw,scene,plan,ratio,box,active):
 world=scene.get('world') or {}; arch=world.get('archetype');
 if not arch:return False
 pal=palette(plan); x0,y0,x1,y1,sw,sh=stage_coords(box); horizon=y0+sh*(.84 if ratio!='9:16' else .89)
 # common authored room/floor planes
 wall=mix(pal['bg'],pal['surface'],.12); floor=mix(pal['bg'],pal['surface'],.24)
 draw.rectangle((int(x0),int(y0),int(x1),int(horizon)),fill=wall)
 draw.polygon([(int(x0),int(horizon)),(int(x1),int(horizon-sh*.06)),(int(x1),int(y1)),(int(x0),int(y1))],fill=floor)
 bindings=(scene.get('assetResolution') or {}).get('bindings',[])
 # World architecture: low-contrast semantic framing establishes foreground/midground/background
 # before the hero mechanism arrives. This replaces the old grid-only sense of space.
 beam=mix(pal['surface'],pal['bg'],.16); deep=mix(pal['surface'],pal['bg'],.08); edge=mix(pal['primary'],pal['bg'],.72)
 if arch not in ('world.editorial-void',):
  # side structural silhouettes create depth without decorative glow.
  draw.polygon([(int(x0),int(y0+sh*.08)),(int(x0+sw*.055),int(y0+sh*.03)),(int(x0+sw*.075),int(horizon)),(int(x0),int(horizon))],fill=deep)
  draw.polygon([(int(x1-sw*.05),int(y0+sh*.05)),(int(x1),int(y0+sh*.11)),(int(x1),int(horizon)),(int(x1-sw*.075),int(horizon-sh*.03))],fill=deep)
  line(draw,[(x0+sw*.06,y0+sh*.11),(x1-sw*.06,y0+sh*.07)],beam,max(4,int(sw*.005)))
  # floor perspective tracks anchor the action plane.
  van=(x0+sw*.52,y0+sh*.42)
  for xx in (x0+sw*.12,x0+sw*.34,x0+sw*.68,x0+sw*.90): line(draw,[(xx,y1),van],edge,max(1,int(sw*.002)))
 if arch=='world.system-registry':
  # tall registry chamber bays behind the active gate.
  for i in range(4):
   xx=x0+sw*(.50+i*.115); rounded(draw,(xx-sw*.045,y0+sh*.13,xx+sw*.045,horizon-sh*.05),sw*.012,mix(pal['surface'],pal['bg'],.10),mix(pal['primary'],pal['bg'],.76),1)
 elif arch=='world.production-floor':
  # overhead material line and rear service columns make this a production hall.
  line(draw,[(x0+sw*.10,y0+sh*.22),(x1-sw*.08,y0+sh*.18)],mix(pal['secondary'],pal['bg'],.72),max(3,int(sw*.004)))
  for i in range(5):
   xx=x0+sw*(.12+i*.19); line(draw,[(xx,y0+sh*.18),(xx,horizon-sh*.04)],mix(pal['surface'],pal['bg'],.18),max(3,int(sw*.004)))
 elif arch=='world.operations-rail':
  # long capability hall: ceiling rail, staggered rear bays and exit dock.
  line(draw,[(x0+sw*.08,y0+sh*.18),(x1-sw*.08,y0+sh*.15)],mix(pal['primary'],pal['bg'],.65),max(4,int(sw*.005)))
  for i in range(5):
   xx=x0+sw*(.13+i*.18); rounded(draw,(xx-sw*.065,y0+sh*.25,xx+sw*.065,horizon-sh*.02),sw*.014,mix(pal['surface'],pal['bg'],.08),mix(pal['primary'],pal['bg'],.80),1)
 elif arch=='world.robotics-bay':
  # deep bay doors and overhead gantry frame the robot handoff.
  rounded(draw,(x0+sw*.16,y0+sh*.16,x1-sw*.15,horizon-sh*.03),sw*.018,mix(pal['surface'],pal['bg'],.07),mix(pal['primary'],pal['bg'],.72),2)
  for i in range(4):
   xx=x0+sw*(.25+i*.17); line(draw,[(xx,y0+sh*.16),(xx,horizon-sh*.03)],mix(pal['surface'],pal['bg'],.20),max(2,int(sw*.003)))
 elif arch=='world.teleop-workshop':
  # observation window and equipment shelving behind the active teleop loop.
  rounded(draw,(x0+sw*.08,y0+sh*.15,x0+sw*.42,y0+sh*.38),sw*.016,mix(pal['surface'],pal['bg'],.09),mix(pal['primary'],pal['bg'],.75),1)
  for i in range(3): line(draw,[(x0+sw*.56,y0+sh*(.18+i*.12)),(x1-sw*.08,y0+sh*(.18+i*.12))],mix(pal['surface'],pal['bg'],.18),max(2,int(sw*.003)))
 elif arch=='world.finance-floor':
  # rear docking towers and converging floor lanes establish financial infrastructure scale.
  for i,(xx,hh) in enumerate(((.16,.24),(.78,.30),(.89,.20))):
   rounded(draw,(x0+sw*xx,y0+sh*(.25-hh*.2),x0+sw*(xx+.07),horizon-sh*.06),sw*.012,mix(pal['surface'],pal['bg'],.09),mix(pal['primary'],pal['bg'],.78),1)
  for xx in (.18,.50,.82): line(draw,[(x0+sw*xx,horizon),(x0+sw*.52,y0+sh*.58)],mix(pal['primary'],pal['bg'],.62),max(2,int(sw*.003)))
 elif arch=='world.valuation-stage':
  # dark valuation chamber with rear datum columns and a clear stage aperture.
  for i in range(5):
   xx=x0+sw*(.18+i*.16); h=sh*(.14+.035*(i%3)); draw.rectangle((int(xx-sw*.025),int(horizon-h),int(xx+sw*.025),int(horizon)),fill=mix(pal['surface'],pal['bg'],.11))
  line(draw,[(x0+sw*.10,horizon-sh*.02),(x1-sw*.08,horizon-sh*.07)],mix(pal['accent'],pal['bg'],.70),max(3,int(sw*.004)))
 if arch=='world.system-registry':
  # population architecture + registration gate
  gx=x0+sw*.22; line(draw,[(gx,y0+sh*.18),(gx,horizon-sh*.05)],mix(pal['primary'],pal['bg'],.42),max(3,int(sw*.005)))
  for r in range(3):
   for c in range(5):
    xx=x0+sw*(.58+c*.065); yy=y0+sh*(.18+r*.13); rr=min(sw,sh)*.018; ellipse(draw,(xx-rr,yy-rr,xx+rr,yy+rr),mix(pal['primary'],pal['surface'],.25 if active>(r*5+c)/16 else .08))
  rounded(draw,(gx-sw*.06,y0+sh*.35,gx+sw*.06,y0+sh*.64),sw*.018,mix(pal['surface'],pal['primary'],.05),mix(pal['primary'],pal['ink'],.14),2)
 elif arch=='world.production-floor':
  rail_y=horizon-sh*.13; line(draw,[(x0+sw*.05,rail_y),(x1-sw*.05,rail_y-sh*.025)],mix(pal['primary'],pal['bg'],.42),max(6,int(sw*.008)))
  for i in range(4): role_station(draw,x0+sw*(.17+i*.22),rail_y-sh*(.14+(i%2)*.025),sw*.11,sh*.12,pal,[pal['secondary'],pal['primary'],pal['accent']][i%3],'work',im=None,active=active)
 elif arch=='world.infrastructure-bench':
  bench_y=horizon-sh*.08; line(draw,[(x0+sw*.08,bench_y),(x1-sw*.08,bench_y)],mix(pal['ink'],pal['bg'],.55),max(6,int(sw*.008)))
  for i in range(5): iso_block(draw,x0+sw*(.18+i*.14),bench_y-sh*.10,sw*.07,sh*.075,sh*.022,pal,[pal['secondary'],pal['primary'],pal['accent']][i%3],im=None,active=active)
  for j in range(3): line(draw,[(x0+sw*.10,y0+sh*(.18+j*.10)),(x0+sw*.37,y0+sh*(.15+j*.11))],mix(pal['primary'],pal['bg'],.62),max(1,int(sw*.002)))
 elif arch=='world.operations-rail':
  pts=[(x0+sw*.07,horizon-sh*.10),(x0+sw*.93,horizon-sh*.16)]; line(draw,pts,mix(pal['primary'],pal['bg'],.32),max(7,int(sw*.009)))
  slots=[x0+sw*(.16+i*.17) for i in range(5)]
  for i,xx in enumerate(slots):
   yy=horizon-sh*(.20+.012*i); role_station(draw,xx,yy,sw*.105,sh*.115,pal,[pal['secondary'],pal['primary'],pal['accent']][i%3],'work',im=None,active=active)
   if bindings:
    _render_binding_at(im,draw,xx,yy,min(sw,sh)*.075,pal,bindings[i%len(bindings)],[pal['secondary'],pal['primary'],pal['accent']][i%3])
 elif arch=='world.robotics-bay':
  # service bays / gantry around hero
  line(draw,[(x0+sw*.12,y0+sh*.18),(x0+sw*.12,horizon)],mix(pal['ink'],pal['bg'],.60),max(5,int(sw*.006))); line(draw,[(x1-sw*.12,y0+sh*.18),(x1-sw*.12,horizon-sh*.04)],mix(pal['ink'],pal['bg'],.60),max(5,int(sw*.006))); line(draw,[(x0+sw*.12,y0+sh*.18),(x1-sw*.12,y0+sh*.18)],mix(pal['ink'],pal['bg'],.60),max(5,int(sw*.006)))
  for i in range(3):
   xx=x0+sw*(.20+i*.30); rounded(draw,(xx-sw*.08,horizon-sh*.15,xx+sw*.08,horizon-sh*.03),sw*.018,mix(pal['surface'],pal['primary'],.05),mix(pal['primary'],pal['bg'],.42),2)
 elif arch=='world.teleop-workshop':
  # console left, task table centre, fleet rack right
  desk(draw,x0+sw*.19,horizon-sh*.17,sw*.25,sh*.18,pal,pal['secondary'],im=None,active=active,kind='data')
  line(draw,[(x0+sw*.38,horizon-sh*.09),(x0+sw*.68,horizon-sh*.11)],mix(pal['ink'],pal['bg'],.52),max(6,int(sw*.007)))
  for r in range(2):
   for c in range(3):
    xx=x0+sw*(.78+c*.055); yy=y0+sh*(.28+r*.18); rounded(draw,(xx-sw*.025,yy-sh*.05,xx+sw*.025,yy+sh*.05),sw*.008,mix(pal['surface'],pal['accent'],.06),mix(pal['accent'],pal['bg'],.45),1)
 elif arch=='world.network-dock':
  ly=horizon-sh*.14; iso_block(draw,x0+sw*.20,ly,sw*.22,sh*.15,sh*.045,pal,pal['primary'],im=None,active=active); iso_block(draw,x0+sw*.80,ly-sh*.02,sw*.22,sh*.15,sh*.045,pal,pal['secondary'],im=None,active=active)
  line(draw,[(x0+sw*.30,ly-sh*.05),(x0+sw*.70,ly-sh*.07)],pal['accent'],max(6,int(sw*.008)))
 elif arch=='world.finance-floor':
  table_y=horizon-sh*.12; iso_block(draw,x0+sw*.52,table_y,sw*.38,sh*.16,sh*.04,pal,pal['primary'],im=None,active=active)
  for i,b in enumerate(bindings[:4]): _render_binding_at(im,draw,x0+sw*(.18+i*.21),y0+sh*(.30+(i%2)*.06),min(sw,sh)*.10,pal,b,[pal['secondary'],pal['primary'],pal['accent']][i%3])
  line(draw,[(x0+sw*.10,table_y+sh*.05),(x1-sw*.10,table_y-sh*.03)],mix(pal['accent'],pal['bg'],.38),max(4,int(sw*.005)))
 elif arch=='world.valuation-stage':
  # editorial valuation chamber with central balance rail / evidence plinths
  cy=horizon-sh*.20; line(draw,[(x0+sw*.18,cy),(x1-sw*.18,cy-sh*.02)],mix(pal['primary'],pal['bg'],.34),max(7,int(sw*.009))); line(draw,[(x0+sw*.50,cy-sh*.17),(x0+sw*.50,cy+sh*.14)],mix(pal['ink'],pal['bg'],.45),max(5,int(sw*.006)))
  for xx in (x0+sw*.26,x0+sw*.74): rounded(draw,(xx-sw*.12,cy+sh*.04,xx+sw*.12,cy+sh*.12),sw*.018,mix(pal['surface'],pal['accent'],.05),mix(pal['accent'],pal['bg'],.45),2)
 elif arch=='world.product-environment':
  line(draw,[(x0+sw*.08,y0+sh*.17),(x0+sw*.08,horizon-sh*.04)],mix(pal['primary'],pal['bg'],.48),max(4,int(sw*.005))); rounded(draw,(x1-sw*.22,horizon-sh*.18,x1-sw*.06,horizon-sh*.04),sw*.018,mix(pal['surface'],pal['accent'],.04),mix(pal['accent'],pal['bg'],.48),2)
 elif arch=='world.editorial-void':
  soft_blob(im,(x0-sw*.05,y0-sh*.05,x0+sw*.35,y0+sh*.38),mix(pal['bg'],pal['primary'],.14),blur=max(18,int(min(sw,sh)*.05)))
 return True

def semantic_environment(im,draw,scene,plan,ratio,box,active):
 """Authored environments: spatial depth, furniture and domain-specific material cues."""
 if _world_environment(im,draw,scene,plan,ratio,box,active): return

 pal=palette(plan); x0,y0,x1,y1,sw,sh=stage_coords(box); style=plan.get('styleProfile',''); mech=scene.get('mechanismId',''); fam=scene.get('visualizationFamily','')
 horizon=y0+sh*(.84 if ratio!='9:16' else .89)
 # subtle floor and perspective, not a flat blank stage
 floor=mix(pal['bg'],pal['surface'],.22); draw.polygon([(int(x0),int(horizon)),(int(x1),int(horizon-sh*.08)),(int(x1),int(y1)),(int(x0),int(y1))],fill=floor)
 line(draw,[(x0+sw*.03,horizon),(x1-sw*.03,horizon-sh*.07)],mix(pal['ink'],pal['bg'],.86),max(1,int(sw*.002)))
 if mech.startswith('A') or 'illustrated' in style:
  # research studio wall: book rail, pinned evidence, plant, lamp. All are quiet background anchors.
  wall=mix(pal['bg'],pal['surface'],.13); draw.rectangle((int(x0),int(y0),int(x1),int(horizon-sh*.02)),fill=wall)
  shelf_y=y0+sh*.18; line(draw,[(x0+sw*.04,shelf_y),(x0+sw*.31,shelf_y)],mix(pal['ink'],pal['bg'],.78),max(2,int(sw*.0025)))
  for i in range(5):
   xx=x0+sw*(.055+i*.047); hh=sh*(.050+.014*((i*3)%2)); ww=sw*.019
   rounded(draw,(xx,shelf_y-hh,xx+ww,shelf_y),max(2,int(ww*.18)),mix(pal['surface'],[pal['secondary'],pal['primary'],pal['accent']][i%3],.16))
  # lamp
  lx=x0+sw*.37; ly=shelf_y-sh*.025; line(draw,[(lx,ly),(lx+sw*.025,ly-sh*.055)],mix(pal['ink'],pal['bg'],.62),max(2,int(sw*.003)))
  draw.polygon([(int(lx+sw*.012),int(ly-sh*.055)),(int(lx+sw*.048),int(ly-sh*.055)),(int(lx+sw*.030),int(ly-sh*.090))],fill=mix(pal['secondary'],pal['surface'],.12))
  # pin rail / evidence string
  rx=x1-sw*.055; line(draw,[(rx,y0+sh*.23),(rx,y0+sh*.70)],mix(pal['ink'],pal['bg'],.84),max(1,int(sw*.002)))
  for j in range(3):
   yy=y0+sh*(.29+j*.15); paper_sheet(draw,rx-sw*.025,yy,sw*.055,sh*.055,pal,[pal['secondary'],pal['primary'],pal['accent']][j],im=None,active=.8)
  # small plant at left floor
  px=x0+sw*.055; py=horizon-sh*.03; rounded(draw,(px-sw*.020,py-sh*.02,px+sw*.020,py+sh*.035),sw*.008,mix(pal['surface'],pal['secondary'],.10))
  for sx,sy in ((-.022,-.06),(.0,-.085),(.022,-.055)):
   ellipse(draw,(px+sw*sx-sw*.012,py+sh*sy-sh*.022,px+sw*sx+sw*.012,py+sh*sy+sh*.022),mix(pal['secondary'],pal['primary'],.20))
 if mech.startswith('C') or 'spatial' in style:
  # perspective ledger rails and material blocks create a chain-space rather than graph-paper emptiness.
  van=(x0+sw*.54,y0+sh*.20)
  for xx in (x0+sw*.06,x0+sw*.28,x0+sw*.72,x0+sw*.94): line(draw,[(xx,horizon),van],mix(pal['primary'],pal['bg'],.82),max(1,int(sw*.002)))
  ly=horizon-sh*.03; line(draw,[(x0+sw*.05,ly),(x1-sw*.05,ly-sh*.055)],mix(pal['primary'],pal['bg'],.58),max(2,int(sw*.003)))
  for i in range(5):
   xx=x0+sw*(.10+i*.19); yy=ly-sh*(.012*i); iso_block(draw,xx,yy,sw*.055,sh*.050,sh*.016,pal,[pal['secondary'],pal['primary'],pal['accent']][i%3],im=None,active=active)
 if 'product' in style:
  # product studio: browser rail, operator zone, customer outcome zone
  line(draw,[(x0+sw*.035,y0+sh*.13),(x0+sw*.035,horizon-sh*.05)],mix(pal['primary'],pal['bg'],.78),max(2,int(sw*.002)))
  # distant customer chair silhouette / operator table adds lived context
  cx=x1-sw*.08; cy=horizon-sh*.04; rounded(draw,(cx-sw*.035,cy-sh*.05,cx+sw*.035,cy+sh*.04),sw*.012,mix(pal['surface'],pal['accent'],.06))
  line(draw,[(cx-sw*.02,cy+sh*.04),(cx-sw*.025,cy+sh*.09)],mix(pal['ink'],pal['bg'],.76),max(2,int(sw*.002))); line(draw,[(cx+sw*.02,cy+sh*.04),(cx+sw*.025,cy+sh*.09)],mix(pal['ink'],pal['bg'],.76),max(2,int(sw*.002)))


def _label_chip(draw,x,y,text,pal,accent,scale=1.0,hide_text=False):
 if hide_text: return
 f=font(max(9,int(14*scale)),bold=True); bb=draw.textbbox((0,0),text,font=f); w=(bb[2]-bb[0])+18*scale; h=(bb[3]-bb[1])+10*scale
 rounded(draw,(x-w*.5,y-h*.5,x+w*.5,y+h*.5),h*.45,mix(pal['surface'],accent,.08),mix(accent,pal['ink'],.14),1)
 draw.text((x-(bb[2]-bb[0])/2,y-(bb[3]-bb[1])/2-1),text,font=f,fill=mix(accent,pal['ink'],.20))

def premium_mechanism_art(im,draw,scene,plan,ratio,p,active,settle,box,hero_scale,label,hide_text=False):
 """Mechanism-specific portfolio compositions built from reusable v1.3 primitives.
 Returns True when the scene is fully rendered here.
 """
 pal=palette(plan); scene['_runtimePalette']=pal; x0,y0,x1,y1,sw,sh=stage_coords(box); mech=scene.get('mechanismId',''); fam=scene.get('visualizationFamily',''); bp=scene.get('compositionBlueprint',''); verb=scene.get('visualVerb','')
 arch=(scene.get('world') or {}).get('archetype')
 if arch=='world.system-registry':
  # A registry scene is a place, not a scatter plot: one identity gate feeds an authored population rack.
  bindings=(scene.get('assetResolution') or {}).get('bindings',[])
  identity=next((b for b in bindings if 'identity' in _asset_concept(b)),None)
  agent=next((b for b in bindings if 'agent' in _asset_concept(b)),None)
  gate_x=x0+sw*.28; gate_y=y0+sh*.56
  rounded(draw,(gate_x-sw*.075,gate_y-sh*.17,gate_x+sw*.075,gate_y+sh*.17),sw*.018,mix(pal['surface'],pal['primary'],.045),mix(pal['primary'],pal['ink'],.18),max(2,int(sw*.003)))
  if identity:_render_binding_at(im,draw,gate_x,gate_y,min(sw,sh)*.105,pal,identity,pal['primary'])
  rack_x=x0+sw*.68; rack_y=y0+sh*.52
  # angled population frame creates a substantial midground system.
  rounded(draw,(rack_x-sw*.21,rack_y-sh*.24,rack_x+sw*.23,rack_y+sh*.24),sw*.022,mix(pal['surface'],pal['primary'],.025),mix(pal['primary'],pal['bg'],.36),2)
  for r in range(3):
   for c in range(4):
    qidx=r*4+c; reveal=clamp((active-qidx*.035)/.65); xx=rack_x+sw*(-.14+c*.09); yy=rack_y+sh*(-.14+r*.14)
    if reveal>.02:
     if agent:_render_binding_at(im,draw,xx,yy,min(sw,sh)*(.055+.012*reveal),pal,agent,[pal['secondary'],pal['primary'],pal['accent']][qidx%3])
     else: token(draw,xx,yy,max(10,int(min(sw,sh)*.024)),pal,'',reveal>.5,im=im)
  # causal registration packet crosses the gate into the population field.
  sx=x0+sw*.11; ex=rack_x-sw*.22; yy=gate_y; q=active; draw_route(draw,[(sx,yy),(gate_x-sw*.09,yy),(gate_x+sw*.10,yy),(ex,yy-sh*.03)],pal,max(5,int(sw*.006)),q)
  token(draw,sx+(ex-sx)*q,yy-sh*.03*q,max(11,int(min(sw,sh)*.026)),pal,'',q>.45,im=im)
  return True
 if arch=='world.operations-rail':
  # One continuous economic rail with semantic capability stations. No disconnected cards or decorative person.
  bindings=(scene.get('assetResolution') or {}).get('bindings',[])
  priority=['launch','identity','wallet','payment','market']
  chosen=[]
  for key in priority:
   b=next((x for x in bindings if key in _asset_concept(x)),None)
   if b and b not in chosen:chosen.append(b)
  if len(chosen)<5:
   chosen += [b for b in bindings if b not in chosen][:5-len(chosen)]
  # Use almost the full beat for the causal traversal. The generic active window intentionally
  # contains longer establish/settle holds; a five-station rail needs continuous semantic action.
  motion=clamp((p-.015)/.94)
  rail_y=y0+sh*.62; xs=[x0+sw*(.14+i*.18) for i in range(5)]
  path=[(x0+sw*.06,rail_y)]+[(xx,rail_y-sh*(.035 if i%2 else 0)) for i,xx in enumerate(xs)]+[(x1-sw*.05,rail_y-sh*.02)]
  # the physical rail itself grows with the action rather than existing fully formed.
  draw_route(draw,path,pal,max(8,int(sw*.010)),clamp(motion*1.18))
  for i,xx in enumerate(xs):
   seq=clamp((motion-i*.11)/.45)
   yy0=rail_y-sh*(.11+(.025 if i%2 else 0)); yy=yy0+(1-ease(seq))*sh*.055
   col=[pal['secondary'],pal['primary'],pal['accent']][i%3]
   # each station rises from the rail and activates as the travelling agent reaches it.
   iso_block(draw,xx,yy+sh*.075,sw*.145,sh*.13,sh*.032,pal,col,im=im,active=seq)
   if seq>.03 and i<len(chosen):_render_binding_at(im,draw,xx,yy-sh*.025,min(sw,sh)*(.075+.035*seq),pal,chosen[i],col)
   if seq>.55:
    rr=min(sw,sh)*.010; ellipse(draw,(xx-rr,yy+sh*.105-rr,xx+rr,yy+sh*.105+rr),col)
  # single agent core traverses the system; station activation follows it.
  segq=motion*(len(path)-1); seg=min(len(path)-2,int(segq)); tt=segq-seg; a,b=path[seg],path[seg+1]
  cx=a[0]+(b[0]-a[0])*tt; cy=a[1]+(b[1]-a[1])*tt
  # the travelling agent sits on a substantial carrier sled so its progress remains legible
  # at mobile size and creates real scene-wide motion rather than a tiny moving dot.
  cw=min(sw,sh)*.105; ch=min(sw,sh)*.055
  soft_shadow(im,(cx-cw*.62,cy+ch*.40,cx+cw*.62,cy+ch*.72),alpha=18,blur=max(4,int(ch*.28)))
  rounded(draw,(cx-cw*.55,cy-ch*.46,cx+cw*.55,cy+ch*.46),ch*.28,mix(pal['surface'],pal['primary'],.08),mix(pal['primary'],pal['ink'],.15),2)
  token(draw,cx,cy,max(18,int(min(sw,sh)*.044)),pal,'',motion>.45,im=im)
  # consequence/handoff: after the five stations complete, the processed carrier exits the rail.
  # This occupies the comprehension/settle phase with meaningful motion rather than idle animation.
  if settle>.01:
   sx=xs[-1]+sw*.035; ex=x1+sw*.12; ey=rail_y-sh*.02; hx=sx+(ex-sx)*settle
   draw_route(draw,[(sx,ey),(ex,ey)],pal,max(5,int(sw*.006)),settle)
   hw=min(sw,sh)*.085; hh=min(sw,sh)*.046
   rounded(draw,(hx-hw*.52,ey-hh*.45,hx+hw*.52,ey+hh*.45),hh*.24,mix(pal['surface'],pal['accent'],.08),mix(pal['accent'],pal['ink'],.12),2)
  # exit barrier opens with an ease that preserves visible travel into the very end of the beat.
  door=1-math.sqrt(max(0.0,1-clamp(p))); gx=x1-sw*.075; gy=rail_y-sh*.14; gw=sw*.035; gh=sh*.22; spread=sw*.055*door
  rounded(draw,(gx-gw-spread,gy-gh*.5,gx-spread,gy+gh*.5),gw*.25,mix(pal['surface'],pal['primary'],.07),mix(pal['primary'],pal['bg'],.38),1)
  rounded(draw,(gx+spread,gy-gh*.5,gx+gw+spread,gy+gh*.5),gw*.25,mix(pal['surface'],pal['primary'],.07),mix(pal['primary'],pal['bg'],.38),1)
  return True
 if arch=='world.robotics-bay' and _composite_source_binding(im,scene,box,active,'agent-robot-handoff'):
  # the semantic core traverses the handoff path already represented by the authored SVG
  sx=x0+sw*.35; ex=x0+sw*.62; yy=y0+sh*.52; q=active; token(draw,sx+(ex-sx)*q,yy,max(12,int(min(sw,sh)*.028)),pal,'',q>.55,im=im)
  return True
 if arch=='world.teleop-workshop' and _composite_source_binding(im,scene,box,active,'teleop-fleet-loop'):
  # captured training-data packets progress through the loop toward the fleet state
  for j,phase in enumerate((0,.16,.32)):
   q=clamp((active-phase)/(1-phase)); sx=x0+sw*.34; ex=x0+sw*.75; yy=y0+sh*(.68-j*.055); token(draw,sx+(ex-sx)*q,yy,max(9,int(min(sw,sh)*.020)),pal,str(j+1),q>.5,im=im)
  return True
 if arch=='world.production-floor':
  # Production world owns a causal input -> work -> settlement path rather than inheriting a generic graph.
  cy=y0+sh*.58; pts=[(x0+sw*.14,cy),(x0+sw*.39,cy-sh*.05),(x0+sw*.64,cy-sh*.02),(x0+sw*.86,cy-sh*.10)]
  draw_route(draw,pts,pal,max(7,int(sw*.009)),active)
  kinds=['work','review','data']; cols=[pal['secondary'],pal['primary'],pal['accent']]
  for i,(xx,yy) in enumerate(pts[1:]): role_station(draw,xx,yy,min(sw,sh)*.19,min(sw,sh)*.135,pal,cols[i],kinds[i],im=im,active=active)
  for j,phase in enumerate((0,.13,.27)):
   q=clamp((active-phase)/(1-phase))*3; seg=min(2,int(q)); tt=q-seg; a,b=pts[seg],pts[seg+1]; token(draw,a[0]+(b[0]-a[0])*tt,a[1]+(b[1]-a[1])*tt,max(10,int(min(sw,sh)*.022)),pal,str(j+1),q>1.2,im=im)
  # completion/value reservoir physically accumulates at settlement end
  rx,ry=pts[-1]; for_n=int(active*5)
  for i in range(for_n):
   rr=min(sw,sh)*.022; ellipse(draw,(rx-rr*3+i*rr*1.4,ry+rr*2,rx-rr+i*rr*1.4,ry+rr*4),pal['accent'])
  return True
 if arch=='world.finance-floor':
  # Asset integration takes place on one shared settlement table; no dashboard/card interpretation.
  table_y=y0+sh*.63; iso_block(draw,x0+sw*.52,table_y,sw*.46,sh*.18,sh*.045,pal,pal['primary'],im=im,active=active)
  bindings=(scene.get('assetResolution') or {}).get('bindings',[])
  useful=[b for b in bindings if any(k in _asset_concept(b) for k in ('market','chain','rwa','asset','stock','payment','escrow'))]
  if not useful: useful=bindings[:3]
  slots=[(x0+sw*.20,y0+sh*.33),(x0+sw*.50,y0+sh*.27),(x0+sw*.80,y0+sh*.33)]
  for i,(xx,yy) in enumerate(slots):
   b=useful[i%len(useful)] if useful else {'need':['stock','rwa','market'][i]}
   # pedestal ties the semantic asset into the world
   rounded(draw,(xx-sw*.09,yy+sh*.07,xx+sw*.09,yy+sh*.12),sw*.012,mix(pal['surface'],pal['accent'],.05),mix(pal['accent'],pal['bg'],.42),1)
   _render_binding_at(im,draw,xx,yy,min(sw,sh)*.14,pal,b,[pal['secondary'],pal['primary'],pal['accent']][i])
   draw_route(draw,[(xx,yy+sh*.12),(x0+sw*.52,table_y-sh*.09)],pal,max(3,int(sw*.004)),clamp((active-i*.12)/(1-i*.12)))
  # shared settlement state resolves after all three arrivals
  q=clamp((active-.55)/.45); token(draw,x0+sw*.52,table_y-sh*.08,max(13,int(min(sw,sh)*.030)),pal,'✓' if q>.72 else '',q>.45,im=im)
  return True
 if arch=='world.valuation-stage':
  # A physical valuation stage: a narrow category cage on one side, a broader economy platform on the other.
  cy=y0+sh*.57; left=x0+sw*.28; right=x0+sw*.71; S=min(sw,sh)
  # floor beam and central fulcrum make the comparison spatial instead of two cards.
  base_y=cy+sh*.19; tilt=(active-.45)*S*.045
  beam=[(left-S*.13,base_y+tilt),(right+S*.16,base_y-tilt)]
  line(draw,beam,mix(pal['accent'],pal['ink'],.10),max(7,int(sw*.009)))
  fulx=x0+sw*.51; draw.polygon([(int(fulx-S*.045),int(base_y+S*.12)),(int(fulx+S*.045),int(base_y+S*.12)),(int(fulx),int(base_y+S*.015))],fill=mix(pal['surface'],pal['primary'],.18))
  # narrow launchpad cage deliberately constrains one seed object.
  cage_w=S*(.12+.035*active); cage_h=S*.18
  line(draw,[(left-cage_w,cy-cage_h),(left-cage_w,cy+cage_h),(left+cage_w,cy+cage_h),(left+cage_w,cy-cage_h)],mix(pal['secondary'],pal['ink'],.06),max(4,int(S*.006)))
  for k in range(4):
   xx=left-cage_w+(2*cage_w)*k/3; line(draw,[(xx,cy-cage_h),(xx,cy+cage_h)],mix(pal['secondary'],pal['bg'],.36),max(1,int(S*.002)))
  token(draw,left,cy,S*.045,pal,'',active>.35,im=im)
  # broader economy platform is open and populated by differentiated bound assets.
  iso_block(draw,right,cy+S*.06,S*.35,S*.19,S*.05,pal,pal['primary'],im=im,active=active)
  bindings=(scene.get('assetResolution') or {}).get('bindings',[])
  places=[(-.11,-.07),(.02,-.12),(.13,-.035)]
  for i,(ox,oy) in enumerate(places):
   b=bindings[i%len(bindings)] if bindings else {'need':['agent','market','data'][i]}
   _render_binding_at(im,draw,right+S*ox,cy+S*oy,S*.09,pal,b,[pal['secondary'],pal['primary'],pal['accent']][i])
  # the category boundary opens toward the larger economy only as the question resolves.
  q=clamp((active-.35)/.65); draw_route(draw,[(left+cage_w,cy),(fulx-S*.03,cy-S*.03),(right-S*.17,cy-S*.02)],pal,max(5,int(S*.006)),q)
  return True
 # ---- AI: brief -> plan -> specialist work -> synthesis -> evaluation -> human approval ----
 if mech=='A04' and 'physical-spatial-mechanism' in fam:
  cy=y0+sh*.57; S=hero_scale*.67; leadx=x0+sw*.17; engine=x0+sw*.53; outx=x0+sw*.84
  # lead at a real desk with the input brief
  desk(draw,leadx+S*.18,cy+S*.18,S*.70,S*.36,pal,pal['secondary'],im=im,active=active,kind='research')
  person(draw,leadx,cy,S,pal,gesture=active,secondary=False,im=im)
  paper_sheet(draw,leadx+S*.34,cy-S*.08,S*.20,S*.14,pal,pal['secondary'],im=im,active=active)
  # central processing tower: layered physical chamber, not a rounded generic card
  ew=min(sw,sh)*.15; eh=ew*1.55
  soft_shadow(im,(engine-ew*.72,cy+eh*.48,engine+ew*.72,cy+eh*.72),alpha=24,blur=max(5,int(ew*.12)))
  iso_block(draw,engine,cy,ew*1.55,eh,eh*.13,pal,pal['primary'],im=None,active=active)
  for i in range(3):
   yy=cy-eh*.27+i*eh*.27; rr=ew*.075; ellipse(draw,(engine-rr,yy-rr,engine+rr,yy+rr),pal['accent'] if active>(i+1)*.23 else mix(pal['muted'],pal['surface'],.34))
  # output task folio with three tabs
  folw=ew*1.15; folh=eh*.68; rounded(draw,(outx-folw*.5,cy-folh*.5,outx+folw*.5,cy+folh*.5),ew*.12,mix(pal['surface'],pal['accent'],.055),mix(pal['accent'],pal['ink'],.15),2)
  for i,col in enumerate((pal['secondary'],pal['primary'],pal['accent'])):
   yy=cy-folh*.25+i*folh*.25; rounded(draw,(outx-folw*.30,yy-ew*.035,outx+folw*(.05+.16*active),yy+ew*.035),ew*.03,col)
  pts=[(leadx+S*.34,cy-S*.08),(engine-ew*.82,cy),(engine+ew*.82,cy),(outx-folw*.55,cy)]
  draw_route(draw,pts,pal,max(6,int(sw*.008)),active)
  q=active*3; i=min(2,int(q)); t=q-i; a,b=pts[i],pts[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,max(13,int(min(sw,sh)*.032)),pal,'brief' if active<.72 else 'tasks',active>.55,im=im)
  return True

 if mech=='A05' and 'object-transformation' in fam:
  # planner table + three owned specialist stations arranged as a studio, not a diagram.
  planner=(x0+sw*.50,y0+sh*.70 if ratio!='9:16' else y0+sh*.52); pr=min(sw,sh)*.19
  desk(draw,planner[0],planner[1],pr*3.0,pr*1.32,pal,pal['primary'],im=im,active=active,kind='work')
  paper_sheet(draw,planner[0],planner[1]-pr*.55,pr*.95,pr*.62,pal,pal['primary'],im=im,active=active)
  if ratio=='9:16': stations=[(x0+sw*.23,y0+sh*.18),(x0+sw*.77,y0+sh*.18),(x0+sw*.50,y0+sh*.81)]
  else: stations=[(x0+sw*.17,y0+sh*.22),(x0+sw*.50,y0+sh*.18),(x0+sw*.83,y0+sh*.22)]
  kinds=['research','work','data']; cols=[pal['secondary'],pal['primary'],pal['accent']]
  for i,(sx,sy) in enumerate(stations):
   desk(draw,sx,sy,pr*2.15,pr*.98,pal,cols[i],im=im,active=active,kind=kinds[i])
   draw_route(draw,[planner,(sx,sy+pr*.52 if ratio!='9:16' else sy)],pal,max(4,int(sw*.005)),active)
   q=clamp((active-i*.10)/(1-i*.10)); xx=planner[0]+(sx-planner[0])*q; yy=planner[1]+(sy-planner[1])*q
   token(draw,xx,yy,pr*.17,pal,str(i+1),q>.45,im=im)
  return True

 if mech=='A06' and 'object-transformation' in fam:
  # three distinct specialist desks with human ownership; task packets traverse the work line.
  if ratio=='9:16': stations=[(x0+sw*.50,y0+sh*(.18+i*.29)) for i in range(3)]
  else: stations=[(x0+sw*(.18+i*.32),y0+sh*.52) for i in range(3)]
  pr=min(sw,sh)*.175; cols=[pal['secondary'],pal['primary'],pal['accent']]; kinds=['research','work','data']
  draw_route(draw,stations,pal,max(5,int(sw*.006)),active)
  for i,(sx,sy) in enumerate(stations):
   desk(draw,sx,sy,pr*2.0,pr*.92,pal,cols[i],im=im,active=active,kind=kinds[i])
   # small owner behind/alongside station
   if ratio!='9:16': person(draw,sx-pr*.72,sy+pr*.57,hero_scale*.49,pal,gesture=active,secondary=(i%2==1),im=im)
   paper_sheet(draw,sx+pr*.58,sy+pr*.44,pr*.48,pr*.32,pal,cols[i],im=im,active=active)
  for j,phase in enumerate((0,.14,.28)):
   q=clamp((active-phase)/(1-phase)); seg=q*2; i=min(1,int(seg)); t=seg-i; a,b=stations[i],stations[i+1]
   token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t+(j-1)*pr*.22,pr*.12,pal,str(j+1),q>.48,im=im)
  return True

 if mech=='A05' and 'spatial-system' in fam:
  center=(x0+sw*.54,y0+sh*.55); pr=min(sw,sh)*(.235 if ratio!='9:16' else .205)
  if ratio=='9:16': srcs=[(x0+sw*.22,y0+sh*.17),(x0+sw*.78,y0+sh*.17),(x0+sw*.22,y0+sh*.68)]; dest=(x0+sw*.72,y0+sh*.80)
  else: srcs=[(x0+sw*.13,y0+sh*.22),(x0+sw*.13,y0+sh*.76),(x0+sw*.43,y0+sh*.19)]; dest=(x0+sw*.88,y0+sh*.55)
  # synthesis table with layered papers
  desk(draw,center[0],center[1],pr*3.15,pr*1.35,pal,pal['primary'],im=im,active=active,kind='work')
  for i,src in enumerate(srcs):
   paper_sheet(draw,src[0],src[1],pr*.62,pr*.42,pal,[pal['secondary'],pal['primary'],pal['accent']][i],im=im,active=active)
   draw_route(draw,[src,center],pal,max(4,int(sw*.005)),active)
   q=clamp((active-i*.07)/(1-i*.07)); token(draw,src[0]+(center[0]-src[0])*q,src[1]+(center[1]-src[1])*q,pr*.13,pal,str(i+1),q>.52,im=im)
  draw_route(draw,[center,dest],pal,max(5,int(sw*.006)),clamp((active-.55)/.45))
  paper_sheet(draw,dest[0],dest[1],pr*.95,pr*.65,pal,pal['accent'],im=im,active=active)
  q=clamp((active-.62)/.38); token(draw,center[0]+(dest[0]-center[0])*q,center[1]+(dest[1]-center[1])*q,pr*.15,pal,'✓',q>.55,im=im)
  return True

 if mech=='A07' and 'human-action' in fam:
  cy=y0+sh*.57; S=hero_scale*.69; lx=x0+sw*.18; rx=x0+sw*.82; easel=x0+sw*.50
  person(draw,lx,cy,S,pal,gesture=active,secondary=False,im=im); person(draw,rx,cy-S*.05,S,pal,gesture=1-active,secondary=True,im=im)
  # evaluator easel with proof sheet and failed-claim repair loop
  ew=min(sw,sh)*.15; eh=ew*1.15; paper_sheet(draw,easel,cy-S*.15,ew,eh,pal,pal['secondary'],im=im,active=active)
  line(draw,[(easel-ew*.35,cy+eh*.35),(easel-ew*.58,cy+eh*.90)],mix(pal['ink'],pal['bg'],.52),max(3,int(sw*.004))); line(draw,[(easel+ew*.35,cy+eh*.35),(easel+ew*.58,cy+eh*.90)],mix(pal['ink'],pal['bg'],.52),max(3,int(sw*.004)))
  route=[(lx+S*.22,cy-S*.11),(easel-ew*.60,cy-S*.12),(easel+ew*.60,cy-S*.12),(rx-S*.20,cy-S*.10)]
  draw_route(draw,route,pal,max(5,int(sw*.006)),active)
  loop=[(easel+ew*.10,cy+eh*.20),(easel+ew*.80,cy+eh*.65),(easel-ew*.80,cy+eh*.65),(easel-ew*.10,cy+eh*.20)]
  draw_route(draw,loop,pal,max(3,int(sw*.004)),clamp((active-.45)/.45))
  q=active*3; i=min(2,int(q)); t=q-i; a,b=route[i],route[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,max(12,int(min(sw,sh)*.030)),pal,'!' if active<.65 else '✓',active>.52,im=im)
  return True

 if mech=='A08' and 'hero-emotional' in fam:
  cy=y0+sh*.57; S=hero_scale*.80; px=x0+sw*.20; dx=x0+sw*.70
  desk(draw,px+S*.16,cy+S*.18,S*.78,S*.35,pal,pal['primary'],im=im,active=active,kind='review')
  person(draw,px,cy,S,pal,gesture=active,secondary=False,im=im)
  # approved dossier enters the review light, with seal and evidence stack
  r=min(sw,sh)*(.265 if ratio!='9:16' else .235); hx=dx+(1-active)*sw*.11; hy=cy-S*.10-(1-active)*sh*.06
  # authored review bay gives the approval moment a place rather than a floating document.
  bay=(dx-r*1.45,cy-r*.98,dx+r*1.45,cy+r*1.05)
  rounded(draw,bay,r*.18,mix(pal['surface'],pal['accent'],.025),mix(pal['muted'],pal['bg'],.28),2)
  line(draw,[(dx-r*1.18,cy+r*.72),(dx+r*1.18,cy+r*.72)],mix(pal['muted'],pal['surface'],.28),max(2,int(r*.025)))
  soft_blob(im,(hx-r*1.35,hy-r*1.35,hx+r*1.35,hy+r*1.35),mix(pal['bg'],pal['accent'],.18),blur=max(18,int(r*.25)))
  paper_sheet(draw,hx,hy,r*1.55,r*1.12,pal,pal['accent'],im=im,active=active)
  evidence_trail(draw,[(px+S*.42+i*r*.38,cy+S*.25-r*(.10+(i%2)*.07)) for i in range(3)],pal,active,im=im)
  draw_route(draw,[(hx-r*.75,hy),(px+S*.30,cy-S*.02)],pal,max(4,int(sw*.005)),active)
  return True

 # AI final return: lead receives the approved dossier at a real research desk with evidence trail still visible.
 if mech=='U06' and 'human-action' in fam and 'illustrated' in plan.get('styleProfile',''):
  cy=y0+sh*.57; S=hero_scale*.82; lead=x0+sw*.18; dossier=x0+sw*.75
  desk(draw,lead+S*.18,cy+S*.19,S*.82,S*.38,pal,pal['secondary'],im=im,active=active,kind='research')
  person(draw,lead,cy,S,pal,gesture=active,secondary=False,im=im)
  # evidence rail stays behind the returned package
  evidence_trail(draw,[(lead+S*.38+i*S*.15,cy+S*.24-S*(.08+(i%2)*.05)) for i in range(4)],pal,active,im=im)
  r=min(sw,sh)*(.225 if ratio!='9:16' else .205); dx=dossier+(1-active)*sw*.12; dy=cy-S*.13
  paper_sheet(draw,dx,dy,r*1.35,r*.92,pal,pal['accent'],im=im,active=active)
  pts=[(dx-r*.72,dy),(x0+sw*.48,cy-S*.07),(lead+S*.30,cy-S*.04)]; draw_route(draw,pts,pal,max(5,int(sw*.006)),active)
  q=active*2; i=min(1,int(q)); t=q-i; a,b=pts[i],pts[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,r*.12,pal,'✓',active>.58,im=im)
  return True

 # ---- General/product: real application, ownership and outcome world ----
 if mech=='U05' and 'product-in-context' in fam:
  cy=y0+sh*.57; S=hero_scale*.56; customer=x0+sw*.12; bx0=x0+sw*.25; bx1=x1-sw*.04; by0=y0+sh*.10; by1=y1-sh*.06
  person(draw,customer,cy+S*.10,S,pal,gesture=.75,secondary=False,im=im)
  # speech/request sheet leaves customer into a large product surface
  paper_sheet(draw,customer+S*.20,cy-S*.12,S*.20,S*.14,pal,pal['secondary'],im=im,active=active)
  soft_shadow(im,(bx0+sw*.02,by1-sh*.02,bx1-sw*.02,by1+sh*.035),alpha=18,blur=max(5,int(sh*.02)))
  rounded(draw,(bx0,by0,bx1,by1),min(sw,sh)*.025,pal['surface'],mix(pal['muted'],pal['bg'],.28),2)
  top=by0+sh*.07; draw.rectangle((int(bx0),int(by0),int(bx1),int(top)),fill=mix(pal['surface'],pal['muted'],.12))
  for i,c in enumerate((pal['primary'],pal['secondary'],pal['accent'])): ellipse(draw,(bx0+18+i*18,by0+18,bx0+25+i*18,by0+25),c)
  # left nav, message thread, owned case rail
  navw=(bx1-bx0)*.15; draw.rectangle((int(bx0),int(top),int(bx0+navw),int(by1)),fill=mix(pal['surface'],pal['primary'],.04))
  for j in range(5): rounded(draw,(bx0+navw*.22,top+sh*(.05+j*.075),bx0+navw*.70,top+sh*(.075+j*.075)),5,mix(pal['muted'],pal['surface'],.34))
  msgx=bx0+navw+sw*.04; msgy=top+sh*.08
  for j,wf in enumerate((.68,.48,.61)):
   rounded(draw,(msgx,msgy+j*sh*.09,msgx+sw*.30*wf,msgy+j*sh*.09+sh*.045),sh*.018,mix(pal['muted'],pal['surface'],.35))
  case_x=bx1-sw*.16; case_y=top+sh*.22; case_y_draw=case_y+(1-active)*(sh*.16 if ratio=='9:16' else sh*.07); paper_sheet(draw,case_x,case_y_draw,sw*.17,sh*.16,pal,pal['accent'],im=im,active=active)
  start=(customer+S*.24,cy-S*.12); end=(case_x-sw*.10,case_y_draw); draw_route(draw,[start,(bx0+navw,case_y),end],pal,max(5,int(sw*.006)),active)
  token(draw,start[0]+(end[0]-start[0])*active,start[1]+(end[1]-start[1])*active,max(13,int(min(sw,sh)*.03)),pal,'case',active>.48,im=im)
  return True

 if mech=='U16' and 'physical-spatial-mechanism' in fam:
  cy=y0+sh*.56; pr=min(sw,sh)*.15; inbox=x0+sw*.15; router=x0+sw*.49; op=x0+sw*.82
  paper_sheet(draw,inbox,cy,pr*.95,pr*.68,pal,pal['secondary'],im=im,active=active)
  # routing sorter as physical tray/tower
  iso_block(draw,router,cy,pr*1.65,pr*1.35,pr*.18,pal,pal['primary'],im=im,active=active)
  for i in range(3): rounded(draw,(router-pr*.46,cy-pr*.35+i*pr*.32,router+pr*.34,cy-pr*.24+i*pr*.32),pr*.05,[pal['secondary'],pal['primary'],pal['accent']][i])
  desk(draw,op,cy+pr*.12,pr*2.1,pr*.92,pal,pal['accent'],im=im,active=active,kind='work')
  person(draw,op-pr*.68,cy+pr*.75,hero_scale*.40,pal,gesture=active,secondary=True,im=im)
  pts=[(inbox+pr*.55,cy),(router-pr*.85,cy),(router+pr*.85,cy),(op-pr*.78,cy)]
  draw_route(draw,pts,pal,max(6,int(sw*.007)),active)
  q=active*3; i=min(2,int(q)); t=q-i; a,b=pts[i],pts[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,pr*.15,pal,'case',active>.45,im=im)
  return True

 if mech=='U09' and 'human-action' in fam and 'product' in plan.get('styleProfile',''):
  cy=y0+sh*.58; S=hero_scale*.66; lx=x0+sw*.20; rx=x0+sw*.80; cx=x0+sw*.50; pr=min(sw,sh)*.15
  if 'handoff-diagonal' in bp:
   person(draw,lx,cy,S,pal,gesture=active,secondary=True,im=im); person(draw,rx,cy-S*.04,S,pal,gesture=1-active,secondary=False,im=im)
   # proposed resolution on a review stand, flanked by evidence slips
   paper_sheet(draw,cx,cy-S*.12,pr*1.15,pr*.82,pal,pal['primary'],im=im,active=active)
   line(draw,[(cx-pr*.35,cy+pr*.24),(cx-pr*.55,cy+pr*.82)],mix(pal['ink'],pal['bg'],.58),max(3,int(sw*.004))); line(draw,[(cx+pr*.35,cy+pr*.24),(cx+pr*.55,cy+pr*.82)],mix(pal['ink'],pal['bg'],.58),max(3,int(sw*.004)))
   evidence_trail(draw,[(cx-pr*.95+i*pr*.62,cy+pr*.76) for i in range(4)],pal,active,im=im)
   pts=[(lx+S*.24,cy-S*.08),(cx-pr*.62,cy-S*.10),(cx+pr*.62,cy-S*.10),(rx-S*.22,cy-S*.08)]; draw_route(draw,pts,pal,max(5,int(sw*.006)),active)
   q=active*3; i=min(2,int(q)); t=q-i; a,b=pts[i],pts[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,pr*.13,pal,'✓',active>.58,im=im)
  else:
   # approved answer passes through the product portal into the customer's device.
   person(draw,lx,cy,S,pal,gesture=active,secondary=True,im=im); person(draw,rx,cy,S,pal,gesture=.20,secondary=False,im=im)
   portalw=pr*1.65; portalh=pr*1.15; soft_shadow(im,(cx-portalw*.55,cy+portalh*.48,cx+portalw*.55,cy+portalh*.72),alpha=18,blur=max(5,int(pr*.10)))
   rounded(draw,(cx-portalw*.5,cy-portalh*.5,cx+portalw*.5,cy+portalh*.5),pr*.18,mix(pal['surface'],pal['primary'],.06),mix(pal['primary'],pal['ink'],.14),2)
   # product route inside portal
   for i,col in enumerate((pal['secondary'],pal['primary'],pal['accent'])):
    xx=cx-portalw*.27+i*portalw*.27; rr=pr*.065; ellipse(draw,(xx-rr,cy-rr,xx+rr,cy+rr),col)
   device_x=rx-S*.36; device_y=cy-S*.20; rounded(draw,(device_x-pr*.32,device_y-pr*.22,device_x+pr*.32,device_y+pr*.22),pr*.06,mix(pal['surface'],pal['accent'],.05),mix(pal['accent'],pal['ink'],.13),2)
   pts=[(lx+S*.24,cy-S*.08),(cx-portalw*.58,cy),(cx+portalw*.58,cy),(device_x-pr*.32,device_y)]; draw_route(draw,pts,pal,max(5,int(sw*.006)),active)
   q=active*3; i=min(2,int(q)); t=q-i; a,b=pts[i],pts[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,pr*.13,pal,'answer',active>.52,im=im)
  return True

 if mech=='U11' and 'object-transformation' in fam:
  # two owned specialist rooms around the same case record; larger and more human than a three-node split diagram.
  cy=y0+sh*.57; pr=min(sw,sh)*.15; case=(x0+sw*.50,y0+sh*.72 if ratio!='9:16' else y0+sh*.50)
  paper_sheet(draw,case[0],case[1],pr*.92,pr*.62,pal,pal['primary'],im=im,active=active)
  if ratio=='9:16': stations=[(x0+sw*.28,y0+sh*.18),(x0+sw*.72,y0+sh*.80)]
  else: stations=[(x0+sw*.20,y0+sh*.28),(x0+sw*.80,y0+sh*.28)]
  for i,(sx,sy) in enumerate(stations):
   col=pal['secondary'] if i==0 else pal['accent']; desk(draw,sx,sy,pr*2.3,pr*1.0,pal,col,im=im,active=active,kind='work' if i else 'research')
   if ratio!='9:16': person(draw,sx-pr*.70,sy+pr*.62,hero_scale*.39,pal,gesture=active,secondary=bool(i),im=im)
   draw_route(draw,[case,(sx,sy+pr*.45 if ratio!='9:16' else sy)],pal,max(5,int(sw*.006)),active)
   q=clamp((active-i*.08)/(1-i*.08)); token(draw,case[0]+(sx-case[0])*q,case[1]+(sy-case[1])*q,pr*.13,pal,str(i+1),q>.48,im=im)
  return True

 if mech=='U27' and 'physical-spatial-mechanism' in fam and 'gate-release' in bp:
  # General/product resolved-customer payoff: completed case visibly reaches the customer and closes the loop.
  cy=y0+sh*.56; pr=min(sw,sh)*(.185 if ratio!='9:16' else .165); source=x0+sw*.13; gate=x0+sw*.47; cust=x0+sw*.82
  paper_sheet(draw,source,cy,pr*.95,pr*.68,pal,pal['primary'],im=im,active=active)
  # confirmation gate is a substantial physical portal with a resolved-state crossbar.
  gw=pr*.62; gh=pr*.86; gap=pr*(.10+.30*active)
  soft_shadow(im,(gate-pr*.92,cy+gh*.72,gate+pr*.92,cy+gh*1.02),alpha=18,blur=max(5,int(pr*.10)))
  iso_block(draw,gate,cy,pr*1.55,pr*1.70,pr*.16,pal,pal['secondary'],im=im,active=active)
  # open lane is redrawn over the block to preserve the semantic gate.
  line(draw,[(gate-gap,cy-gh),(gate-gap,cy+gh)],pal['secondary'],max(6,int(pr*.065))); line(draw,[(gate+gap,cy-gh),(gate+gap,cy+gh)],pal['secondary'],max(6,int(pr*.065)))
  if active>.55: line(draw,[(gate-gap*.75,cy),(gate+gap*.75,cy)],pal['accent'],max(4,int(pr*.045)))
  # customer/device form a clear resolved hero, not a small endpoint icon.
  person(draw,cust,cy+pr*.30,hero_scale*.66,pal,gesture=active,secondary=False,im=im)
  dx=cust-pr*.55; dy=cy-pr*.55; rounded(draw,(dx-pr*.40,dy-pr*.28,dx+pr*.40,dy+pr*.28),pr*.08,mix(pal['surface'],pal['accent'],.06),mix(pal['accent'],pal['ink'],.14),2)
  ellipse(draw,(dx-pr*.07,dy-pr*.07,dx+pr*.07,dy+pr*.07),pal['accent'] if active>.55 else mix(pal['muted'],pal['surface'],.35))
  pts=[(source+pr*.52,cy),(gate-pr*.55,cy),(gate+pr*.55,cy),(cust-pr*.55,cy-pr*.15)]; draw_route(draw,pts,pal,max(6,int(sw*.007)),active)
  q=active*3; i=min(2,int(q)); t=q-i; a,b=pts[i],pts[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,pr*.14,pal,'✓',active>.58,im=im)
  return True

 if mech=='U24' and 'product-in-context' in fam:
  # performance payoff: a large before→after proof stage with product context, not a dashboard card.
  bx0=x0+sw*.035; bx1=x1-sw*.035; by0=y0+sh*.07; by1=y1-sh*.045
  soft_shadow(im,(bx0+sw*.02,by1-sh*.015,bx1-sw*.02,by1+sh*.035),alpha=20,blur=max(6,int(sh*.022)))
  rounded(draw,(bx0,by0,bx1,by1),min(sw,sh)*.026,pal['surface'],mix(pal['muted'],pal['bg'],.24),2)
  # subtle product rail makes the metric feel evidenced by the same system.
  railh=sh*.075; draw.rectangle((int(bx0),int(by0),int(bx1),int(by0+railh)),fill=mix(pal['surface'],pal['primary'],.035))
  for i,c in enumerate((pal['primary'],pal['secondary'],pal['accent'])): ellipse(draw,(bx0+18+i*18,by0+18,bx0+25+i*18,by0+25),c)
  cy=by0+(by1-by0)*.57; r=min(sw,sh)*(.145 if ratio!='9:16' else .115); lx=bx0+(bx1-bx0)*.20; rx=bx0+(bx1-bx0)*.80
  # oversized clock dials + large numeric proof.
  for xx,col,val in ((lx,pal['secondary'],'19'),(rx,pal['accent'],'6')):
   soft_blob(im,(xx-r*1.2,cy-r*1.2,xx+r*1.2,cy+r*1.2),mix(pal['bg'],col,.07),blur=max(12,int(r*.16)))
   ellipse(draw,(xx-r,cy-r,xx+r,cy+r),mix(pal['surface'],col,.045),mix(col,pal['ink'],.13),max(3,int(r*.035)))
   for a in range(0,360,45):
    aa=math.radians(a); xA=xx+math.cos(aa)*r*.78; yA=cy+math.sin(aa)*r*.78; xB=xx+math.cos(aa)*r*.90; yB=cy+math.sin(aa)*r*.90; line(draw,[(xA,yA),(xB,yB)],mix(col,pal['surface'],.20),max(1,int(r*.018)))
   line(draw,[(xx,cy),(xx+r*.05,cy-r*.50)],col,max(4,int(r*.045))); line(draw,[(xx,cy),(xx+r*.46,cy+r*.12)],col,max(4,int(r*.045)))
   if not hide_text:
    f=font(max(22,int(r*.52)),bold=True); bb=draw.textbbox((0,0),val,font=f); draw.text((xx-(bb[2]-bb[0])/2,cy+r*1.08),val,font=f,fill=col)
  # descending time curve crosses a physical milestone track and finishes with a resolved proof seal.
  pts=[(lx+r*1.12,cy+r*.30),(bx0+(bx1-bx0)*.43,cy+r*.22),(bx0+(bx1-bx0)*.56,cy-r*.06),(rx-r*1.12,cy-r*.36)]
  draw_route(draw,pts,pal,max(6,int(sw*.007)),active)
  for j in range(3):
   xx=bx0+(bx1-bx0)*(.43+j*.065); yy=cy+r*(.18-j*.11); rr=r*.055; ellipse(draw,(xx-rr,yy-rr,xx+rr,yy+rr),[pal['secondary'],pal['primary'],pal['accent']][j])
  q=active*(len(pts)-1); i=min(len(pts)-2,int(q)); t=q-i; a,b=pts[i],pts[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,r*.18,pal,'✓',active>.60,im=im)
  return True

 # ---- Crypto: spatial mechanisms with physical infrastructure language ----
 if mech=='C11' and 'physical-spatial-mechanism' in fam:
  cy=y0+sh*.56; pr=min(sw,sh)*.14
  if verb in ('approve','release','settle'):
   vault=x0+sw*.13; gate=x0+sw*.42; wallet=x0+sw*.70; receipt=x0+sw*.88
   iso_block(draw,vault,cy,pr*1.55,pr*1.25,pr*.20,pal,pal['secondary'],im=im,active=active)
   # vault bars and approval gate
   for j in (-.28,0,.28): line(draw,[(vault+pr*j,cy-pr*.36),(vault+pr*j,cy+pr*.36)],mix(pal['secondary'],pal['bg'],.25),max(2,int(pr*.025)))
   gap=pr*(.08+.30*active); line(draw,[(gate-gap,cy-pr*.62),(gate-gap,cy+pr*.62)],pal['primary'],max(5,int(pr*.055))); line(draw,[(gate+gap,cy-pr*.62),(gate+gap,cy+pr*.62)],pal['primary'],max(5,int(pr*.055)))
   iso_block(draw,wallet,cy-pr*.02,pr*1.25,pr*.85,pr*.14,pal,pal['accent'],im=im,active=active)
   paper_sheet(draw,receipt,cy+pr*.10,pr*.70,pr*.92,pal,pal['primary'],im=im,active=active)
   pts=[(vault+pr*.78,cy),(gate-pr*.40,cy),(gate+pr*.40,cy),(wallet-pr*.62,cy),(receipt-pr*.38,cy+pr*.08)]; draw_route(draw,pts,pal,max(6,int(sw*.007)),active)
   q=active*(len(pts)-1); i=min(len(pts)-2,int(q)); t=q-i; a,b=pts[i],pts[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,pr*.13,pal,'✓' if active>.65 else 'pay',active>.48,im=im)
  else:
   wallet=x0+sw*.17; identity=x0+sw*.49; agent=x0+sw*.82
   iso_block(draw,wallet,cy,pr*1.25,pr*.86,pr*.15,pal,pal['secondary'],im=im,active=active)
   # identity passport chamber with lock aperture
   paper_sheet(draw,identity,cy,pr*1.15,pr*.88,pal,pal['primary'],im=im,active=active)
   rr=pr*.13; ellipse(draw,(identity-rr,cy-rr,identity+rr,cy+rr),pal['primary']); line(draw,[(identity,cy-rr*.2),(identity,cy+rr*.55)],pal['surface'],max(2,int(rr*.18)))
   # onchain agent represented as a compact machine/identity terminal, not a generic human
   iso_block(draw,agent,cy,pr*1.30,pr*1.10,pr*.18,pal,pal['accent'],im=im,active=active)
   ant=cy-pr*.72; line(draw,[(agent,cy-pr*.55),(agent,ant)],pal['accent'],max(2,int(pr*.025))); ellipse(draw,(agent-pr*.05,ant-pr*.05,agent+pr*.05,ant+pr*.05),pal['accent'])
   pts=[(wallet+pr*.62,cy),(identity-pr*.58,cy),(identity+pr*.58,cy),(agent-pr*.65,cy)]; draw_route(draw,pts,pal,max(6,int(sw*.007)),active)
   q=active*3; i=min(2,int(q)); t=q-i; a,b=pts[i],pts[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,pr*.13,pal,'auth',active>.50,im=im)
  return True

 if mech=='C09' and 'physical-spatial-mechanism' in fam:
  cy=y0+sh*.56; pr=min(sw,sh)*.12; ident=x0+sw*.18; record=x0+sw*.50; rep=x0+sw*.82
  paper_sheet(draw,ident,cy,pr*.95,pr*.72,pal,pal['secondary'],im=im,active=active)
  # settlement record as isometric ledger block
  iso_block(draw,record,cy,pr*1.6,pr*1.15,pr*.18,pal,pal['primary'],im=im,active=active)
  # reputation tower grows with active state
  levels=4; basey=cy+pr*.55
  for i in range(levels):
   q=clamp(active*1.25-i*.16); yy=basey-i*pr*.33; iso_block(draw,rep,yy,pr*(1.25-.10*i),pr*.34,pr*.08,pal,pal['accent'],im=None,active=q)
  pts=[(ident+pr*.55,cy),(record-pr*.82,cy),(record+pr*.82,cy),(rep-pr*.70,cy)]; draw_route(draw,pts,pal,max(6,int(sw*.007)),active)
  q=active*3; i=min(2,int(q)); t=q-i; a,b=pts[i],pts[i+1]; token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,pr*.14,pal,'rep',active>.55,im=im)
  return True

 return False

def evidence_trail(draw,pts,pal,active,im=None):
 # A sequence of material evidence slips that can survive handoffs and review.
 for i,(x,y) in enumerate(pts):
  q=clamp((active-i*.12)/(1-i*.12 if i<7 else 1))
  w=46; h=31
  paper_sheet(draw,x,y,w,h,pal,[pal['secondary'],pal['primary'],pal['accent']][i%3],im=im,active=q)

def draw_route(draw,pts,pal,width,active_t):
 base=mix(pal['muted'],pal['bg'],.45); line(draw,pts,base,width)
 if active_t>0:
  # progressive piecewise interpolation
  segs=[]; lengths=[]; total=0
  for a,b in zip(pts,pts[1:]):
   l=math.dist(a,b); lengths.append(l); total+=l
  rem=total*clamp(active_t); out=[pts[0]]
  for i,l in enumerate(lengths):
   if rem>=l: out.append(pts[i+1]); rem-=l
   else:
    if l>0:
     t=rem/l; a,b=pts[i],pts[i+1]; out.append((a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t))
    break
  if len(out)>1: line(draw,out,pal['primary'],width)

def stage_coords(box):
 x0,y0,x1,y1=box; return x0,y0,x1,y1,x1-x0,y1-y0

def family_art(im,draw,scene,plan,ratio,progress,hide_text=False):
 pal=palette(plan); L=layout(im,ratio); x0,y0,x1,y1,sw,sh=stage_coords(L['stage']); fam=scene.get('visualizationFamily',''); p=ease(clamp(progress)); active=clamp((p-.10)/.68); settle=clamp((p-.78)/.22)
 label=(scene.get('persistentObject') or {}).get('label','item'); blueprint=scene.get('compositionBlueprint',''); topology=scene.get('compositionTopology','')
 hero_scale=min(sw,sh)*(.84 if ratio!='9:16' else .78)
 semantic_environment(im,draw,scene,plan,ratio,L['stage'],active)
 if premium_mechanism_art(im,draw,scene,plan,ratio,p,active,settle,L['stage'],hero_scale,label,hide_text):
  return

 # HUMAN ACTION — blueprint-aware causal staging with semantic occlusion.
 if 'human-action' in fam:
  cy=y0+sh*.55; left=x0+sw*.25; right=x0+sw*.76
  if 'over-shoulder' in blueprint or topology=='depth':
   # foreground lead + returned evidence package, with depth rather than another two-node handoff.
   person(draw,left,cy+sh*.06,hero_scale*.78,pal,gesture=active,secondary=False,im=im)
   pr=min(sw,sh)*(.195 if ratio!='9:16' else .175)
   # Package physically arrives into the review field. Portrait/square receive extra travel so the handoff reads at smaller width.
   if ratio=='9:16':
    pxf=right; pyf=cy+sh*.08; px=pxf; py=pyf+(1-active)*sh*.20
   else:
    pxf=right; pyf=cy-sh*.02; px=pxf+(1-active)*sw*(.18 if ratio=='1:1' else .12); py=pyf
   soft_shadow(im,(px-pr*.9,py+pr*.78,px+pr*.9,py+pr*1.08),alpha=24,blur=max(5,int(pr*.18)))
   rounded(draw,(px-pr,py-pr*.72,px+pr,py+pr*.72),pr*.24,mix(pal['surface'],pal['accent'],.08),mix(pal['accent'],pal['ink'],.18),max(1,int(pr*.035)))
   # evidence stack resolves progressively as the package arrives.
   for i in range(3):
    yy=py-pr*.34+i*pr*.31; fill=mix(pal['muted'],pal['surface'],.42 if active>(i+1)*.20 else .18)
    rounded(draw,(px-pr*.55,yy-pr*.06,px+pr*(.12+.38*active),yy+pr*.06),pr*.05,fill)
   # physical desk + evidence slips make the review context legible without relying on labels.
   desk_y=cy+sh*.28; line(draw,[(left-hero_scale*.23,desk_y),(left+hero_scale*.34,desk_y)],mix(pal['ink'],pal['bg'],.64),max(3,int(sw*.005)))
   evpts=[(left+hero_scale*.28+i*pr*.42,desk_y-pr*(.18+(i%2)*.12)) for i in range(3)]
   evidence_trail(draw,evpts,pal,active,im=im)
   pts=[(left+hero_scale*.20,cy-sh*.02),(x0+sw*.48,cy-sh*.10),(px-pr*1.05,py)]
   draw_route(draw,pts,pal,max(5,int(sw*.008)),active)
   if active>.12:
    if active<.5: a,b=pts[0],pts[1]; t=active*2
    else: a,b=pts[1],pts[2]; t=(active-.5)*2
    token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,max(15,int(min(sw,sh)*.04)),pal,'✓' if active>.68 else label,active>.55,im=im)
  elif 'handoff-diagonal' in blueprint or topology=='diagonal':
   # Two people occupy staggered depth planes; result travels on a diagonal lane behind both bodies.
   lcy=cy+sh*.08; rcy=cy-sh*.07
   pts=[(left+hero_scale*.22,lcy-sh*.10),(x0+sw*.50,cy-sh*.10),(right-hero_scale*.22,rcy+sh*.02)]
   draw_route(draw,pts,pal,max(6,int(sw*.009)),active)
   # review/checkpoint is a real evaluator workbench with a bounded repair return.
   mx,my=pts[1]; cr=min(sw,sh)*.072
   role_station(draw,mx,my,cr*2.8,cr*1.8,pal,pal['secondary'],'review',im=im,active=active)
   if scene.get('visualVerb') in ('validate','repair','check') or scene.get('mechanismId') in ('A07','U07'):
    loop_y=my+cr*2.15; loop=[(mx+cr*.72,my+cr*.35),(mx+cr*1.5,loop_y),(mx-cr*1.5,loop_y),(mx-cr*.72,my+cr*.35)]
    draw_route(draw,loop,pal,max(3,int(sw*.004)),clamp((active-.48)/.40))
    if active>.66:
     q=clamp((active-.66)/.34); a,b=loop[1],loop[2]; token(draw,a[0]+(b[0]-a[0])*q,a[1]+(b[1]-a[1])*q,cr*.22,pal,'!',True,im=im)
   if active>.08:
    if active<.5:a,b=pts[0],pts[1];t=active*2
    else:a,b=pts[1],pts[2];t=(active-.5)*2
    token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,max(15,int(min(sw,sh)*.04)),pal,'✓' if active>.70 else label,active>.58,im=im)
   person(draw,left,lcy,hero_scale*.76,pal,gesture=active,secondary=False,im=im)
   person(draw,right,rcy,hero_scale*.76,pal,gesture=1-active,secondary=True,im=im)
  elif 'action-zone' in blueprint:
   # One actor operates a bounded work zone; second actor receives the completed state.
   workx=x0+sw*.50; worky=cy-sh*.02; wr=min(sw,sh)*.16
   rounded(draw,(workx-wr*1.18,worky-wr*.70,workx+wr*1.18,worky+wr*.70),wr*.23,mix(pal['surface'],pal['primary'],.065),mix(pal['muted'],pal['bg'],.20),2)
   # internal progress rail gives the zone causal meaning.
   draw_route(draw,[(workx-wr*.70,worky),(workx+wr*.70,worky)],pal,max(4,int(sw*.006)),active)
   evidence_trail(draw,[(workx-wr*.72,worky-wr*.82),(workx,worky-wr*.95),(workx+wr*.72,worky-wr*.82)],pal,active,im=im)
   for i in range(3):
    xx=workx-wr*.55+i*wr*.55; rr=wr*.075
    ellipse(draw,(xx-rr,worky-rr,xx+rr,worky+rr),pal['accent'] if active>(i+1)*.25 else mix(pal['muted'],pal['surface'],.35))
   person(draw,left,cy+sh*.04,hero_scale*.68,pal,gesture=active,secondary=False,im=im)
   person(draw,right,cy+sh*.04,hero_scale*.62,pal,gesture=.25,secondary=True,im=im)
   if active>.55:
    token(draw,workx+wr*.95,worky,max(15,int(min(sw,sh)*.04)),pal,'✓',True,im=im)
  else:
   pts=[(left+hero_scale*.24,cy-sh*.045),(x0+sw*.50,cy-sh*.045),(right-hero_scale*.24,cy-sh*.045)]
   draw_route(draw,pts,pal,max(6,int(sw*.010)),active)
   if scene.get('visualVerb') in ('validate','repair','check') or scene.get('mechanismId') in ('A07','U07'):
    midx=x0+sw*.50; loop_y=cy+sh*.20; col=mix(pal['muted'],pal['bg'],.30)
    line(draw,[(midx,cy-sh*.04),(midx,loop_y),(left+hero_scale*.18,loop_y)],col,max(3,int(sw*.005)))
   if active>.06:
    if active<.5: a,b=pts[0],pts[1]; t=active*2
    else: a,b=pts[1],pts[2]; t=(active-.5)*2
    token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,max(16,int(min(sw,sh)*.045)),pal,'✓' if active>.70 else label,active>.58,im=im)
   person(draw,left,cy,hero_scale*.72,pal,gesture=active,secondary=False,im=im)
   person(draw,right,cy,hero_scale*.72,pal,gesture=1-active,secondary=True,im=im)

 # PRODUCT WORLD — interface/media variants retain product context without becoming a dashboard deck.
 elif 'product-in-context' in fam:
  bx=(x0+sw*.025,y0+sh*.07,x1-sw*.025,y1-sh*.035)
  soft_shadow(im,(bx[0]+sw*.02,bx[3]-sh*.035,bx[2]-sw*.02,bx[3]+sh*.03),alpha=18,blur=max(6,int(sh*.025)))
  rounded(draw,bx,min(sw,sh)*.03,pal['surface'],mix(pal['muted'],pal['bg'],.38),max(1,int(sw*.002)))
  barh=sh*.075; draw.rectangle((bx[0],bx[1],bx[2],bx[1]+barh),fill=mix(pal['surface'],pal['muted'],.14))
  for i in range(3): ellipse(draw,(bx[0]+18+i*18,bx[1]+barh*.36,bx[0]+25+i*18,bx[1]+barh*.54),[pal['primary'],pal['secondary'],pal['accent']][i])
  if 'interface-focus' in blueprint:
   # One dominant product surface + performance evidence integrated into it.
   ux=bx[0]+sw*.055; uy=bx[1]+barh+sh*.055; uw=(bx[2]-bx[0])*.82; uh=sh*.48
   rounded(draw,(ux,uy,ux+uw,uy+uh),min(sw,sh)*.022,mix(pal['bg'],pal['surface'],.68))
   # before/after flow line, not a card grid.
   gx=ux+uw*.10; gy=uy+uh*.72; gw=uw*.76; gh=uh*.48
   vals=[.80,.72,.61,.46,.31]
   pts=[(gx+gw*i/(len(vals)-1),gy-gh*(1-v)) for i,v in enumerate(vals)]
   draw_route(draw,pts,pal,max(4,int(sw*.006)),active)
   for i,(xx,yy) in enumerate(pts):
    rr=max(3,int(min(sw,sh)*.010)); ellipse(draw,(xx-rr,yy-rr,xx+rr,yy+rr),pal['accent'] if i==len(pts)-1 else pal['primary'])
   # compact before/after values sourced from facts when available.
   nums=[]
   for ft in plan.get('_requiredFacts',[]): nums += re.findall(r'-?\d+(?:\.\d+)?%?',str(ft))
   fbig=font(max(18,int(min(sw,sh)*.075)),bold=True)
   if not hide_text:
    leftv=nums[0] if nums else '19'; rightv=nums[-1] if len(nums)>1 else ('6' if nums else '6')
    draw.text((ux+uw*.08,uy+uh*.10),leftv,font=fbig,fill=mix(pal['ink'],pal['bg'],.12))
    draw.text((ux+uw*.68,uy+uh*.10),rightv,font=fbig,fill=pal['accent'])
  else:
   # media-to-world: product is a place where a real request enters and leaves as an owned case.
   ux=bx[0]+sw*.055; uy=bx[1]+barh+sh*.055; uw=(bx[2]-bx[0])*.63
   rounded(draw,(ux,uy,ux+uw,uy+sh*.42),min(sw,sh)*.022,mix(pal['bg'],pal['surface'],.64))
   # product chrome has a left rail, ticket body and one highlighted request—not a generic empty browser.
   railw=uw*.12; rounded(draw,(ux,uy,ux+railw,uy+sh*.42),min(sw,sh)*.012,mix(pal['surface'],pal['primary'],.055))
   for j in range(4):
    yy=uy+sh*(.055+j*.075); rr=max(2,int(min(sw,sh)*.008)); ellipse(draw,(ux+railw*.42-rr,yy-rr,ux+railw*.42+rr,yy+rr),pal['primary'] if j==1 else mix(pal['muted'],pal['surface'],.32))
   for i,lw in enumerate([.80,.60,.70]): rounded(draw,(ux+railw+sw*.035,uy+sh*(.07+i*.082),ux+railw+sw*(.035+lw*.35),uy+sh*(.102+i*.082)),5,mix(pal['muted'],pal['surface'],.38))
   paper_sheet(draw,ux+uw*.72,uy+sh*.20,uw*.22,sh*.18,pal,pal['accent'],im=im,active=active)
   px=bx[2]-sw*.14; py=uy+sh*.21; sx=ux+uw*.67; sy=uy+sh*.20
   draw_route(draw,[(sx,sy),(px,py)],pal,max(4,int(sw*.006)),active)
   tx=sx+(px-sx)*active; ty=sy+(py-sy)*active
   token(draw,tx,ty,max(17,int(min(sw,sh)*.048)),pal,'✓' if active>.72 else label,active>.40,im=im)
   if ratio!='9:16': person(draw,bx[0]+sw*.07,bx[3]-sh*.055,hero_scale*.48,pal,gesture=.8,secondary=True,im=im)

 # OBJECT TRANSFORMATION — blueprint-aware so split/recombine and state-ladder do not look identical.
 elif 'object-transformation' in fam:
  if 'state-ladder' in blueprint or topology=='vertical':
   rr=min(sw,sh)*(.178 if ratio!='9:16' else .135)
   if ratio=='9:16':
    cx=x0+sw*.52; top=y0+sh*.14; gap=sh*.25; stations=[(cx,top+i*gap) for i in range(3)]
   else:
    stations=[(x0+sw*.20,y0+sh*.55),(x0+sw*.50,y0+sh*.55),(x0+sw*.80,y0+sh*.55)]
   draw_route(draw,stations,pal,max(6,int(sw*.009)),active)
   kinds=['search','work','data']
   for i,(xx,yy) in enumerate(stations):
    boxr=rr*1.35; role_station(draw,xx,yy,boxr*2.0,boxr*1.12,pal,[pal['secondary'],pal['primary'],pal['accent']][i],kinds[i],im=im,active=active)
    # evidence slip accumulates beside/below each specialist tool station.
    if ratio=='9:16': ex,ey=xx+boxr*.98,yy+boxr*.18
    else: ex,ey=xx,yy+boxr*.82
    paper_sheet(draw,ex,ey,boxr*.58,boxr*.38,pal,[pal['secondary'],pal['primary'],pal['accent']][i],im=im,active=active)
   # three owned task particles travel through the same tool ladder with phase offsets
   for j,phase in enumerate((0,.16,.32)):
    q=clamp((active-phase)/(1-phase));
    if q<.5: a,b=stations[0],stations[1]; t=q*2
    else: a,b=stations[1],stations[2]; t=(q-.5)*2
    xx=a[0]+(b[0]-a[0])*t + (j-1)*rr*.55; yy=a[1]+(b[1]-a[1])*t
    token(draw,xx,yy,rr*.25,pal,str(j+1),q>.55,im=im)
  else:
   cx=x0+sw*.50; cy=y0+sh*(.62 if ratio!='9:16' else .52); rr=min(sw,sh)*(.235 if ratio!='9:16' else .205)
   # central brief/package
   soft_shadow(im,(cx-rr*.85,cy+rr*.70,cx+rr*.85,cy+rr*.96),alpha=22,blur=max(5,int(rr*.16)))
   rounded(draw,(cx-rr*.90,cy-rr*.58,cx+rr*.90,cy+rr*.58),rr*.25,mix(pal['surface'],pal['primary'],.09),mix(pal['primary'],pal['ink'],.16),2)
   token(draw,cx,cy,rr*.27,pal,label,active>.55,im=im)
   # split branches stay behind the child tasks
   destinations=[]
   if ratio=='9:16': destinations=[(cx,cy-rr*2.35),(cx-rr*1.8,cy+rr*2.0),(cx+rr*1.8,cy+rr*2.0)]
   else: destinations=[(x0+sw*.18,y0+sh*.23),(x0+sw*.50,y0+sh*.18),(x0+sw*.82,y0+sh*.23)]
   kinds=['search','work','data']
   for i,dst in enumerate(destinations):
    draw_route(draw,[(cx,cy),dst],pal,max(4,int(sw*.006)),active)
    # each branch terminates in an owned specialist station rather than a floating dot.
    role_station(draw,dst[0],dst[1],rr*1.48,rr*.88,pal,[pal['secondary'],pal['primary'],pal['accent']][i],kinds[i],im=im,active=active)
    dist=clamp(active*1.18); xx=cx+(dst[0]-cx)*dist; yy=cy+(dst[1]-cy)*dist
    token(draw,xx,yy,rr*.25,pal,str(i+1),active>.42,im=im)

 # PHYSICAL / SPATIAL MECHANISM — blueprint-specific physical logic, not one generic circle-and-line rig.
 elif 'physical-spatial-mechanism' in fam:
  cy=y0+sh*.55; pr=min(sw,sh)*(.195 if ratio!='9:16' else .175)
  if 'gate-release' in blueprint:
   if ratio=='9:16': source=(x0+sw*.5,y0+sh*.16); gate=(x0+sw*.5,y0+sh*.50); dest=(x0+sw*.5,y0+sh*.84)
   else: source=(x0+sw*.10,cy); gate=(x0+sw*.50,cy); dest=(x0+sw*.90,cy)
   draw_route(draw,[source,gate,dest],pal,max(7,int(min(sw,sh)*.018)),active)
   gx,gy=gate; gw=pr*.78; gh=pr*1.45
   # barrier halves move apart only after the process reaches approval.
   open_amt=clamp((active-.52)/.38)*pr*.48
   rounded(draw,(gx-gw-open_amt,gy-gh*.52,gx-pr*.10-open_amt,gy+gh*.52),pr*.12,mix(pal['surface'],pal['secondary'],.12),mix(pal['secondary'],pal['ink'],.15),2)
   rounded(draw,(gx+pr*.10+open_amt,gy-gh*.52,gx+gw+open_amt,gy+gh*.52),pr*.12,mix(pal['surface'],pal['secondary'],.12),mix(pal['secondary'],pal['ink'],.15),2)
   for pt,col in ((source,pal['primary']),(dest,pal['accent'])):
    xx,yy=pt; rounded(draw,(xx-pr*.58,yy-pr*.40,xx+pr*.58,yy+pr*.40),pr*.18,mix(pal['surface'],col,.07),mix(col,pal['ink'],.13),2)
   if scene.get('mechanismId')=='U27':
    # Cause/effect closes on a person + completed record rather than an abstract destination alone.
    if ratio=='9:16':
     person(draw,x0+sw*.20,y0+sh*.80,hero_scale*.52,pal,gesture=active,secondary=False,im=im)
     paper_sheet(draw,x0+sw*.76,y0+sh*.82,pr*.85,pr*.58,pal,pal['accent'],im=im,active=active)
    else:
     person(draw,x1-sw*.18,cy+sh*.14,hero_scale*.56,pal,gesture=active,secondary=False,im=im)
     paper_sheet(draw,x1-sw*.08,cy-pr*.82,pr*.86,pr*.58,pal,pal['accent'],im=im,active=active)
   if active<.5:a,b=source,gate;t=active*2
   else:a,b=gate,dest;t=(active-.5)*2
   token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,max(16,int(min(sw,sh)*.043)),pal,'✓' if active>.72 else label,active>.55,im=im)
  elif 'channel-transfer' in blueprint:
   if ratio=='9:16': pts=[(x0+sw*.5,y0+sh*.15),(x0+sw*.5,y0+sh*.48),(x0+sw*.5,y0+sh*.83)]
   else: pts=[(x0+sw*.10,cy),(x0+sw*.50,cy),(x0+sw*.90,cy)]
   draw_route(draw,pts,pal,max(7,int(min(sw,sh)*.018)),active)
   # middle checkpoint is a channel sleeve, not a giant circular backplate.
   cx,ccy=pts[1]; cw=pr*1.05; ch=pr*.72
   soft_shadow(im,(cx-cw*.72,ccy+ch*.72,cx+cw*.72,ccy+ch*.98),alpha=19,blur=max(5,int(pr*.15)))
   rounded(draw,(cx-cw,ccy-ch,cx+cw,ccy+ch),pr*.22,mix(pal['surface'],pal['primary'],.075),mix(pal['primary'],pal['ink'],.14),2)
   for i in range(3):
    xx=cx-cw*.48+i*cw*.48; rr=pr*.07
    ellipse(draw,(xx-rr,ccy-rr,xx+rr,ccy+rr),pal['accent'] if active>(i+1)/4 else mix(pal['muted'],pal['surface'],.35))
   # source is a request/case sheet; destination is an owned work/output station.
   paper_sheet(draw,pts[0][0],pts[0][1],pr*1.15,pr*.78,pal,pal['secondary'],im=im,active=active)
   role_station(draw,pts[2][0],pts[2][1],pr*1.25,pr*.78,pal,pal['accent'],'work',im=im,active=active)
   if scene.get('mechanismId')=='U16':
    # Routing resolves at a visible operator, not at a faceless endpoint.
    if ratio=='9:16': person(draw,x0+sw*.22,y0+sh*.78,hero_scale*.49,pal,gesture=active,secondary=True,im=im)
    else: person(draw,x1-sw*.13,cy+sh*.20,hero_scale*.44,pal,gesture=active,secondary=True,im=im)
   elif scene.get('mechanismId')=='U06' and ratio!='9:16':
    person(draw,x0+sw*.73,cy+sh*.20,hero_scale*.40,pal,gesture=active,secondary=True,im=im)
   if active<.5:a,b=pts[0],pts[1];t=active*2
   else:a,b=pts[1],pts[2];t=(active-.5)*2
   token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,max(16,int(min(sw,sh)*.043)),pal,label,active>.52,im=im)
  elif 'circular-loop' in blueprint:
   cx=x0+sw*.51; ccy=y0+sh*.54; rr=min(sw,sh)*.22
   if scene.get('visualVerb') in ('approve','release','settle'):
    # Escrow release variant: vault -> approval gate -> wallet -> settlement receipt.
    # This must remain visually distinct from the surrounding authorization loop.
    escrow=(cx-rr*1.68,ccy+rr*.58); check=(cx-rr*.10,ccy); wallet=(cx+rr*1.58,ccy-rr*.52); record=(cx+rr*.82,ccy+rr*1.32)
    path=[escrow,check,wallet,record]
    draw_route(draw,path,pal,max(6,int(sw*.008)),active)
    # Escrow vault: heavy physical container with a gated mouth, not another node.
    ex,ey=escrow; vw=rr*.62; vh=rr*.48
    soft_shadow(im,(ex-vw*.70,ey+vh*.70,ex+vw*.70,ey+vh*.95),alpha=20,blur=max(5,int(rr*.10)))
    rounded(draw,(ex-vw,ey-vh,ex+vw,ey+vh),rr*.14,mix(pal['surface'],pal['secondary'],.09),mix(pal['secondary'],pal['ink'],.16),3)
    for j in (-.42,0,.42): line(draw,[(ex+vw*j,ey-vh*.72),(ex+vw*j,ey+vh*.72)],mix(pal['secondary'],pal['bg'],.28),max(2,int(rr*.025)))
    # Approval gate opens progressively at the decision point.
    gx,gy=check; gh=rr*.60; gap=rr*(.10+.28*active)
    line(draw,[(gx-gap,gy-gh),(gx-gap,gy+gh)],pal['primary'],max(5,int(rr*.055)))
    line(draw,[(gx+gap,gy-gh),(gx+gap,gy+gh)],pal['primary'],max(5,int(rr*.055)))
    # Wallet has a visible receiving slot.
    wx,wy=wallet; ww=rr*.58; wh=rr*.38
    rounded(draw,(wx-ww,wy-wh,wx+ww,wy+wh),rr*.13,mix(pal['surface'],pal['accent'],.09),mix(pal['accent'],pal['ink'],.16),3)
    rounded(draw,(wx-ww*.15,wy-wh*.18,wx+ww*.72,wy+wh*.12),rr*.055,mix(pal['accent'],pal['surface'],.18))
    # Settlement record is a tall receipt with internal proof lines.
    rx,ry=record; rw=rr*.42; rh=rr*.56
    rounded(draw,(rx-rw,ry-rh,rx+rw,ry+rh),rr*.11,mix(pal['surface'],pal['primary'],.07),mix(pal['primary'],pal['ink'],.14),2)
    for j,wf in enumerate((.55,.72,.42)):
     yy=ry-rh*.48+j*rh*.40; rounded(draw,(rx-rw*.58,yy-rr*.025,rx-rw*.58+rw*1.15*wf,yy+rr*.025),rr*.03,mix(pal['muted'],pal['surface'],.38))
    if active<.34:a,b=escrow,check;t=active/.34
    elif active<.70:a,b=check,wallet;t=(active-.34)/.36
    else:a,b=wallet,record;t=(active-.70)/.30
    token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,rr*.16,pal,'✓' if active>.62 else label,active>.50,im=im)
   else:
    # Authorization loop: route surrounds an identity capsule, not an opaque circular cutout.
    soft_shadow(im,(cx-rr*.62,ccy+rr*.45,cx+rr*.62,ccy+rr*.68),alpha=18,blur=max(5,int(rr*.12)))
    rounded(draw,(cx-rr*.52,ccy-rr*.72,cx+rr*.52,ccy+rr*.72),rr*.24,mix(pal['surface'],pal['primary'],.07),mix(pal['primary'],pal['ink'],.13),2)
    # identity dossier detail: portrait seal + credential lines, embedded inside the capsule.
    ir=rr*.12; ellipse(draw,(cx-ir,ccy-rr*.30-ir,cx+ir,ccy-rr*.30+ir),pal['primary'])
    for j,wf in enumerate((.52,.68,.40)):
     yy=ccy+rr*(-.03+j*.20); rounded(draw,(cx-rr*.27,yy-rr*.025,cx-rr*.27+rr*.54*wf,yy+rr*.025),rr*.025,mix(pal['muted'],pal['surface'],.38))
    nodes=[(cx,ccy-rr*1.28),(cx+rr*1.55,ccy),(cx,ccy+rr*1.28),(cx-rr*1.55,ccy)]
    looppts=nodes+[nodes[0]]; draw_route(draw,looppts,pal,max(5,int(sw*.007)),active)
    for i,(xx,yy) in enumerate(nodes): token(draw,xx,yy,rr*.16,pal,str(i+1),active>(i+1)*.16,im=im)
    token(draw,cx,ccy,rr*.22,pal,label,active>.48,im=im)
  else:
   # central apparatus is a chamber/gateway, not a hard circular plate.
   if ratio=='9:16': pts=[(x0+sw*.5,y0+sh*.12),(x0+sw*.5,y0+sh*.50),(x0+sw*.5,y0+sh*.86)]
   else: pts=[(x0+sw*.08,cy),(x0+sw*.50,cy),(x0+sw*.92,cy)]
   source,center,dest=pts
   draw_route(draw,pts,pal,max(8,int(min(sw,sh)*.020)),active)
   # material input/output objects make the apparatus read as a process rather than a diagram.
   paper_sheet(draw,source[0],source[1],pr*1.15,pr*.80,pal,pal['secondary'],im=im,active=active)
   if scene.get('mechanismId')=='C09':
    # reputation destination is an identity dossier with a visible score seal.
    paper_sheet(draw,dest[0],dest[1],pr*1.20,pr*.86,pal,pal['accent'],im=im,active=active)
    sr=pr*.16; ellipse(draw,(dest[0]+pr*.28-sr,dest[1]+pr*.18-sr,dest[0]+pr*.28+sr,dest[1]+pr*.18+sr),pal['accent'])
   else:
    role_station(draw,dest[0],dest[1],pr*1.28,pr*.80,pal,pal['accent'],'work',im=im,active=active)
   cx,ccy=center; cw=pr*1.18; ch=pr*.92
   soft_shadow(im,(cx-cw*.70,ccy+ch*.72,cx+cw*.70,ccy+ch*.96),alpha=20,blur=max(5,int(pr*.16)))
   rounded(draw,(cx-cw,ccy-ch,cx+cw,ccy+ch),pr*.26,mix(pal['surface'],pal['primary'],.075),mix(pal['primary'],pal['ink'],.14),2)
   # mechanical throat and three internal states add material depth without concentric circles.
   rounded(draw,(cx-pr*.42,ccy-pr*.62,cx+pr*.42,ccy+pr*.62),pr*.18,mix(pal['bg'],pal['primary'],.06),mix(pal['muted'],pal['bg'],.16),2)
   for i in range(3):
    yy=ccy-pr*.38+i*pr*.38; rr=pr*.075
    ellipse(draw,(cx-rr,yy-rr,cx+rr,yy+rr),pal['accent'] if active>(i+1)/4 else mix(pal['muted'],pal['surface'],.35))
   if active<.5:t=active*2;a,b=source,center
   else:t=(active-.5)*2;a,b=center,dest
   token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,max(17,int(min(sw,sh)*.045)),pal,label,active>.50,im=im)
   if scene.get('mechanismId')=='A04':
    # Agent task execution begins with a visible human brief owner; the apparatus then owns the work.
    if ratio=='9:16':
     person(draw,x0+sw*.24,y0+sh*.79,hero_scale*.48,pal,gesture=active,secondary=False,im=im)
     paper_sheet(draw,x0+sw*.48,y0+sh*.72,pr*.82,pr*.56,pal,pal['secondary'],im=im,active=active)
    else:
     person(draw,x0+sw*.13,cy+sh*.10,hero_scale*.62,pal,gesture=active,secondary=False,im=im)
     evidence_trail(draw,[(x0+sw*.23+i*pr*.48,cy+pr*1.40) for i in range(2)],pal,active,im=im)

 # SPATIAL SYSTEM — branch/recombination when the topology says merge.
 elif 'spatial-system' in fam:
  if scene.get('visualVerb') in ('merge','recombine') or topology in ('radial','branch'):
   center=(x0+sw*.53,y0+sh*.53); rr=min(sw,sh)*(.132 if ratio!='9:16' else .108)
   srcs=[(x0+sw*.12,y0+sh*.22),(x0+sw*.12,y0+sh*.78),(x0+sw*.45,y0+sh*.20)] if ratio!='9:16' else [(x0+sw*.18,y0+sh*.18),(x0+sw*.82,y0+sh*.18),(x0+sw*.18,y0+sh*.67)]
   dest=(x0+sw*.88,y0+sh*.53) if ratio!='9:16' else (x0+sw*.70,y0+sh*.80)
   # Source anchors remain visible after particles move, making the causal branches legible at settle.
   for i,src in enumerate(srcs):
    sx,sy=src; ar=rr*.62
    paper_sheet(draw,sx,sy,ar*1.55,ar*1.02,pal,[pal['secondary'],pal['primary'],pal['accent']][i],im=im,active=active)
    draw_route(draw,[src,center],pal,max(5,int(sw*.007)),active)
    q=clamp(active-i*.08); xx=src[0]+(center[0]-src[0])*q; yy=src[1]+(center[1]-src[1])*q
    token(draw,xx,yy,rr*.34,pal,str(i+1),q>.55,im=im)
   cr=rr*1.55; role_station(draw,center[0],center[1],cr*2.0,cr*1.35,pal,pal['primary'],'work',im=im,active=active)
   # synthesis papers visibly stack into the central workbench.
   evidence_trail(draw,[(center[0]-cr*.48,center[1]+cr*.63),(center[0],center[1]+cr*.70),(center[0]+cr*.48,center[1]+cr*.63)],pal,active,im=im)
   # After recombination, the approved/result state exits to a distinct destination package.
   draw_route(draw,[center,dest],pal,max(5,int(sw*.007)),clamp((active-.58)/.42))
   dx,dy=dest; dr=rr*.92; rounded(draw,(dx-dr,dy-dr*.62,dx+dr,dy+dr*.62),dr*.24,mix(pal['surface'],pal['accent'],.07),mix(pal['accent'],pal['ink'],.14),2)
   q=clamp((active-.62)/.38); token(draw,center[0]+(dest[0]-center[0])*q,center[1]+(dest[1]-center[1])*q,rr*.40,pal,'✓' if q>.65 else label,q>.45,im=im)
  else:
   pts=[(x0+sw*.14,y0+sh*.60),(x0+sw*.50,y0+sh*.31),(x0+sw*.85,y0+sh*.60)] if ratio!='9:16' else [(x0+sw*.5,y0+sh*.15),(x0+sw*.28,y0+sh*.48),(x0+sw*.66,y0+sh*.76)]
   draw_route(draw,pts,pal,max(6,int(min(sw,sh)*.015)),active)
   for i,(xx,yy) in enumerate(pts):
    r=min(sw,sh)*.09; rounded(draw,(xx-r,yy-r*.72,xx+r,yy+r*.72),r*.30,mix(pal['surface'],pal['primary' if i==1 else 'secondary'],.09),mix(pal['muted'],pal['bg'],.20),2)
    ellipse(draw,(xx-r*.18,yy-r*.18,xx+r*.18,yy+r*.18),[pal['secondary'],pal['primary'],pal['accent']][i])
   if active<.5: t=active*2;a,b=pts[0],pts[1]
   else: t=(active-.5)*2;a,b=pts[1],pts[2]
   token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,max(15,int(min(sw,sh)*.04)),pal,label,active>.5,im=im)

 elif 'evidence-data-reveal' in fam:
  # chart is embedded in a product/evidence surface with before/after anchors.
  panel=(x0+sw*.035,y0+sh*.08,x1-sw*.035,y1-sh*.05); rounded(draw,panel,min(sw,sh)*.028,mix(pal['surface'],pal['bg'],.04),mix(pal['muted'],pal['bg'],.30),2)
  gx=x0+sw*.10; gy=y0+sh*.78; gw=sw*.69; gh=sh*.52
  line(draw,[(gx,gy-gh),(gx,gy),(gx+gw,gy)],mix(pal['ink'],pal['bg'],.58),max(2,int(sw*.003)))
  vals=[.72,.66,.62,.50,.42,.35]; pts=[(gx+gw*i/(len(vals)-1),gy-gh*(1-v)) for i,v in enumerate(vals)]
  draw_route(draw,pts,pal,max(4,int(sw*.008)),active)
  ix=min(len(pts)-1,int(active*(len(pts)-1))); xx,yy=pts[ix]; token(draw,xx,yy,max(12,int(min(sw,sh)*.03)),pal,'',True,im=im)
  mx=x0+sw*.68; my=y0+sh*.13; f=font(max(22,int(min(sw,sh)*.115)),bold=True,serif='illustrated' in plan.get('styleProfile',''))
  fact='PROOF'; nums=[]
  for ft in plan.get('_requiredFacts',[]): nums += re.findall(r'-?\d+(?:\.\d+)?%?',str(ft))
  if nums: fact=(nums[-1] if active>.65 else nums[0])
  if not hide_text: draw.text((mx,my),fact,font=f,fill=pal['accent' if active>.6 else 'ink'])
  if active>.72: rounded(draw,(x0+sw*.61,y0+sh*.39,x0+sw*.94,y0+sh*.56),min(sw,sh)*.022,mix(pal['surface'],pal['accent'],.08),mix(pal['accent'],pal['ink'],.12),2)

 elif 'comparison-decision' in fam:
  cy=y0+sh*.56; r=min(sw,sh)*.17; lx=x0+sw*.27; rx=x0+sw*.74
  rounded(draw,(lx-r,cy-r,lx+r,cy+r),r*.24,mix(pal['surface'],pal['secondary'],.08),mix(pal['muted'],pal['bg'],.22),2)
  rounded(draw,(rx-r,cy-r,rx+r,cy+r),r*.24,mix(pal['surface'],pal['primary'],.08),mix(pal['primary'],pal['ink'],.15) if active>.6 else mix(pal['muted'],pal['bg'],.22),2)
  draw_route(draw,[(lx+r*.85,cy),(rx-r*.85,cy)],pal,max(4,int(sw*.007)),active)
  token(draw,lx+(rx-lx)*active,cy,max(15,int(min(sw,sh)*.042)),pal,'✓' if active>.65 else label,active>.55,im=im)

 elif 'hero-emotional' in fam:
  if 'tension-release' in blueprint:
   # Pull back to the whole causal chain: identity -> work -> payment -> reputation.
   if ratio=='9:16': pts=[(x0+sw*.50,y0+sh*(.18+i*.21)) for i in range(4)]
   else: pts=[(x0+sw*(.13+i*.245),y0+sh*.57) for i in range(4)]
   draw_route(draw,pts,pal,max(6,int(min(sw,sh)*.014)),active)
   labels=['ID','WORK','PAY','REP']; cols=[pal['secondary'],pal['primary'],pal['accent'],mix(pal['accent'],pal['primary'],.45)]
   for i,(xx,yy) in enumerate(pts):
    bw=min(sw,sh)*.12; bh=bw*.70
    soft_shadow(im,(xx-bw*.65,yy+bh*.52,xx+bw*.65,yy+bh*.76),alpha=15,blur=max(4,int(bw*.10)))
    rounded(draw,(xx-bw,yy-bh,xx+bw,yy+bh),bw*.24,mix(pal['surface'],cols[i],.07),mix(cols[i],pal['ink'],.13),2)
    # each causally different state gets a different embedded material glyph.
    if i==0:
     rr=bw*.15; ellipse(draw,(xx-rr,yy-rr*.9,xx+rr,yy+rr*1.1),cols[i]); line(draw,[(xx-bw*.35,yy+bw*.33),(xx+bw*.35,yy+bw*.33)],cols[i],max(2,int(bw*.035)))
    elif i==1:
     for j in range(3):
      tx=xx-bw*.34+j*bw*.34; rounded(draw,(tx-bw*.10,yy-bw*.16,tx+bw*.10,yy+bw*.16),bw*.05,cols[i])
    elif i==2:
     rounded(draw,(xx-bw*.42,yy-bw*.22,xx+bw*.42,yy+bw*.22),bw*.07,cols[i]); ellipse(draw,(xx+bw*.18-bw*.07,yy-bw*.07,xx+bw*.18+bw*.07,yy+bw*.07),pal['surface'])
    else:
     for j,hf in enumerate((.28,.48,.72)):
      xj=xx-bw*.30+j*bw*.28; draw.rectangle((int(xj),int(yy+bw*.30-bw*hf),int(xj+bw*.13),int(yy+bw*.30)),fill=cols[i])
    if not hide_text:
     ff=font(max(9,int(bw*.18)),bold=True); bb=draw.textbbox((0,0),labels[i],font=ff); draw.text((xx-(bb[2]-bb[0])/2,yy+bw*.43),labels[i],font=ff,fill=cols[i])
   q=active*(len(pts)-1); i=min(len(pts)-2,int(q)); t=q-i; a,b=pts[i],pts[i+1]
   token(draw,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,max(14,int(min(sw,sh)*.035)),pal,'✓' if active>.78 else label,active>.48,im=im)
  else:
   cx=x0+sw*.66;cy=y0+sh*.54;r=min(sw,sh)*(.295+.018*math.sin(active*math.pi))
   # The result physically arrives into the reviewer field; this is a semantic handoff, not a static hero card.
   if ratio=='9:16': hx=cx; hy=cy-(1-active)*sh*.16
   else: hx=cx+(1-active)*sw*.14; hy=cy-(1-active)*sh*.055
   # halo is a soft atmospheric depth layer BEHIND the hero, never a hard foreground circle.
   soft_blob(im,(hx-r*1.48,hy-r*1.48,hx+r*1.48,hy+r*1.48),mix(pal['bg'],pal['accent'],.22),blur=max(18,int(r*.28)))
   soft_shadow(im,(hx-r*.90,hy+r*.68,hx+r*.90,hy+r*.92),alpha=22,blur=max(5,int(r*.16)))
   rounded(draw,(hx-r,hy-r*.72,hx+r,hy+r*.72),r*.26,pal['surface'],mix(pal['primary'],pal['ink'],.18),max(2,int(r*.04)))
   # evidence dossier and approval seal form a composed result, not a lone token in a box.
   paper_sheet(draw,hx-r*.28,hy,r*.88,r*.72,pal,pal['primary'],im=im,active=active)
   sealx=hx+r*.38; sealy=hy+r*.18; sr=r*.13; ellipse(draw,(sealx-sr,sealy-sr,sealx+sr,sealy+sr),pal['accent'] if active>.55 else mix(pal['muted'],pal['surface'],.35))
   if active>.55:
    line(draw,[(sealx-sr*.45,sealy),(sealx-sr*.08,sealy+sr*.35),(sealx+sr*.50,sealy-sr*.40)],pal['surface'],max(2,int(sr*.20)))
   # reviewer desk with three evidence slips creates a believable inspection moment.
   desk_y=y0+sh*.78; line(draw,[(x0+sw*.08,desk_y),(x0+sw*.46,desk_y)],mix(pal['ink'],pal['bg'],.62),max(3,int(sw*.005)))
   evidence_trail(draw,[(x0+sw*(.27+i*.07),desk_y-r*(.22+(i%2)*.10)) for i in range(3)],pal,active,im=im)
   person(draw,x0+sw*.20,y0+sh*.62,hero_scale*.70,pal,gesture=active,secondary=False,im=im)

 else:
  cx=x0+sw*.53;cy=y0+sh*.55;r=min(sw,sh)*.23
  soft_blob(im,(cx-r*1.15,cy-r*1.15,cx+r*1.15,cy+r*1.15),mix(pal['bg'],pal['primary'],.18),blur=max(16,int(r*.22)))
  token(draw,cx,cy,r*.40,pal,label,active>.55,im=im)

 # State/debug overlays are suppressed in production. They may be explicitly enabled for diagnostics.
 if not hide_text and plan.get('_debugOverlays',DEBUG_OVERLAYS_DEFAULT):
  sf=font(max(9,int(min(im.size)*.015)),bold=True); state='IDLE' if p<.18 else 'ACTIVE' if p<.75 else 'SETTLED'; box=(x1-int(sw*.17),y1-int(sh*.075),x1,y1)
  rounded(draw,box,min(sw,sh)*.018,mix(pal['surface'],pal['bg'],.10)); draw.text((box[0]+10,box[1]+7),state,font=sf,fill=pal['primary'])

def apply_camera(im,scene,scene_time,ratio,reduced_motion=False):
 state=sp.camera_state(scene,scene_time,ratio,reduced_motion)
 zoom=float(state['scale']); x_pct=float(state['xPct']); y_pct=float(state['yPct'])
 if abs(zoom-1)<.0005 and abs(x_pct)<.01 and abs(y_pct)<.01:return im
 w,h=im.size; nw=max(w,int(round(w*zoom))); nh=max(h,int(round(h*zoom)))
 tmp=im.resize((nw,nh),Image.Resampling.BICUBIC)
 base_x=(nw-w)/2; base_y=(nh-h)/2
 # Positive camera x means the framing moves right through the world, so crop shifts right.
 x=base_x + w*(x_pct/100.0); y=base_y + h*(y_pct/100.0)
 x=max(0,min(nw-w,x)); y=max(0,min(nh-h,y))
 return tmp.crop((int(round(x)),int(round(y)),int(round(x))+w,int(round(y))+h))

def performance_overlay(im,scene,plan,ratio,perf,hide_text=False):
 """Semantic action execution layer.
 It visualises scheduled action/contact/ownership state without pretending Step D art rigs already exist."""
 d=ImageDraw.Draw(im,'RGBA'); pal=palette(plan); w,h=im.size
 cur=perf.get('currentAction') or {}; verb=cur.get('verb'); p=clamp(cur.get('progress',0) if isinstance(cur,dict) else 0)
 if not verb:return im
 def pt(nx,ny):return int(nx*w),int(ny*h)
 mech=scene.get('mechanismId',''); pid=(scene.get('persistentObject') or {}).get('semanticEntityId')
 # Action geometry is deliberately semantic: one prop moves, makes contact, then causes a visible consequence.
 source=(.18,.60); target=(.78,.60)
 if mech=='A11': source=(.26,.55); target=(.68,.55)
 elif mech=='A12': source=(.22,.58); target=(.58,.58)
 elif mech=='C12': source=(.28,.58); target=(.70,.58)
 elif mech=='U30': source=(.34,.56); target=(.70,.56)
 if verb in {'receive','assign','route','carry-transfer','dock','deliver'}:
  q=ease(clamp(p)); sx,sy=source; tx,ty=target; cx,cy=pt(sp.lerp(sx,tx,q), sp.lerp(sy,ty,q)-.055*math.sin(q*math.pi))
  r=max(7,int(min(w,h)*.014)); owner=(perf.get('owners') or {}).get(pid)
  fill=pal['secondary'] if owner=='source' else pal['accent'] if owner=='in-transfer' else pal['primary']
  soft_shadow(im,(cx-r*1.3,cy+r*.6,cx+r*1.3,cy+r*.9),alpha=22,blur=max(3,int(r*.2)))
  rounded(d,(cx-r*1.2,cy-r*.72,cx+r*1.2,cy+r*.72),r*.45,fill,pal['surface'],max(2,int(r*.13)))
  # target socket/gate reacts only around contact.
  gx,gy=pt(tx,ty); gr=r*1.45; ellipse(d,(gx-gr,gy-gr,gx+gr,gy+gr),mix(pal['bg'],pal['surface'],.12),pal['primary'],max(2,int(r*.12)))
  contact=perf.get('contact')
  if contact:
   strength=float(contact.get('contactStrength',0)); rr=gr*(1+.24*strength); ellipse(d,(gx-rr,gy-rr,gx+rr,gy+rr),(pal['accent'][0],pal['accent'][1],pal['accent'][2],int(85+135*strength)),width=max(2,int(r*.20)))
 elif verb=='process':
  cx,cy=pt(.55,.57); r=max(12,int(min(w,h)*.028)); pulse=.5+.5*math.sin(p*math.pi*2)
  ellipse(d,(cx-r*(1+pulse*.22),cy-r*(1+pulse*.22),cx+r*(1+pulse*.22),cy+r*(1+pulse*.22)),(pal['primary'][0],pal['primary'][1],pal['primary'][2],55),width=max(2,int(r*.14)))
 elif verb=='accumulate':
  tx,ty=(.66,.53) if mech=='A12' else (.67,.55); gx,gy=pt(tx,ty); r=max(4,int(min(w,h)*.007))
  for i in range(5):
   qi=clamp(p*1.35-i*.12); sx=.28+i*.055; sy=.70-i*.025; x,y=pt(sp.lerp(sx,tx,ease(qi)),sp.lerp(sy,ty,ease(qi))); ellipse(d,(x-r,y-r,x+r,y+r),pal['secondary'])
  rr=max(11,int(min(w,h)*.025)); ellipse(d,(gx-rr,gy-rr,gx+rr,gy+rr),mix(pal['surface'],pal['primary'],.10),pal['primary'],max(2,int(rr*.10)))
 elif verb=='distribute':
  sx,sy=(.63,.52); x0,y0=pt(sx,sy); r=max(5,int(min(w,h)*.009))
  for i,(tx,ty) in enumerate([(.72,.42),(.80,.55),(.70,.69)]):
   q=clamp(p*1.2-i*.08); x,y=pt(sp.lerp(sx,tx,ease(q)),sp.lerp(sy,ty,ease(q))); line(d,[(x0,y0),(x,y)],mix(pal['muted'],pal['primary'],.28),max(2,int(r*.35))); ellipse(d,(x-r,y-r,x+r,y+r),pal['accent'])
 elif verb in {'transform','compare'}:
  cx,cy=pt(.55,.56); r=max(16,int(min(w,h)*.035)); q=ease(p)
  if verb=='transform':
   rounded(d,(cx-r*(1+.5*q),cy-r*(.65+.25*q),cx+r*(1+.5*q),cy+r*(.65+.25*q)),r*(.42-.25*q),mix(pal['surface'],pal['primary'],.08),pal['primary'],max(2,int(r*.10)))
  else:
   lx,ly=pt(.35,.57); rx,ry=pt(.72,.57); rr=r*.58
   rounded(d,(lx-rr,ly-rr,lx+rr,ly+rr),rr*.3,mix(pal['surface'],pal['secondary'],.08),pal['secondary'],max(2,int(rr*.12)))
   rounded(d,(rx-rr*(.8+.2*q),ry-rr*(.8+.2*q),rx+rr*(.8+.2*q),ry+rr*(.8+.2*q)),rr*.3,mix(pal['surface'],pal['primary'],.08),pal['primary'],max(2,int(rr*.12)))
 elif verb in {'reveal','prove-resolve','settle'}:
  # consequence hold / settle: restrained semantic emphasis only.
  tx,ty=perf.get('targetPoint',(.55,.55)); cx,cy=pt(tx,ty); r=max(9,int(min(w,h)*.018)); a=int(45+75*ease(p)); ellipse(d,(cx-r,cy-r,cx+r,cy+r),(pal['primary'][0],pal['primary'][1],pal['primary'][2],a),width=max(2,int(r*.12)))
 return im

def render_scene(scene,plan,ratio='16:9',progress=.85,hide_text=False,scene_time=None,reduced_motion=False,camera_enabled=True):
 if wb_pil is not None and str(plan.get('executionMode') or '')=='WHITEBOARD_SEMANTIC_GRAPH':
  return wb_pil.render_scene(scene,plan,ratio,progress,hide_text,scene_time,reduced_motion,camera_enabled)
 size=RATIO_SIZES[ratio]
 key=(ratio,plan.get('brand'),plan.get('styleProfile'))
 if key not in _BACKGROUND_CACHE:
  bg=Image.new('RGBA',size,(255,255,255,255)); bd=ImageDraw.Draw(bg,'RGBA'); draw_background(bg,bd,plan,ratio,0)
  _BACKGROUND_CACHE[key]=bg.copy()
 duration=float((scene.get('semanticPerformanceRuntime') or {}).get('sceneDuration') or scene.get('timingOverrideSeconds') or 1.0)
 if scene_time is None: scene_time=clamp(progress)*duration
 perf=sp.runtime_state(scene,scene_time)
 # Existing family renderer remains the Step C visual base, but its progress is now driven by the active semantic action.
 cur=perf.get('currentAction') or {}
 # Existing scene art keeps cumulative scene progress; independent actions are layered by performance_overlay.
 visual_p=perf.get('sceneProgress',progress)
 im=_BACKGROUND_CACHE[key].copy(); d=ImageDraw.Draw(im,'RGBA')
 headline(im,d,scene,plan,ratio,hide_text); family_art(im,d,scene,plan,ratio,visual_p,hide_text); footer(im,d,scene,plan,ratio,hide_text)
 performance_overlay(im,scene,plan,ratio,perf,hide_text)
 return (apply_camera(im,scene,scene_time,ratio,reduced_motion) if camera_enabled else im).convert('RGB')

def _draw_transition_semantic(im,prev_scene,scene,plan,ratio,state):
 d=ImageDraw.Draw(im,'RGBA'); pal=palette(plan); w,h=im.size; x=int(state['x']*w); y=int(state['y']*h); sc=float(state.get('scale',1)); base=max(12,int(min(w,h)*.035*sc)); typ=state.get('type')
 if typ=='world-geometry-continuity':
  yy=y; line(d,[(0,yy),(w,yy)],pal['primary'],max(4,int(base*.22))); ellipse(d,(x-base*.42,yy-base*.42,x+base*.42,yy+base*.42),pal['accent']); return
 if typ=='media-continuity':
  ww=base*(2.0+state.get('shapeMix',0)*3.0); hh=base*(1.25+state.get('shapeMix',0)*2.0); rounded(d,(x-ww,y-hh,x+ww,y+hh),base*.22,mix(pal['surface'],pal['primary'],.07),pal['primary'],max(2,int(base*.12))); return
 if typ=='typography-continuity':
  # type becomes a spatial marker rather than crossfading a whole layout.
  txt='•'; f=font(max(18,int(base*1.25)),bold=True); d.text((x-base*.35,y-base*.8),txt,font=f,fill=pal['accent']); line(d,[(x,y+base*.3),(x,y+base*1.5)],pal['primary'],max(3,int(base*.15))); return
 if typ=='shape-continuity':
  q=state.get('shapeMix',0); rr=base*(1-q*.3); rounded(d,(x-base*1.05,y-rr,x+base*1.05,y+rr),rr*(1-q*.78),pal['surface'],pal['primary'],max(2,int(base*.13))); return
 # object/motion/meaning continuity: same runtime semantic object carries across the boundary.
 fill=mix(pal['secondary'],pal['accent'],state.get('shapeMix',0)) if typ=='meaning-continuity' else pal['secondary']
 soft_shadow(im,(x-base*1.2,y+base*.65,x+base*1.2,y+base*.92),alpha=28,blur=max(4,int(base*.22)))
 rounded(d,(x-base,y-base*.62,x+base,y+base*.62),base*.34,fill,pal['surface'],max(2,int(base*.11)))

def render_transition_frame(prev_scene,scene,plan,ratio,progress,hide_text=False,reduced_motion=False):
 if wb_pil is not None and str(plan.get('executionMode') or '')=='WHITEBOARD_SEMANTIC_GRAPH':
  return wb_pil.render_transition_frame(prev_scene,scene,plan,ratio,progress,hide_text,reduced_motion)
 st=sp.transition_state(prev_scene,scene,progress)
 if not st.get('enabled'):
  return render_scene(scene if progress>=.5 else prev_scene,plan,ratio,.95 if progress<.5 else .05,hide_text,reduced_motion=reduced_motion)
 # The full layout is not crossfaded. It cuts once while the same semantic runtime identity continues through the boundary.
 if st['baseScene']=='outgoing':
  base=render_scene(prev_scene,plan,ratio,.94,hide_text,reduced_motion=reduced_motion).convert('RGBA')
 else:
  base=render_scene(scene,plan,ratio,.06,hide_text,reduced_motion=reduced_motion).convert('RGBA')
 _draw_transition_semantic(base,prev_scene,scene,plan,ratio,st)
 return base.convert('RGB')

def storyboard(plan,ratio,out,hide_text=False,cols=None):
 scenes=plan['sceneSpecs']; ims=[render_scene(s,plan,ratio,.92,hide_text) for s in scenes]
 thumbw=420 if ratio!='9:16' else 270
 thumbs=[]
 for im in ims:
  scale=thumbw/im.width; thumbs.append(im.resize((thumbw,int(im.height*scale)),Image.Resampling.BICUBIC))
 if cols is None: cols=3 if ratio!='9:16' else 4
 rows=math.ceil(len(thumbs)/cols); gap=18; top=70; tw=max(x.width for x in thumbs);th=max(x.height for x in thumbs)
 sheet=Image.new('RGB',(cols*tw+(cols+1)*gap,top+rows*th+(rows+1)*gap),(20,22,25));sd=ImageDraw.Draw(sheet)
 title=f"{plan['briefId']} · {ratio}" + (' · TEXT HIDDEN' if hide_text else '')
 sd.text((gap,20),title,font=font(24,bold=True),fill=(242,242,240))
 for i,im in enumerate(thumbs):
  x=gap+(i%cols)*(tw+gap);y=top+gap+(i//cols)*(th+gap);sheet.paste(im,(x,y))
 Path(out).parent.mkdir(parents=True,exist_ok=True);sheet.save(out,quality=91)
 return out

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('plan');ap.add_argument('out');ap.add_argument('--ratio',default='16:9');ap.add_argument('--hide-text',action='store_true');a=ap.parse_args()
 plan=json.loads(Path(a.plan).read_text()); storyboard(plan,a.ratio,a.out,a.hide_text)
