from pathlib import Path
import json
ROOT=Path("/mnt/data/nexmind-runtime/overlays/WHITEBOARD_PRODUCTION_SYSTEM_V2_MAX_2026-09-04")
def status(): return json.loads((ROOT/"reports/MAX_CAPACITY_STATUS.json").read_text())
if __name__=="__main__": print(json.dumps(status(),indent=2))
