from pathlib import Path
import io, math, subprocess, json, hashlib
import cairosvg
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_PRODUCTION_SYSTEM_V2_MAX_2026-09-04')
AE=Path('/mnt/data/whiteboard_capacity_audit/extracted/NexStudio_Autonomous_Explainer_V1_Curated_200/NexStudio_Autonomous_Explainer_V1_Curated_200/assets')
AUD=Path('/mnt/data/whiteboard_capacity_audit/extracted/p10a_nested/NexStudio_Whiteboard_V1_Engine_Merge_Pack/explainer-motion/whiteboard-v1/assets/audio/production')
OUT=ROOT/'outputs'; OUT.mkdir(parents=True,exist_ok=True)
W,H,FPS,DUR=1280,720,25,14.0
BG=(247,244,234,255); INK=(30,32,31,255); MUTED=(74,77,75,255); BLUE=(93,111,232,255); RED=(217,91,67,255); GREEN=(46,138,104,255); HI=(241,211,107,95)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'; FONT_B='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

def font(sz,b=False): return ImageFont.truetype(FONT_B if b else FONT,sz)
def clamp(x,a=0,b=1): return max(a,min(b,x))
def ease(x): x=clamp(x); return x*x*(3-2*x)
def svg(rel,size):
    data=cairosvg.svg2png(url=str(AE/rel),output_width=size[0],output_height=size[1])
    im=Image.open(io.BytesIO(data)).convert('RGBA')
    box=im.getbbox(); return im.crop(box) if box else im

def fit(im,w,h):
    s=min(w/im.width,h/im.height); return im.resize((max(1,int(im.width*s)),max(1,int(im.height*s))),Image.Resampling.LANCZOS)
def paste_alpha(dst,im,xy,alpha=1.0):
    if alpha<=0:return
    if alpha<.999:
        im=im.copy(); a=im.getchannel('A').point(lambda v:int(v*alpha)); im.putalpha(a)
    dst.alpha_composite(im,xy)
def reveal_lr(im,p,rough=18):
    p=clamp(p); mask=Image.new('L',im.size,0); d=ImageDraw.Draw(mask); x=int(im.width*p)
    pts=[(0,0),(max(0,x-rough),0),(min(im.width,x+rough),im.height*.20),(max(0,x-rough//2),im.height*.45),(min(im.width,x+rough),im.height*.7),(max(0,x-rough),im.height),(0,im.height)]
    d.polygon(pts,fill=255)
    out=im.copy(); out.putalpha(Image.composite(im.getchannel('A'),Image.new('L',im.size,0),mask)); return out

def rough_poly(draw,pts,fill,width=5,portion=1.0):
    # draw partial piecewise line
    if len(pts)<2:return
    seg=[]; total=0
    for a,b in zip(pts[:-1],pts[1:]):
        l=math.dist(a,b); seg.append(l); total+=l
    want=total*clamp(portion); acc=0
    for (a,b),l in zip(zip(pts[:-1],pts[1:]),seg):
        if want<=acc:break
        frac=min(1,(want-acc)/l) if l else 1
        end=(a[0]+(b[0]-a[0])*frac,a[1]+(b[1]-a[1])*frac)
        draw.line([a,end],fill=fill,width=width,joint='curve')
        acc+=l

def text(draw,xy,s,sz=28,b=False,fill=INK,anchor=None): draw.text(xy,s,font=font(sz,b),fill=fill,anchor=anchor)

hero=fit(svg('characters/expressive/AEV1-183-frustrated.svg',(520,520)),500,440)
invoice=fit(svg('icons/documents/AEV1-103-invoice.svg',(180,180)),110,110)
receipt=fit(svg('icons/documents/AEV1-106-receipt.svg',(180,180)),105,105)
money=fit(svg('icons/commerce/AEV1-093-money.svg',(180,180)),90,90)
chart_icon=fit(svg('icons/data/AEV1-067-chart-line.svg',(180,180)),90,90)
paper=fit(svg('objects/props/AEV1-129-paper-sheet.svg',(180,180)),96,96)

# scattered docs ending locations
starts=[(90,68),(340,42),(70,365),(430,348),(270,5),(18,212)]
ends=[(665,180),(790,180),(915,180),(665,305),(790,305),(915,305)]
icons=[invoice,receipt,paper,invoice,receipt,paper]

silent=OUT/'MAX_LOCAL_WHITEBOARD_TEST_SILENT.mp4'
cmd=['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgba','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',str(silent)]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
keyframes=[]
for fi in range(int(FPS*DUR)):
    t=fi/FPS
    im=Image.new('RGBA',(W,H),BG); d=ImageDraw.Draw(im)
    # title / narrative spine
    title_a=ease(t/1.0)
    if title_a>0:
        # small editorial header, not narration transcript
        text(d,(64,62),'WHERE IS THE MONEY GOING?',34,True,INK)
        d.line((64,108,490,108),fill=(*BLUE[:3],int(255*title_a)),width=5)
    # 0–3s authored human + scattered paperwork
    hp=ease((t-.25)/1.8)
    h=reveal_lr(hero,hp)
    paste_alpha(im,h,(80,145),1)
    for i,(ic,st) in enumerate(zip(icons,starts)):
        pa=ease((t-(.45+i*.13))/1.4)
        if pa>0: paste_alpha(im,reveal_lr(ic,pa),(st[0]+80,st[1]+120),.95)
    # 2.7–5.4 organize docs to monthly columns (move icons from chaos to structure)
    m=ease((t-2.7)/2.3)
    if m>0:
        # ghost over old positions by drawing a clean organization zone
        panel_alpha=int(220*m)
        d.rounded_rectangle((610,132,1038,420),radius=24,fill=(247,244,234,panel_alpha),outline=(*MUTED[:3],int(95*m)),width=2)
        for j,label in enumerate(['JAN','FEB','MAR']):
            x=720+j*125
            text(d,(x,155),label,19,True,MUTED,anchor='mm')
        for i,(ic,st,en) in enumerate(zip(icons,starts,ends)):
            x=int((st[0]+80)*(1-m)+en[0]*m); y=int((st[1]+120)*(1-m)+en[1]*m)
            paste_alpha(im,ic,(x,y),.95)
        if m>.45:
            text(d,(825,394),'monthly picture',19,False,MUTED,anchor='mm')
    # 5.0–8.4 transition into cash-flow chart
    c=ease((t-5.0)/2.1)
    if c>0:
        # cover organization panel into chart whiteboard vignette
        d.rounded_rectangle((590,122,1135,535),radius=28,fill=BG,outline=(*MUTED[:3],int(130*c)),width=2)
        text(d,(628,156),'MONTHLY CASH FLOW',25,True,INK)
        # axes draw-on
        rough_poly(d,[(655,465),(655,240)],INK,5,c)
        rough_poly(d,[(655,465),(1062,465)],INK,5,c)
        # line plot
        pts=[(680,420),(758,388),(830,410),(904,337),(980,350),(1040,285)]
        rough_poly(d,pts,BLUE,8,ease((t-5.7)/1.8))
        # labels / values
        if t>6.5:
            rows=[('Rent',790,'fixed',INK),('Tools',855,'needed',INK),('Subscription',920,'recurring',RED)]
            for name,y,val,col in rows:
                text(d,(690,y-490+165),name,19,False,col)  # maps to 465 region
    # explicit expense reveal panel 7.2–10.5
    e=ease((t-7.2)/1.5)
    if e>0:
        bx=(700,545,1100,635)
        d.rounded_rectangle(bx,radius=18,fill=(255,255,255,int(205*e)),outline=(*RED[:3],int(220*e)),width=3)
        text(d,(730,572),'Recurring subscription',22,True,INK)
        text(d,(1042,572),'₦',22,True,RED,anchor='mm')
        text(d,(1060,572),'18k',22,True,RED,anchor='lm')
        text(d,(730,606),'repeats every month',17,False,MUTED)
        # hand-drawn circle/highlight around row
        circle_pts=[]
        cx,cy,rx,ry=900,590,220,54
        for k in range(45):
            a=2*math.pi*k/44
            circle_pts.append((cx+rx*math.cos(a)+2*math.sin(a*3),cy+ry*math.sin(a)+1.5*math.cos(a*4)))
        rough_poly(d,circle_pts,RED,5,ease((t-8.0)/1.0))
    # Cross out 9.3–11.0
    xp=ease((t-9.3)/1.1)
    if xp>0:
        rough_poly(d,[(715,552),(1095,628)],RED,8,min(1,xp*2))
        rough_poly(d,[(1095,552),(715,628)],RED,8,max(0,min(1,xp*2-1)))
    # final improvement 10.3–14
    fp=ease((t-10.3)/1.7)
    if fp>0:
        # fade red row with warm board overlay
        d.rounded_rectangle((680,540,1120,650),radius=22,fill=(*BG[:3],int(235*fp)))
        # new clean report block
        d.rounded_rectangle((680,540,1120,650),radius=22,outline=(*GREEN[:3],int(230*fp)),width=3)
        text(d,(710,566),'LEAK REMOVED',23,True,GREEN)
        text(d,(710,605),'more cash left at month-end',19,False,MUTED)
        # upward mini line
        rough_poly(d,[(925,612),(972,600),(1008,604),(1054,570),(1090,558)],GREEN,7,fp)
        # check mark
        rough_poly(d,[(631,598),(646,615),(671,577)],GREEN,8,fp)
    # subtle board footer
    text(d,(64,684),'MAX LOCAL ASSET-ASSEMBLED WHITEBOARD • authored human asset + board transformation',14,False,(112,112,108,255))
    p.stdin.write(im.tobytes())
    if fi in [int(FPS*x) for x in [1.5,3.7,6.4,8.7,10.3,12.8]]: keyframes.append(im.convert('RGB').copy())
p.stdin.close(); rc=p.wait();
if rc: raise SystemExit(rc)
# mux actual whiteboard marker bed, low volume
final=OUT/'NEXMIND_WHITEBOARD_MAX_LOCAL_TEST_V1.mp4'
marker=AUD/'whiteboard-marker-bed-48k.wav'
subprocess.run(['ffmpeg','-y','-loglevel','error','-stream_loop','-1','-i',str(marker),'-i',str(silent),'-filter:a','volume=0.055,afade=t=in:st=0:d=0.4,afade=t=out:st=13.2:d=0.7','-map','1:v:0','-map','0:a:0','-t',str(DUR),'-c:v','copy','-c:a','aac','-b:a','128k','-shortest',str(final)],check=True)
# contact sheet
thumbs=[]
for im in keyframes:
    im.thumbnail((560,315)); thumbs.append(im)
sheet=Image.new('RGB',(1120,945),(247,244,234))
for i,im in enumerate(thumbs): sheet.paste(im,((i%2)*560,(i//2)*315))
contact=OUT/'NEXMIND_WHITEBOARD_MAX_LOCAL_TEST_CONTACT.jpg'; sheet.save(contact,quality=92)
# manifest
man={
 'schema':'NexMindWhiteboardMaxLocalTestV1','testClass':'MAX_LOCAL_ASSET_ASSEMBLED_WHITEBOARD',
 'brief':'A small business owner is overwhelmed by invoices and receipts; paperwork organizes into a monthly cash-flow picture, reveals a recurring expense, crosses it out, and shows improved cash flow.',
 'durationSeconds':DUR,'resolution':[W,H],'fps':FPS,
 'authoredAssets':[str(AE/'characters/expressive/AEV1-183-frustrated.svg'),str(AE/'icons/documents/AEV1-103-invoice.svg'),str(AE/'icons/documents/AEV1-106-receipt.svg'),str(AE/'objects/props/AEV1-129-paper-sheet.svg')],
 'boardMechanicsUsed':['progressive reveal','object reorganization','data-in-context','annotation circle','cross-out','state transformation','hold/reframe composition'],
 'soundAsset':str(marker),
 'truthBoundary':{'authoredHumanExecutor':'NOT_AVAILABLE','humanPixels':'existing governed whole-action authored asset','customHumanAnatomyGenerated':False,'imageGenerationUsed':False,'commercialPassClaim':False},
 'output':str(final),'contactSheet':str(contact)
}
(OUT/'MAX_LOCAL_TEST_MANIFEST.json').write_text(json.dumps(man,indent=2)+'\n')
print(final); print(contact)
