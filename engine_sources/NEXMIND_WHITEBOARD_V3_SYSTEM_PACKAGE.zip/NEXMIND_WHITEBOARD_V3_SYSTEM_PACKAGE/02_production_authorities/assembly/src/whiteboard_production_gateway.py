from __future__ import annotations
import argparse, hashlib, json, os, subprocess, sys, time
from pathlib import Path
from typing import Any, Dict

ROOT=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_PRODUCTION_SYSTEM_V1_2026-09-04')
CURRENT=Path('/mnt/data/nexmind-runtime/current').resolve()
PATHS={
 'phase0a':Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_RESET_PHASE0A_2026-08-26'),
 'l1':Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER1_STORY_SCENE_COMPOSER_2026-08-27'),
 'l2':Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER2_WHITEBOARD_PERFORMER_2026-08-27'),
 'l3':Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER3_ENVIRONMENT_COMPOSER_2026-08-27'),
 'l4':Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER4_ACTION_TEMPORAL_STATE_2026-08-27'),
 'l5':Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER5_CINEMATOGRAPHY_CHOREOGRAPHY_2026-08-27'),
 'vf':Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_VISUAL_FOUNDATION_ASSET_ARTIST_2026-08-27'),
 'l6':Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER6_SEMANTIC_VISUAL_REALIZATION_2026-08-27'),
 'p9':Path('/mnt/data/nexmind-runtime/recovery-authorities/NEXMIND_P9_NEXART_2026-08-13/NexMind_God_Mode_P9_NexArt_Specialist_Artists'),
 'p25':Path('/mnt/data/nexmind-runtime/recovery-authorities/NEXMIND_P25P3_2026-08-12/NexMind_God_Mode_P25P3'),
 'gate':Path('/mnt/data/nexmind-runtime/recovery-authorities/NEXSTUDIO_GATES1_10_2026-08-12'),
 'v15qa':ROOT/'donors/V15_GOLD_GRAMMAR_QA',
 'v16qa':ROOT/'donors/V16_SILENT_STORYTELLING_QA',
 'reference':Path('/mnt/data/v18_recovery/reference_video/Whiteboard Animation Explainer Video by Whiteboard Animations Studio.mp4')
}
for k in ['phase0a','l1','l2','l3','l4','l5','vf','l6']:
    sys.path.insert(0,str(PATHS[k]))
sys.path.insert(0,str(PATHS['p9']/'src'))

from policy_router import route
from story_scene_composer import compose_story
from whiteboard_performer import story_performer_sequence
from environment_composer import ground_story_environment
from temporal_state_compiler import compile_story_temporal
from physical_scene_fusion import compile_unified_story_temporal
from cinema_choreography import compile_story_cinema
from semantic_drawable_projection import compile_drawable_story
from visual_realization import visual_realization_story
from whiteboard_semantic_renderer import render_contact_sheet
from asset_fitness_resolver import resolve_asset
from nexmind_god_mode.illustration_form_resolver import IllustrationFormResolver
from nexmind_god_mode.artist_council import SpecialistArtistCouncil

FORM_INDEX=PATHS['p9']/'donors/NEXSTUDIO_ILLUSTRATION_CAPABILITY_INDEX_V1.json'
POLICY=json.loads((ROOT/'policy/PRODUCTION_AUTHORITY_POLICY.json').read_text())

def stable(x:Any)->str:
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()

def _gateway_manifest()->Dict[str,Any]:
    gw=CURRENT/'ASSIMILATION_RUNTIME/runtime/system-execution-gateway.js'
    p=subprocess.run(['node','-e',"const g=require(process.argv[1]);console.log(JSON.stringify(g.manifest()))",str(gw)],capture_output=True,text=True,check=True)
    return json.loads(p.stdout)

def _cert(path:Path,name:str)->Any:
    p=path/name
    if not p.exists(): return None
    try:return json.loads(p.read_text())
    except Exception:return None

def _decision(obj:Any)->str|None:
    if not isinstance(obj,dict):return None
    return obj.get('decision') or obj.get('status') or obj.get('certification')

def status()->Dict[str,Any]:
    required={k:v.exists() for k,v in PATHS.items()}
    layer_decisions={
      'phase0a':_decision(_cert(PATHS['phase0a'],'PHASE0A_CERTIFICATION.json')),
      'layer1':_decision(_cert(PATHS['l1'],'LAYER1_CERTIFICATION.json')),
      'layer2':_decision(_cert(PATHS['l2'],'LAYER2_CERTIFICATION.json')),
      'layer3':_decision(_cert(PATHS['l3'],'LAYER3_CERTIFICATION.json')),
      'layer4':_decision(_cert(PATHS['l4'],'LAYER4_CERTIFICATION.json')),
      'layer5':_decision(_cert(PATHS['l5'],'LAYER5_CERTIFICATION.json')),
      'visualFoundation':_decision(_cert(PATHS['vf'],'VISUAL_FOUNDATION_CERTIFICATION.json')),
      'layer6':_decision(_cert(PATHS['l6'],'LAYER6_CERTIFICATION.json')),
    }
    gate_files=['explainer-motion/whiteboard-v1/runtime/whiteboard_compiler.py','explainer-motion/whiteboard-v1/runtime/whiteboard-runtime.js','explainer-motion/whiteboard-v1/runtime/production-whiteboard-primitives.js','explainer-motion/whiteboard-v1/public-integration/v1/runtime/gate8-whiteboard-adapter.js']
    return {
      'schema':'NexMindWhiteboardProductionSystemStatusV1','candidate':str(ROOT),'canonicalRuntime':str(CURRENT),
      'canonicalGateway':_gateway_manifest(),'requiredAuthoritiesPresent':required,'layerDecisions':layer_decisions,
      'p25FormResolver':FORM_INDEX.exists(),'p9NexArtSource':(PATHS['p9']/'src/nexmind_god_mode/council_p9.py').exists(),
      'gate1to10BoardMechanics':{x:(PATHS['gate']/x).exists() for x in gate_files},
      'creativePolicy':POLICY,
      'assemblyDecision':'ASSEMBLED_STRUCTURAL_PRODUCTION_PATH__CREATIVE_PIXEL_GATE_CLOSED',
      'productionReadyClaim':False
    }

def _semantic_parts(story:dict)->list[str]:
    vals=[]
    for row in story.get('cast',[]): vals.append('person '+str(row.get('label') or row.get('id')))
    for row in story.get('props',[]): vals.append('object '+str(row.get('label') or row.get('id')))
    env=(story.get('scene') or {}).get('environment')
    if env:vals.append('environment '+str(env))
    return list(dict.fromkeys(x for x in vals if x and x!='None'))

def _ops(story:dict)->list[str]:
    return list(dict.fromkeys(str(x.get('operation','')).lower() for x in story.get('actions',[]) if x.get('operation')))

def _art_candidate_stub(text:str,story:dict)->dict:
    parts=_semantic_parts(story); ops=_ops(story)
    hero=(story.get('cast') or story.get('props') or [{'label':'story subject'}])[0]
    return {
      'candidate_id':'production-execution-requirements','visual_candidate_id':'whiteboard-production',
      'art_thesis':'Purpose-drawn narrative Whiteboard illustration; action and readable interaction dominate.',
      'hero':{'semantic_ref':str(hero.get('label') or hero.get('id')),'art_budget':'HIGH','prominence':'DOMINANT','recognizable_required':True},
      'composition':{'archetype':'compact-authored-scene','hierarchy_order':['hero','interaction','story-prop','environment-cue'],'negative_space_intent':'protect readable white space around action','density':'BALANCED','asymmetry_intent':'natural narrative staging','support_budget':3,'decoration_budget':1},
      'form_request':{'concept':text,'representation':'AUTHORED_ILLUSTRATION','semantic_parts':parts,'required_operations':ops,'style':'professional commercial whiteboard cartoon'},
      'beat_art':[], 'typography_intent':'minimal; never narration transcription','risk_notes':['no procedural mannequin fallback','no diagram downgrade']
    }

def illustration_requirements(text:str,allow_generation:bool=False)->Dict[str,Any]:
    story=compose_story(text,'production-scene-001')
    cand=_art_candidate_stub(text,story)
    resolver=IllustrationFormResolver.from_file(FORM_INDEX)
    form=resolver.resolve(cand['form_request'],{'production_scoped_asset_generation':allow_generation})
    council=SpecialistArtistCouncil(provider=None)
    roles=council.required_roles(cand,{'assets':[]})
    return {'formRequest':cand['form_request'],'formResolution':form,'requiredNexArtRoles':roles,'noSilentDiagramDowngrade':True}

def compile_production(text:str, job_dir:Path|None=None, allow_generation:bool=False)->Dict[str,Any]:
    t0=time.time(); job_dir=Path(job_dir or ROOT/'jobs'/('job-'+stable(text)[:12])); job_dir.mkdir(parents=True,exist_ok=True)
    routing=route('NARRATIVE_SCENE')
    story=compose_story(text,'production-scene-001')
    performer=story_performer_sequence(text)
    env=ground_story_environment(text)
    temporal=compile_story_temporal(text)
    unified=compile_unified_story_temporal(text)
    cinema=compile_story_cinema(text)
    drawable=compile_drawable_story(text)
    realization=visual_realization_story(text)
    art=illustration_requirements(text,allow_generation=allow_generation)
    blockers=[]
    blocking_relations=list(story.get('blocking') or [])
    # Narrative Whiteboard beats require a concrete action. If the deterministic
    # interpreter loses the action, fail closed rather than pretending downstream
    # illustration/rendering can repair missing story semantics.
    action_count=len(story.get('actions',[]) or [])
    shot_count=len(cinema.get('shots',[]) or []) if isinstance(cinema,dict) else 0
    if routing and action_count == 0:
        blockers.append({'code':'SEMANTIC_INTERPRETATION_INCOMPLETE','detail':{'reason':'Narrative route produced no concrete action','sourceText':text,'shotCount':shot_count}})
    if action_count > 0 and shot_count == 0:
        blockers.append({'code':'CINEMATOGRAPHY_PLAN_INCOMPLETE','detail':{'reason':'Actions exist but no shots were produced','actionCount':action_count}})
    form_status=art['formResolution'].get('status')
    if form_status in {'UNSUPPORTED_FORM_REQUIRED','FORM_REQUEST_INVALID'}:
        blockers.append({'code':'PRODUCTION_ILLUSTRATION_FORM_UNAVAILABLE','detail':art['formResolution']})
    elif form_status=='GENERATION_REQUIRED':
        blockers.append({'code':'AUTHORED_ILLUSTRATION_EXECUTOR_NOT_BOUND','detail':'P25/P9 correctly require production-scoped authored illustration, but no approved final illustration executor is bound to this assembled runtime.'})
    # Layer 6 is deliberately technical evidence only; it must not clear the creative gate.
    stage={'routing':routing,'story':story,'performer':performer,'environment':env,'temporal':temporal,'unified':unified,'cinema':cinema,'drawable':drawable,'visualRealization':realization,'illustration':art}
    for name,obj in stage.items():
        (job_dir/f'{name}.json').write_text(json.dumps(obj,indent=2,default=str)+'\n')
    manifest={
      'schema':'NexMindWhiteboardProductionPlanV1','jobId':job_dir.name,'sourceText':text,'stageHashes':{k:stable(v) for k,v in stage.items()},
      'authorities':POLICY['authorityOrder'],'renderAuthority':{'boardMechanics':'GATE1_10_WHITEBOARD_BROWSER_RUNTIME','technicalStaticEvidence':'LAYER6_SEMANTIC_RENDERER','finalIllustration':'P9_NEXART_PLUS_GOVERNED_AUTHORED_ASSET'},
      'blockingRelations':blocking_relations,'blockers':blockers,'structuralPathAssembled':True,'creativePixelGate':'CLOSED','animationGate':'CLOSED','productionReadyClaim':False,'elapsedSeconds':round(time.time()-t0,3)
    }
    (job_dir/'PRODUCTION_PLAN.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return {'jobDir':str(job_dir),'plan':manifest,'summary':{'cast':len(story.get('cast',[])),'props':len(story.get('props',[])),'actions':len(story.get('actions',[])),'shots':len(cinema.get('shots',[])) if isinstance(cinema,dict) else None,'illustrationStatus':art['formResolution'].get('status'),'nexArtRoles':art['requiredNexArtRoles']}}

def static_preview(text:str, out:Path)->Dict[str,Any]:
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    meta=render_contact_sheet(text,out)
    return {'status':'TECHNICAL_STATIC_EVIDENCE_RENDERED','path':str(out),'meta':meta,'creativePass':False,'animationAuthorized':False}

def main():
    ap=argparse.ArgumentParser();sp=ap.add_subparsers(dest='cmd',required=True)
    sp.add_parser('status')
    c=sp.add_parser('compile');c.add_argument('story');c.add_argument('--job-dir');c.add_argument('--allow-generation',action='store_true')
    a=sp.add_parser('illustration');a.add_argument('story');a.add_argument('--allow-generation',action='store_true')
    p=sp.add_parser('static-preview');p.add_argument('story');p.add_argument('--out',default=str(ROOT/'qa/STATIC_TECHNICAL_PREVIEW.png'))
    ns=ap.parse_args()
    if ns.cmd=='status':out=status()
    elif ns.cmd=='compile':out=compile_production(ns.story,Path(ns.job_dir) if ns.job_dir else None,ns.allow_generation)
    elif ns.cmd=='illustration':out=illustration_requirements(ns.story,ns.allow_generation)
    else:out=static_preview(ns.story,Path(ns.out))
    print(json.dumps(out,indent=2,default=str))
if __name__=='__main__':main()
