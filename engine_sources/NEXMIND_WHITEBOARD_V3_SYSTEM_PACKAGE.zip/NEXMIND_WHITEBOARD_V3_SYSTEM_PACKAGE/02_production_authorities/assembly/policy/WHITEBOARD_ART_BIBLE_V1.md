# NexStudio Whiteboard Art Bible V1

**Phase:** Elite Rebuild Phase 1  
**Status:** LOCKED  
**Purpose:** Define one coherent illustration language before any production character/icon library is expanded.

## 1. Foundational rule

Every visible element must look as though the same illustrator made it for the same board. Character, icon, prop, document, connector, annotation and live typography may have different *roles*, but they may not have different visual identities.

The art system is intentionally **premium editorial whiteboard**, not school doodles, corporate flowchart clip-art, or fully coloured cartoons.

## 2. Surface

The canonical editorial surface is warm off-white `#F7F4EA`, with extremely low-contrast deterministic grain. Texture must never become a visual subject. Pure white is allowed only when a customer brand or faithful UI capture requires it. Dirty grey boards, exaggerated paper fibres and faux-aged paper are rejected.

## 3. Ink and line hierarchy

Primary ink is charcoal `#1E201F`, not digital black. Secondary construction/detail ink may use `#4A4D4B` and soft ink `#70736F`.

Canonical 1080-equivalent stroke roles:

- hero contour: **4.6 px**
- support/prop contour: **3.5 px**
- icon contour: **3.2 px**
- detail: **2.15 px**
- single-stroke handwriting: **2.25 px**
- annotation: **5.6 px**
- hero emphasis: **6.2 px**

All canonical strokes use round caps and round joins. Width variation communicates hierarchy; it must not look like unrelated icon packs were combined.

### Roughness

Roughness is deterministic and restrained. Hero lines remain confident. Annotation can be slightly more gestural. The system does not add independent random wobble to every path.

## 4. Palette roles

Colour has semantic ownership.

- **Primary accent `#5D6FE8`:** hero focus, continuity object, key path.
- **Secondary accent `#2F8F72`:** supporting comparison or second state.
- **Warning `#D95B43`:** friction, rejection, correction, problem.
- **Success `#2E8A68`:** approval or completed outcome.
- **Highlighter `#F1D36B` at ~32% opacity:** temporary emphasis only.

Maximum structural accent roles per beat: **2**. Colour is never added merely to make the board lively. Brand palettes map into these roles instead of replacing semantic hierarchy.

## 5. Fill philosophy

Default treatment is open outline. Strategic fills are allowed because elite whiteboard illustration does not require empty outlines everywhere.

Allowed fills:

- one semantic accent area;
- small ink silhouette (hair, shoe, tiny deep-shadow shape);
- restrained hatch;
- marker highlight.

A hero illustration should not become a fully coloured cartoon. Scene-level solid-fill coverage is capped at roughly **22%** under the default editorial profile.

## 6. Character construction rules

Hero humans need a readable silhouette and actual body volume. Torso, head, hands/arms and clothing must read as an illustrated person, not a skeleton made from lines. A stickman may exist only as a tiny symbolic pictogram.

Faces are deliberately simple: eyes/brows/mouth sufficient for readable emotion at output size. Detail is earned by narrative importance.

## 7. Icon construction

Icons are semantic shorthand, not decorative badges. Default enclosure is **none**. Circles/boxes are introduced only when they are literally part of the concept or needed for a specific semantic state.

Icons use the same charcoal ink, rounded geometry and line hierarchy as props and characters.

## 8. Prop construction

Props should feel physically drawable and story-usable. A phone is a phone, a screen is a screen, a document is a document. Literal containers are allowed. Generic rectangles representing abstract concepts are not.

Occlusion is encouraged: a hand may overlap a phone; a laptop may overlap a torso; a document may sit under a hand. This is how illustrated scenes stop looking like floating icon clouds.

## 9. Typography and handwriting

Three roles exist.

### Editorial live type
Used for major titles, required exact factual numbers, names and product-faithful text. It uses the existing NexStudio typography system; Phase 1 does not introduce or distribute new font files.

### Single-stroke handwriting
Used for short observations and interpretive notes, normally **five words or fewer**.

### Micro-labels
Used only when an object genuinely needs identification. They must remain readable at target output size.

Paragraph handwriting and narration transcription are forbidden.

## 10. Complexity tiers

**Hero:** highest expressive detail and 24–55% of the active composition.  
**Support:** about 58% of hero detail.  
**Symbol:** about 30% of hero detail.

A symbol may not visually overpower a hero just because its source SVG contains more paths.

## 11. Composition rules

- negative space is intentional, generally 24–62%;
- hero must dominate the largest support object by at least ~1.25× unless a specific comparison requires equal weight;
- no more than four equal-weight objects before grouping/hierarchy is introduced;
- foreground/background overlap is allowed and encouraged;
- floating asset clouds are not a default composition.

## 12. Connectors and annotations

Connectors represent relationships or movement. They are not layout scaffolding. An unexplained arrow is a failure. Arrowheads are open and hand-drawn, not PowerPoint triangles.

Annotations are more gestural and thicker than normal object lines. They must have a semantic purpose defined by Phase 0.

## 13. Draw strategies by tier

Simple icons can fully draw. Complex characters should normally use **construct**, **outline + fill**, **build**, or **transform**. The viewer should never wait for dozens of micro-paths to trace merely because an SVG contains them.

## 14. Canonical family test

Phase 1 is accepted only if the same board can place: an illustrated human, semantic icon, physical phone/UI prop, literal document, relationship connector and handwritten annotation together without a family mismatch. The acceptance specimen is `demos/phase1-art-bible-specimen.html`.

## 15. Hard visual mismatches

Reject:

- pure-black thin stick character beside thick rounded icons;
- neon icon packs inside charcoal illustration;
- square line caps beside rounded character contours;
- full-colour flat cartoon props beside open-line people;
- annotation stroke thinner than object detail;
- arbitrary shadows/3D effects;
- unrelated corner-radius systems;
- generic icon circles used purely as decoration.

## 16. Phase boundary

This Art Bible defines the system. It does **not** claim that the complete production character/action library exists. Building that library is Phase 2. Phase 1 provides a canonical reference human and family specimen only so the standard is visually testable.
