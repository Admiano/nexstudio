#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, json, subprocess, sys
CURRENT=Path('/mnt/data/nexmind-runtime/current').resolve()
OVERLAY=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_RESET_PHASE0A_2026-08-26')
P3_ROOT=Path('/mnt/data/nexmind-runtime/recovery-authorities/NEXMIND_P25P3_2026-08-12/NexMind_God_Mode_P25P3')
sys.path.insert(0,str(OVERLAY))
from policy_router import route, select_asset

def gateway_status():
    gw=CURRENT/'ASSIMILATION_RUNTIME/runtime/system-execution-gateway.js'
    js=f"const g=require({json.dumps(str(gw))}); console.log(JSON.stringify(g.manifest()));"
    p=subprocess.run(['node','-e',js],text=True,capture_output=True,check=True)
    return json.loads(p.stdout)

def activity(payload):
    gw=CURRENT/'ASSIMILATION_RUNTIME/runtime/system-execution-gateway.js'
    js="const g=require(process.argv[1]); const x=JSON.parse(process.argv[2]); console.log(JSON.stringify(g.activity(x,{})));"
    p=subprocess.run(['node','-e',js,str(gw),json.dumps(payload)],text=True,capture_output=True,check=True)
    return json.loads(p.stdout)

def resolve_form(request, *, production_scoped_asset_generation=False):
    src=P3_ROOT/'src'; idx=P3_ROOT/'donors/NEXSTUDIO_ILLUSTRATION_CAPABILITY_INDEX_V1.json'
    if not src.exists() or not idx.exists():
        return {'status':'FORM_RESOLVER_UNAVAILABLE','no_silent_degrade':True}
    if str(src) not in sys.path: sys.path.insert(0,str(src))
    from nexmind_god_mode.illustration_form_resolver import IllustrationFormResolver
    resolver=IllustrationFormResolver.from_file(idx)
    cap={'production_scoped_asset_generation':bool(production_scoped_asset_generation)}
    try:
        return resolver.resolve(request,cap)
    except Exception as exc:
        return {'status':'FORM_REQUEST_INVALID','errorType':type(exc).__name__,'reason':str(exc)[:500],'no_silent_degrade':True}

def status():
    cert=json.loads((OVERLAY/'PHASE0A_CERTIFICATION.json').read_text())
    return {'schema':'NexMindChatSessionStatusV2','canonicalRuntime':str(CURRENT),'overlay':str(OVERLAY),'gateway':gateway_status(),'supplementalFormResolver':{'source':str(P3_ROOT),'available':P3_ROOT.exists(),'authority':'PRIMARY_NARROW_FAIL_CLOSED_FORM_RESOLUTION'},'phase0aDecision':cert['decision'],'phase1Started':cert['phase1Started']}

def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest='cmd',required=True)
    sub.add_parser('status')
    r=sub.add_parser('route'); r.add_argument('task_class');r.add_argument('--treatment')
    a=sub.add_parser('activity');a.add_argument('json_payload')
    s=sub.add_parser('select-asset');s.add_argument('json_candidates')
    f=sub.add_parser('resolve-form');f.add_argument('json_request');f.add_argument('--allow-generation',action='store_true')
    ns=ap.parse_args()
    if ns.cmd=='status': out=status()
    elif ns.cmd=='route': out=route(ns.task_class,treatment=ns.treatment)
    elif ns.cmd=='activity': out=activity(json.loads(ns.json_payload))
    elif ns.cmd=='select-asset': out=select_asset(json.loads(ns.json_candidates))
    else: out=resolve_form(json.loads(ns.json_request),production_scoped_asset_generation=ns.allow_generation)
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
