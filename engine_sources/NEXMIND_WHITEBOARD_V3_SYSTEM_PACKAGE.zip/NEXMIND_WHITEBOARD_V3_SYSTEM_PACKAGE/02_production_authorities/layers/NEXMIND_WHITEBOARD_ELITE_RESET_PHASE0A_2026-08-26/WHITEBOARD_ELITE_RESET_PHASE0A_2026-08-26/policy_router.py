from __future__ import annotations
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
EVIDENCE=json.loads((ROOT/'PER_CAPABILITY_EVIDENCE_TABLE.json').read_text())
POLICY=json.loads((ROOT/'TASK_TO_CAPABILITY_ROUTING_POLICY.json').read_text())
DIMS=EVIDENCE['scoringDimensions']; DIR=EVIDENCE['directionality']; THRESH=EVIDENCE['minimumFitnessThreshold']

def _score(profile, role):
    W=EVIDENCE['taskWeights'].get(role,EVIDENCE['weights'])
    total=0.0; denom=0.0
    for d in DIMS:
        w=float(W.get(d,0.0))
        if w<=0: continue
        v=float(profile.get(d,0.0)); denom+=w
        total += w*((1.0-v) if DIR[d]=='lower_is_better' else v)
    return total/denom if denom else 0.0

def route(task_class, *, treatment=None):
    tc=task_class.upper()
    aliases={'NARRATIVE_SCENE':'ILLUSTRATED_NARRATIVE_SCENE','ENVIRONMENT_SCENE':'ENVIRONMENT_ESTABLISHING_SCENE','DATA_CHART':'DATA_CHART','DIAGRAM':'DIAGRAM','PHYSICAL_PROCESS':'PHYSICAL_DEMONSTRATION','PHYSICAL_DEMONSTRATION':'PHYSICAL_DEMONSTRATION','CHARACTER_ACTION':'CHARACTER_ACTION','ABSTRACT_EXPLANATION':'ABSTRACT_CONCEPT','ABSTRACT_CONCEPT':'ABSTRACT_CONCEPT'}
    role=aliases.get(tc,tc)
    treatment_evaluation=None
    if role=='ABSTRACT_CONCEPT':
        candidates=['illustrated_metaphor','physical_analogy','transformation','diagram','comparison','chart']
        if treatment is None:
            return {'taskClass':role,'authorities':POLICY['roleMatrix'][role],'treatmentEvaluation':{'required':True,'candidates':candidates,'decision':'ART_DIRECTOR_MUST_SCORE_TREATMENTS'},'selectedCapabilities':[],'status':'TREATMENT_DECISION_REQUIRED'}
        treatment_evaluation={'required':True,'candidates':candidates,'selected':treatment}
        role_for_caps='DIAGRAM' if treatment=='diagram' else 'DATA_CHART' if treatment=='chart' else 'ILLUSTRATED_NARRATIVE_SCENE'
    else: role_for_caps=role
    ranked=[]
    for cid,rec in EVIDENCE['capabilities'].items():
        if role_for_caps not in rec.get('roles',[]): continue
        ranked.append({'capability':cid,'fitness':round(_score(rec['profile'],role_for_caps),4),'available':bool(rec.get('availability')),'authorityClass':rec.get('authorityClass','SPECIALIST')})
    ranked.sort(key=lambda x:(-x['fitness'],x['capability']))
    valid=[x for x in ranked if x['available'] and x['fitness']>=THRESH]
    authority=[x for x in valid if x['authorityClass'] not in {'EXECUTION_SURFACE','EXECUTION_ENGINE'}]
    if not authority:
        return {'taskClass':role,'authorities':POLICY['roleMatrix'].get(role,[]),'treatmentEvaluation':treatment_evaluation,'rankedCandidates':ranked,'selectedCapabilities':[],'status':'NO_SUITABLE_CAPABILITY'}
    # One or more semantic/specialist authorities plus compatible execution assists.
    selected=authority + [x for x in valid if x['authorityClass'] in {'EXECUTION_SURFACE','EXECUTION_ENGINE'}]
    return {'taskClass':role,'authorities':POLICY['roleMatrix'].get(role,[]),'treatmentEvaluation':treatment_evaluation,'rankedCandidates':ranked,'selectedCapabilities':selected,'status':'ROUTED_BY_ROLE_FITNESS'}

def select_asset(candidates, threshold=0.78):
    valid=[]
    for c in candidates:
        if c.get('embeddedText',False) or c.get('bakedPropContamination',False) or c.get('poseCompatible') is False or c.get('styleCompatible') is False:
            continue
        vals=[float(c.get(k,0.0)) for k in ('semanticRelevance','actionCompatibility','environmentCompatibility','cameraCompatibility','assetCleanliness','confidence')]
        score=sum(vals)/len(vals)
        if score>=threshold: valid.append((score,c))
    if not valid: return {'status':'NO_SUITABLE_ASSET','selected':None,'threshold':threshold}
    valid.sort(key=lambda x:(-x[0],str(x[1].get('assetId',''))))
    return {'status':'ASSET_SELECTED','selected':valid[0][1],'fitness':round(valid[0][0],4),'threshold':threshold}
