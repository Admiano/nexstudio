# NexMind Whiteboard Elite — Reset Phase 0A Report

**Decision:** `PHASE0A_BLOCKED_WITH_EXACT_REASONS`  
**Phase 1 started:** **NO**  
**Updated:** 2026-08-26

## Executive result

The capability-authority reset itself is now implemented and tested. Whiteboard task routing in the isolated Phase 0A overlay is role-aware, chart/diagram specialists no longer have broad illustrated-scene authority, asset sources are candidates rather than authorities, low-confidence retrieval fails closed, and promotion is per role and reversible. The canonical recovered runtime was not rewritten and NexStick/Stickman code was not changed.

Phase 0A is still **blocked from certification** for one narrower reason: the exact previous 8,705-file productionization candidate cannot yet be reconstructed byte-for-byte. The Library recovery now covers **3,908 / 4,048 unique candidate target hashes**, but candidate-specific Whiteboard/P8/service/vendor integration bytes are still missing. Advancing to Phase 1 would create an unproven fork from the previously promoted canonical generation.

## Recovery state

### Physically installed canonical recovery

- Current frozen generation: `NEXMIND_FULL_ASSIMILATION_V1_CERTIFIED_RECOVERY_2026-08-26`
- Manifest integrity: **1,829 / 1,829 exact; 0 mismatches**
- Installed tree: **1,863 files**
- Frozen tree digest: `16f83da6f58d31fa977e59bd7f76c608a6b7dc9c859d602f5587cc196bd1b235`
- Exact Aug-17 rollback/convergence source recovered: `d390ef039e4b055c966cad457b29796abacadaa18353c142d9747318df314603`

### Newly recovered verified authorities

1. **Gate 1–10 authoritative release source** — exact SHA `72ca08ba...ff70`, ZIP integrity PASS. This removes the earlier “Gate source unavailable” blocker. Its Whiteboard policy says representation must follow communication need, generic diagram/text-card/anonymous-node-chain are forbidden defaults, and diagrams require structural necessity.
2. **NexMind P2.5/P3 Art + Storyboard source** — recovered and rerun: **60/60 PASS**; adversarial harness **2,000/2,000 PASS**; silent illustration downgrade attacks **400/400 blocked**. Its generic `IllustrationFormResolver` resolves a valid illustration form, requests governed production-scoped generation, or fails closed with `forbidden_fallback: DIAGRAM`.
3. **P9 NexArt Specialist Artists source** — recovered. **9/10** source files added by the later productionization candidate match this recovered package byte-for-byte. Targeted specialist tests **16/16 PASS** and P9 gate **PASS**. One candidate-specific `provider_schemas_p9.py` file remains missing.

## Whiteboard failure diagnosis

The failed grocery/school-style output is not explained by “not enough assets.” The recovered code and ledgers show a representation/routing failure:

- broad domain routing did not distinguish narrative scene vs environment vs diagram vs chart vs physical process strongly enough;
- a diagram agent and VChart had historically broad Whiteboard registration;
- native Whiteboard business rendering contains prompt-substring chart/funnel decisions and generic node/box flow;
- named-environment rendering contains noun branches rather than a general spatial scene grammar;
- the old asset resolver could rank weak candidates without a minimum multi-dimensional fitness gate;
- Scene Fabricator could turn missing semantics into `box`;
- mechanical QA was able to pass work that remained visibly poor.

The ByteDance/VisActor audit does **not** show VChart directly rendered the bad pixels in the recovered runtime: its module is not installed/executable. The defect is governance: a chart/data-storytelling specialist had too much broad Whiteboard authority. VChart is now `SPECIALIST_ONLY` for charts; VRender is diagram/data render assist only.

## Authority reset now in force in the overlay

The corrected selection sequence is:

`task class -> Art Director treatment -> role-aware capability selection -> fail-closed illustration-form resolution when needed -> candidate asset retrieval -> multi-dimensional asset fitness -> scene/specialist construction -> Whiteboard visual-language translation -> Cinema/continuity -> rendered-pixel critic`

Global prestige/priority is not a scoring input. If no suitable asset clears the fitness gate, the result is `NO_SUITABLE_ASSET`, followed by modular construction, governed authored-art request, correct simplification or replanning. Generic boxes and irrelevant polished stock art are forbidden rescue mechanisms.

## Recovered authority promotion decisions

- **PRIMARY, narrow role:** P2.5/P3 `IllustrationFormResolver` for recognizable-form resolution / no-silent-degrade behavior. It does not own task classification, scene design or final asset choice.
- **SECONDARY:** Gate1–10 story/representation policy for story-before-diagram and board continuity.
- **SECONDARY:** P9 specialist doctrines + semantic scene graph and P9 rendered-preview critic.
- **QUARANTINED:** P9 historical `required_roles()` word-set dispatcher. It uses noun sets and can fall back to `DIAGRAM`; this conflicts with the reset’s no-noun-hardcoding/task-class law.
- **REFERENCE_ONLY:** older Phase5 commercial illustration resolver because its benchmark lineage contains domain/noun regex heuristics.
- **SPECIALIST_ONLY:** VisActor/VChart for data charts and VRender for diagram/data render assist.

## Required microtests

All Phase 0A routing microtests pass under the isolated policy:

- narrative physical scene -> scene/environment/character/object/Whiteboard stack; diagram/chart authority absent;
- environment scene -> environment/scene construction;
- diagram -> diagram topology + Whiteboard surface;
- data chart -> chart-specific path;
- abstract explanation -> Art Director treatment decision required rather than boxes by default;
- physical process -> object/action/environment stack;
- contaminated/low-fit asset -> `NO_SUITABLE_ASSET`.

This proves the reset makes different task classes route differently for principled reasons. It does **not** claim those paths yet produce 9.0/10 final Whiteboard pixels; that is Phase 1+ work and has not begun.

## Anti-hardcoding result

No new scenario/test noun branch exists in the Phase 0A executable router. The P2.5/P3 production resolver is generic and its own tests verify fixture topics are absent from production source. Recovered legacy authorities containing noun/word heuristics are explicitly scoped or quarantined instead of silently promoted.

## Exact remaining recovery blocker

The candidate reconstruction scan currently has **4,048 unique target hashes**, of which **3,908 are physically recovered** and **140 remain missing**. The most important missing integration bytes are:

- all **9 candidate-modified files** at their promoted hashes, including the Whiteboard PIL adapter and P8 orchestration/provider bridge revisions; two Stickman consumer bridge hashes are counted for reconstruction completeness only and were not audited or changed;
- **3 `services/nexmind_universal_capabilities` production-service files** (`__init__.py`, `asset_resolver.py`, `production_bridge.py`);
- **10 universal-capability vendor target rows**, including the candidate versions of `scene_fabricator.py` and `whiteboard_render.py`;
- **1 P9 candidate-specific file**: `provider_schemas_p9.py`;
- productionization evidence files required for exact archive equality.

Because these integration bytes are missing, it would be inaccurate to claim the recovered Gate/P3/P9 sources reproduce the exact previously promoted productionization path.

## Phase 1 readiness

The **design of the authority reset is ready** for Phase 1: role-aware routing, fail-closed form/asset behavior, specialist scoping, asset-bank governance, promotion ledger, ByteDance scope, anti-hardcoding rules and microtests are in place.

The **canonical integration base is not yet objectively recovered enough** to cross the user-defined Phase 0A exit gate. Therefore Phase 1 remains locked.

## Final recovery and closure sweep

The final Library check inspected the exact productionization creation window. Both the persistent folder record and generated aliases contain the candidate SHA sidecar and certification evidence, but no candidate ZIP bytes. The remaining source names were also checked against direct Library revisions where available; same-named pre-candidate files were rejected when their SHA-256 did not match the candidate diff targets. A local recovered-authority/archive scan found **zero** remaining critical target-hash hits. This closes the recovery search without inventing source.

The Phase 0A executable closure suite passes: the six task classes still route distinctly, contaminated assets return `NO_SUITABLE_ASSET`, unresolved recognizable illustration form returns `UNSUPPORTED_FORM_REQUIRED` with diagram fallback forbidden, malformed form requests now return governed `FORM_REQUEST_INVALID`, and the frozen canonical tree still hashes to `16f83da6f58d31fa977e59bd7f76c608a6b7dc9c859d602f5587cc196bd1b235` across **1,863 files**. No Stickman/NexStick code changed.

Artifacts: `FINAL_RECOVERY_SWEEP.json` and `qa/PHASE0A_CLOSURE_QA.json`.

## Final Phase 0A decision

`PHASE0A_BLOCKED_WITH_EXACT_REASONS`

No Phase 1 implementation was started.
