from __future__ import annotations
import html, json
from pathlib import Path
from whiteboard_performer import sample_performer

ROOT=Path(__file__).resolve().parent

def render_svg(frame,width=360,height=440,title='Whiteboard Performer'):
    if frame.get('status')!='OK':
        return f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"><rect width="100%" height="100%" fill="white"/><text x="20" y="40">{html.escape(frame.get("status","FAIL"))}</text></svg>'
    pts=[]
    def xy(p):
        x,y=p['whiteboard2d']; return width/2+x*180,height-36-y*235
    def line(a,b,w=4):
        x1,y1=xy(a);x2,y2=xy(b);return f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="#111" stroke-width="{w}" stroke-linecap="round"/>'
    p=frame
    torso=p['torso']
    for a,b in [(torso['pelvis'],torso['spine']),(torso['spine'],torso['chest']),(torso['chest'],torso['neck'])]:pts.append(line(a,b,5))
    for a,b in [(p['shoulderL'],p['elbowL']),(p['elbowL'],p['wristL']),(p['shoulderR'],p['elbowR']),(p['elbowR'],p['wristR']),
                (p['hipL'],p['kneeL']),(p['kneeL'],p['footL']['ankle']),(p['footL']['ankle'],p['footL']['toe']),
                (p['hipR'],p['kneeR']),(p['kneeR'],p['footR']['ankle']),(p['footR']['ankle'],p['footR']['toe'])]:pts.append(line(a,b,4))
    # shoulder bridge and hip bridge keep the black-stick family readable.
    pts.append(line(p['shoulderL'],p['shoulderR'],4));pts.append(line(p['hipL'],p['hipR'],4))
    hx,hy=xy(p['head']);r=p['head']['radiusMeters']*190
    pts.append(f'<circle cx="{hx:.1f}" cy="{hy:.1f}" r="{r:.1f}" fill="none" stroke="#111" stroke-width="4"/>')
    for hand,wrist in ((p['fingersL'],p['wristL']),(p['fingersR'],p['wristR'])):
        wx,wy=xy(wrist); pc=hand['palmCenter']; px=width/2+pc[0]*180; py=height-36-pc[1]*235
        pts.append(f'<line x1="{wx:.1f}" y1="{wy:.1f}" x2="{px:.1f}" y2="{py:.1f}" stroke="#111" stroke-width="3" stroke-linecap="round"/>')
        pts.append(f'<circle cx="{px:.1f}" cy="{py:.1f}" r="2.4" fill="#111"/>')
        for d in hand['digits']:
            arr=[]
            for x,y in d['polyline']: arr.append(f'{width/2+x*180:.1f},{height-36-y*235:.1f}')
            pts.append(f'<polyline points="{" ".join(arr)}" fill="none" stroke="#111" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/>')
    # held object is intentionally a neutral proof glyph, not an asset-bank body/pose substitute.
    for obj in p.get('heldObjects',[]):
        pos=obj.get('position')
        if pos:
            ox,oy=xy(pos);pts.append(f'<rect x="{ox-13:.1f}" y="{oy-9:.1f}" width="26" height="18" rx="3" fill="none" stroke="#555" stroke-width="2"/>')
    label=f"{title} • {p.get('action')} • {p.get('phase') or ''}"
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}"><rect width="100%" height="100%" fill="white"/><text x="12" y="20" font-family="Arial" font-size="11" font-weight="700" fill="#111">{html.escape(label)}</text><g>{"".join(pts)}</g></svg>'

def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('request_json');ap.add_argument('--time',type=float,default=.6);ap.add_argument('--out',required=True)
    ns=ap.parse_args();frame=sample_performer(json.loads(ns.request_json),ns.time);Path(ns.out).write_text(render_svg(frame));print(ns.out)
if __name__=='__main__':main()
