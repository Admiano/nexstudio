import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from whiteboard_performer import sample_performer, performer_policy, story_performer_sequence

REQ_PICKUP={'action':'pickup','familyId':'adult_man_average','activeHand':'left','grip':{'position':[0,1.18,.62],'approachNormal':[0,0,-1],'object':{'id':'test_object','size':[.34,.18,.2]},'loadClass':'light'}}

def test_contract_required_fields():
    f=sample_performer({'action':'walk','speedMps':.8},.45)
    assert f['status']=='OK'
    for k in ['root','head','torso','shoulderL','shoulderR','elbowL','elbowR','wristL','wristR','fingersL','fingersR','hipL','hipR','kneeL','kneeR','footL','footR','gaze','contacts','heldObjects','facialState']:
        assert k in f

def test_nexstick_is_performance_authority():
    f=sample_performer(REQ_PICKUP,.775)
    assert f['sourceAuthority']=='NEXSTICK_PERFORMANCE'
    assert f['sourceEngine']=='NEXSTICK_INTERACTION_V1'
    assert f['invariants']['motionAuthoredByWhiteboard'] is False
    assert f['invariants']['contactAuthoredByWhiteboard'] is False

def test_whole_body_assets_are_not_structural_authority():
    f=sample_performer({'action':'idle'},.2)
    assert f['wholeBodyAssetAuthority']=='OPTIONAL_STYLE_ONLY'
    assert f['assetBankStructuralAuthority'] is False
    assert f['invariants']['poseAssetRequired'] is False

def test_semantic_hands_project_to_five_digits():
    f=sample_performer(REQ_PICKUP,.775)
    assert len(f['fingersL']['digits'])==5
    assert len(f['fingersR']['digits'])==5
    assert f['fingersL']['semanticState']=='grip'

def test_ownership_and_contact_are_preserved_from_nexstick():
    f=sample_performer(REQ_PICKUP,1.395)
    assert f['heldObjects']
    assert f['heldObjects'][0]['id']=='test_object'
    assert f['heldObjects'][0]['owner']=='actor'
    assert any(c.get('kind')=='pickup' for c in f['contacts'])

def test_deterministic_projection_hash():
    a=sample_performer(REQ_PICKUP,.775)
    b=sample_performer(REQ_PICKUP,.775)
    assert a['frameHash']==b['frameHash']
    assert a==b

def test_blocked_nexstick_fails_closed():
    f=sample_performer({'action':'definitely_unsupported_action'},.2)
    assert f['status']=='NEXSTICK_PERFORMANCE_BLOCKED'
    assert f['sourceAuthority']=='NEXSTICK_PERFORMANCE'
    assert f['wholeBodyAssetAuthority']=='OPTIONAL_STYLE_ONLY'

def test_narrative_default_policy():
    p=performer_policy('NARRATIVE_SCENE')
    assert p['status']=='NEXSTICK_PROJECTED_DEFAULT'
    assert p['wholeBodyIllustrationAsset']=='OPTIONAL_STYLE_ONLY'

def test_layer1_to_layer2_story_bridge():
    seq=story_performer_sequence('Mira walks into the room and takes a book from the table.')
    assert seq['performerPolicy']=='NEXSTICK_PROJECTED_DEFAULT_FOR_NARRATIVE_ACTORS'
    assert seq['frames']
    assert all(x.get('performer',{}).get('status')=='OK' for x in seq['frames'] if 'performer' in x)
