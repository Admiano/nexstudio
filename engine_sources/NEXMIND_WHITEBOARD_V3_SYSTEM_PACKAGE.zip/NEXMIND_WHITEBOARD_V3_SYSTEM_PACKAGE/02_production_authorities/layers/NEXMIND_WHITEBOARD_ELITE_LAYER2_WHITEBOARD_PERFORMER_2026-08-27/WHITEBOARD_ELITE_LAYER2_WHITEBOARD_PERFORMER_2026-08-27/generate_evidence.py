from pathlib import Path
import json, subprocess, sys, hashlib, re
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from whiteboard_performer import sample_performer, story_performer_sequence, performer_policy
from whiteboard_performer_renderer import render_svg

E=ROOT/'evidence';E.mkdir(exist_ok=True)
cases=[
 ('idle',{'action':'idle'},.35),
 ('walk',{'action':'walk','speedMps':.8},.48),
 ('present',{'action':'present','activeHand':'right'},.72),
 ('point',{'action':'point','activeHand':'left'},.72),
 ('high_reach',{'action':'high_reach','activeHand':'left','target':[0,1.25,.46]},.78),
 ('pickup',{'action':'pickup','familyId':'adult_man_average','activeHand':'left','grip':{'position':[0,1.18,.62],'approachNormal':[0,0,-1],'object':{'id':'test_item','size':[.34,.18,.2]},'loadClass':'light'}},1.395),
 ('place',{'action':'place','familyId':'adult_man_average','activeHand':'right','grip':{'position':[0,.72,.52],'approachNormal':[0,0,-1],'object':{'id':'test_item','size':[.34,.18,.2]},'loadClass':'light'}},1.0),
 ('carry',{'action':'carry','familyId':'adult_man_average','activeHand':'right','grip':{'position':[0,.82,.34],'approachNormal':[0,0,-1],'object':{'id':'test_item','size':[.28,.18,.18]},'loadClass':'light'}},.55),
]
rows=[]
for name,req,t in cases:
    f=sample_performer(req,t,actor_id='proof_actor')
    rows.append({'case':name,'status':f.get('status'),'sourceEngine':f.get('sourceEngine'),'action':f.get('action'),'phase':f.get('phase'),'frameHash':f.get('frameHash'),'contacts':len(f.get('contacts',[])),'heldObjects':len(f.get('heldObjects',[])),'fiveDigitsEach':len(f.get('fingersL',{}).get('digits',[]))==5 and len(f.get('fingersR',{}).get('digits',[]))==5})
    (E/f'{name.upper()}_WHITEBOARD_PERFORMER_FRAME.json').write_text(json.dumps(f,indent=2)+'\n')
    (E/f'{name.upper()}_WHITEBOARD_PERFORMER_FRAME.svg').write_text(render_svg(f,title=name))
(E/'ACTION_MATRIX.json').write_text(json.dumps({'schema':'WhiteboardPerformerActionMatrixV1','status':'PASS' if all(x['status']=='OK' for x in rows) else 'FAIL','rows':rows},indent=2)+'\n')

story='Ada walks into the shop and takes bread from the shelf.'
seq=story_performer_sequence(story)
(E/'ADA_STORY_PERFORMER_SEQUENCE.json').write_text(json.dumps(seq,indent=2)+'\n')
# Compact representative frame: pickup final-held state.
rep=next(x['performer'] for x in reversed(seq['frames']) if x['segment']=='PICKUP' and x.get('performer',{}).get('heldObjects'))
(E/'ADA_PICKUP_WHITEBOARD_PERFORMER_FRAME.json').write_text(json.dumps(rep,indent=2)+'\n')
(E/'ADA_PICKUP_WHITEBOARD_PERFORMER_FRAME.svg').write_text(render_svg(rep,title='Ada pickup performer proof'))

# Build a raster contact sheet from four representative SVGs when CairoSVG/Pillow are present.
try:
    import cairosvg
    from PIL import Image,ImageOps,ImageDraw
    picks=['WALK','PRESENT','PICKUP','PLACE']
    imgs=[]
    for key in picks:
        svg=(E/f'{key}_WHITEBOARD_PERFORMER_FRAME.svg').read_bytes()
        png=E/f'{key}_WHITEBOARD_PERFORMER_FRAME.png'
        cairosvg.svg2png(bytestring=svg,write_to=str(png),output_width=360,output_height=440)
        imgs.append(Image.open(png).convert('RGB'))
    sheet=Image.new('RGB',(720,880),'white')
    for i,img in enumerate(imgs): sheet.paste(img,((i%2)*360,(i//2)*440))
    sheet.save(E/'WHITEBOARD_PERFORMER_CONTACT_SHEET.png')
except Exception as exc:
    (E/'CONTACT_SHEET_ERROR.txt').write_text(repr(exc))

(E/'PERFORMER_POLICY_PROOF.json').write_text(json.dumps({
 'narrative':performer_policy('NARRATIVE_SCENE'),
 'physical':performer_policy('PHYSICAL_PROCESS'),
 'noActor':performer_policy('NARRATIVE_SCENE',has_actor=False),
 'explicitStyle':performer_policy('NARRATIVE_SCENE',explicit_style_requires_full_body_asset=True),
},indent=2)+'\n')
