'use strict';
const fs=require('fs');
const path=require('path');
const CANONICAL=path.resolve('/mnt/data/nexmind-runtime/current');
const V5ROOT=path.join(CANONICAL,'inherited/PODCAST_V26/FINAL_RUNTIME/vendor_v5_1');
const BRANCHC=path.join(CANONICAL,'inherited/PODCAST_V26/FINAL_INTERACTIONS/INTERACTION_RUNTIME/branch-c-interaction.js');
process.env.NEXSTICK_V5_ROOT=process.env.NEXSTICK_V5_ROOT||V5ROOT;
const V5=require(path.join(V5ROOT,'runtime/node-bootstrap-v5.js'));
const C=require(BRANCHC);
const BRANCH_C_ACTIONS=new Set(['conversation','present','point','low_reach','mid_reach','high_reach','pickup','floor_pickup','table_pickup','high_pickup','carry','place','press','tap','give','receive','handoff','sit','seated_talk','stand']);
function sample(req,t){
  const action=String(req?.action||'');
  const source=BRANCH_C_ACTIONS.has(action)?'NEXSTICK_INTERACTION_V1':'NexPerformanceUnifiedV5';
  const state=source==='NEXSTICK_INTERACTION_V1'?C.sample(req,t):V5.sample(req,t);
  return {schema:'NexStickPerformanceSampleEnvelopeV1',sourceEngine:source,sourceVersion:source==='NEXSTICK_INTERACTION_V1'?C.version:V5.version,request:req,time:+t||0,state,contracts:{branchC:C.contract(),performance:V5.contract()}};
}
const input=JSON.parse(fs.readFileSync(0,'utf8')||'{}');
process.stdout.write(JSON.stringify(sample(input.request||{},input.time||0)));
