from __future__ import annotations

import hashlib
import json
import math
import subprocess
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

ROOT = Path(__file__).resolve().parent
CANONICAL = Path('/mnt/data/nexmind-runtime/current').resolve()
LAYER1 = Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER1_STORY_SCENE_COMPOSER_2026-08-27')
SOURCE_JS = ROOT / 'nexstick_performance_source.js'

REQUIRED_POSE = (
    'root','pelvis','spine','chest','neck','head',
    'shoulder_l','elbow_l','wrist_l','shoulder_r','elbow_r','wrist_r',
    'hip_l','knee_l','ankle_l','toe_l','hip_r','knee_r','ankle_r','toe_r'
)

INTERACTION_ACTIONS = {
    'conversation','present','point','low_reach','mid_reach','high_reach',
    'pickup','floor_pickup','table_pickup','high_pickup','carry','place',
    'press','tap','give','receive','handoff','sit','seated_talk','stand'
}

# Generic semantic translation only. These values never select a story action or object.
HAND_PROFILES = {
    'relaxed': {'spread': .34, 'curl': .30, 'index': .78, 'thumb': .60},
    'open': {'spread': .86, 'curl': .06, 'index': 1.00, 'thumb': .82},
    'present': {'spread': .72, 'curl': .08, 'index': .96, 'thumb': .82},
    'point': {'spread': .24, 'curl': .72, 'index': 1.34, 'thumb': .58},
    'tap': {'spread': .20, 'curl': .76, 'index': 1.24, 'thumb': .52},
    'pinch': {'spread': .18, 'curl': .58, 'index': .88, 'thumb': .88},
    'grip': {'spread': .18, 'curl': .88, 'index': .60, 'thumb': .66},
    'receive': {'spread': .76, 'curl': .12, 'index': .96, 'thumb': .84},
    'give': {'spread': .60, 'curl': .18, 'index': .92, 'thumb': .78},
    'handoff': {'spread': .52, 'curl': .24, 'index': .90, 'thumb': .76},
}


def _canon(v: Any) -> str:
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def _hash(v: Any) -> str:
    return hashlib.sha256(_canon(v).encode()).hexdigest()


def _vec3(v: Iterable[float]) -> List[float]:
    a=list(v)
    return [round(float(a[0]), 6), round(float(a[1]), 6), round(float(a[2]), 6)]


def _sample_nexstick(request: Dict[str, Any], time: float) -> Dict[str, Any]:
    p = subprocess.run(
        ['node', str(SOURCE_JS)],
        input=json.dumps({'request': request, 'time': float(time)}),
        text=True, capture_output=True, check=True,
    )
    return json.loads(p.stdout)


def _project_world(p: List[float], root: List[float], camera_yaw_deg: float) -> Tuple[List[float], float, List[float]]:
    dx, dy, dz = p[0]-root[0], p[1], p[2]-root[2]
    a = math.radians(-camera_yaw_deg)
    c, s = math.cos(a), math.sin(a)
    x = c*dx + s*dz
    z = -s*dx + c*dz
    return [round(x, 6), round(dy, 6)], round(z, 6), [round(dx,6),round(dy,6),round(dz,6)]


def _point(pose: Dict[str, Any], key: str, root: List[float], yaw: float) -> Dict[str, Any]:
    p = pose[key]
    wb, depth, local = _project_world(p, root, yaw)
    return {'world3d': _vec3(p), 'actorLocal3d': local, 'whiteboard2d': wb, 'depth': depth}


def _hand_semantic(raw: Dict[str, Any], side: str) -> Dict[str, Any]:
    h = (raw.get('hands') or {}).get(side) or {}
    semantic = h.get('semanticState') or h.get('pose') or 'relaxed'
    return {
        'semanticState': semantic if semantic in HAND_PROFILES else 'relaxed',
        'source': h,
    }


def _norm2(v: List[float], fallback=(1.0,0.0)) -> List[float]:
    n=math.hypot(v[0],v[1])
    if n < 1e-9: return [float(fallback[0]),float(fallback[1])]
    return [v[0]/n,v[1]/n]


def _add2(a,b): return [a[0]+b[0],a[1]+b[1]]

def _mul2(a,s): return [a[0]*s,a[1]*s]


def _finger_projection(frame_points: Dict[str, Dict[str, Any]], raw: Dict[str, Any], side: str) -> Dict[str, Any]:
    suffix='L' if side=='left' else 'R'
    wrist=frame_points[f'wrist{suffix}']['whiteboard2d']
    elbow=frame_points[f'elbow{suffix}']['whiteboard2d']
    forward=_norm2([wrist[0]-elbow[0], wrist[1]-elbow[1]], (1 if side=='left' else -1,0))
    tangent=[-forward[1],forward[0]]
    sem=_hand_semantic(raw,side)
    profile=HAND_PROFILES[sem['semanticState']]
    palm=_add2(wrist,_mul2(forward,.070))
    names=['thumb','index','middle','ring','little']
    offsets=[-.58,-.32,0,.28,.52]
    base_lengths=[.090,.135,.142,.129,.110]
    digits=[]
    for i,(name,off,L) in enumerate(zip(names,offsets,base_lengths)):
        factor=profile['thumb'] if name=='thumb' else (profile['index'] if name=='index' else 1.0)
        spread=off*.055*profile['spread']*(1 if side=='left' else -1)
        base=_add2(palm,_mul2(tangent,spread))
        if sem['semanticState'] in ('point','tap') and name=='index':
            curl=0.02
        elif sem['semanticState']=='pinch' and name in ('thumb','index'):
            curl=.42
        else:
            curl=profile['curl']
        direction=_norm2(_add2(forward,_mul2(tangent,off*.22*profile['spread'])),forward)
        mid=_add2(base,_mul2(direction,L*.52*factor))
        bend_dir=_norm2(_add2(direction,_mul2(tangent,(-1 if side=='left' else 1)*curl*.72)),direction)
        tip=_add2(mid,_mul2(bend_dir,L*.48*factor*(1-.42*curl)))
        digits.append({'name':name,'polyline':[[round(x,6),round(y,6)] for x,y in [base,mid,tip]]})
    return {
        'mode':'NEXSTICK_SEMANTIC_DIGIT_PROJECTION',
        'semanticState': sem['semanticState'],
        'contactAnchor': sem['source'].get('contactAnchor'),
        'palmOrientation': sem['source'].get('palmOrientation') or sem['source'].get('orientation'),
        'approachNormal': sem['source'].get('approachNormal'),
        'palmCenter':[round(palm[0],6),round(palm[1],6)],
        'digits': digits,
        'authority': 'NexStick hand semantic state + deterministic Whiteboard geometry translation',
        'doesNotAuthorMotion': True,
    }


def _project_optional_world(v: Any, root: List[float], yaw: float):
    if not isinstance(v, list) or len(v)!=3: return None
    wb,depth,local=_project_world(v,root,yaw)
    return {'world3d':_vec3(v),'actorLocal3d':local,'whiteboard2d':wb,'depth':depth}


def project_performance_state(envelope: Dict[str, Any], *, actor_id: str='actor', camera_yaw_deg: float=0.0) -> Dict[str, Any]:
    raw = envelope.get('state') or {}
    if raw.get('blocked'):
        return {
            'schema':'WhiteboardPerformerFrameV1', 'status':'NEXSTICK_PERFORMANCE_BLOCKED',
            'actorId':actor_id, 'sourceAuthority':'NEXSTICK_PERFORMANCE',
            'failure':raw.get('failure') or 'UNKNOWN_NEXSTICK_FAILURE',
            'sourceEngine':envelope.get('sourceEngine'), 'sourceVersion':envelope.get('sourceVersion'),
            'request':envelope.get('request'), 'time':envelope.get('time'),
            'wholeBodyAssetAuthority':'OPTIONAL_STYLE_ONLY', 'assetBankStructuralAuthority':False,
        }
    pose=raw.get('pose3d') or (raw.get('pose') if isinstance(raw.get('pose'),dict) else None)
    if not pose:
        raise ValueError('NEXSTICK_POSE3D_REQUIRED')
    missing=[k for k in REQUIRED_POSE if k not in pose]
    if missing:
        raise ValueError('NEXSTICK_POSE_INCOMPLETE:'+','.join(missing))
    root3=pose['root']
    points={
        'root':_point(pose,'root',root3,camera_yaw_deg),
        'head':_point(pose,'head',root3,camera_yaw_deg),
        'shoulderL':_point(pose,'shoulder_l',root3,camera_yaw_deg), 'shoulderR':_point(pose,'shoulder_r',root3,camera_yaw_deg),
        'elbowL':_point(pose,'elbow_l',root3,camera_yaw_deg), 'elbowR':_point(pose,'elbow_r',root3,camera_yaw_deg),
        'wristL':_point(pose,'wrist_l',root3,camera_yaw_deg), 'wristR':_point(pose,'wrist_r',root3,camera_yaw_deg),
        'hipL':_point(pose,'hip_l',root3,camera_yaw_deg), 'hipR':_point(pose,'hip_r',root3,camera_yaw_deg),
        'kneeL':_point(pose,'knee_l',root3,camera_yaw_deg), 'kneeR':_point(pose,'knee_r',root3,camera_yaw_deg),
    }
    points['footL']={'ankle':_point(pose,'ankle_l',root3,camera_yaw_deg),'toe':_point(pose,'toe_l',root3,camera_yaw_deg)}
    points['footR']={'ankle':_point(pose,'ankle_r',root3,camera_yaw_deg),'toe':_point(pose,'toe_r',root3,camera_yaw_deg)}
    torso={k:_point(pose,k,root3,camera_yaw_deg) for k in ('pelvis','spine','chest','neck')}
    fingersL=_finger_projection(points,raw,'left')
    fingersR=_finger_projection(points,raw,'right')
    target=None
    target_source=None
    if isinstance(raw.get('gazeTarget'),list): target=raw['gazeTarget'];target_source='nexstick.gazeTarget'
    elif isinstance(raw.get('interactionTarget'),list): target=raw['interactionTarget'];target_source='nexstick.interactionTarget'
    elif isinstance((raw.get('contact') or {}).get('target'),list): target=raw['contact']['target'];target_source='nexstick.contact.target'
    elif isinstance((raw.get('prop') or {}).get('position'),list): target=raw['prop']['position'];target_source='nexstick.prop.position'
    if target is None:
        yaw=math.radians(float((raw.get('worldTransform') or {}).get('yawDeg',0)))
        target=[pose['head'][0]+math.sin(yaw), pose['head'][1], pose['head'][2]+math.cos(yaw)]
        target_source='derived_forward_from_nexstick_world_yaw'
    gaze_target=_project_optional_world(target,root3,camera_yaw_deg)
    contact=raw.get('contact') or None
    contacts=[]
    if contact:
        contacts.append({
            **{k:v for k,v in contact.items() if k not in ('worldPoint','target')},
            'worldPoint':_project_optional_world(contact.get('worldPoint'),root3,camera_yaw_deg),
            'target':_project_optional_world(contact.get('target'),root3,camera_yaw_deg),
        })
    fp=raw.get('footPlant') or {}
    for sd,name in [('l','leftFoot'),('r','rightFoot')]:
        if float(fp.get(sd,0) or 0)>0:
            contacts.append({'kind':'foot_plant','effector':name,'weight':float(fp[sd])})
    held=[]
    prop=raw.get('prop') or None
    if prop and (prop.get('owner') in ('actor','shared','giver','receiver') or 'hand' in str(prop.get('support',''))):
        held.append({**prop,'position':_project_optional_world(prop.get('position'),root3,camera_yaw_deg)})
    face=raw.get('facialState') or raw.get('face') or 'neutral'
    frame={
        'schema':'WhiteboardPerformerFrameV1', 'status':'OK', 'actorId':actor_id,
        'sourceAuthority':'NEXSTICK_PERFORMANCE', 'sourceEngine':envelope.get('sourceEngine'), 'sourceVersion':envelope.get('sourceVersion'),
        'sourceStateHash':_hash(raw), 'request':envelope.get('request'), 'time':envelope.get('time'),
        'action':raw.get('action') or (envelope.get('request') or {}).get('action'), 'phase':raw.get('phase'),
        'projection':{'space':'ACTOR_LOCAL_WHITEBOARD_2D_WITH_WORLD3D_BACKREFERENCE','cameraYawDeg':float(camera_yaw_deg),'rootWorld3d':_vec3(root3)},
        'root':points['root'], 'head':{**points['head'],'radiusMeters':.09}, 'torso':torso,
        'shoulderL':points['shoulderL'], 'shoulderR':points['shoulderR'], 'elbowL':points['elbowL'], 'elbowR':points['elbowR'],
        'wristL':points['wristL'], 'wristR':points['wristR'], 'fingersL':fingersL, 'fingersR':fingersR,
        'hipL':points['hipL'], 'hipR':points['hipR'], 'kneeL':points['kneeL'], 'kneeR':points['kneeR'], 'footL':points['footL'], 'footR':points['footR'],
        'gaze':{'target':gaze_target,'source':target_source}, 'contacts':contacts, 'heldObjects':held,
        'facialState':{'state':face,'source':'nexstick' if raw.get('facialState') or raw.get('face') else 'neutral_when_nexstick_has_no_explicit_face_state'},
        'wholeBodyAssetAuthority':'OPTIONAL_STYLE_ONLY', 'assetBankStructuralAuthority':False,
        'invariants':{'motionAuthoredByWhiteboard':False,'contactAuthoredByWhiteboard':False,'ownershipAuthoredByWhiteboard':False,'poseAssetRequired':False},
    }
    frame['frameHash']=_hash(frame)
    return frame


def sample_performer(request: Dict[str, Any], time: float, *, actor_id='actor', camera_yaw_deg=0.0) -> Dict[str, Any]:
    return project_performance_state(_sample_nexstick(request,time),actor_id=actor_id,camera_yaw_deg=camera_yaw_deg)


def _world_to_local(target: Dict[str,float], stage: Dict[str,float], yaw_deg: float) -> List[float]:
    dx,dy,dz=target['x']-stage['x'],target['y']-stage.get('y',0),target['z']-stage['z']
    a=math.radians(-yaw_deg); c,s=math.cos(a),math.sin(a)
    return [c*dx+s*dz,dy,-s*dx+c*dz]


def _affordance(comp: Dict[str,Any], entity_id: str) -> Optional[Dict[str,Any]]:
    return next((x for x in comp.get('objectAffordances',[]) if x.get('entityId')==entity_id),None)


def _reachability(comp: Dict[str,Any], entity_id: str, prefer_insertion=False) -> Optional[Dict[str,Any]]:
    rows=[x for x in (comp.get('worldProjection') or {}).get('reachability',[]) if x.get('entityId')==entity_id]
    if prefer_insertion:
        q=next((x for x in rows if ':insertion:' in str(x.get('socketId'))),None)
        if q:return q
    return rows[0] if rows else None


def story_performer_sequence(story_text: str, *, camera_yaw_deg=0.0) -> Dict[str,Any]:
    import sys
    if str(LAYER1) not in sys.path: sys.path.insert(0,str(LAYER1))
    from story_scene_composer import compose_story
    comp=compose_story(story_text,'layer2-story-performer')
    actor=(comp.get('cast') or [{'id':'actor_0','label':'actor'}])[0]
    frames=[]
    if any(a.get('operation')=='APPROACH' for a in comp.get('actions',[])):
        req={'action':'walk','speedMps':.8}
        for frac in (.18,.50,.82):
            env=_sample_nexstick(req,1.2*frac)
            frames.append({'segment':'APPROACH','performer':project_performance_state(env,actor_id=actor['id'],camera_yaw_deg=camera_yaw_deg)})
    for plan in comp.get('compiledActivities',[]):
        act=(plan.get('activity') or {}).get('action')
        activity=plan.get('activity') or {}
        if act not in ('pickup','place'):
            continue
        entity_id=activity.get('targetId') if act=='pickup' else activity.get('destinationId')
        r=_reachability(comp,entity_id,prefer_insertion=(act=='place')) if entity_id else None
        target_aff=_affordance(comp, activity.get('targetId')) if activity.get('targetId') else None
        if not r:
            frames.append({'segment':act.upper(),'status':'NO_WORLD_REACHABILITY'})
            continue
        local=_world_to_local(r['targetPosition'],r['stagingPosition'],r['facingYawDeg'])
        obj=target_aff or _affordance(comp,activity.get('toolId')) or {}
        dims=obj.get('dimensions') or {'x':.18,'y':.12,'z':.14}
        oid=(activity.get('targetId') if act=='pickup' else activity.get('toolId')) or 'object'
        req={
            'action':act,'familyId':'adult_man_average','activeHand':r.get('preferredHand') or 'right',
            'grip':{'position':local,'approachNormal':[0,0,-1],'object':{'id':oid,'size':[dims['x'],dims['y'],dims['z']]},'loadClass':activity.get('loadClass') or 'light'}
        }
        dur=1.55 if act=='pickup' else 1.45
        for frac in (.22,.50,.72,.90):
            env=_sample_nexstick(req,dur*frac)
            frames.append({'segment':act.upper(),'worldStaging':r,'performer':project_performance_state(env,actor_id=actor['id'],camera_yaw_deg=camera_yaw_deg)})
    return {
        'schema':'WhiteboardStoryPerformerSequenceV1','sourceStory':story_text,'actor':actor,
        'performerPolicy':'NEXSTICK_PROJECTED_DEFAULT_FOR_NARRATIVE_ACTORS',
        'wholeBodyIllustrationAssets':'OPTIONAL_STYLE_ONLY_NOT_STRUCTURAL_AUTHORITY',
        'composition':{'environment':comp.get('scene'),'actions':comp.get('actions'),'continuity':comp.get('continuity')},
        'frames':frames,
    }


def performer_policy(task_class: str, *, has_actor: bool=True, explicit_style_requires_full_body_asset: bool=False) -> Dict[str,Any]:
    t=str(task_class or '').upper()
    narrative=t in {'NARRATIVE_SCENE','ENVIRONMENT_SCENE','PHYSICAL_PROCESS','ILLUSTRATED_NARRATIVE_SCENE','ENVIRONMENT_ESTABLISHING_SCENE','PHYSICAL_DEMONSTRATION'}
    if has_actor and narrative and not explicit_style_requires_full_body_asset:
        return {'status':'NEXSTICK_PROJECTED_DEFAULT','structuralPerformer':'WhiteboardPerformerFrameV1','wholeBodyIllustrationAsset':'OPTIONAL_STYLE_ONLY'}
    if explicit_style_requires_full_body_asset:
        return {'status':'STYLE_ASSET_ALLOWED_WITH_POSE_FIT_GATE','structuralPerformer':'NexStick performance still preferred as motion/contact authority','wholeBodyIllustrationAsset':'STYLE_MATERIAL_ONLY'}
    return {'status':'NO_PERFORMER_REQUIRED' if not has_actor else 'TREATMENT_DECISION_REQUIRED'}
