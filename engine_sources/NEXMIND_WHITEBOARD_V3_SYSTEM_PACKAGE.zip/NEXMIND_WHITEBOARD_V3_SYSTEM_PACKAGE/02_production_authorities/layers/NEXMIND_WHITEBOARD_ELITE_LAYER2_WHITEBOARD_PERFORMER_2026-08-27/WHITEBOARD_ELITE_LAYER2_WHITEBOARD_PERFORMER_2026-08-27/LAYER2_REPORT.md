# NexMind Whiteboard Elite — Layer 2 Whiteboard Performer

## Decision

**LAYER2_WHITEBOARD_PERFORMER_PROJECTION_PASS**

Layer 2 establishes a stable `WhiteboardPerformerFrameV1` actor contract derived from executable NexStick performance state. For narrative, environment and physical-demonstration scenes with actors, `NEXSTICK_PROJECTED` is now the default structural performer. Whole-body illustration assets are optional styling material only.

## Contract

Each valid frame carries root, head, torso chain, bilateral shoulders/elbows/wrists, five projected digits per hand, hips/knees/feet, gaze, contacts, held-object ownership and facial state. Every point keeps world-3D backreference plus actor-local/Whiteboard-2D projection.

Motion, contact and ownership are never authored by Whiteboard. A blocked NexStick performance remains blocked; the layer does not substitute a random body illustration.

## Live authority

- `NexPerformanceUnifiedV5` 5.1.0-skin-safe-angular-continuity supplies whole-body performance state.
- `NEXSTICK_INTERACTION_V1` 1.0.0-branch-c-interaction-authority supplies interaction phases, contact, ownership and semantic hand state.
- Recovered W01–W05 authorities were audited. W02 V9 proves independent per-digit controls and anatomical mesh contact in its integration metadata, but its executable `.blend`/action payload is not present in the recovered Phase0 authority subset, so it was **not** falsely promoted to the live per-frame source.

## Fingers

The active V5.1/Branch-C stream does not expose per-digit XYZ coordinates. Layer 2 therefore produces five deterministic Whiteboard digit polylines from live NexStick wrist/elbow geometry plus NexStick semantic hand state. This is marked `NEXSTICK_SEMANTIC_DIGIT_PROJECTION` and explicitly `doesNotAuthorMotion=true`. When an executable W02 per-digit stream is recovered/merged later, this contract can accept that stronger source without changing downstream Whiteboard consumers.

## Story bridge

Layer 1 composition can be passed directly into `story_performer_sequence()`. The Ada shop proof produces 11 performer frames spanning approach, pickup and placement, with the actor routed through NexStick rather than an asset-bank whole-body pose. Scenario nouns exist only in evidence fixtures; the Layer 2 executable scan is **PASS** with zero banned scenario-token dispatch hits.

## QA

- Layer 2 unit/contract tests: **9/9 PASS**
- Generic action matrix: **8/8 PASS**
- Existing Visual Construction regression: **57/57 PASS**
- Branch-C mechanical regression: **31/31 PASS**
- Branch-C adversarial regression: **14/14 PASS**
- Canonical tree after cleanup: **1863 files**, SHA-256 `16f83da6f58d31fa977e59bd7f76c608a6b7dc9c859d602f5587cc196bd1b235` — exact frozen digest restored.

During final QA, pytest created eight cache files under the frozen canonical generation. They were identified by exact archive comparison and removed; no canonical source bytes were changed.

## Quality boundary

This certification is deliberately scoped. Layer 2 faithfully exposes NexStick truth; it does **not** certify every underlying pickup/place pose as elite. Some Branch-C frames currently report large contact residuals. Those are preserved in `contacts[].effectorResidualM` instead of being hidden with a Whiteboard-authored corrective pose. NexStick convergence remains the authority for improving that mechanical performance.

## Commands

```bash
python /mnt/data/nexmind-chat-session/run.py performer-policy NARRATIVE_SCENE
python /mnt/data/nexmind-chat-session/run.py performer-frame '{"action":"walk","speedMps":0.8}' --time 0.45
python /mnt/data/nexmind-chat-session/run.py perform-story "Ada walks into the shop and takes bread from the shelf."
```
