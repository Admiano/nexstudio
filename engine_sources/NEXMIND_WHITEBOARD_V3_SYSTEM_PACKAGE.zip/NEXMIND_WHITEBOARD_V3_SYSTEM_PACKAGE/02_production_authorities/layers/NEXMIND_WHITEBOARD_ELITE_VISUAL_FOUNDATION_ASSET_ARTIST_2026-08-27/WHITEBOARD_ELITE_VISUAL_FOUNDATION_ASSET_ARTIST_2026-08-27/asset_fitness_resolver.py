from __future__ import annotations
from dataclasses import dataclass
from math import prod
from typing import Any, Dict, Iterable, List, Mapping, Tuple

DIMENSIONS=("semantic","pose","action","style","camera","editability","cleanliness")
DEFAULT_FLOORS={
    "semantic":0.72,
    "pose":0.78,
    "action":0.80,
    "style":0.68,
    "camera":0.70,
    "editability":0.62,
    "cleanliness":0.82,
}
DEFAULT_THRESHOLD=0.80

# Canonical aliases allow older candidate metadata to enter the stronger gate.
ALIASES={
    "semantic":("semantic","semanticRelevance"),
    "pose":("pose","poseFitness","poseCompatibilityScore"),
    "action":("action","actionCompatibility"),
    "style":("style","styleCompatibility"),
    "camera":("camera","cameraCompatibility"),
    "editability":("editability","editabilityScore"),
    "cleanliness":("cleanliness","assetCleanliness"),
}

HARD_VETO_FLAGS={
    "embedded_words":("embeddedWords","embeddedText"),
    "baked_irrelevant_props":("bakedInIrrelevantProps","bakedPropContamination"),
    "fixed_incompatible_pose":("fixedIncompatibleBodyPose",),
    "wrong_perspective":("wrongPerspective",),
    "style_mismatch":("styleMismatch",),
    "non_removable_background":("nonRemovableBackground",),
}
NEGATIVE_COMPATIBILITY_FLAGS={
    "pose_incompatible":"poseCompatible",
    "perspective_incompatible":"perspectiveCompatible",
    "style_incompatible":"styleCompatible",
    "background_not_removable":"backgroundRemovable",
}
SOFT_PENALTIES={
    "decorativeIllustration":0.45,
    "excessiveComplexity":0.55,
}


def _num(c:Mapping[str,Any], names:Iterable[str], default:float=0.0)->float:
    for n in names:
        if n in c:
            try: return max(0.0,min(1.0,float(c[n])))
            except (TypeError,ValueError): return default
    return default


def _dims(c:Mapping[str,Any])->Dict[str,float]:
    return {d:_num(c,ALIASES[d]) for d in DIMENSIONS}


def _hard_vetoes(c:Mapping[str,Any], *, structural:bool=True)->List[str]:
    reasons=[]
    for reason,flags in HARD_VETO_FLAGS.items():
        if any(bool(c.get(f,False)) for f in flags): reasons.append(reason)
    for reason,flag in NEGATIVE_COMPATIBILITY_FLAGS.items():
        if c.get(flag) is False: reasons.append(reason)
    # Whole-body finished illustration may be style material, but it cannot own performance structure.
    if structural and bool(c.get("wholeBodyIllustration",False)) and not bool(c.get("structurallyEditable",False)):
        reasons.append("whole_body_fixed_pose_not_structural_authority")
    return reasons


def score_asset(c:Mapping[str,Any], *, structural:bool=True, floors:Mapping[str,float]|None=None)->Dict[str,Any]:
    floors=dict(DEFAULT_FLOORS if floors is None else floors)
    d=_dims(c)
    vetoes=_hard_vetoes(c,structural=structural)
    floor_failures=[k for k,v in d.items() if v < float(floors.get(k,0.0))]
    # Geometric mean preserves a 0-1 score while remaining multiplicative: one weak factor hurts.
    gm=prod(max(v,1e-9) for v in d.values()) ** (1.0/len(d))
    penalty=1.0; penalties=[]
    for flag,mult in SOFT_PENALTIES.items():
        if bool(c.get(flag,False)):
            penalty*=mult; penalties.append({"flag":flag,"multiplier":mult})
    score=gm*penalty
    return {
        "assetId":c.get("assetId"),
        "dimensions":d,
        "geometricMean":round(gm,6),
        "penaltyMultiplier":round(penalty,6),
        "fitness":round(score,6),
        "hardVetoes":vetoes,
        "floorFailures":floor_failures,
        "penalties":penalties,
        "structuralUse":bool(structural),
    }


def resolve_asset(candidates:Iterable[Mapping[str,Any]], *, structural:bool=True, threshold:float=DEFAULT_THRESHOLD, floors:Mapping[str,float]|None=None)->Dict[str,Any]:
    assessed=[]
    for c in candidates:
        a=score_asset(c,structural=structural,floors=floors)
        accepted=(not a["hardVetoes"] and not a["floorFailures"] and a["fitness"]>=threshold)
        a["accepted"]=accepted
        assessed.append((a,c))
    accepted=[x for x in assessed if x[0]["accepted"]]
    accepted.sort(key=lambda x:(-x[0]["fitness"],str(x[0].get("assetId") or "")))
    ranked=[x[0] for x in sorted(assessed,key=lambda x:(-x[0]["fitness"],str(x[0].get("assetId") or "")))]
    if not accepted:
        return {
            "status":"CONSTRUCT_REQUIRED",
            "selected":None,
            "threshold":threshold,
            "structuralUse":bool(structural),
            "reason":"NO_ASSET_PASSES_MULTIDIMENSIONAL_FITNESS_GATE",
            "next":"USE_CONSTRUCTOR_OR_GOVERNED_ARTIST",
            "assessed":ranked,
        }
    a,c=accepted[0]
    return {
        "status":"ASSET_SELECTED",
        "selected":dict(c),
        "fitness":a["fitness"],
        "threshold":threshold,
        "structuralUse":bool(structural),
        "assessed":ranked,
    }


def compatibility_select_asset(candidates:Iterable[Mapping[str,Any]], threshold:float=DEFAULT_THRESHOLD)->Dict[str,Any]:
    """Drop-in successor to Phase0A select_asset; structural by default.

    Existing callers recognize NO_SUITABLE_ASSET as the fail-closed signal.
    The richer direct API uses CONSTRUCT_REQUIRED; this adapter preserves the
    old signal while explicitly pointing at construction.
    """
    effective=max(float(threshold),DEFAULT_THRESHOLD)
    out=resolve_asset(candidates,structural=True,threshold=effective)
    if out.get('status')=='CONSTRUCT_REQUIRED':
        out=dict(out); out['status']='NO_SUITABLE_ASSET'; out['constructorRequired']=True
    return out
