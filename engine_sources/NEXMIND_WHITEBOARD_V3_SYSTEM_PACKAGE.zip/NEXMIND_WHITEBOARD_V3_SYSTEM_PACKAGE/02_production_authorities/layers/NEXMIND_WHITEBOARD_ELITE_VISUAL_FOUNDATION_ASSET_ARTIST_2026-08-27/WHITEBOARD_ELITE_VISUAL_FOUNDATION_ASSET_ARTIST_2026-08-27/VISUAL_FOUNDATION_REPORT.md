# NexMind Whiteboard Elite — Visual Foundation Correction

## Decision

**VISUAL_FOUNDATION_ASSET_ARTIST_GOVERNANCE_PASS**

This correction addresses two foundations exposed by the Layer 5 wireframe proof: structural asset selection and artist authority. It does **not** claim the box/line renderer is visually fixed yet.

## Asset Resolver

The active structural resolver no longer averages only semantic/context similarity. It evaluates seven dimensions: semantic, pose, action, style, camera, editability and cleanliness. Fitness uses a multiplicative/geometric formulation, per-dimension minimum floors, severe penalties and hard contamination vetoes. A strong score in one dimension cannot compensate for a structurally bad dimension.

Hard-veto classes include embedded text, baked irrelevant props, incompatible fixed pose, wrong perspective, style mismatch, non-removable background, and fixed whole-body illustration used as performer structure. Decorative illustration and excessive complexity receive severe penalties. Missing fitness evidence is low confidence and therefore fails closed.

The active chat launcher and Story Scene Composer now use this stronger gate through a routing shim. Historical Layer 1 source was not rewritten. Existing callers still receive `NO_SUITABLE_ASSET`, now with `constructorRequired=true` and `USE_CONSTRUCTOR_OR_GOVERNED_ARTIST`.

An adversarial fixture demonstrates the change: the earlier Phase0A average scored a polished semantically-related but structurally unfit candidate **0.8983 and selected it**. The new resolver rejects it because pose/editability fail floors, its background is a hard veto, and decorative-art penalty applies.

## Truth-Constrained Artists

The recovered P9 specialist doctrines remain useful, but its noun/word-set `required_roles()` router remains quarantined. The replacement dispatches from typed scene truth, not prompt vocabulary.

- Character Artist: performance frames + identity; may style/simplify but must preserve trajectory, contacts, held objects, gaze and identity.
- Environment Artist: environment composition; may convert primitives into semantic drawable forms, occlusion plans and shot LOD while preserving world anchors, paths and interaction surfaces.
- Object Artist: affordance geometry; may author recognizable reusable forms while preserving grip/support/articulation truth.
- Interaction/Pose Artist: certified interaction solution; may improve silhouette/overlap only without moving contact or ownership truth.
- Art Critic: must review actual rendered pixels, not plans alone.

A contact-mutating Interaction/Pose Artist proposal is rejected by contract. Unrelated unseen scene/entity names with identical typed truth produce identical role dispatch.

## QA

- Visual-foundation tests: **17/17 PASS**
- Layers 1–5 plus new gate: **65/65 PASS**
- Visual Construction: **57/57 PASS**
- Executable anti-hardcoding scan: **PASS**
- Canonical frozen tree: **1863 files**, digest `16f83da6f58d31fa977e59bd7f76c608a6b7dc9c859d602f5587cc196bd1b235` — **PASS**

## Remaining visual work

The Layer 5 contact sheet still fails the human visual bar because physical primitives are rendered as wireframe/bounds. The next visual correction remains **Semantic Drawable Projection + occlusion/depth cleanup + shot-specific LOD**, with Environment/Object/Character artists operating on certified truth and the new Asset Resolver supplying only fit assets.
