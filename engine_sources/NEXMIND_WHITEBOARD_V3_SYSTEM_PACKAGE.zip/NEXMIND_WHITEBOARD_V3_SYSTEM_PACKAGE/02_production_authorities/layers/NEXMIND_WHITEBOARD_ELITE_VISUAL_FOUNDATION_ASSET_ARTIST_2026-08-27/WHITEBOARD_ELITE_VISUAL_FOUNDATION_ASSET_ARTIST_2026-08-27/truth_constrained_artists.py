from __future__ import annotations
from copy import deepcopy
from typing import Any, Dict, Iterable, List, Mapping

ARTIST_ROLES=("CHARACTER_ARTIST","ENVIRONMENT_ARTIST","OBJECT_ARTIST","INTERACTION_POSE_ARTIST","ART_CRITIC")

ROLE_INPUTS={
 "CHARACTER_ARTIST":("performerFrames","identityContract"),
 "ENVIRONMENT_ARTIST":("environmentComposition",),
 "OBJECT_ARTIST":("affordanceObjects",),
 "INTERACTION_POSE_ARTIST":("certifiedInteractions",),
 "ART_CRITIC":("renderedFrames",),
}

IMMUTABLE_BY_ROLE={
 "CHARACTER_ARTIST":["jointTopology","rootTrajectory","contacts","heldObjects","gazeTargets","identity"],
 "ENVIRONMENT_ARTIST":["worldAnchors","walkablePaths","interactionSurfaces","spatialRelations"],
 "OBJECT_ARTIST":["objectIdentity","affordances","graspRegions","supportRegions","articulationAxes"],
 "INTERACTION_POSE_ARTIST":["contactPoints","ownershipTimeline","actorIdentity","objectIdentity","supportState"],
 "ART_CRITIC":["referenceTruth","renderedPixels"],
}

ALLOWED_BY_ROLE={
 "CHARACTER_ARTIST":["strokeLanguage","silhouetteCleanup","lineWeight","facialStyling","clothingStyling","identityConsistentSimplification"],
 "ENVIRONMENT_ARTIST":["semanticDrawableForms","occlusionPlan","shotLOD","lineHierarchy","styleNormalization","detailBudget"],
 "OBJECT_ARTIST":["recognizableForm","strokePlan","semanticParts","styleNormalization","reusableDrawableDefinition"],
 "INTERACTION_POSE_ARTIST":["silhouetteReadability","limbOverlapCleanup","cameraFacingReadability","nonContactCurveRefinement"],
 "ART_CRITIC":["readabilityReview","continuityReview","occlusionReview","styleReview","contactVisibilityReview","failureReasons"],
}


def derive_required_roles(truth:Mapping[str,Any])->List[str]:
    """Typed structural dispatch. No prompt nouns or scenario word lists are consulted."""
    roles=[]
    if truth.get("performerFrames") and truth.get("identityContract"): roles.append("CHARACTER_ARTIST")
    if truth.get("environmentComposition"): roles.append("ENVIRONMENT_ARTIST")
    if truth.get("affordanceObjects"): roles.append("OBJECT_ARTIST")
    if truth.get("certifiedInteractions"): roles.append("INTERACTION_POSE_ARTIST")
    if truth.get("renderedFrames"): roles.append("ART_CRITIC")
    return roles


def build_artist_work_orders(truth:Mapping[str,Any], style_contract:Mapping[str,Any]|None=None)->Dict[str,Any]:
    roles=derive_required_roles(truth)
    orders=[]
    for role in roles:
        required=ROLE_INPUTS[role]
        missing=[k for k in required if not truth.get(k)]
        if missing:
            continue
        payload={k:deepcopy(truth[k]) for k in required}
        # Include cross-cutting certified truth only as references; artists do not own it.
        refs={k:deepcopy(truth[k]) for k in ("sceneId","worldProjection","ownershipTimeline","contactSolution") if k in truth}
        orders.append({
            "role":role,
            "status":"READY",
            "truthInputs":payload,
            "truthReferences":refs,
            "immutable":list(IMMUTABLE_BY_ROLE[role]),
            "allowedEnhancements":list(ALLOWED_BY_ROLE[role]),
            "styleContract":deepcopy(style_contract or {}),
            "failurePolicy":"FAIL_CLOSED_PRESERVE_CERTIFIED_TRUTH",
        })
    return {"schema":"TruthConstrainedArtistWorkOrdersV1","roles":roles,"orders":orders}


def validate_artist_result(order:Mapping[str,Any], result:Mapping[str,Any])->Dict[str,Any]:
    role=order.get("role")
    if role not in ARTIST_ROLES: return {"status":"REJECTED","reason":"UNKNOWN_ROLE"}
    if result.get("role")!=role: return {"status":"REJECTED","reason":"ROLE_MISMATCH"}
    if result.get("inventedPhysics") is True: return {"status":"REJECTED","reason":"ARTIST_INVENTED_PHYSICS"}
    if result.get("changedOwnership") is True: return {"status":"REJECTED","reason":"ARTIST_CHANGED_OWNERSHIP"}
    if result.get("changedContactAnchors") is True: return {"status":"REJECTED","reason":"ARTIST_CHANGED_CERTIFIED_CONTACT"}
    if result.get("changedWorldAnchors") is True: return {"status":"REJECTED","reason":"ARTIST_CHANGED_WORLD_TRUTH"}
    preserved=set(result.get("preservedTruth",[]))
    required=set(order.get("immutable",[]))
    missing=sorted(required-preserved)
    if missing: return {"status":"REJECTED","reason":"IMMUTABLE_TRUTH_NOT_ATTESTED","missing":missing}
    enhancements=set(result.get("enhancements",[]))
    illegal=sorted(enhancements-set(order.get("allowedEnhancements",[])))
    if illegal: return {"status":"REJECTED","reason":"OUT_OF_SCOPE_ENHANCEMENT","illegal":illegal}
    if role=="ART_CRITIC" and not result.get("pixelEvidenceReviewed",False):
        return {"status":"REJECTED","reason":"CRITIC_DID_NOT_REVIEW_RENDERED_PIXELS"}
    return {"status":"ACCEPTED","role":role}
