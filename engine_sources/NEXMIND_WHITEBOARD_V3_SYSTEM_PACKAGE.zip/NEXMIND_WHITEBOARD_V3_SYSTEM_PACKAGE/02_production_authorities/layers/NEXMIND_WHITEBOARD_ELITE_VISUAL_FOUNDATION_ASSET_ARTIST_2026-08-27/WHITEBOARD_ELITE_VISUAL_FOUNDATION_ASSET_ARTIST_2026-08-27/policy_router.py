"""Visual-foundation routing shim.

Keeps Phase0A task/capability routing authority while superseding only the
structural asset selector with the stronger multidimensional gate.
"""
from __future__ import annotations
import importlib.util
from pathlib import Path

PHASE0=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_RESET_PHASE0A_2026-08-26/policy_router.py')
spec=importlib.util.spec_from_file_location('_phase0a_policy_router',PHASE0)
_mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(_mod)
route=_mod.route
from asset_fitness_resolver import compatibility_select_asset as select_asset
