from asset_fitness_resolver import resolve_asset, score_asset
from truth_constrained_artists import derive_required_roles, build_artist_work_orders, validate_artist_result


def good(asset_id='good'):
    return dict(assetId=asset_id,semantic=.94,pose=.93,action=.94,style=.9,camera=.9,editability=.88,cleanliness=.95,structurallyEditable=True)

def test_one_bad_dimension_cannot_be_averaged_away():
    c=good('bad-pose'); c['pose']=.3
    r=resolve_asset([c])
    assert r['status']=='CONSTRUCT_REQUIRED'
    assert 'pose' in r['assessed'][0]['floorFailures']

def test_embedded_text_is_hard_veto():
    c=good('text'); c['embeddedText']=True
    r=resolve_asset([c])
    assert r['status']=='CONSTRUCT_REQUIRED'
    assert 'embedded_words' in r['assessed'][0]['hardVetoes']

def test_polished_irrelevant_asset_loses_to_constructor():
    c=good('polished-but-wrong'); c.update(semantic=.88,pose=.18,action=.12,camera=.45,decorativeIllustration=True)
    r=resolve_asset([c])
    assert r['status']=='CONSTRUCT_REQUIRED'

def test_whole_body_fixed_asset_cannot_be_structural_performer():
    c=good('whole-body'); c.update(wholeBodyIllustration=True,structurallyEditable=False)
    r=resolve_asset([c],structural=True)
    assert r['status']=='CONSTRUCT_REQUIRED'
    assert 'whole_body_fixed_pose_not_structural_authority' in r['assessed'][0]['hardVetoes']

def test_style_only_can_consider_non_structural_material_if_otherwise_fit():
    c=good('whole-body'); c.update(wholeBodyIllustration=True,structurallyEditable=False)
    r=resolve_asset([c],structural=False)
    assert r['status']=='ASSET_SELECTED'

def test_good_asset_is_selected():
    r=resolve_asset([good('a'),dict(good('b'),semantic=.80)])
    assert r['status']=='ASSET_SELECTED' and r['selected']['assetId']=='a'

def typed_truth(labels=('x','y','z')):
    return {
      'sceneId':labels[0],
      'performerFrames':[{'id':labels[1]}], 'identityContract':{'id':labels[1]},
      'environmentComposition':{'id':labels[2]},
      'affordanceObjects':[{'id':'o'}],
      'certifiedInteractions':[{'id':'i'}],
      'renderedFrames':[{'id':'r'}],
    }

def test_artist_dispatch_uses_typed_truth_not_nouns():
    a=derive_required_roles(typed_truth(('shop','bread','shelf')))
    b=derive_required_roles(typed_truth(('nebula','quasar','fjord')))
    assert a==b==['CHARACTER_ARTIST','ENVIRONMENT_ARTIST','OBJECT_ARTIST','INTERACTION_POSE_ARTIST','ART_CRITIC']

def test_artist_work_orders_carry_immutable_truth_contracts():
    pkg=build_artist_work_orders(typed_truth())
    assert len(pkg['orders'])==5
    assert all(o['failurePolicy']=='FAIL_CLOSED_PRESERVE_CERTIFIED_TRUTH' for o in pkg['orders'])

def test_interaction_artist_cannot_change_contact():
    pkg=build_artist_work_orders(typed_truth())
    o=next(x for x in pkg['orders'] if x['role']=='INTERACTION_POSE_ARTIST')
    r={'role':o['role'],'preservedTruth':o['immutable'],'enhancements':['silhouetteReadability'],'changedContactAnchors':True}
    assert validate_artist_result(o,r)['status']=='REJECTED'

def test_critic_must_review_pixels():
    pkg=build_artist_work_orders(typed_truth())
    o=next(x for x in pkg['orders'] if x['role']=='ART_CRITIC')
    r={'role':o['role'],'preservedTruth':o['immutable'],'enhancements':['readabilityReview'],'pixelEvidenceReviewed':False}
    assert validate_artist_result(o,r)['status']=='REJECTED'

def test_baked_irrelevant_props_are_vetoed():
    c=good('baked'); c['bakedInIrrelevantProps']=True
    r=resolve_asset([c]); assert r['status']=='CONSTRUCT_REQUIRED'
    assert 'baked_irrelevant_props' in r['assessed'][0]['hardVetoes']

def test_fixed_incompatible_pose_is_vetoed():
    c=good('fixed'); c['fixedIncompatibleBodyPose']=True
    r=resolve_asset([c]); assert r['status']=='CONSTRUCT_REQUIRED'

def test_wrong_perspective_is_vetoed():
    c=good('persp'); c['wrongPerspective']=True
    r=resolve_asset([c]); assert r['status']=='CONSTRUCT_REQUIRED'

def test_style_mismatch_is_vetoed():
    c=good('style'); c['styleMismatch']=True
    r=resolve_asset([c]); assert r['status']=='CONSTRUCT_REQUIRED'

def test_non_removable_background_is_vetoed():
    c=good('bg'); c['nonRemovableBackground']=True
    r=resolve_asset([c]); assert r['status']=='CONSTRUCT_REQUIRED'

def test_excessive_complexity_is_severely_penalized():
    c=good('complex'); c['excessiveComplexity']=True
    r=resolve_asset([c]); assert r['status']=='CONSTRUCT_REQUIRED'
    assert r['assessed'][0]['penaltyMultiplier']==.55

def test_asset_id_or_domain_name_does_not_change_fitness():
    a=score_asset(good('alpha'))
    b=score_asset(good('unseen-domain-object-name'))
    assert a['fitness']==b['fitness'] and a['dimensions']==b['dimensions']
