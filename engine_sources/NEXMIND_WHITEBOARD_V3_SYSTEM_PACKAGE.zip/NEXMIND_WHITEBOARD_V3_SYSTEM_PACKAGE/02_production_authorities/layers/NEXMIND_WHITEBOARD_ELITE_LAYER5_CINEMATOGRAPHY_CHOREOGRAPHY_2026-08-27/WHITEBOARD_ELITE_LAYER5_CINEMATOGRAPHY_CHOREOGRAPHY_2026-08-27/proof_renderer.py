from __future__ import annotations
import math, subprocess, sys
from pathlib import Path
from typing import Any,Dict,List,Tuple
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from physical_scene_fusion import compile_unified_story_temporal
from cinema_choreography import compile_story_cinema

W,H=1280,720

def _lerp(a,b,t):return a+(b-a)*t
def _mix_rect(a,b,t):
    return {'min':{'x':_lerp(a['min']['x'],b['min']['x'],t),'y':_lerp(a['min']['y'],b['min']['y'],t)},'max':{'x':_lerp(a['max']['x'],b['max']['x'],t),'y':_lerp(a['max']['y'],b['max']['y'],t)}}
def _crop_pt(p,v):
    sx=max(1e-6,v['max']['x']-v['min']['x']);sy=max(1e-6,v['max']['y']-v['min']['y'])
    return ((p[0]-v['min']['x'])/sx*W,(p[1]-v['min']['y'])/sy*H)
def _raw_project(p,d):
    x=p[0]/max(.001,d['x']);y=p[1]/max(.001,d['y']);z=p[2]/max(.001,d['z'])
    return [.50+x*.72-z*.34,.86-y*.68-z*.22]
def _projection_fit(comp):
    d=comp['dimensions'];pts=[]
    for c in comp['components']:
        b=c['bounds']
        for x in (b['min']['x'],b['max']['x']):
            for y in (b['min']['y'],b['max']['y']):
                for z in (b['min']['z'],b['max']['z']):pts.append(_raw_project([x,y,z],d))
    xmin=min(p[0] for p in pts);xmax=max(p[0] for p in pts);ymin=min(p[1] for p in pts);ymax=max(p[1] for p in pts);m=.04
    def f(p):return [m+(p[0]-xmin)/max(1e-6,xmax-xmin)*(1-2*m),m+(p[1]-ymin)/max(1e-6,ymax-ymin)*(1-2*m)]
    return lambda p:f(_raw_project(p,d))
def _component_geom(draw,c,v,alpha=255):
    b=c['screenBounds'];x0,y0=_crop_pt((b['min']['x'],b['min']['y']),v);x1,y1=_crop_pt((b['max']['x'],b['max']['y']),v)
    x0,x1=min(x0,x1),max(x0,x1);y0,y1=min(y0,y1),max(y0,y1)
    ink=(18,18,18,alpha);soft=(130,130,130,alpha)
    prim=c.get('primitive')
    if prim in {'wall','surface','path'}:
        draw.line([(x0,y1),(x1,y1)],fill=ink,width=3)
        if prim=='path':draw.line([(x0,y0),(x1,y0)],fill=soft,width=1)
    elif prim=='storage':
        draw.rectangle([x0,y0,x1,y1],outline=ink,width=3)
        for k in (0.25,.5,.75):draw.line([(x0,y0+(y1-y0)*k),(x1,y0+(y1-y0)*k)],fill=ink,width=2)
    elif prim=='work_surface':
        yy=y0+(y1-y0)*.35;draw.line([(x0,yy),(x1,yy)],fill=ink,width=4);draw.line([(x0+(x1-x0)*.12,yy),(x0+(x1-x0)*.12,y1)],fill=ink,width=3);draw.line([(x1-(x1-x0)*.12,yy),(x1-(x1-x0)*.12,y1)],fill=ink,width=3)
    elif prim in {'opening','signage','equipment','container','fixture','seat'}:
        draw.rectangle([x0,y0,x1,y1],outline=ink,width=3)
        if prim=='container':
            n=int(c.get('geometry',{}).get('arrayCount') or 1)
            if n>1:
                for k in range(1,min(n,8)):xx=x0+(x1-x0)*k/n;draw.line([(xx,y0),(xx,y1)],fill=soft,width=1)
        if prim=='equipment':draw.rectangle([x0+(x1-x0)*.2,y0+(y1-y0)*.18,x1-(x1-x0)*.2,y0+(y1-y0)*.45],outline=soft,width=2)
    else:draw.rectangle([x0,y0,x1,y1],outline=soft,width=2)

def _actor_world_point(point,transform):
    local=point.get('actorLocal3d') or point.get('world3d')
    if not local:return None
    root=(transform or {}).get('positionWorld3d') or [0,0,0];yaw=math.radians(float((transform or {}).get('facingYawDeg',0)));c,s=math.cos(yaw),math.sin(yaw)
    x=float(root[0])+c*float(local[0])+s*float(local[2]);z=float(root[2])-s*float(local[0])+c*float(local[2]);y=float(root[1])+float(local[1])
    return [x,y,z]
def _draw_actor(draw,perf,transform,project,v):
    if not isinstance(perf,dict) or perf.get('status')!='OK':return
    def p(k):
        w=_actor_world_point(perf[k],transform);return _crop_pt(tuple(project(w)),v) if w else None
    pairs=[('head','shoulderL'),('head','shoulderR'),('shoulderL','elbowL'),('elbowL','wristL'),('shoulderR','elbowR'),('elbowR','wristR'),('hipL','kneeL'),('hipR','kneeR')]
    # torso chain
    torso=perf.get('torso',{}); tp=[]
    for k in ('neck','chest','spine','pelvis'):
        if k in torso:
            w=_actor_world_point(torso[k],transform);tp.append(_crop_pt(tuple(project(w)),v))
    if len(tp)>1:draw.line(tp,fill=(0,0,0),width=5)
    for a,b in pairs:
        if a in perf and b in perf:
            pa,pb=p(a),p(b)
            if pa and pb:draw.line([pa,pb],fill=(0,0,0),width=5)
    for side in ('L','R'):
        hip=p('hip'+side);knee=p('knee'+side);foot=perf.get('foot'+side,{}).get('ankle')
        if foot:
            fw=_actor_world_point(foot,transform);fp=_crop_pt(tuple(project(fw)),v)
            if hip and knee:draw.line([hip,knee],fill=(0,0,0),width=5)
            if knee:draw.line([knee,fp],fill=(0,0,0),width=5)
    hw=_actor_world_point(perf['head'],transform);hp=_crop_pt(tuple(project(hw)),v);r=max(6,int(24/(v['max']['x']-v['min']['x'])));draw.ellipse([hp[0]-r,hp[1]-r,hp[0]+r,hp[1]+r],outline=(0,0,0),width=4)

def _font(size):
    for p in ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf'):
        if Path(p).exists():return ImageFont.truetype(p,size)
    return ImageFont.load_default()

def render_story_proof(story_text:str,out_mp4:Path,out_sheet:Path,fps:int=24):
    temporal=compile_unified_story_temporal(story_text);plan=compile_story_cinema(story_text);g=temporal['environmentGrounding'];comp=g['environmentComposition'];project=_projection_fit(comp);env=comp['shotProjection']['components'];frames=temporal['renderFrames']
    tmp=out_mp4.parent/'_layer5_frames';tmp.mkdir(exist_ok=True)
    shot_images=[];frame_no=0
    for si,shot in enumerate(plan['shots']):
        dur=max(.75,float(shot['durationHintSeconds']));count=max(12,int(dur*fps));cur=shot['camera']['viewport'];nxt=plan['shots'][si+1]['camera']['viewport'] if si+1<len(plan['shots']) and plan['shots'][si+1]['sceneId']==shot['sceneId'] else cur
        lo,hi=shot['sourceFrameRange']
        for j in range(count):
            t=j/max(1,count-1);v=_mix_rect(cur,nxt,max(0,(t-.86)/.14)) if t>.86 else cur
            im=Image.new('RGB',(W,H),'white');d=ImageDraw.Draw(im)
            visible=max(1,int(len(env)*min(1,t/.30))) if t<.30 else len(env)
            for c in env[:visible]:_component_geom(d,c,v)
            if t>=.22:
                fi=lo if hi<=lo else min(hi,lo+int((hi-lo)*max(0,min(1,(t-.35)/.5))))
                fr=frames[fi];_draw_actor(d,fr.get('performer'),fr.get('worldActorTransform'),project,v)
                os=fr.get('objects') or []
                if os and isinstance(os[0].get('positionWorld3d'),list):
                    q=_crop_pt(tuple(project(os[0]['positionWorld3d'])),v);rw=max(5,int(12/(v['max']['x']-v['min']['x'])));d.rectangle([q[0]-rw,q[1]-rw*.55,q[0]+rw,q[1]+rw*.55],outline=(0,0,0),width=3)
            if t<.24 and any(o['operation']=='WHITEBOARD_HAND_MARKER' for o in shot['drawingChoreography']['operations']):
                x=80+360*t;y=100;d.line([(x,y),(x+34,y+16)],fill=(70,70,70),width=8);d.ellipse([x+28,y+10,x+42,y+24],fill=(70,70,70))
            d.rectangle([0,0,W,54],fill='white');d.text((22,12),f"{si+1}/{len(plan['shots'])}  {shot['camera']['shotType']}   frames {lo}-{hi}",font=_font(24),fill=(20,20,20))
            path=tmp/f'{frame_no:05d}.png';im.save(path);frame_no+=1
            if j==int(count*.58):shot_images.append(im.copy())
    subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate',str(fps),'-i',str(tmp/'%05d.png'),'-c:v','libx264','-pix_fmt','yuv420p',str(out_mp4)],check=True)
    cols=3;cellw=420;cellh=252;rows=math.ceil(len(shot_images)/cols);sheet=Image.new('RGB',(cols*cellw,rows*cellh),'white')
    for i,im in enumerate(shot_images):
        thumb=im.resize((cellw,236));sheet.paste(thumb,((i%cols)*cellw,(i//cols)*cellh));ImageDraw.Draw(sheet).text(((i%cols)*cellw+8,(i//cols)*cellh+234),f'Shot {i+1}',font=_font(14),fill=(0,0,0))
    sheet.save(out_sheet)
    for p in tmp.glob('*.png'):p.unlink()
    tmp.rmdir()
    return {'shots':len(plan['shots']),'renderFrames':len(frames),'mp4':str(out_mp4),'sheet':str(out_sheet)}
