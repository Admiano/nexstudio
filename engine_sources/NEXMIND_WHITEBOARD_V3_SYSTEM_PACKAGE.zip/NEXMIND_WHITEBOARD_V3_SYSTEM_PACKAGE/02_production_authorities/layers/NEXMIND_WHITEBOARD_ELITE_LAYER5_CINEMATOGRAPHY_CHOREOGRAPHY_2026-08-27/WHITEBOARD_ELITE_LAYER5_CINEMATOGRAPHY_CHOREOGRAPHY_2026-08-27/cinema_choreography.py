from __future__ import annotations
import hashlib, json, math, sys
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

ROOT=Path(__file__).resolve().parent
CANONICAL=Path('/mnt/data/nexmind-runtime/current').resolve()
LAYER3=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER3_ENVIRONMENT_COMPOSER_2026-08-27')
LAYER4=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER4_ACTION_TEMPORAL_STATE_2026-08-27')
for p in (CANONICAL/'ASSIMILATION_RUNTIME/runtime', LAYER3, LAYER4):
    if str(p) not in sys.path: sys.path.insert(0,str(p))
from capability_hub import resolve
from physical_scene_fusion import compile_unified_story_temporal

SCHEMA='WhiteboardCinemaPlanV1'
SHOT_SCHEMA='WhiteboardShotPlanV1'
CHOREO_SCHEMA='WhiteboardDrawingChoreographyV1'

# These are cinematic information roles, not story/content categories.
SHOT_ROLE_PROFILES={
    'CONTEXT': {'shotType':'WIDE_ESTABLISHING','scale':1.00,'duration':0.85,'cameraMotion':'LOCKED_OR_GENTLE_PUSH'},
    'BODY_ACTION': {'shotType':'MEDIUM_ACTION','scale':0.60,'duration':0.85,'cameraMotion':'BOUNDED_TRACK_OR_REFRAME'},
    'CONTACT': {'shotType':'CLOSE_HAND','scale':0.31,'duration':0.70,'cameraMotion':'PUSH_OR_CUT'},
    'STATE_CHANGE': {'shotType':'INSERT_STATE','scale':0.22,'duration':0.55,'cameraMotion':'LOCKED_DETAIL'},
    'MULTI_ACTOR': {'shotType':'TWO_SHOT','scale':0.68,'duration':0.95,'cameraMotion':'BOUNDED_REFRAME'},
    'CONSEQUENCE': {'shotType':'MEDIUM_CONSEQUENCE','scale':0.55,'duration':0.80,'cameraMotion':'SETTLE_OR_PULL'},
}

DRAW_PHASES=('OUTLINE','DETAIL','FILL_HIGHLIGHT','PERFORM','TRANSITION')
ALLOWED_STROKE_OPS={
    'DRAW_ON','ERASE','REDRAW','MORPH','PAN','PUSH','OBJECT_TRANSLATION','CHARACTER_MOTION',
    'HAND_MOVEMENT','CAMERA_REFRAME','WHITEBOARD_HAND_MARKER','HOLD','CUT'
}


def _canon(v:Any)->str: return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def _hash(v:Any)->str: return hashlib.sha256(_canon(v).encode()).hexdigest()
def _clamp(v,a=0.0,b=1.0): return max(a,min(b,float(v)))
def _rect(cx,cy,w,h):
    w,h=min(1.0,max(.06,w)),min(1.0,max(.06,h)); cx,cy=_clamp(cx),_clamp(cy)
    x0=min(max(0.0,cx-w/2),1.0-w); y0=min(max(0.0,cy-h/2),1.0-h)
    x1=x0+w; y1=y0+h
    return {'min':{'x':round(x0,6),'y':round(y0,6)},'max':{'x':round(x1,6),'y':round(y1,6)}}

def _center(bounds):
    return ((float(bounds['min']['x'])+float(bounds['max']['x']))/2,(float(bounds['min']['y'])+float(bounds['max']['y']))/2)

def cinema_capability_plan()->Dict[str,Any]:
    cinema=resolve('CINEMA_AGENT',['cinema_media','environment_scene'],True)
    wb=resolve('WHITEBOARD_ARTIST',['whiteboard','environment_scene'],True)
    def rows(xs):
        return [{'capabilityId':r['capabilityId'],'use':r['use'],'integrationStatus':r['integrationStatus']} for r in xs]
    wanted_camera={'yomotsu-camera-controls','three-js','world-intelligence-contract','tonejs-tone-js'}
    wanted_draw={'rough-stuff-rough','rough-stuff-rough-notation','steveruizok-perfect-freehand','svg-js','flubber'}
    return {
        'schema':'WhiteboardLayer5CapabilityBindingV1',
        'cinema':[r for r in rows(cinema) if r['capabilityId'] in wanted_camera or 'camera' in r['use'].lower() or 'timing' in r['use'].lower()],
        'drawing':[r for r in rows(wb) if r['capabilityId'] in wanted_draw],
        'selectionPolicy':'ROLE_AND_EVIDENCE_ONLY_NO_GLOBAL_PRESTIGE',
        'scenarioKeying':False,
    }

def _component_map(environment_grounding:Optional[Dict[str,Any]])->Tuple[Dict[str,Any],Dict[str,Any]]:
    if not environment_grounding:return {},{}
    ec=environment_grounding.get('environmentComposition') or {}
    shot=ec.get('shotProjection') or {}
    bycomp={x['componentId']:x for x in shot.get('components',[])}
    placement={x['entityId']:x for x in environment_grounding.get('entityPlacements',[])}
    return bycomp,placement

def _entity_focus(entity_id:Optional[str], bycomp:Dict[str,Any], placement:Dict[str,Any])->Optional[Tuple[float,float]]:
    if not entity_id:return None
    p=placement.get(entity_id)
    c=bycomp.get((p or {}).get('componentId'))
    if c:
        q=c['projectedCenter'];return float(q['x']),float(q['y'])
    return None

def _first_object_id(frame):
    os=frame.get('objects') or []
    return os[0].get('entityId') if os else None

def _event_flags(frames:List[Dict[str,Any]])->List[Dict[str,Any]]:
    out=[]; prev_owner=None; prev_contact=False
    for i,f in enumerate(frames):
        os=f.get('objects') or []; obj=os[0] if os else {}; owner=obj.get('owner')
        contact=bool((f.get('contacts') or {}).get('active'))
        performers=f.get('performer') or {}; actor_count=len(f.get('actorIds') or [])
        pphase=performers.get('phase') if isinstance(performers,dict) else None
        state_change=(prev_owner is not None and owner is not None and owner!=prev_owner) or bool(obj.get('articulation')) or obj.get('contents') is not None or obj.get('pressAmount') is not None
        out.append({'index':i,'contact':contact,'contactStart':contact and not prev_contact,'stateChange':state_change,'owner':owner,'multiActor':actor_count>1,'phase':pphase,'bridge':bool(f.get('bridge'))})
        if owner is not None:prev_owner=owner
        prev_contact=contact
    return out

def _window(center:int,n:int,radius:int=1)->Tuple[int,int]: return max(0,center-radius),min(n-1,center+radius)

def _candidate_shots(frames:List[Dict[str,Any]], scene_introduced:bool=False)->List[Dict[str,Any]]:
    n=len(frames)
    if n==0:return []
    flags=_event_flags(frames); candidates=[]
    cursor=0
    if not scene_introduced:
        candidates.append({'role':'CONTEXT','frameRange':[0,0],'reason':'introduce physical world and blocking before action detail'})
        cursor=1
    contact_starts=[x['index'] for x in flags if x['contactStart']]
    changes=[x['index'] for x in flags if x['stateChange']]
    # Collapse immediately-adjacent state transitions into one insert; separated transitions remain distinct.
    chosen_changes=[]
    for idx in changes:
        if not chosen_changes or idx-chosen_changes[-1]>=2: chosen_changes.append(idx)
    anchors=[]
    for idx in contact_starts: anchors.append((max(0,idx-1),min(n-1,idx+1),'CONTACT',idx))
    for idx in chosen_changes: anchors.append((idx,idx,'STATE_CHANGE',idx))
    anchors.sort(key=lambda x:(x[0],0 if x[2]=='CONTACT' else 1,x[1]))

    def filler_role(a,b):
        multi=any(flags[i]['multiActor'] for i in range(max(0,a),min(n,b+1)))
        return 'MULTI_ACTOR' if multi else 'BODY_ACTION'

    # Preserve participant geography at least once when the beat contains multiple actors.
    if any(x['multiActor'] for x in flags):
        first_multi=next(x['index'] for x in flags if x['multiActor'])
        candidates.append({'role':'MULTI_ACTOR','frameRange':[first_multi,first_multi],'reason':'establish participant geography before interaction detail'})
        cursor=max(cursor,first_multi+1)
    for alo,ahi,role,idx in anchors:
        if cursor<alo:
            r=filler_role(cursor,alo-1)
            candidates.append({'role':r,'frameRange':[cursor,alo-1],'reason':'keep physical action/restaging continuously observed between detail shots'})
        # Detail shots may share only the cut-boundary frame with the preceding body shot; time never rewinds.
        dlo=max(cursor-1 if cursor>0 else 0,alo)
        dhi=max(dlo,ahi)
        candidates.append({'role':role,'frameRange':[dlo,dhi],'reason':'prove hand contact' if role=='CONTACT' else 'show ownership/articulation/content state transition'})
        cursor=max(cursor,dhi+1)
    if cursor<n:
        # Final interval becomes consequence unless it still contains active body/multi-actor performance.
        r='MULTI_ACTOR' if any(flags[i]['multiActor'] for i in range(cursor,n)) else ('CONSEQUENCE' if n-cursor<=2 else 'BODY_ACTION')
        candidates.append({'role':r,'frameRange':[cursor,n-1],'reason':'show physical consequence and continuity after interaction' if r=='CONSEQUENCE' else 'keep remaining physical performance visible'})
    if not candidates:
        candidates=[{'role':'BODY_ACTION','frameRange':[0,n-1],'reason':'observe physical performance'}]
    return candidates


def _world_screen_mapper(environment_grounding:Optional[Dict[str,Any]]):
    if not environment_grounding:return None
    comp=environment_grounding.get('environmentComposition') or {};dims=comp.get('dimensions');components=comp.get('components') or []
    if not dims or not components:return None
    def raw(p):
        x=float(p[0])/max(.001,float(dims['x']));y=float(p[1])/max(.001,float(dims['y']));z=float(p[2])/max(.001,float(dims['z']))
        return [.50+x*.72-z*.34,.86-y*.68-z*.22]
    pts=[]
    for c in components:
        b=c['bounds']
        for x in (b['min']['x'],b['max']['x']):
            for y in (b['min']['y'],b['max']['y']):
                for z in (b['min']['z'],b['max']['z']):pts.append(raw([x,y,z]))
    xmin=min(p[0] for p in pts);xmax=max(p[0] for p in pts);ymin=min(p[1] for p in pts);ymax=max(p[1] for p in pts);m=.04
    return lambda p:(m+(raw(p)[0]-xmin)/max(1e-6,xmax-xmin)*(1-2*m),m+(raw(p)[1]-ymin)/max(1e-6,ymax-ymin)*(1-2*m))

def _performer_point_world(point:Dict[str,Any],transform:Optional[Dict[str,Any]]):
    local=(point or {}).get('actorLocal3d') or (point or {}).get('world3d')
    if not local:return None
    tr=transform or {};root=tr.get('positionWorld3d') or [0,0,0];yaw=math.radians(float(tr.get('facingYawDeg',0)));c,si=math.cos(yaw),math.sin(yaw)
    return [float(root[0])+c*float(local[0])+si*float(local[2]),float(root[1])+float(local[1]),float(root[2])-si*float(local[0])+c*float(local[2])]

def _focus_for_candidate(c,frames,bycomp,placement,environment_grounding=None)->Tuple[float,float,List[str]]:
    lo,hi=c['frameRange']; target_ids=[];physical_pts=[];mapper=_world_screen_mapper(environment_grounding)
    for f in frames[lo:hi+1]:
        oid=_first_object_id(f)
        if oid and oid not in target_ids:target_ids.append(oid)
        for aid in f.get('actorIds') or []:
            if aid not in target_ids:target_ids.append(aid)
        if mapper:
            for o in f.get('objects') or []:
                p=o.get('positionWorld3d')
                if isinstance(p,list) and len(p)==3:physical_pts.append(mapper(p))
            tr=f.get('worldActorTransform')
            if tr and isinstance(tr.get('positionWorld3d'),list):physical_pts.append(mapper(tr['positionWorld3d']))
            if c['role'] in {'CONTACT','STATE_CHANGE'}:
                perf=f.get('performer') or {}
                if isinstance(perf,dict) and perf.get('status')=='OK':
                    active=((perf.get('request') or {}).get('activeHand') or 'right').lower();key='wristL' if active=='left' else 'wristR'
                    if key in perf:
                        w=_performer_point_world(perf[key],tr)
                        if w:physical_pts.append(mapper(w))
    if physical_pts:
        return sum(p[0] for p in physical_pts)/len(physical_pts),sum(p[1] for p in physical_pts)/len(physical_pts),target_ids
    pts=[_entity_focus(e,bycomp,placement) for e in target_ids]; pts=[p for p in pts if p]
    if pts:return sum(p[0] for p in pts)/len(pts),sum(p[1] for p in pts)/len(pts),target_ids
    return .5,.55,target_ids

def _camera_contract(role,cx,cy,world_projection=None)->Dict[str,Any]:
    p=SHOT_ROLE_PROFILES[role]; scale=p['scale']; aspect=16/9
    h=min(1.0,scale); w=min(1.0,h*aspect)
    if role=='CONTEXT': viewport={'min':{'x':0.0,'y':0.0},'max':{'x':1.0,'y':1.0}}
    else: viewport=_rect(cx,cy,w,h)
    safe=(world_projection or {}).get('cameraSafeZones',[])
    return {
        'authority':'CINEMA_AGENT_ROLE_PLANNER',
        'shotType':p['shotType'],'viewport':viewport,'targetCenter':{'x':round(cx,6),'y':round(cy,6)},
        'motion':p['cameraMotion'],'fitMode':'FIT_SEMANTIC_SUBJECTS_WITH_MARGIN','bounded':True,
        'cameraSafeZones':deepcopy(safe),'donorContract':'yomotsu-camera-controls fit/lookAt/reframe semantics',
    }

def _drawing_choreography(shot:Dict[str,Any], prev:Optional[Dict[str,Any]], next_shot:Optional[Dict[str,Any]])->Dict[str,Any]:
    role=shot['role']; lo,hi=shot['sourceFrameRange']; ops=[]
    # Construction is always explicit and staged; TYPE_REVEAL is never the master reveal operation.
    ops.append({'phase':'OUTLINE','operation':'DRAW_ON','targets':['primary_environment_contours','primary_actor_contours'],'timing':[0.00,.22],'authority':'rough/perfect-freehand/svg stroke construction'})
    detail_op='REDRAW' if prev is not None and prev.get('sceneId')!=shot.get('sceneId') and role=='CONTEXT' else 'DRAW_ON'
    ops.append({'phase':'DETAIL','operation':detail_op,'targets':['shot_relevant_environment_detail','prop_detail','facial_or_hand_detail_when_visible'],'timing':[.18,.34],'authority':'semantic SVG groups'})
    ops.append({'phase':'FILL_HIGHLIGHT','operation':'DRAW_ON','targets':['attention_path_or_contact_region'],'timing':[.30,.42],'authority':'rough-notation style emphasis; optional'})
    if hi>lo:
        ops.append({'phase':'PERFORM','operation':'CHARACTER_MOTION','targets':['performer_frames'],'sourceFrameRange':[lo,hi],'timing':[.40,.88],'authority':'NexStick via Layer2/Layer4'})
    else:
        ops.append({'phase':'PERFORM','operation':'HOLD','targets':['physical_state_frame'],'sourceFrameRange':[lo,hi],'timing':[.40,.82],'authority':'Layer4 temporal state'})
    if role in {'CONTACT','STATE_CHANGE'}:
        ops.append({'phase':'PERFORM','operation':'HAND_MOVEMENT','targets':['contact_effector'],'sourceFrameRange':[lo,hi],'timing':[.42,.82],'authority':'NexStick hand/contact state'})
    if role=='STATE_CHANGE':
        ops.append({'phase':'PERFORM','operation':'OBJECT_TRANSLATION','targets':['same_entity_id_state_change'],'sourceFrameRange':[lo,hi],'timing':[.48,.76],'authority':'Layer4 position/ownership continuity'})
        ops.append({'phase':'PERFORM','operation':'MORPH','targets':['same_entity_same_graphic_state'],'sourceFrameRange':[lo,hi],'timing':[.62,.84],'authority':'flubber-style same-identity geometry interpolation','sameIdentityRequired':True})
    if shot['camera']['motion'] not in {'LOCKED_DETAIL'}:
        op='PUSH' if 'PUSH' in shot['camera']['motion'] else ('PAN' if 'TRACK' in shot['camera']['motion'] else 'CAMERA_REFRAME')
        ops.append({'phase':'PERFORM','operation':op,'targets':['camera'],'timing':[.38,.84],'authority':'Cinema camera contract'})
    marker=role in {'CONTEXT','STATE_CHANGE'}
    if marker:
        ops.append({'phase':'OUTLINE','operation':'WHITEBOARD_HAND_MARKER','targets':['active_draw_stroke_only'],'timing':[.02,.25],'policy':'presentation device only; never substitutes for story actor'})
    # Transition policy is continuity-aware. Morph is legal only when the same graphic/entity remains the subject.
    if next_shot is None:
        trans='HOLD'
    elif shot['sceneId']!=next_shot['sceneId']:
        trans='ERASE'
    else:
        common=set(shot.get('subjectIds',[]))&set(next_shot.get('subjectIds',[]))
        trans='CAMERA_REFRAME' if common else 'CUT'
    ops.append({'phase':'TRANSITION','operation':trans,'targets':['shot_boundary'],'timing':[.88,1.00],'sameIdentityRequired':trans=='MORPH'})
    assert all(x['operation'] in ALLOWED_STROKE_OPS for x in ops)
    return {'schema':CHOREO_SCHEMA,'phaseOrder':list(DRAW_PHASES),'operations':ops,'typeRevealIsMasterReveal':False,'markerPolicy':'OPTIONAL_WHEN_DRAWING_IS_VISIBLE_NOT_ALWAYS_ON'}

def compile_cinematic_sequence(payload:Dict[str,Any])->Dict[str,Any]:
    if payload.get('schema') not in {'WhiteboardCinematicPhysicalInputV1','WhiteboardStoryTemporalSequenceV1'}:
        raise ValueError('WHITEBOARD_PHYSICAL_SEQUENCE_REQUIRED')
    if payload.get('schema')=='WhiteboardStoryTemporalSequenceV1':
        scenes=[{'sceneId':'scene_0','temporalFrames':payload.get('renderFrames') or [],'environmentGrounding':payload.get('environmentGrounding'),'worldProjection':payload.get('worldProjection'),'introduced':False}]
        beats=[{'beatId':'beat_0','sceneId':'scene_0','frameRange':[0,max(0,len(scenes[0]['temporalFrames'])-1)]}]
    else:
        scenes=payload.get('scenes') or [];beats=payload.get('beats') or []
    by_scene={s['sceneId']:s for s in scenes}; all_shots=[]; beat_plans=[]
    scene_seen=set()
    for bidx,beat in enumerate(beats):
        scene=by_scene[beat['sceneId']]; frames=scene.get('temporalFrames') or []
        lo,hi=beat.get('frameRange',[0,max(0,len(frames)-1)]); local=frames[lo:hi+1]
        bycomp,placement=_component_map(scene.get('environmentGrounding'))
        candidates=_candidate_shots(local, scene['sceneId'] in scene_seen or bool(scene.get('introduced')))
        shots=[]
        for sidx,c in enumerate(candidates):
            cx,cy,subjects=_focus_for_candidate(c,local,bycomp,placement,scene.get('environmentGrounding'))
            shot={'schema':SHOT_SCHEMA,'shotId':f"{beat['beatId']}:shot:{sidx}",'beatId':beat['beatId'],'sceneId':scene['sceneId'],'role':c['role'],'reason':c['reason'],'sourceFrameRange':[lo+c['frameRange'][0],lo+c['frameRange'][1]],'beatSourceFrameRange':[lo,hi],'subjectIds':subjects,'camera':_camera_contract(c['role'],cx,cy,scene.get('worldProjection')),'durationHintSeconds':SHOT_ROLE_PROFILES[c['role']]['duration'],'continuityAuthority':'Layer4 entity identity + state continuity'}
            shots.append(shot)
        scene_seen.add(scene['sceneId']);all_shots.extend(shots);beat_plans.append({'beatId':beat['beatId'],'sceneId':scene['sceneId'],'shotIds':[s['shotId'] for s in shots],'shotCount':len(shots)})
    for i,shot in enumerate(all_shots):
        shot['drawingChoreography']=_drawing_choreography(shot,all_shots[i-1] if i else None,all_shots[i+1] if i+1<len(all_shots) else None)
        shot['shotHash']=_hash({k:v for k,v in shot.items() if k!='shotHash'})
    out={'schema':SCHEMA,'beats':beat_plans,'shots':all_shots,'capabilityBinding':cinema_capability_plan(),'invariants':validate_cinema_plan(all_shots),'scenarioSpecificLogic':False}
    out['planHash']=_hash(out);return out

def compile_story_cinema(story_text:str)->Dict[str,Any]:
    temporal=compile_unified_story_temporal(story_text); grounding=temporal.get('environmentGrounding') or {}
    frames=temporal.get('renderFrames') or []
    physical={'schema':'WhiteboardCinematicPhysicalInputV1','scenes':[{'sceneId':'scene_0','temporalFrames':frames,'environmentGrounding':grounding,'worldProjection':temporal.get('worldProjection'),'introduced':False}], 'beats':[{'beatId':'beat_0','sceneId':'scene_0','frameRange':[0,max(0,len(frames)-1)]}]}
    plan=compile_cinematic_sequence(physical)
    plan['sourceText']=story_text;plan['sourceTemporalSchema']=temporal.get('schema');plan['sourceEnvironmentSchema']=grounding.get('schema');plan['unifiedSceneHash']=temporal.get('sceneHash');plan['sourceContinuity']=deepcopy(temporal.get('invariants'));plan['sourceSpatialContinuity']=deepcopy(temporal.get('spatialContinuity'));plan['physicalFusion']=deepcopy(temporal.get('fusionInvariants'))
    plan['planHash']=_hash({k:v for k,v in plan.items() if k!='planHash'});return plan

def validate_cinema_plan(shots:List[Dict[str,Any]])->Dict[str,Any]:
    ops=[o['operation'] for s in shots for o in s.get('drawingChoreography',{}).get('operations',[])]
    ranges=[s['sourceFrameRange'] for s in shots]
    bybeat={}
    for s in shots: bybeat.setdefault(s.get('beatId'),[]).append(s)
    timeline_checks=[]
    for bid,seq in bybeat.items():
        target=seq[0].get('beatSourceFrameRange') or seq[0]['sourceFrameRange']
        prev_start=None;prev_end=None;covered=set()
        monotonic=True
        for s in seq:
            a,b=s['sourceFrameRange'];covered.update(range(a,b+1))
            if prev_start is not None and (a<prev_start or b<prev_end):monotonic=False
            if prev_end is not None and a>prev_end+1:monotonic=False
            prev_start,prev_end=a,b
        required=set(range(target[0],target[1]+1))
        timeline_checks.append({'beatId':bid,'monotonicNoHiddenRewind':monotonic,'completePhysicalCoverage':required<=covered,'sourceRange':target})
    return {
        'beatCanContainMultipleShots':True,
        'shotCount':len(shots),
        'allShotsHavePhysicalFrameRanges':all(isinstance(r,list) and len(r)==2 and r[0]<=r[1] for r in ranges),
        'allShotsHaveCameraContracts':all(bool(s.get('camera',{}).get('viewport')) for s in shots),
        'allShotsHaveFivePhaseDrawingGrammar':all(s.get('drawingChoreography',{}).get('phaseOrder')==list(DRAW_PHASES) for s in shots),
        'timelineChecks':timeline_checks,
        'allBeatsPhysicallyCovered':all(x['completePhysicalCoverage'] for x in timeline_checks),
        'noHiddenTemporalRewind':all(x['monotonicNoHiddenRewind'] for x in timeline_checks),
        'typeRevealOnly':set(ops)<= {'HOLD','CUT'},
        'usesDrawOn':'DRAW_ON' in ops,'usesCharacterMotion':'CHARACTER_MOTION' in ops,'usesHandMovement':'HAND_MOVEMENT' in ops,
        'usesObjectTranslation':'OBJECT_TRANSLATION' in ops,'usesCameraReframing':any(x in ops for x in ('PAN','PUSH','CAMERA_REFRAME')),
        'usesMorph':'MORPH' in ops,'usesEraseOrRedraw':any(x in ops for x in ('ERASE','REDRAW')),
        'morphRequiresSameIdentity':all(o.get('sameIdentityRequired') is True for s in shots for o in s['drawingChoreography']['operations'] if o['operation']=='MORPH'),
        'scenarioSpecificLogic':False,
        'pass': bool(shots) and 'DRAW_ON' in ops and all(bool(s.get('camera',{}).get('viewport')) for s in shots) and all(s.get('drawingChoreography',{}).get('phaseOrder')==list(DRAW_PHASES) for s in shots) and all(x['completePhysicalCoverage'] and x['monotonicNoHiddenRewind'] for x in timeline_checks),
    }

