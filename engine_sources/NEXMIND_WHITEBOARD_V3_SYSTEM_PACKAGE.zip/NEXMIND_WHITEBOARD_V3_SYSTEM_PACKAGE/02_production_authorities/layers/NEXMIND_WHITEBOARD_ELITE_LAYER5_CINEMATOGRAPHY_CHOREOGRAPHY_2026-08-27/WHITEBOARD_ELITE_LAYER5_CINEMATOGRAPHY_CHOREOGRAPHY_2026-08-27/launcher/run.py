#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, json, subprocess, sys
CURRENT=Path('/mnt/data/nexmind-runtime/current').resolve()
OVERLAY=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_RESET_PHASE0A_2026-08-26')
LAYER1=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER1_STORY_SCENE_COMPOSER_2026-08-27')
LAYER2=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER2_WHITEBOARD_PERFORMER_2026-08-27')
LAYER3=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER3_ENVIRONMENT_COMPOSER_2026-08-27')
LAYER4=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER4_ACTION_TEMPORAL_STATE_2026-08-27')
LAYER5=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER5_CINEMATOGRAPHY_CHOREOGRAPHY_2026-08-27')
P3_ROOT=Path('/mnt/data/nexmind-runtime/recovery-authorities/NEXMIND_P25P3_2026-08-12/NexMind_God_Mode_P25P3')
sys.path.insert(0,str(OVERLAY))
sys.path.insert(0,str(LAYER1))
sys.path.insert(0,str(LAYER2))
sys.path.insert(0,str(LAYER3))
sys.path.insert(0,str(LAYER4))
sys.path.insert(0,str(LAYER5))
from policy_router import route, select_asset
from story_scene_composer import compose_story
from whiteboard_performer import sample_performer, story_performer_sequence, performer_policy
from environment_composer import compose_environment, ground_story_environment
from temporal_state_compiler import compile_temporal_activity, compile_story_temporal
from cinema_choreography import compile_story_cinema, compile_cinematic_sequence, cinema_capability_plan
from physical_scene_fusion import compile_unified_story_temporal

def gateway_status():
    gw=CURRENT/'ASSIMILATION_RUNTIME/runtime/system-execution-gateway.js'
    js=f"const g=require({json.dumps(str(gw))}); console.log(JSON.stringify(g.manifest()));"
    p=subprocess.run(['node','-e',js],text=True,capture_output=True,check=True)
    return json.loads(p.stdout)

def activity(payload):
    gw=CURRENT/'ASSIMILATION_RUNTIME/runtime/system-execution-gateway.js'
    js="const g=require(process.argv[1]); const x=JSON.parse(process.argv[2]); console.log(JSON.stringify(g.activity(x,{})));"
    p=subprocess.run(['node','-e',js,str(gw),json.dumps(payload)],text=True,capture_output=True,check=True)
    return json.loads(p.stdout)

def resolve_form(request, *, production_scoped_asset_generation=False):
    src=P3_ROOT/'src'; idx=P3_ROOT/'donors/NEXSTUDIO_ILLUSTRATION_CAPABILITY_INDEX_V1.json'
    if not src.exists() or not idx.exists():
        return {'status':'FORM_RESOLVER_UNAVAILABLE','no_silent_degrade':True}
    if str(src) not in sys.path: sys.path.insert(0,str(src))
    from nexmind_god_mode.illustration_form_resolver import IllustrationFormResolver
    resolver=IllustrationFormResolver.from_file(idx)
    cap={'production_scoped_asset_generation':bool(production_scoped_asset_generation)}
    try:
        return resolver.resolve(request,cap)
    except Exception as exc:
        return {'status':'FORM_REQUEST_INVALID','errorType':type(exc).__name__,'reason':str(exc)[:500],'no_silent_degrade':True}

def status():
    cert=json.loads((OVERLAY/'PHASE0A_CERTIFICATION.json').read_text())
    return {'schema':'NexMindChatSessionStatusV2','canonicalRuntime':str(CURRENT),'overlay':str(OVERLAY),'gateway':gateway_status(),'supplementalFormResolver':{'source':str(P3_ROOT),'available':P3_ROOT.exists(),'authority':'PRIMARY_NARROW_FAIL_CLOSED_FORM_RESOLUTION'},'phase0aDecision':cert['decision'],'phase1Started':cert['phase1Started'],'userDirectedLayer1':{'started':LAYER1.exists(),'layer':'Story Scene Composer','overlay':str(LAYER1)},'userDirectedLayer2':{'started':LAYER2.exists(),'layer':'Whiteboard Performer','overlay':str(LAYER2),'defaultNarrativePerformer':'NEXSTICK_PROJECTED'},'userDirectedLayer3':{'started':LAYER3.exists(),'layer':'Environment Composer','overlay':str(LAYER3),'environmentStructuralAuthority':'GENERAL_PRIMITIVE_COMPILER','construction':'DECLARATIVE_ARCHETYPE_OR_GENERIC_PRIMITIVE_SYNTHESIS'},'userDirectedLayer4':{'started':LAYER4.exists(),'layer':'Action and temporal state','overlay':str(LAYER4),'temporalAuthority':'GENERIC_STATE_MACHINE_OVER_UNIVERSAL_ACTIVITY_AND_NEXSTICK','identityContinuity':True,'ownershipEventGated':True},'userDirectedLayer5':{'started':LAYER5.exists(),'layer':'Whiteboard cinematography and drawing choreography','overlay':str(LAYER5),'authority':'PHYSICAL_SHOT_PLANNER_PLUS_STROKE_CHOREOGRAPHY','oneBeatMayContainMultipleShots':True,'fivePhaseDrawingGrammar':True,'typeRevealMaster':False,'unifiedWorldFusion':True}}

def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest='cmd',required=True)
    sub.add_parser('status')
    r=sub.add_parser('route'); r.add_argument('task_class');r.add_argument('--treatment')
    a=sub.add_parser('activity');a.add_argument('json_payload')
    s=sub.add_parser('select-asset');s.add_argument('json_candidates')
    f=sub.add_parser('resolve-form');f.add_argument('json_request');f.add_argument('--allow-generation',action='store_true')
    c=sub.add_parser('compose-story');c.add_argument('story_text');c.add_argument('--scene-id',default='story-scene-001')
    pf=sub.add_parser('performer-frame');pf.add_argument('json_request');pf.add_argument('--time',type=float,default=.6);pf.add_argument('--actor-id',default='actor');pf.add_argument('--camera-yaw',type=float,default=0.0)
    ps=sub.add_parser('perform-story');ps.add_argument('story_text');ps.add_argument('--camera-yaw',type=float,default=0.0)
    pp=sub.add_parser('performer-policy');pp.add_argument('task_class');pp.add_argument('--no-actor',action='store_true');pp.add_argument('--style-asset',action='store_true')
    ec=sub.add_parser('compose-environment');ec.add_argument('environment_id');ec.add_argument('--requested-primitives',default='');ec.add_argument('--topology',choices=['interior','exterior'])
    gs=sub.add_parser('ground-story-environment');gs.add_argument('story_text')
    ta=sub.add_parser('temporal-action');ta.add_argument('json_payload')
    ts=sub.add_parser('temporal-story');ts.add_argument('story_text')
    us=sub.add_parser('unified-story');us.add_argument('story_text')
    cs=sub.add_parser('cinema-story');cs.add_argument('story_text')
    cp=sub.add_parser('cinema-plan');cp.add_argument('json_payload')
    sub.add_parser('cinema-capabilities')
    ns=ap.parse_args()
    if ns.cmd=='status': out=status()
    elif ns.cmd=='route': out=route(ns.task_class,treatment=ns.treatment)
    elif ns.cmd=='activity': out=activity(json.loads(ns.json_payload))
    elif ns.cmd=='select-asset': out=select_asset(json.loads(ns.json_candidates))
    elif ns.cmd=='compose-story': out=compose_story(ns.story_text,ns.scene_id)
    elif ns.cmd=='performer-frame': out=sample_performer(json.loads(ns.json_request),ns.time,actor_id=ns.actor_id,camera_yaw_deg=ns.camera_yaw)
    elif ns.cmd=='perform-story': out=story_performer_sequence(ns.story_text,camera_yaw_deg=ns.camera_yaw)
    elif ns.cmd=='performer-policy': out=performer_policy(ns.task_class,has_actor=not ns.no_actor,explicit_style_requires_full_body_asset=ns.style_asset)
    elif ns.cmd=='compose-environment': out=compose_environment(ns.environment_id, requested_primitives=[x.strip() for x in ns.requested_primitives.split(',') if x.strip()] or None, topology=ns.topology)
    elif ns.cmd=='ground-story-environment': out=ground_story_environment(ns.story_text)
    elif ns.cmd=='temporal-action':
        x=json.loads(ns.json_payload); out=compile_temporal_activity(x.get('activity') or x,world_projection=x.get('worldProjection'),scene_spec=x.get('nexSceneSpec'),actor_id=x.get('actorId','actor_0'),partner_id=x.get('partnerId'))
    elif ns.cmd=='temporal-story': out=compile_story_temporal(ns.story_text)
    elif ns.cmd=='unified-story': out=compile_unified_story_temporal(ns.story_text)
    elif ns.cmd=='cinema-story': out=compile_story_cinema(ns.story_text)
    elif ns.cmd=='cinema-plan': out=compile_cinematic_sequence(json.loads(ns.json_payload))
    elif ns.cmd=='cinema-capabilities': out=cinema_capability_plan()
    else: out=resolve_form(json.loads(ns.json_request),production_scoped_asset_generation=ns.allow_generation)
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
