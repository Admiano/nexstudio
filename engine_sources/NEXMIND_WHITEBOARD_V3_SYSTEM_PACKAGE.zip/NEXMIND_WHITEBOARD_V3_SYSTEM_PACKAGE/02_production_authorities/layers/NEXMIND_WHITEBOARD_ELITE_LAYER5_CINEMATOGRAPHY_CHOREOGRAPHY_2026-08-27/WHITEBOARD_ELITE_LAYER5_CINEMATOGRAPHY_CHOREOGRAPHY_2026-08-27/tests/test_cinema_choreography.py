import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from cinema_choreography import compile_cinematic_sequence,validate_cinema_plan,ALLOWED_STROKE_OPS

def frame(i,contact=False,owner='source',multi=False,bridge=False,state=False):
    return {'schema':'WhiteboardTemporalFrameV1','index':i,'actorIds':['actor_a','actor_b'] if multi else ['actor_a'],'performer':{'status':'OK','phase':'CONTACT' if contact else 'APPROACH'},'objects':[{'entityId':'entity_x','owner':owner,'articulation':{'value':.5} if state else None,'positionWorld3d':[i*.1,.8,0]}],'contacts':{'active':contact},'bridge':{'kind':'HELD_OBJECT_RESTAGE'} if bridge else None}

def physical(frames,scene='scene_a',introduced=False):
    return {'schema':'WhiteboardCinematicPhysicalInputV1','scenes':[{'sceneId':scene,'temporalFrames':frames,'introduced':introduced,'worldProjection':{'cameraSafeZones':[{'position':{'x':0,'y':2,'z':5},'radius':.7}]}}], 'beats':[{'beatId':'beat_a','sceneId':scene,'frameRange':[0,len(frames)-1]}]}

def test_one_beat_expands_to_multiple_shots():
    fs=[frame(0),frame(1),frame(2,True),frame(3,True,'actor_a.rightHand'),frame(4,False,'actor_a.rightHand',bridge=True),frame(5,True,'destination')]
    p=compile_cinematic_sequence(physical(fs)); assert len(p['shots'])>=4;assert p['beats'][0]['shotCount']==len(p['shots'])

def test_contact_and_state_change_get_detail_coverage():
    fs=[frame(0),frame(1),frame(2,True),frame(3,True,'actor_a.rightHand')]
    roles={s['role'] for s in compile_cinematic_sequence(physical(fs))['shots']};assert 'CONTACT' in roles and 'STATE_CHANGE' in roles

def test_multi_actor_gets_two_shot_role():
    fs=[frame(0,multi=True),frame(1,contact=True,multi=True),frame(2,owner='actor_b.leftHand',multi=True)]
    roles={s['role'] for s in compile_cinematic_sequence(physical(fs))['shots']};assert 'MULTI_ACTOR' in roles

def test_all_shots_have_five_phase_grammar():
    fs=[frame(0),frame(1),frame(2,True),frame(3,True,'actor_a.rightHand')]
    p=compile_cinematic_sequence(physical(fs));assert all(s['drawingChoreography']['phaseOrder']==['OUTLINE','DETAIL','FILL_HIGHLIGHT','PERFORM','TRANSITION'] for s in p['shots'])

def test_stroke_operations_are_from_general_grammar():
    p=compile_cinematic_sequence(physical([frame(0),frame(1,True),frame(2,True,'actor_a.rightHand')]))
    ops={o['operation'] for s in p['shots'] for o in s['drawingChoreography']['operations']};assert ops<=ALLOWED_STROKE_OPS;assert 'DRAW_ON' in ops;assert 'CHARACTER_MOTION' in ops

def test_morph_only_same_identity():
    p=compile_cinematic_sequence(physical([frame(0),frame(1,True),frame(2,True,'actor_a.rightHand'),frame(3,False,'actor_a.rightHand')]))
    for s in p['shots']:
        for o in s['drawingChoreography']['operations']:
            if o['operation']=='MORPH': assert o['sameIdentityRequired'] is True

def test_no_scene_intro_repetition_when_already_introduced():
    p=compile_cinematic_sequence(physical([frame(0),frame(1,True)],introduced=True));assert all(s['role']!='CONTEXT' for s in p['shots'])

def test_unseen_identifier_invariance():
    fs=[frame(0),frame(1),frame(2,True),frame(3,True,'actor_a.rightHand')]
    a=compile_cinematic_sequence(physical(fs,'unseen_alpha'));b=compile_cinematic_sequence(physical(fs,'unseen_omega'))
    def sig(p):return [(s['role'],s['sourceFrameRange'],s['camera']['shotType'],[o['operation'] for o in s['drawingChoreography']['operations']]) for s in p['shots']]
    assert sig(a)==sig(b)

def test_camera_viewports_bounded():
    p=compile_cinematic_sequence(physical([frame(0),frame(1,True),frame(2,owner='actor_a.rightHand')]))
    for s in p['shots']:
        b=s['camera']['viewport']; assert 0<=b['min']['x']<=b['max']['x']<=1 and 0<=b['min']['y']<=b['max']['y']<=1

def test_plan_validation_passes():
    p=compile_cinematic_sequence(physical([frame(0),frame(1),frame(2,True),frame(3,True,'actor_a.rightHand')]));assert validate_cinema_plan(p['shots'])['pass']

def test_marker_is_optional_not_actor_authority():
    p=compile_cinematic_sequence(physical([frame(0),frame(1,True),frame(2,True,'actor_a.rightHand')]))
    marker=[o for s in p['shots'] for o in s['drawingChoreography']['operations'] if o['operation']=='WHITEBOARD_HAND_MARKER']
    assert marker and all('never substitutes' in o['policy'] for o in marker)

def test_scene_change_transition_erases_not_morphs():
    fs=[frame(0),frame(1,True),frame(2,owner='actor_a.rightHand')]
    payload={'schema':'WhiteboardCinematicPhysicalInputV1','scenes':[{'sceneId':'a','temporalFrames':fs},{'sceneId':'b','temporalFrames':fs}], 'beats':[{'beatId':'ba','sceneId':'a','frameRange':[0,2]},{'beatId':'bb','sceneId':'b','frameRange':[0,2]}]}
    p=compile_cinematic_sequence(payload); boundary=next(s for s in p['shots'] if s['beatId']=='ba' and s is p['shots'][p['shots'].index(s)])
    last_a=[s for s in p['shots'] if s['beatId']=='ba'][-1]
    trans=last_a['drawingChoreography']['operations'][-1]['operation'];assert trans=='ERASE'

def test_static_physical_beat_is_valid_without_forced_character_motion():
    p=compile_cinematic_sequence(physical([frame(0)]));assert p['invariants']['pass'];assert p['invariants']['allBeatsPhysicallyCovered']
