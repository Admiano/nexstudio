from __future__ import annotations
import json, math, sys
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Optional

CANONICAL=Path('/mnt/data/nexmind-runtime/current').resolve()
LAYER1=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER1_STORY_SCENE_COMPOSER_2026-08-27')
LAYER3=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER3_ENVIRONMENT_COMPOSER_2026-08-27')
LAYER4=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER4_ACTION_TEMPORAL_STATE_2026-08-27')
for p in (LAYER1,LAYER3,LAYER4,CANONICAL/'VC_RUNTIME'):
    if str(p) not in sys.path:sys.path.insert(0,str(p))
from story_scene_composer import compose_story
import environment_composer as envc
from temporal_state_compiler import compile_temporal_activity,validate_sequence,validate_spatial_continuity,_held_transit_frames,PROFILES
from src.scene_spec import validate_scene,scene_hash
from src.world_projection import project_world


def _v(d):return [float(d['x']),float(d['y']),float(d['z'])]
def _d(v):return {'x':round(float(v[0]),6),'y':round(float(v[1]),6),'z':round(float(v[2]),6)}
def _addp(d,delta):return _d([float(d['x'])+delta[0],float(d['y'])+delta[1],float(d['z'])+delta[2]])
def _shift_bounds(b,delta):return {'min':_addp(b['min'],delta),'max':_addp(b['max'],delta)}

def _reposition_entity(entity:Dict[str,Any],position:Dict[str,float])->Dict[str,Any]:
    e=deepcopy(entity);old=_v(e['transform']['position']);new=_v(position);delta=[new[i]-old[i] for i in range(3)];e['transform']['position']=_d(new)
    sp=e.get('spatial') or {}
    if sp.get('bounds'):sp['bounds']=_shift_bounds(sp['bounds'],delta)
    for key in ('supportPlanes','collisionVolumes','walkableRegions'):
        sp[key]=[_shift_bounds(b,delta) for b in sp.get(key,[])]
    it=e.get('interaction') or {}
    for key in ('graspRegions','insertionSockets','reachableRegions'):
        it[key]=[_shift_bounds(b,delta) if isinstance(b,dict) and 'min' in b and 'max' in b else b for b in it.get(key,[])]
    for key in ('attachmentPoints',):
        rows=[]
        for x in it.get(key,[]):
            q=deepcopy(x)
            if isinstance(q,dict) and isinstance(q.get('position'),dict):q['position']=_addp(q['position'],delta)
            rows.append(q)
        it[key]=rows
    return e

def _proxy_to_component(entity:Dict[str,Any],component_entity:Dict[str,Any],position:Dict[str,float])->Dict[str,Any]:
    # Semantic story identity may reference set geometry, but duplicate collision authority stays with the set component.
    e=deepcopy(entity);e['transform']['position']=deepcopy(position)
    e['spatial']=deepcopy(component_entity['spatial']);e['spatial']['walkObstacle']=False;e['spatial']['collisionVolumes']=[]
    # Preserve story interaction affordances if present; otherwise static set support remains semantic only.
    if not e.get('interaction',{}).get('graspRegions') and not e.get('interaction',{}).get('insertionSockets'):
        e['interaction']=deepcopy(component_entity['interaction'])
    e['semanticTags']=list(dict.fromkeys((e.get('semanticTags') or [])+(component_entity.get('semanticTags') or [])+['semantic_geometry_proxy']))
    return e

def fuse_story_environment(story_text:str)->Dict[str,Any]:
    grounding=envc.ground_story_environment(story_text);story=grounding['storyComposition'];comp=grounding['environmentComposition']
    env_scene=envc._nex_scene_spec(comp['environmentId'],comp['dimensions'],comp['camera'],comp['components'])
    env_by_id={e['id']:e for e in env_scene['entities']};placements={x['entityId']:x for x in grounding.get('entityPlacements',[])}
    story_scene=story['nexSceneSpec'];story_entities=[]
    for src in story_scene.get('entities',[]):
        pl=placements.get(src['id'])
        if not pl:
            story_entities.append(deepcopy(src));continue
        component=env_by_id.get(pl.get('componentId'))
        if pl.get('binding')=='ENVIRONMENT_COMPONENT' and component:
            e=_proxy_to_component(src,component,pl['position'])
        else:
            e=_reposition_entity(src,pl['position'])
        story_entities.append(e)
    fused=deepcopy(env_scene);fused['sceneId']='fused-'+story_scene['sceneId'];fused['entities']=deepcopy(env_scene['entities'])+story_entities;fused['relationships']=deepcopy(story_scene.get('relationships',[]));fused['metadata']={'source':'WhiteboardLayer5PhysicalSceneFusionV1','environmentSourceSceneId':env_scene['sceneId'],'storySourceSceneId':story_scene['sceneId'],'semanticGeometryFusion':True,'scenarioSpecificLogic':False}
    validate_scene(fused);world=project_world(fused)
    return {'schema':'WhiteboardUnifiedPhysicalSceneV1','story':story,'environmentGrounding':grounding,'nexSceneSpec':fused,'worldProjection':world,'sceneHash':scene_hash(fused),'invariants':{'singleWorldCoordinateAuthority':True,'storyEntitiesGroundedInDrawableSet':True,'environmentGeometryFromLayer3':True,'storySemanticsFromLayer1':True,'worldProjectionRecomputedAfterFusion':True,'scenarioSpecificLogic':False}}

def _source_for(story:Dict[str,Any],item_id:Optional[str])->Optional[str]:
    if not item_id:return None
    for b in story.get('blocking',[]):
        if b.get('subjectId')==item_id and b.get('relation') in {'supported_by','inside','on','supported-by'}:return b.get('objectId')
    for c in story.get('continuity',[]):
        if c.get('entityId')==item_id:
            chain=c.get('ownershipChain') or []
            if chain:return chain[0].get('holderId')
    return None

def _activity_from_action(action:Dict[str,Any],story:Dict[str,Any])->Optional[Dict[str,Any]]:
    op=str(action.get('operation') or '').lower().replace('_',' ')
    if op not in PROFILES:return None
    a={'action':op}
    for k in ('targetId','itemId','toolId','destinationId','partnerId','activeHand','loadClass','handoffTarget'):
        if action.get(k) is not None:a[k]=action[k]
    item=a.get('itemId') or a.get('toolId') or (a.get('targetId') if op in {'pickup','remove','carry','give','receive','pour','drink'} else None)
    if item and 'itemId' not in a:a['itemId']=item
    if op in {'pickup','remove'} and 'sourceId' not in a:a['sourceId']=_source_for(story,item)
    return a

def _dist3(a,b):return math.sqrt(sum((float(a[i])-float(b[i]))**2 for i in range(3)))
def _lerp(a,b,t):return float(a)+(float(b)-float(a))*float(t)
def _interp_value(a,b,t):
    if isinstance(a,(int,float)) and isinstance(b,(int,float)) and not isinstance(a,bool) and not isinstance(b,bool):return round(_lerp(a,b,t),6)
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):return [_interp_value(x,y,t) for x,y in zip(a,b)]
    if isinstance(a,dict) and isinstance(b,dict):
        return {k:_interp_value(a[k],b[k],t) if k in a and k in b else deepcopy(a.get(k,b.get(k))) for k in set(a)|set(b)}
    return deepcopy(a if t<1.0 else b)

def densify_temporal_for_cinema(frames:List[Dict[str,Any]],max_object_step_m:float=.25)->List[Dict[str,Any]]:
    if not frames:return []
    out=[deepcopy(frames[0])]
    for a,b in zip(frames,frames[1:]):
        ao=(a.get('objects') or [{}])[0];bo=(b.get('objects') or [{}])[0]
        same_entity=ao.get('entityId') and ao.get('entityId')==bo.get('entityId')
        same_actors=(a.get('actorIds') or [])==(b.get('actorIds') or [])
        same_action=a.get('action')==b.get('action')
        pa,pb=ao.get('positionWorld3d'),bo.get('positionWorld3d')
        steps=1
        if same_entity and isinstance(pa,list) and isinstance(pb,list) and len(pa)==3 and len(pb)==3:
            steps=max(1,int(math.ceil(_dist3(pa,pb)/max_object_step_m)))
        if same_entity and same_actors and same_action and steps>1:
            for j in range(1,steps):
                t=j/steps;f=_interp_value(a,b,t)
                f['schema']='WhiteboardTemporalFrameV1';f['interpolation']={'kind':'CINEMA_RENDER_INBETWEEN','fromCheckpoint':a.get('renderIndex',a.get('index')),'toCheckpoint':b.get('renderIndex',b.get('index')),'progress':round(t,6),'authority':'interpolation between Layer4/NexStick physical checkpoints; no semantic event invention'}
                # Event state cannot move early: ownership, support and contact remain from the earlier checkpoint until the later checkpoint is reached.
                if f.get('objects') and a.get('objects'):
                    f['objects'][0]['owner']=deepcopy(ao.get('owner'));f['objects'][0]['support']=deepcopy(ao.get('support'))
                if a.get('contacts') is not None:f['contacts']=deepcopy(a.get('contacts'))
                f['renderIndex']=len(out);out.append(f)
        q=deepcopy(b);q['renderIndex']=len(out);out.append(q)
    for i,f in enumerate(out):f['renderIndex']=i
    return out

def compile_unified_story_temporal(story_text:str)->Dict[str,Any]:
    fused=fuse_story_environment(story_text);story=fused['story'];actor=(story.get('cast') or [{'id':'actor_0'}])[0]['id'];world=fused['worldProjection'];scene=fused['nexSceneSpec'];seqs=[]
    for action in story.get('actions',[]):
        a=_activity_from_action(action,story)
        if not a:continue
        try:
            seq=compile_temporal_activity(a,world_projection=world,scene_spec=scene,actor_id=actor,partner_id=a.get('partnerId'))
            reach=(seq.get('performanceBinding') or {}).get('reachability') or {}
            stage=reach.get('stagingPosition')
            if stage:
                for fr in seq.get('frames',[]):
                    fr.setdefault('worldActorTransform',{'positionWorld3d':[float(stage.get('x',0)),float(stage.get('y',0)),float(stage.get('z',0))],'facingYawDeg':float(reach.get('facingYawDeg',0))})
            seqs.append(seq)
        except Exception as exc:
            seqs.append({'schema':'WhiteboardTemporalActionSequenceV1','action':a['action'],'status':'FAILED_CLOSED','reason':str(exc),'frames':[],'activity':a})
    render=[];bridge_count=0
    good=[s for s in seqs if s.get('frames')]
    for si,seq in enumerate(good):
        if render and seq['frames']:
            prev=good[si-1];last=render[-1];first=seq['frames'][0]
            lo=(last.get('objects') or [{}])[0];fo=(first.get('objects') or [{}])[0]
            same=lo.get('entityId') and lo.get('entityId')==fo.get('entityId')
            held=same and isinstance(lo.get('owner'),str) and '.rightHand' in lo.get('owner','') and isinstance(fo.get('owner'),str) and '.rightHand' in fo.get('owner','')
            if held:
                a,b=lo.get('positionWorld3d'),fo.get('positionWorld3d')
                if isinstance(a,list) and isinstance(b,list):
                    dist=math.sqrt(sum((float(a[k])-float(b[k]))**2 for k in range(3)))
                    if dist>.20:
                        bridge=_held_transit_frames(lo['entityId'],actor,a,b,prev.get('performanceBinding',{}).get('reachability'),seq.get('performanceBinding',{}).get('reachability'))
                        render.extend(bridge);bridge_count+=len(bridge)
        render.extend(deepcopy(seq['frames']))
    for i,f in enumerate(render):f['renderIndex']=i
    dense=densify_temporal_for_cinema(render)
    return {'schema':'WhiteboardUnifiedStoryTemporalSequenceV1','sourceText':story_text,'sceneHash':fused['sceneHash'],'actorId':actor,'environmentGrounding':fused['environmentGrounding'],'nexSceneSpec':scene,'worldProjection':world,'sourceSequences':seqs,'checkpointFrames':render,'renderFrames':dense,'transitBridgeFrames':bridge_count,'renderInbetweenFrames':max(0,len(dense)-len(render)),'invariants':validate_sequence(dense) if dense else {'pass':False},'checkpointSpatialContinuity':validate_spatial_continuity(render) if render else {'pass':False},'spatialContinuity':validate_spatial_continuity(dense,.30) if dense else {'pass':False},'fusionInvariants':fused['invariants']}
