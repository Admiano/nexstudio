from __future__ import annotations

import json
import math
import re
import subprocess
import sys
from copy import deepcopy
from pathlib import Path

CANONICAL = Path('/mnt/data/nexmind-runtime/current').resolve()
VC_ROOT = CANONICAL / 'VC_RUNTIME'
CAP_ROOT = CANONICAL / 'CAPABILITY_RUNTIME'
PHASE0A = Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_RESET_PHASE0A_2026-08-26')
ROOT = Path(__file__).resolve().parent
ENV_PROFILE_PATH = ROOT / 'environment_profiles.json'

if str(VC_ROOT) not in sys.path:
    sys.path.insert(0, str(VC_ROOT))
if str(PHASE0A) not in sys.path:
    sys.path.insert(0, str(PHASE0A))

from src.scene_spec import vec, bounds, validate_scene, scene_hash
from src.world_projection import project_world
from src.environment_library import resolve_environment
from src.object_affordance import compile_scene_affordances
from src.stance_selector import select_stance
from src.asset_registry import resolve_assets
from policy_router import select_asset


ACTION_PATTERNS = {
    'navigate': [r'\bwalk(?:s|ed|ing)?\b', r'\bgo(?:es|ing|ne)?\b', r'\benter(?:s|ed|ing)?\b', r'\bapproach(?:es|ed|ing)?\b', r'\bmove(?:s|d|ing)?\b'],
    'pickup': [r'\bpick(?:s|ed|ing)?\s+up\b', r'\btake(?:s|n|ing)?\b', r'\btook\b', r'\bgrab(?:s|bed|bing)?\b', r'\blift(?:s|ed|ing)?\b', r'\bcollect(?:s|ed|ing)?\b', r'\bremove(?:s|d|ing)?\b'],
    'place': [r'\bplace(?:s|d|ing)?\b', r'\bput(?:s|ting)?\b', r'\bset(?:s|ting)?\b', r'\bdrop(?:s|ped|ping)?\b', r'\binsert(?:s|ed|ing)?\b'],
    'open': [r'\bopen(?:s|ed|ing)?\b'],
    'close': [r'\bclose(?:s|d|ing)?\b', r'\bshut(?:s|ting)?\b'],
    'push': [r'\bpush(?:es|ed|ing)?\b', r'\bpress(?:es|ed|ing)?\b'],
    'pull': [r'\bpull(?:s|ed|ing)?\b', r'\bdrag(?:s|ged|ging)?\b'],
    'carry': [r'\bcarry(?:ies|ied|ing)?\b', r'\btransport(?:s|ed|ing)?\b'],
    'give': [r'\bgive(?:s|n|ing)?\b', r'\bgave\b', r'\bhand(?:s|ed|ing)?\s+over\b'],
    'receive': [r'\breceive(?:s|d|ing)?\b'],
    'read': [r'\bread(?:s|ing)?\b', r'\binspect(?:s|ed|ing)?\b'],
    'use': [r'\buse(?:s|d|ing)?\b', r'\boperate(?:s|d|ing)?\b'],
}

DETERMINERS = {'a', 'an', 'the', 'some', 'this', 'that', 'these', 'those'}
PREP_ENV = ('into', 'inside', 'in', 'to', 'toward', 'towards')
PREP_SOURCE = ('from', 'off', 'out of')
PREP_DEST = ('into', 'in', 'inside', 'on', 'onto', 'to')

ROLE_SPECS = {
    'primary_actor': {'kind': 'person', 'size': (.68, 1.68, .34), 'tags': ['actor']},
    'service_staff': {'kind': 'person', 'size': (.68, 1.68, .34), 'tags': ['actor', 'service_staff']},
    'support_fixture': {'kind': 'environment_structure', 'size': (1.45, 1.80, .48), 'tags': ['support_surface', 'storage', 'environment_structure']},
    'target_item': {'kind': 'rigid_object', 'size': (.34, .18, .20), 'tags': ['graspable', 'portable']},
    'carry_container': {'kind': 'rigid_object', 'size': (.62, .38, .42), 'tags': ['container', 'portable', 'graspable', 'item_receiver']},
    'merchandise_context': {'kind': 'environment_structure', 'size': (1.6, 1.3, .35), 'tags': ['background_context']},
    'transaction_station': {'kind': 'environment_structure', 'size': (1.5, .9, .72), 'tags': ['transaction_station', 'support_surface', 'environment_structure']},
    'generic_object': {'kind': 'rigid_object', 'size': (.48, .38, .36), 'tags': []},
    'generic_support': {'kind': 'environment_structure', 'size': (1.2, .9, .65), 'tags': ['support_surface', 'environment_structure']},
    'generic_destination': {'kind': 'rigid_object', 'size': (.62, .42, .45), 'tags': ['container', 'item_receiver']},
}

ROLE_POSITIONS = {
    'primary_actor': (-.95, .84, .15),
    'service_staff': (2.45, .84, -1.25),
    'support_fixture': (.58, .90, .00),
    'target_item': (.45, 1.18, -.18),
    'carry_container': (-1.20, .26, .62),
    'merchandise_context': (1.75, .70, .68),
    'transaction_station': (2.35, .45, -1.20),
    'generic_object': (.45, .42, 0),
    'generic_support': (.60, .45, 0),
    'generic_destination': (-1.1, .30, .55),
}


def _slug(text: str) -> str:
    return re.sub(r'[^a-z0-9]+', '_', text.lower()).strip('_') or 'entity'


def _clean_phrase(text: str | None) -> str | None:
    if not text:
        return None
    words = re.findall(r"[A-Za-z0-9'-]+", text.strip())
    while words and words[0].lower() in DETERMINERS:
        words.pop(0)
    while words and words[-1].lower() in {'then'}:
        words.pop()
    return ' '.join(words).strip() or None


def _first_action(clause: str) -> tuple[str | None, re.Match | None]:
    hits = []
    for action, pats in ACTION_PATTERNS.items():
        for pat in pats:
            m = re.search(pat, clause, re.I)
            if m:
                hits.append((m.start(), -len(m.group(0)), action, m))
    if not hits:
        return None, None
    _, _, action, match = sorted(hits, key=lambda x: (x[0], x[1], x[2]))[0]
    return action, match


def _find_prep(rest: str, preps: tuple[str, ...]) -> tuple[str | None, int]:
    candidates = []
    for prep in preps:
        m = re.search(r'\b' + re.escape(prep) + r'\b', rest, re.I)
        if m:
            candidates.append((m.start(), prep))
    if not candidates:
        return None, -1
    idx, prep = min(candidates)
    return prep, idx


def parse_story(text: str) -> dict:
    text = ' '.join(str(text).strip().split())
    if not text:
        raise ValueError('STORY_TEXT_REQUIRED')
    name_match = re.match(r'^([A-Z][A-Za-z0-9_-]*)\b', text)
    actor = name_match.group(1) if name_match else 'person'
    clauses = [c.strip(' ,.;') for c in re.split(r'\b(?:and then|then|and)\b|[;]', text, flags=re.I) if c.strip(' ,.;')]
    actions = []
    env_cue = None
    for clause in clauses:
        action, m = _first_action(clause)
        if not action or not m:
            continue
        rest = clause[m.end():].strip()
        rec = {'action': action, 'clause': clause, 'actorLabel': actor}
        if action == 'navigate':
            prep, idx = _find_prep(rest, PREP_ENV)
            if prep is not None:
                env_cue = _clean_phrase(rest[idx + len(prep):])
                rec['destinationLabel'] = env_cue
        elif action == 'pickup':
            prep, idx = _find_prep(rest, PREP_SOURCE)
            rec['targetLabel'] = _clean_phrase(rest[:idx] if idx >= 0 else rest)
            if prep is not None:
                rec['sourceLabel'] = _clean_phrase(rest[idx + len(prep):])
        elif action == 'place':
            prep, idx = _find_prep(rest, PREP_DEST)
            rec['targetLabel'] = _clean_phrase(rest[:idx] if idx >= 0 else rest)
            if prep is not None:
                rec['destinationLabel'] = _clean_phrase(rest[idx + len(prep):])
        elif action == 'give':
            prep, idx = _find_prep(rest, ('to',))
            rec['targetLabel'] = _clean_phrase(rest[:idx] if idx >= 0 else rest)
            if prep is not None:
                rec['destinationLabel'] = _clean_phrase(rest[idx + len(prep):])
        else:
            rec['targetLabel'] = _clean_phrase(rest)
        actions.append(rec)
    return {'actorLabel': actor, 'environmentCue': env_cue, 'actions': actions, 'sourceText': text}


def _load_profiles() -> dict:
    return json.loads(ENV_PROFILE_PATH.read_text())


def _profile_for(cue: str | None) -> dict | None:
    if not cue:
        return None
    norm = _clean_phrase(cue).lower() if _clean_phrase(cue) else ''
    for row in _load_profiles().get('entries', []):
        aliases = {_clean_phrase(x).lower() for x in row.get('aliases', []) if _clean_phrase(x)}
        aliases.add(row['environmentId'].replace('_', ' ').lower())
        if norm in aliases:
            return deepcopy(row)
    return None


def _role_for_parsed(label: str, relation_role: str) -> str:
    if relation_role == 'source':
        return 'support_fixture'
    if relation_role == 'destination':
        return 'generic_destination'
    if relation_role == 'target':
        return 'target_item'
    return 'generic_object'


def _bnd_from_center(pos, size):
    x, y, z = pos
    sx, sy, sz = size
    return bounds(x - sx / 2, max(0, y - sy / 2), z - sz / 2, x + sx / 2, y + sy / 2, z + sz / 2)


def _support_plane(b, y: float | None = None):
    mn, mx = b['min'], b['max']
    sy = float(y if y is not None else mx['y'])
    pad_x = (mx['x'] - mn['x']) * .08
    pad_z = (mx['z'] - mn['z']) * .08
    return bounds(mn['x'] + pad_x, sy - .01, mn['z'] + pad_z, mx['x'] - pad_x, sy + .01, mx['z'] - pad_z)


def _small_region(center, radius=.09):
    x, y, z = center
    return bounds(x-radius, y-radius, z-radius, x+radius, y+radius, z+radius)


def _entity(entity_id: str, label: str, semantic_role: str, extra_tags=None, asset_resolution=None):
    spec = ROLE_SPECS.get(semantic_role, ROLE_SPECS['generic_object'])
    pos = ROLE_POSITIONS.get(semantic_role, ROLE_POSITIONS['generic_object'])
    size = spec['size']
    b = _bnd_from_center(pos, size)
    tags = set(spec.get('tags', [])) | set(extra_tags or [])
    kind = spec['kind']
    support = []
    if 'support_surface' in tags:
        if semantic_role == 'support_fixture':
            support = [_support_plane(b, pos[1] + .26)]
        else:
            support = [_support_plane(b)]
    graspable = bool({'graspable', 'portable'} & tags)
    grasp = [_small_region(pos, min(.10, max(.045, min(size)*.3)))] if graspable else []
    insertion = []
    if 'container' in tags or 'item_receiver' in tags:
        insertion = [_small_region((pos[0], pos[1] + size[1]*.20, pos[2]), min(.15, max(.08, min(size)*.35)))]
    selected = (asset_resolution or {}).get('selected') or {}
    constructor = selected.get('assetId') if (asset_resolution or {}).get('status') == 'ASSET_SELECTED' else None
    return {
        'id': entity_id,
        'kind': kind,
        'label': label,
        'assetId': selected.get('assetId') if selected else None,
        'constructor': constructor,
        'transform': {'position': vec(*pos), 'rotation': vec(), 'scale': vec(1,1,1)},
        'spatial': {
            'bounds': b,
            'supportPlanes': support,
            'collisionVolumes': [b] if kind in {'rigid_object','articulated_object','environment_structure'} else [],
            'walkableRegions': [],
            'walkObstacle': kind in {'environment_structure','articulated_object'},
            'cameraVisibility': True,
            'occlusionMask': None,
            'depthOrder': 1,
        },
        'interaction': {
            'graspRegions': grasp,
            'handRequirement': 'either' if graspable else 'none',
            'insertionSockets': insertion,
            'hinge': None,
            'slider': None,
            'attachmentPoints': [],
            'states': ['idle'],
            'ownership': None,
            'reachableRegions': grasp,
        },
        'visual': {
            'drawableContour': True,
            'fillAreas': [],
            'semanticParts': [label],
            'strokeGroups': ['outline','detail'],
            'drawingOrderDependencies': [],
            'importance': .95 if semantic_role in {'primary_actor','target_item','support_fixture'} else .68,
        },
        'semanticTags': sorted(tags | {semantic_role}),
    }


def _asset_candidate_score(label: str, role: str, hit: dict) -> dict:
    aid = str(hit.get('assetId',''))
    label_n = _slug(label)
    exact = _slug(aid) == label_n
    semantic = 1.0 if exact else .58
    traits = set(hit.get('semanticTraits', []))
    required = {
        'support_fixture': {'support_surface','storage','environment_structure'},
        'target_item': {'graspable','portable'},
        'carry_container': {'container','portable'},
        'transaction_station': {'transaction_station'},
        'service_staff': {'actor'},
    }.get(role, set())
    action_compat = 1.0 if not required else min(1.0, .45 + .18 * len(required & traits))
    if hit.get('promoted') and not exact:
        semantic = max(semantic, .68)
    return {
        'assetId': aid,
        'semanticRelevance': semantic,
        'actionCompatibility': action_compat,
        'environmentCompatibility': .92,
        'cameraCompatibility': .92,
        'assetCleanliness': 1.0,
        'confidence': semantic,
        'embeddedText': False,
        'bakedPropContamination': False,
        'poseCompatible': True,
        'styleCompatible': True,
        'sourceCandidate': hit,
    }


def resolve_asset_for(label: str, role: str) -> dict:
    hits = resolve_assets(label)
    candidates = [_asset_candidate_score(label, role, h) for h in hits]
    decision = select_asset(candidates, threshold=.78)
    decision['queryLabel'] = label
    decision['semanticRole'] = role
    decision['candidates'] = candidates
    if decision.get('selected'):
        decision['selected'] = decision['selected'].get('sourceCandidate', decision['selected'])
    return decision


def _add_rel(rels, kind, subject, obj):
    if not subject or not obj or subject == obj:
        return
    key = (kind, subject, obj)
    if key not in {(r['type'], r['subject'], r['object']) for r in rels}:
        rels.append({'type': kind, 'subject': subject, 'object': obj})


def _environment_resolution(profile: dict | None, cue: str | None, entities: list[dict], action: str | None):
    env_id = profile['environmentId'] if profile else _slug(cue or 'everyday')
    requirements = {
        'environmentId': env_id if profile else None,
        'environmentType': env_id,
        'semanticTags': (profile or {}).get('semanticTraits', []),
        'action': action,
        'spatialRequirements': (profile or {}).get('spatialProfile', {}),
    }
    return resolve_environment(requirements, entities, path=ENV_PROFILE_PATH)


def _activity_compile(payload: dict, world: dict) -> dict:
    uac = CAP_ROOT / 'runtime/universal-activity-compiler.js'
    js = "const u=require(process.argv[1]); const p=JSON.parse(process.argv[2]); const w=JSON.parse(process.argv[3]); console.log(JSON.stringify(u.compile(p,{world:w})));"
    p = subprocess.run(['node','-e',js,str(uac),json.dumps(payload,separators=(',',':')),json.dumps(world,separators=(',',':'))], capture_output=True, text=True, check=True)
    return json.loads(p.stdout)


def _distance_xz(a, b):
    return math.hypot(float(a['x'])-float(b['x']), float(a['z'])-float(b['z']))


def _stance_for(target_id: str, world: dict, affordances: list[dict], current='stand') -> dict:
    socket = next((s for s in world.get('interactionSockets',[]) if s['entityId']==target_id), None)
    reach = next((r for r in world.get('reachability',[]) if socket and r['socketId']==socket['socketId']), None)
    aff = next((a for a in affordances if a['entityId']==target_id), {})
    if not socket:
        return {'schema':'NexStanceDecisionV1','selected':'stand','feasible':True,'reason':'NO_PHYSICAL_SOCKET'}
    target = socket['position']
    # Reach fitness is evaluated from the WorldProjection staging point, not the actor's
    # pre-approach scene origin. This preserves the planner contract: locomotion/restaging
    # happens before the stance decision for the actual manipulation.
    origin = (reach or {}).get('stagingPosition') or world.get('actorStartZones',[{'position':{'x':0,'y':0,'z':0}}])[0]['position']
    distance = _distance_xz(origin, target)
    return select_stance(
        target_height=float(target['y']),
        reach_distance=min(distance, 1.2),
        load_class=aff.get('massClass','light'),
        required_hands=aff.get('requiredHands','either'),
        current=current,
        allow_kneel=False,
        clearance=1.0,
    )


def _find_id(entities, label):
    n = _slug(label or '')
    for e in entities:
        if _slug(e['label']) == n:
            return e['id']
    return None


def _environment_defaults(profile: dict | None):
    return (profile or {}).get('defaultCast', []), (profile or {}).get('defaultProps', [])


def compose_story(text: str, scene_id: str='story-scene-001') -> dict:
    parsed = parse_story(text)
    profile = _profile_for(parsed.get('environmentCue'))
    primary_action = next((a for a in parsed['actions'] if a['action'] != 'navigate'), parsed['actions'][0] if parsed['actions'] else None)
    action_name = primary_action['action'] if primary_action else None
    cast_defaults, prop_defaults = _environment_defaults(profile)

    asset_decisions = {}
    entities = []
    actor_label = parsed['actorLabel']
    asset_decisions[f'person:{actor_label}'] = resolve_asset_for(actor_label, 'primary_actor')
    actor = _entity('actor_0', actor_label, 'primary_actor', ['primary_actor'], asset_decisions[f'person:{actor_label}'])
    entities.append(actor)

    for i, rec in enumerate(cast_defaults, 1):
        label = rec['label']
        role = rec.get('semanticRole','service_staff')
        asset_decisions[f'cast:{label}'] = resolve_asset_for(label, role)
        entities.append(_entity(f'cast_{i}', label, role, rec.get('semanticTags',[]), asset_decisions[f'cast:{label}']))

    parsed_roles = {}
    for a in parsed['actions']:
        for key, rr in [('sourceLabel','source'),('targetLabel','target'),('destinationLabel','destination')]:
            label = a.get(key)
            if not label or (key=='destinationLabel' and a['action']=='navigate'):
                continue
            parsed_roles.setdefault(_slug(label), (label, _role_for_parsed(label, rr)))

    for rec in prop_defaults:
        label, role = rec['label'], rec.get('semanticRole','generic_object')
        parsed_roles.setdefault(_slug(label), (label, role))

    for i, (_, (label, role)) in enumerate(sorted(parsed_roles.items()), 1):
        extra = []
        default = next((r for r in prop_defaults if _slug(r.get('label',''))==_slug(label)), None)
        if default:
            role = default.get('semanticRole', role)
            extra = default.get('semanticTags', [])
        asset_decisions[f'prop:{label}'] = resolve_asset_for(label, role)
        entities.append(_entity(f'prop_{i}', label, role, extra, asset_decisions[f'prop:{label}']))

    env_res = _environment_resolution(profile, parsed.get('environmentCue'), entities, action_name)
    env_id = env_res.get('environmentType') or (profile or {}).get('environmentId') or _slug(parsed.get('environmentCue') or 'everyday')
    dims = ((profile or {}).get('spatialProfile') or {}).get('dimensions', {'x':7.0,'y':3.2,'z':5.0})
    rels = []

    target_id = _find_id(entities, primary_action.get('targetLabel') if primary_action else None)
    source_id = _find_id(entities, primary_action.get('sourceLabel') if primary_action else None)
    explicit_dest_id = _find_id(entities, primary_action.get('destinationLabel') if primary_action and primary_action['action']!='navigate' else None)

    if source_id and target_id:
        _add_rel(rels, 'on', target_id, source_id)
        _add_rel(rels, 'beside', actor['id'], source_id)
    if target_id:
        _add_rel(rels, 'looking-at', actor['id'], target_id)
    if primary_action and primary_action['action']=='place' and target_id and not source_id:
        _add_rel(rels, 'held-by', target_id, actor['id'])

    inferred_dest = None
    if primary_action and primary_action['action']=='pickup' and not explicit_dest_id:
        eligible = [r for r in prop_defaults if r.get('acceptsTransferredItems') and 'pickup' in r.get('afterActions', [])]
        if eligible:
            inferred_dest = _find_id(entities, eligible[0]['label'])
    destination_id = explicit_dest_id or inferred_dest
    if destination_id:
        _add_rel(rels, 'beside', destination_id, actor['id'])

    scene = {
        'schema':'NexSceneSpecV1',
        'sceneId':scene_id,
        'scene': {
            'environmentType': env_id,
            'dimensions': vec(dims['x'], dims['y'], dims['z']),
            'cameraSpace': {'position':vec(0,2.9,7.4),'target':vec(0,.9,0),'fov':43},
            'worldCoordinateSystem':'Y_UP_RIGHT_HANDED',
            'perspectiveMode':'perspective',
            'styleFamily':'whiteboard-clean-line',
            'aspectRatio':'16:9',
        },
        'entities': entities,
        'relationships': rels,
        'metadata': {
            'sourceText': text,
            'parsedStory': parsed,
            'environmentResolution': env_res,
            'assetPolicy': 'PHASE0A_FAIL_CLOSED_FITNESS_GATE',
            'storyComposer': 'NexStorySceneComposerLayer1V1',
        },
    }
    validate_scene(scene)
    world = project_world(scene)
    affordances = compile_scene_affordances(scene)

    compiled = []
    semantic_actions = []
    stance_plans = []
    if primary_action and target_id:
        if primary_action['action'] == 'place' and destination_id:
            # For placement, the manipulated item is the tool and the receiver/support is
            # the physical target. This matches UniversalActivityCompiler's transfer contract.
            insertion = next((s for s in world.get('interactionSockets',[]) if s['entityId']==destination_id and s['kind']=='insertion'), None)
            socket = insertion or next((s for s in world.get('interactionSockets',[]) if s['entityId']==destination_id), None)
            cp = _activity_compile({'action':'place','targetId':destination_id,'toolId':target_id,'socketId':socket['socketId'] if socket else None,'destinationId':destination_id,'intentText':primary_action['clause']}, world)
            compiled.append(cp)
            stance_plans.append({'action':'place','targetId':destination_id,'decision':_stance_for(destination_id,world,affordances)})
            semantic_actions.append({'operation':'PLACE','itemId':target_id,'itemLabel':next(e['label'] for e in entities if e['id']==target_id),'destinationId':destination_id,'destinationLabel':next(e['label'] for e in entities if e['id']==destination_id)})
        else:
            socket = next((s for s in world.get('interactionSockets',[]) if s['entityId']==target_id and s['kind']=='grip_center'), None)
            act_payload = {'action':primary_action['action'],'targetId':target_id,'socketId':socket['socketId'] if socket else None,'intentText':primary_action['clause']}
            cp = _activity_compile(act_payload, world)
            compiled.append(cp)
            stance_plans.append({'action':primary_action['action'],'targetId':target_id,'decision':_stance_for(target_id,world,affordances)})
            if primary_action['action']=='pickup':
                semantic_actions.extend([
                    {'operation':'APPROACH','targetId':target_id,'targetLabel':primary_action.get('targetLabel')},
                    {'operation':'REACH','targetId':target_id,'targetLabel':primary_action.get('targetLabel')},
                    {'operation':'CONTACT','targetId':target_id,'targetLabel':primary_action.get('targetLabel')},
                    {'operation':'PICKUP','targetId':target_id,'targetLabel':primary_action.get('targetLabel')},
                ])
            else:
                semantic_actions.append({'operation':primary_action['action'].upper(),'targetId':target_id,'targetLabel':primary_action.get('targetLabel')})

    if destination_id and target_id and primary_action and primary_action['action']=='pickup':
        insertion = next((s for s in world.get('interactionSockets',[]) if s['entityId']==destination_id and s['kind']=='insertion'), None)
        if insertion:
            cp = _activity_compile({'action':'place','targetId':destination_id,'toolId':target_id,'socketId':insertion['socketId'],'destinationId':destination_id,'intentText':'place transferred item into receiver'}, world)
            compiled.append(cp)
            stance_plans.append({'action':'place','targetId':destination_id,'decision':_stance_for(destination_id,world,affordances,current='stand')})
        semantic_actions.append({'operation':'PLACE','itemId':target_id,'itemLabel':next(e['label'] for e in entities if e['id']==target_id),'destinationId':destination_id,'destinationLabel':next(e['label'] for e in entities if e['id']==destination_id)})

    camera_context = ((profile or {}).get('spatialProfile') or {}).get('cameraContext')
    camera = [
        {'shot':'medium '+(camera_context+' shot' if camera_context else 'spatial action shot'),'purpose':'establish blocking and approach'},
    ]
    if any(x['operation']=='CONTACT' for x in semantic_actions):
        camera.append({'shot':'hand insert','purpose':'prove reach/contact/pickup state change'})

    continuity = []
    if target_id:
        target_label = next(e['label'] for e in entities if e['id']==target_id)
        chain = []
        if source_id:
            chain.append({'state':'supported','holderId':source_id,'holderLabel':next(e['label'] for e in entities if e['id']==source_id)})
        chain.append({'state':'held','holderId':actor['id'],'holderLabel':actor_label})
        if destination_id:
            chain.append({'state':'contained_or_supported','holderId':destination_id,'holderLabel':next(e['label'] for e in entities if e['id']==destination_id)})
        continuity.append({'entityId':target_id,'entityLabel':target_label,'ownershipChain':chain})

    blocking = []
    if source_id:
        blocking.append({'subjectId':actor['id'],'relation':'beside','objectId':source_id})
    if destination_id:
        blocking.append({'subjectId':destination_id,'relation':'near','objectId':actor['id']})
    if source_id and target_id:
        blocking.append({'subjectId':target_id,'relation':'supported_by','objectId':source_id})

    return {
        'schema':'NexStorySceneCompositionV1',
        'composerVersion':'Layer1V1',
        'sourceText':text,
        'scene': {'environment':env_id,'environmentMode':env_res.get('mode')},
        'cast':[{'id':e['id'],'label':e['label'],'semanticTags':e.get('semanticTags',[])} for e in entities if e['kind']=='person'],
        'props':[{'id':e['id'],'label':e['label'],'semanticRole':next((t for t in e.get('semanticTags',[]) if t in ROLE_SPECS),None),'assetStatus':asset_decisions.get('prop:'+e['label'],{}).get('status')} for e in entities if e['kind']!='person'],
        'blocking':blocking,
        'actions':semantic_actions,
        'camera':camera,
        'continuity':continuity,
        'assetResolution':asset_decisions,
        'environmentResolution':env_res,
        'stancePlans':stance_plans,
        'compiledActivities':compiled,
        'nexSceneSpec':scene,
        'worldProjection':world,
        'objectAffordances':affordances,
        'integrity': {
            'sceneHash':scene_hash(scene),
            'uses': ['NexSceneSpec','WorldProjection','EnvironmentLibrary','ObjectAffordance','UniversalActivityCompiler','StancePlanner','AssetResolver'],
            'scenarioSpecificBranches': False,
            'assetFallbackPolicy':'NO_SUITABLE_ASSET_OR_SEMANTIC_CONSTRUCTION',
        }
    }


def main():
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('text')
    ap.add_argument('--scene-id',default='story-scene-001')
    ap.add_argument('--out')
    ns=ap.parse_args()
    out=compose_story(ns.text,ns.scene_id)
    data=json.dumps(out,indent=2,ensure_ascii=False)
    if ns.out:
        Path(ns.out).write_text(data+'\n')
    print(data)

if __name__=='__main__':
    main()
