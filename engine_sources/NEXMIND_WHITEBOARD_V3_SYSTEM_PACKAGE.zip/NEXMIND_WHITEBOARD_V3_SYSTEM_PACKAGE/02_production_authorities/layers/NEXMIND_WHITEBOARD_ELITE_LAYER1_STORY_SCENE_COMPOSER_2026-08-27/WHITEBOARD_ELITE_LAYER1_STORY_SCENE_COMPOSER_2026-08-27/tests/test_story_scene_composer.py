from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from story_scene_composer import compose_story, parse_story


def test_requested_story_contract():
    out=compose_story('Ada walks into the shop and takes bread from the shelf.')
    assert out['scene']['environment']=='retail_store'
    assert [x['label'] for x in out['cast']][:2]==['Ada','cashier']
    labels={x['label'] for x in out['props']}
    assert {'basket','bread','shelf','products','checkout'} <= labels
    ops=[x['operation'] for x in out['actions']]
    assert ops==['APPROACH','REACH','CONTACT','PICKUP','PLACE']
    assert out['continuity'][0]['ownershipChain'][0]['holderLabel']=='shelf'
    assert out['continuity'][0]['ownershipChain'][1]['holderLabel']=='Ada'
    assert out['continuity'][0]['ownershipChain'][2]['holderLabel']=='basket'
    assert out['camera'][0]['shot']=='medium aisle shot'
    assert out['camera'][1]['shot']=='hand insert'
    assert out['integrity']['scenarioSpecificBranches'] is False


def test_generic_unseen_scene_has_same_grammar_without_retail_defaults():
    out=compose_story('Leo walks into the studio and takes camera from the table.')
    assert out['scene']['environment']=='studio'
    assert [x['label'] for x in out['cast']]==['Leo']
    labels={x['label'] for x in out['props']}
    assert {'camera','table'} <= labels
    assert 'basket' not in labels and 'checkout' not in labels
    assert [x['operation'] for x in out['actions']][:4]==['APPROACH','REACH','CONTACT','PICKUP']
    assert out['integrity']['scenarioSpecificBranches'] is False


def test_parser_is_action_relation_driven():
    p=parse_story('Mina walks into the room and takes parcel from the counter.')
    assert p['environmentCue']=='room'
    act=next(x for x in p['actions'] if x['action']=='pickup')
    assert act['targetLabel']=='parcel'
    assert act['sourceLabel']=='counter'


def test_asset_resolution_fails_closed_for_unknown_target():
    out=compose_story('Ada walks into the shop and takes bread from the shelf.')
    assert out['assetResolution']['prop:bread']['status']=='NO_SUITABLE_ASSET'
    assert out['assetResolution']['prop:shelf']['status']=='NO_SUITABLE_ASSET'


def test_existing_systems_are_exercised():
    out=compose_story('Ada walks into the shop and takes bread from the shelf.')
    assert out['nexSceneSpec']['schema']=='NexSceneSpecV1'
    assert out['worldProjection']['schema']=='NexWorldProjectionV1'
    assert out['objectAffordances']
    assert all('execution' in x for x in out['compiledActivities'])
    assert out['stancePlans']


def test_explicit_place_uses_receiver_as_physical_target():
    out=compose_story('Nia walks into the studio and places parcel into box.')
    assert [x['operation'] for x in out['actions']]==['PLACE']
    assert out['actions'][0]['itemLabel']=='parcel'
    assert out['actions'][0]['destinationLabel']=='box'
    assert out['compiledActivities'][0]['execution']=='PHYSICAL_PLAN'
    assert out['compiledActivities'][0]['activity']['targetId']==out['actions'][0]['destinationId']
    assert out['compiledActivities'][0]['activity']['toolId']==out['actions'][0]['itemId']
