from __future__ import annotations

import json
import re
from pathlib import Path

from environment_composer import compose_environment, ground_story_environment, normalize_environment_id
from environment_composer_renderer import render_composition_svg

ROOT = Path(__file__).resolve().parents[1]
CATALOG = json.loads((ROOT / 'environment_archetypes.json').read_text())
KNOWN = [x['environmentId'] for x in CATALOG['knownEnvironments']]
PRIMITIVES = list(CATALOG['primitiveCatalog'])


def _geometry_signature(comp):
    return [
        (
            c['primitive'], c['role'],
            tuple(round(c['position'][k], 5) for k in ('x','y','z')),
            tuple(round(c['size'][k], 5) for k in ('x','y','z')),
            tuple(sorted(c['semanticTags'])),
        )
        for c in comp['components']
    ]


def test_all_declared_archetypes_compile_through_one_engine():
    assert len(KNOWN) >= 13
    for env in KNOWN:
        comp = compose_environment(env)
        assert comp['environmentId'] == env
        assert comp['constructionMode'] == 'DECLARATIVE_ARCHETYPE'
        assert comp['componentCount'] >= 5
        assert comp['worldProjection']['worldChecks']['pathExists'] is True
        assert len(comp['shotProjection']['components']) == comp['componentCount']


def test_profile_data_is_declarative_not_executable_dispatch():
    for row in CATALOG['knownEnvironments']:
        assert 'builder' not in row
        assert 'function' not in row
        assert all(x.get('layout',{}).get('mode') == 'instances' for x in row.get('components',[]))
        for x in row.get('components',[]):
            assert x['primitive'] in PRIMITIVES


def test_named_examples_exist_as_geometry_not_text_substitutes():
    comp = compose_environment('retail_store')
    roles = {c['role'] for c in comp['components']}
    assert {'aisle_geometry','shelf_bank','product_row','checkout_zone','counter','register','entrance','signage_zone'} <= roles
    shelves = [c for c in comp['components'] if c['role'] == 'shelf_bank']
    products = [c for c in comp['components'] if c['role'] == 'product_row']
    assert len(shelves) >= 4
    assert len(products) >= len(shelves) * 3
    assert all(c['drawSpec']['bakedTextAllowed'] is False for c in comp['components'])
    assert all(c['drawSpec']['semanticGeometryOnly'] is True for c in comp['components'])


def test_unseen_environment_uses_only_requested_general_primitives():
    requested = ['wall','opening','surface','storage','seat','work_surface','path','container','fixture','signage','equipment']
    comp = compose_environment('planetary_archive', requested_primitives=requested)
    assert comp['constructionMode'] == 'GENERIC_PRIMITIVE_SYNTHESIS'
    observed = {c['primitive'] for c in comp['components'] if c['source'] == 'primitive_synthesis'}
    assert set(requested) <= observed
    assert comp['worldProjection']['worldChecks']['pathExists'] is True


def test_unseen_noun_does_not_change_geometry_when_requirements_are_same():
    requested = ['opening','path','surface','storage','seat','work_surface','fixture','signage','equipment']
    names = ['planetary_archive','underwater_gallery','desert_monastery','orbital_habitat','unknown_place_77']
    comps = [compose_environment(name, requested_primitives=requested) for name in names]
    base = _geometry_signature(comps[0])
    assert all(_geometry_signature(c) == base for c in comps[1:])


def test_many_unseen_primitive_combinations_compile_and_remain_walkable():
    combos = [
        ['path'], ['opening','path'], ['path','storage'], ['path','work_surface','seat'],
        ['opening','path','container'], ['path','fixture','equipment'], ['path','surface','signage'],
        ['wall','opening','path','storage'], ['path','surface','storage','seat','equipment'],
    ]
    for i, primitives in enumerate(combos):
        comp = compose_environment(f'unseen_{i}', requested_primitives=primitives)
        assert comp['constructionMode'] == 'GENERIC_PRIMITIVE_SYNTHESIS'
        assert comp['worldProjection']['worldChecks']['pathExists'] is True
        assert not any(c.get('assetId') for c in comp['components'])


def test_story_grounding_uses_semantic_capability_binding():
    grounded = ground_story_environment('Ada walks into the shop and takes bread from the shelf.')
    placements = {p['label']: p for p in grounded['entityPlacements']}
    assert grounded['integrationNotes']['storyNounDispatch'] is False
    assert placements['Ada']['binding'] == 'ACTOR_PATH'
    assert placements['bread']['binding'] == 'SUPPORTED_BY_ENVIRONMENT_COMPONENT'
    assert placements['shelf']['binding'] == 'ENVIRONMENT_COMPONENT'
    assert placements['bread']['componentId'] == placements['shelf']['componentId']


def test_unseen_story_gets_semantically_required_primitive_set():
    grounded = ground_story_environment('Mira walks into the observatory and places a notebook on the console.')
    comp = grounded['environmentComposition']
    assert comp['constructionMode'] == 'GENERIC_PRIMITIVE_SYNTHESIS'
    assert {'opening','path','container','work_surface'} <= set(grounded['primitiveNeeds'])
    assert grounded['integrationNotes']['storyNounDispatch'] is False
    assert any(p['semanticRole'] == 'generic_destination' and p['binding'] == 'ENVIRONMENT_COMPONENT' for p in grounded['entityPlacements'])


def test_shot_projection_is_generated_from_world_components():
    comp = compose_environment('classroom')
    ids = {c['id'] for c in comp['components']}
    projected = comp['shotProjection']['components']
    assert {x['componentId'] for x in projected} == ids
    assert all(0 <= x['screenBounds']['min']['x'] <= 1.5 for x in projected)
    assert all(-.5 <= x['screenBounds']['max']['y'] <= 1.5 for x in projected)


def test_renderer_contains_geometry_and_zero_text_elements(tmp_path):
    comp = compose_environment('warehouse')
    svg_path = tmp_path / 'set.svg'
    render_composition_svg(comp, str(svg_path))
    text = svg_path.read_text().lower()
    assert '<line' in text or '<polyline' in text
    assert '<text' not in text


def test_executable_sources_have_no_named_environment_or_benchmark_dispatch():
    forbidden = [
        'retail_store','shop','store','grocery','bread','ada','school','classroom','kitchen','hospital',
        'home','office','workshop','street','restaurant','warehouse','bedroom','transit_stop','cashier','shelf','checkout'
    ]
    for path in [ROOT/'environment_composer.py', ROOT/'environment_composer_renderer.py']:
        text = path.read_text().lower()
        for term in forbidden:
            assert not re.search(r'(?<![a-z0-9_])'+re.escape(term)+r'(?![a-z0-9_])', text), (path.name, term)


def test_aliases_are_data_driven():
    assert normalize_environment_id('shop') == 'retail_store'
    assert normalize_environment_id('bus stop') == 'transit_stop'
    assert normalize_environment_id('lecture room') == 'classroom'
