# Layer 3 — Environment Composer

## Decision
**PASS — generalized structural set construction.**

Layer 3 now converts an environment concept into a drawable, spatially grounded set before Whiteboard rendering. The implementation no longer contains one Python builder per environment. The executable composer and renderer contain **zero named-environment or benchmark-story dispatch terms** from the certification scan.

## Architecture

`Story Scene Composer → Environment concept / semantic requirements → declarative archetype or generic primitive synthesis → 3D component world → NexSceneSpec → WorldProjection → Whiteboard shot projection`

Known environments are represented only as **declarative data profiles** in `environment_archetypes.json`. They describe spatial priors using the same primitive vocabulary used for unseen environments. Adding or changing a known environment does not require adding a new Python function.

The primitive vocabulary is:

`wall, opening, surface, storage, seat, work_surface, path, container, fixture, signage, equipment`

Every component receives a real 3D center, size, bounds, semantic tags and generic anchors such as `actor_path`, `support_surface`, `entry`, `container_receiver`, `sit`, `use` or `staff`.

## Story grounding

Layer 3 does not search for labels like shelf, cashier or checkout. Story props bind to environment components by semantic capabilities. A support fixture selects a suitable `support_surface`/`storage` component; a service actor selects a `service_station`; portable containers remain actor-near props. The target item follows the Story Scene Composer's `supported_by` relation to the selected support component.

## Unseen environments

For unseen environments, the environment name is not a geometry key. Primitive requirements drive construction. Five unrelated unseen names given identical requirements produced the **same geometry signature**, while varied primitive combinations also remained walkable.

## Drawable proof

The proof renderer consumes only primitive type + geometry parameters and outputs line geometry. It contains no environment-specific renderer branches and emits no `<text>` elements in set renders. The retail proof contains actual shelf frames and repeated product-row geometry rather than a rectangle labeled “SHELF”.

## QA

- Layer 3: **12/12 PASS**
- Layer 1 + Layer 2 regression: **15/15 PASS**
- Visual Construction regression: **57/57 PASS**
- Environment matrix: **13 declared + 8 unseen PASS**
- Executable anti-hardcoding scan: **PASS**
- Unseen-name invariance: **PASS**
- Frozen canonical runtime: **1863 files**, SHA-256 `16f83da6f58d31fa977e59bd7f76c608a6b7dc9c859d602f5587cc196bd1b235` — exact match

## Scope boundary

This layer certifies **environment semantics, set construction, world positions, pathability and Whiteboard projection contracts**. The included renders are structural visual proofs, not a claim that final art direction, illustration richness, camera staging or compositing is already at the final 9/10 Whiteboard release bar.
