from __future__ import annotations

import json
import math
import re
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

# This overlay must never dirty the frozen canonical runtime with __pycache__ files.
sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parent
ARCH_PATH = ROOT / 'environment_archetypes.json'
LAYER1 = Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER1_STORY_SCENE_COMPOSER_2026-08-27')
CANONICAL = Path('/mnt/data/nexmind-runtime/current').resolve()
VC_ROOT = CANONICAL / 'VC_RUNTIME'
if str(VC_ROOT) not in sys.path:
    sys.path.insert(0, str(VC_ROOT))

from src.scene_spec import validate_scene, scene_hash
from src.world_projection import project_world


def vec(x: float = 0.0, y: float = 0.0, z: float = 0.0) -> Dict[str, float]:
    return {'x': float(x), 'y': float(y), 'z': float(z)}


def size3(x: float = 0.0, y: float = 0.0, z: float = 0.0) -> Dict[str, float]:
    return {'x': float(x), 'y': float(y), 'z': float(z)}


def _slug(value: str) -> str:
    return re.sub(r'[^a-z0-9]+', '_', str(value).lower()).strip('_') or 'environment'


def _load_catalog() -> Dict[str, Any]:
    return json.loads(ARCH_PATH.read_text())


def _aliases_and_profiles() -> Tuple[Dict[str, str], Dict[str, Dict[str, Any]]]:
    aliases: Dict[str, str] = {}
    profiles: Dict[str, Dict[str, Any]] = {}
    for row in _load_catalog().get('knownEnvironments', []):
        env_id = _slug(row['environmentId'])
        profiles[env_id] = row
        aliases[env_id] = env_id
        aliases[_slug(env_id.replace('_', ' '))] = env_id
        for alias in row.get('aliases', []):
            aliases[_slug(alias)] = env_id
    return aliases, profiles


def normalize_environment_id(value: str) -> str:
    aliases, _ = _aliases_and_profiles()
    norm = _slug(value)
    return aliases.get(norm, norm)


def _bounds(position: Dict[str, float], size: Dict[str, float]) -> Dict[str, Dict[str, float]]:
    return {
        'min': vec(position['x'] - size['x'] / 2, position['y'] - size['y'] / 2, position['z'] - size['z'] / 2),
        'max': vec(position['x'] + size['x'] / 2, position['y'] + size['y'] / 2, position['z'] + size['z'] / 2),
    }


def _center(bounds: Dict[str, Any]) -> Dict[str, float]:
    mn, mx = bounds['min'], bounds['max']
    return vec((mn['x'] + mx['x']) / 2, (mn['y'] + mx['y']) / 2, (mn['z'] + mx['z']) / 2)


def _normalized_to_world(p: Iterable[float], s: Iterable[float], dims: Dict[str, float]) -> Tuple[Dict[str, float], Dict[str, float]]:
    px, py, pz = [float(v) for v in p]
    sx, sy, sz = [max(0.002, float(v)) for v in s]
    pos = vec(px * dims['x'], py * dims['y'], pz * dims['z'])
    size = size3(sx * dims['x'], sy * dims['y'], sz * dims['z'])
    return pos, size


def _support_plane(bounds: Dict[str, Any]) -> Dict[str, Any]:
    mn, mx = bounds['min'], bounds['max']
    padx = max(0.01, (mx['x'] - mn['x']) * .06)
    padz = max(0.01, (mx['z'] - mn['z']) * .06)
    return {
        'min': vec(mn['x'] + padx, mx['y'] - .012, mn['z'] + padz),
        'max': vec(mx['x'] - padx, mx['y'] + .012, mx['z'] - padz),
    }


def _anchor(anchor_id: str, role: str, position: Dict[str, float], component_id: str) -> Dict[str, Any]:
    return {'id': anchor_id, 'role': role, 'position': deepcopy(position), 'targetComponentId': component_id}


def _anchors_for(component_id: str, primitive: str, tags: Iterable[str], bounds: Dict[str, Any]) -> List[Dict[str, Any]]:
    tags = set(tags)
    c = _center(bounds)
    mn, mx = bounds['min'], bounds['max']
    out: List[Dict[str, Any]] = []
    if primitive == 'path' or 'walkable' in tags or 'actor_path' in tags:
        out.append(_anchor(f'{component_id}:actor', 'actor_path', vec(c['x'], 0.0, c['z']), component_id))
    if primitive == 'opening' or 'entry' in tags:
        out.append(_anchor(f'{component_id}:entry', 'entry', vec(c['x'], 0.0, c['z']), component_id))
    if primitive in {'surface', 'work_surface', 'storage', 'container'} or 'support_surface' in tags:
        out.append(_anchor(f'{component_id}:support', 'support_surface', vec(c['x'], mx['y'], c['z']), component_id))
        out.append(_anchor(f'{component_id}:approach', 'approach', vec(c['x'], 0.0, mx['z'] + .45), component_id))
    if primitive == 'container' or 'container_receiver' in tags:
        out.append(_anchor(f'{component_id}:insertion', 'container_receiver', vec(c['x'], mx['y'] + .05, c['z']), component_id))
    if primitive == 'seat' or 'seat' in tags:
        out.append(_anchor(f'{component_id}:sit', 'sit', vec(c['x'], mn['y'] + (mx['y'] - mn['y']) * .52, c['z']), component_id))
    if primitive in {'equipment', 'fixture'}:
        out.append(_anchor(f'{component_id}:use', 'use', vec(c['x'], min(mx['y'], mn['y'] + .9), mx['z']), component_id))
    if 'service_station' in tags:
        out.append(_anchor(f'{component_id}:staff', 'staff', vec(c['x'], 0.0, c['z'] - .45), component_id))
    return out


def _component(component_id: str, role: str, primitive: str, position: Dict[str, float], size: Dict[str, float], *,
               tags: Optional[Iterable[str]] = None, geometry: Optional[Dict[str, Any]] = None,
               walk_obstacle: Optional[bool] = None, zone: bool = False, source: str = 'recipe') -> Dict[str, Any]:
    catalog = _load_catalog().get('primitiveCatalog', {})
    primitive_spec = catalog.get(primitive, {})
    sem_tags = sorted(set([primitive, role] + [str(x) for x in (tags or [])]))
    obstacle = primitive_spec.get('walkObstacle', True) if walk_obstacle is None else bool(walk_obstacle)
    bounds = _bounds(position, size)
    return {
        'id': component_id,
        'role': role,
        'primitive': primitive,
        'position': position,
        'size': size,
        'bounds': bounds,
        'walkObstacle': obstacle,
        'zone': bool(zone),
        'semanticTags': sem_tags,
        'anchors': _anchors_for(component_id, primitive, sem_tags, bounds),
        'geometry': deepcopy(geometry or {}),
        'drawSpec': {
            'family': primitive_spec.get('drawFamily', primitive),
            'semanticGeometryOnly': True,
            'bakedTextAllowed': False,
            'wholeIllustrationStructuralAuthority': False,
        },
        'source': source,
    }


def _shell(topology: str, dims: Dict[str, float]) -> List[Dict[str, Any]]:
    topology = str(topology or 'interior').lower()
    if topology == 'exterior':
        return [_component('shell:ground', 'ground', 'path', vec(0, .02, 0), size3(dims['x'], .04, dims['z']), tags=['walkable', 'actor_path'], walk_obstacle=False, zone=True, source='topology')]
    t = .10
    return [
        _component('shell:floor', 'floor_base', 'surface', vec(0, .02, 0), size3(dims['x'], .04, dims['z']), tags=['floor', 'walkable'], geometry={'floorPlane': True}, walk_obstacle=False, source='topology'),
        _component('shell:back', 'boundary', 'wall', vec(0, dims['y']/2, -dims['z']/2 + t/2), size3(dims['x'], dims['y'], t), tags=['boundary'], source='topology'),
        _component('shell:left', 'boundary', 'wall', vec(-dims['x']/2 + t/2, dims['y']/2, 0), size3(t, dims['y'], dims['z']), tags=['boundary'], source='topology'),
        _component('shell:right', 'boundary', 'wall', vec(dims['x']/2 - t/2, dims['y']/2, 0), size3(t, dims['y'], dims['z']), tags=['boundary'], source='topology'),
        _component('shell:front_base', 'floor_edge', 'path', vec(0, .015, dims['z']/2 - .03), size3(dims['x'], .03, .06), tags=['floor_edge'], walk_obstacle=False, source='topology'),
    ]


def _compile_children(parent: Dict[str, Any], child_spec: Dict[str, Any]) -> List[Dict[str, Any]]:
    if child_spec.get('pattern') != 'stacked_layers':
        return []
    count = max(1, int(child_spec.get('count', 1)))
    scale = [float(x) for x in child_spec.get('sizeScale', [.8, .08, .8])]
    pb = parent['bounds']
    mn, mx = pb['min'], pb['max']
    h = mx['y'] - mn['y']
    out = []
    for i in range(count):
        frac = (i + 1) / (count + 1)
        pos = vec(parent['position']['x'], mn['y'] + h * frac, parent['position']['z'])
        size = size3(parent['size']['x'] * scale[0], max(.025, parent['size']['y'] * scale[1]), parent['size']['z'] * scale[2])
        cid = f"{parent['id']}:{_slug(child_spec.get('role', 'child'))}:{i+1}"
        out.append(_component(
            cid,
            str(child_spec.get('role', 'child')),
            str(child_spec.get('primitive', 'container')),
            pos,
            size,
            tags=child_spec.get('tags', []),
            geometry=child_spec.get('geometry', {}),
            walk_obstacle=child_spec.get('walkObstacle', False),
            zone=bool(child_spec.get('zone', False)),
            source='recipe_child',
        ))
    return out


def _compile_profile(profile: Dict[str, Any], dims: Dict[str, float]) -> List[Dict[str, Any]]:
    components = _shell(profile.get('topology', 'interior'), dims)
    serial: Dict[str, int] = {}
    for spec in profile.get('components', []):
        role = str(spec['role'])
        primitive = str(spec['primitive'])
        serial.setdefault(role, 0)
        layout = spec.get('layout', {})
        if layout.get('mode') != 'instances':
            raise ValueError(f'UNSUPPORTED_LAYOUT_MODE:{layout.get("mode")}')
        for item in layout.get('items', []):
            serial[role] += 1
            pos, size = _normalized_to_world(item['p'], item['s'], dims)
            cid = f"set:{_slug(role)}:{serial[role]}"
            parent = _component(
                cid, role, primitive, pos, size,
                tags=spec.get('tags', []), geometry=spec.get('geometry', {}),
                walk_obstacle=spec.get('walkObstacle'), zone=bool(spec.get('zone', False)), source='archetype_data',
            )
            components.append(parent)
            if spec.get('children'):
                components.extend(_compile_children(parent, spec['children']))
    return components


def _primitive_bundle(requested: Optional[Iterable[str]]) -> List[str]:
    catalog = _load_catalog().get('primitiveCatalog', {})
    raw = [_slug(x) for x in (requested or [])]
    valid = [x for x in raw if x in catalog]
    if valid:
        return list(dict.fromkeys(valid))
    return ['opening', 'path', 'surface', 'storage', 'seat', 'work_surface', 'fixture', 'signage', 'equipment']


def _synthesized_component_spec(primitive: str, index: int, dims: Dict[str, float]) -> Tuple[Dict[str, float], Dict[str, float], List[str], Dict[str, Any], bool, bool]:
    catalog = _load_catalog()['primitiveCatalog'][primitive]
    default = catalog['defaultSize']
    sx, sy, sz = [float(x) for x in default]
    # Primitive-specific physical placement is part of the generic geometry compiler, not environment-specific logic.
    if primitive == 'path':
        p = [0, .005, .10]; s = [max(.38, sx), .01, max(.34, sz)]; tags = ['walkable', 'actor_path']; geom = {}; obstacle = False; zone = True
    elif primitive == 'opening':
        p = [-.46, sy/2, .33]; s = [sx, sy, sz]; tags = ['entry', 'opening']; geom = {}; obstacle = False; zone = False
    elif primitive == 'signage':
        p = [.12, .72, -.47]; s = [sx, sy, sz]; tags = ['signage']; geom = {'blankPanel': True}; obstacle = False; zone = False
    elif primitive == 'wall':
        p = [.18, .42, -.20]; s = [sx, sy, sz]; tags = ['divider', 'boundary']; geom = {'panel': True}; obstacle = True; zone = False
    else:
        slots = [(-.28,-.24),(.05,-.28),(.30,-.18),(-.30,.12),(0,.18),(.28,.14),(-.10,.32),(.18,.34)]
        x, z = slots[index % len(slots)]
        p = [x, sy/2, z]; s = [sx, sy, sz]
        tags = []
        if primitive in {'surface', 'storage', 'work_surface'}:
            tags.append('support_surface')
        if primitive == 'storage':
            tags.append('storage')
        if primitive == 'container':
            tags.append('container_receiver')
        if primitive == 'seat':
            tags.append('seat')
        if primitive in {'equipment', 'fixture'}:
            tags.append('usable')
        geom = {'levels': 3} if primitive == 'storage' else {'legs': True} if primitive == 'work_surface' else {'back': True} if primitive == 'seat' else {}
        obstacle = bool(catalog.get('walkObstacle', True)); zone = False
    pos, size = _normalized_to_world(p, s, dims)
    return pos, size, tags, geom, obstacle, zone


def _synthesize_unseen(dims: Dict[str, float], topology: str, requested_primitives: Optional[Iterable[str]]) -> List[Dict[str, Any]]:
    components = _shell(topology, dims)
    for i, primitive in enumerate(_primitive_bundle(requested_primitives)):
        pos, size, tags, geom, obstacle, zone = _synthesized_component_spec(primitive, i, dims)
        components.append(_component(f'synth:{primitive}:{i+1}', f'{primitive}_zone', primitive, pos, size, tags=tags, geometry=geom, walk_obstacle=obstacle, zone=zone, source='primitive_synthesis'))
    return components


def _camera_for(dims: Dict[str, float]) -> Dict[str, Any]:
    return {'position': vec(0, max(3.8, dims['y'] + .45), dims['z'] + 4.0), 'target': vec(0, dims['y'] * .25, 0), 'fov': 42.0}


def _component_to_entity(c: Dict[str, Any]) -> Dict[str, Any]:
    primitive = c['primitive']
    b = c['bounds']
    support_planes = [_support_plane(b)] if ('support_surface' in c['semanticTags'] or primitive in {'surface', 'work_surface', 'storage', 'container'}) else []
    walk_regions = [b] if primitive == 'path' or 'walkable' in c['semanticTags'] else []
    kind = 'rigid_object' if primitive in {'equipment', 'container'} else 'environment_structure'
    return {
        'id': c['id'],
        'kind': kind,
        'label': c['role'],
        'assetId': None,
        'constructor': f"primitive:{primitive}",
        'transform': {'position': deepcopy(c['position']), 'rotation': vec(), 'scale': vec(1, 1, 1)},
        'spatial': {
            'bounds': deepcopy(b),
            'supportPlanes': support_planes,
            'collisionVolumes': [deepcopy(b)] if c['walkObstacle'] else [],
            'walkableRegions': walk_regions,
            'walkObstacle': bool(c['walkObstacle']),
            'cameraVisibility': True,
            'occlusionMask': None,
            'depthOrder': 1.0,
        },
        'interaction': {
            'graspRegions': [], 'handRequirement': 'none', 'insertionSockets': [],
            'hinge': None, 'slider': None, 'attachmentPoints': [], 'states': ['static'],
            'ownership': None, 'reachableRegions': [],
        },
        'visual': {
            'drawableContour': True, 'fillAreas': [], 'semanticParts': [primitive],
            'strokeGroups': [primitive], 'drawingOrderDependencies': [],
            'importance': .7 if c.get('zone') else .8,
        },
        'semanticTags': deepcopy(c['semanticTags']),
    }


def _nex_scene_spec(environment_id: str, dims: Dict[str, float], camera: Dict[str, Any], components: List[Dict[str, Any]]) -> Dict[str, Any]:
    scene = {
        'schema': 'NexSceneSpecV1',
        'sceneId': f'environment-{_slug(environment_id)}',
        'scene': {
            'environmentType': environment_id,
            'dimensions': deepcopy(dims),
            'cameraSpace': deepcopy(camera),
            'worldCoordinateSystem': 'Y_UP_RIGHT_HANDED',
            'perspectiveMode': 'perspective',
            'styleFamily': 'whiteboard',
            'aspectRatio': '16:9',
        },
        'entities': [_component_to_entity(c) for c in components],
        'relationships': [],
        'metadata': {'source': 'WhiteboardEnvironmentComposerV2', 'structuralAssetAuthority': False},
    }
    validate_scene(scene)
    return scene


def _project_point(point: Dict[str, float], dims: Dict[str, float]) -> Dict[str, float]:
    # Stable axonometric projection into normalized shot space; renderer consumes the same contract.
    x = point['x'] / max(.001, dims['x'])
    y = point['y'] / max(.001, dims['y'])
    z = point['z'] / max(.001, dims['z'])
    return {'x': round(.50 + x * .72 - z * .34, 6), 'y': round(.86 - y * .68 - z * .22, 6)}


def _shot_projection(components: List[Dict[str, Any]], dims: Dict[str, float]) -> Dict[str, Any]:
    raw_rows = []
    all_points: List[Dict[str, float]] = []
    for c in components:
        b = c['bounds']; mn, mx = b['min'], b['max']
        corners = [
            vec(x, y, z)
            for x in (mn['x'], mx['x'])
            for y in (mn['y'], mx['y'])
            for z in (mn['z'], mx['z'])
        ]
        pts = [_project_point(p, dims) for p in corners]
        center = _project_point(c['position'], dims)
        all_points.extend(pts); all_points.append(center)
        raw_rows.append((c, pts, center))
    xmin = min(p['x'] for p in all_points); xmax = max(p['x'] for p in all_points)
    ymin = min(p['y'] for p in all_points); ymax = max(p['y'] for p in all_points)
    span_x = max(1e-6, xmax - xmin); span_y = max(1e-6, ymax - ymin)
    margin = .04
    def fit(p: Dict[str, float]) -> Dict[str, float]:
        return {
            'x': round(margin + (p['x'] - xmin) / span_x * (1 - 2 * margin), 6),
            'y': round(margin + (p['y'] - ymin) / span_y * (1 - 2 * margin), 6),
        }
    projected = []
    for c, pts, center in raw_rows:
        fitted = [fit(p) for p in pts]
        projected.append({
            'componentId': c['id'], 'primitive': c['primitive'], 'role': c['role'],
            'screenBounds': {
                'min': {'x': min(p['x'] for p in fitted), 'y': min(p['y'] for p in fitted)},
                'max': {'x': max(p['x'] for p in fitted), 'y': max(p['y'] for p in fitted)},
            },
            'projectedCenter': fit(center),
            'depthKey': round(c['position']['z'] + c['position']['y'] * .02, 6),
            'drawFamily': c['drawSpec']['family'],
            'geometry': deepcopy(c['geometry']),
        })
    projected.sort(key=lambda x: (x['depthKey'], x['componentId']))
    return {
        'schema': 'WhiteboardEnvironmentShotProjectionV1',
        'space': 'NORMALIZED_2D',
        'projection': 'AXONOMETRIC_WHITEBOARD_FIT_TO_VIEW',
        'viewportMargin': margin,
        'components': projected,
    }


def _world_projection_summary(scene: Dict[str, Any]) -> Dict[str, Any]:
    world = project_world(scene)
    graph = world.get('pathGraph', {})
    return {
        'schema': 'NexWorldProjectionSummaryV1',
        'sourceSchema': world.get('schema'),
        'sceneHash': world.get('sceneHash'),
        'worldChecks': deepcopy(world.get('worldChecks', {})),
        'collisionCount': len(world.get('collisions', [])),
        'supportPlaneCount': len(world.get('supportPlanes', [])),
        'walkableAreaCount': len(world.get('walkableAreas', [])),
        'pathGraph': {'algorithm': graph.get('algorithm'), 'nodeCount': len(graph.get('nodes', [])), 'edgeCount': len(graph.get('edges', []))},
        'cameraSafeZones': deepcopy(world.get('cameraSafeZones', [])),
    }


def compose_environment(environment_id: str, *, dimensions: Optional[Dict[str, float]] = None,
                        requested_primitives: Optional[List[str]] = None, topology: Optional[str] = None,
                        include_world_projection: bool = True) -> Dict[str, Any]:
    env_id = normalize_environment_id(environment_id)
    _, profiles = _aliases_and_profiles()
    profile = profiles.get(env_id)
    catalog = _load_catalog()
    if dimensions:
        dims = {k: float(dimensions[k]) for k in ('x', 'y', 'z')}
    else:
        raw_dims = (profile or {}).get('dimensions') or catalog['defaultInteriorDimensions']
        dims = {'x': float(raw_dims[0]), 'y': float(raw_dims[1]), 'z': float(raw_dims[2])}
    resolved_topology = str(topology or (profile or {}).get('topology') or 'interior').lower()
    if resolved_topology not in {'interior', 'exterior'}:
        resolved_topology = 'interior'
    if profile:
        components = _compile_profile(profile, dims)
        construction_mode = 'DECLARATIVE_ARCHETYPE'
    else:
        components = _synthesize_unseen(dims, resolved_topology, requested_primitives)
        construction_mode = 'GENERIC_PRIMITIVE_SYNTHESIS'
    camera = _camera_for(dims)
    scene = _nex_scene_spec(env_id, dims, camera, components)
    shot = _shot_projection(components, dims)
    world_summary = _world_projection_summary(scene) if include_world_projection else {'schema': 'NexWorldProjectionSummaryV1', 'status': 'NOT_REQUESTED'}
    return {
        'schema': 'WhiteboardEnvironmentCompositionV2',
        'environmentId': env_id,
        'constructionMode': construction_mode,
        'topology': resolved_topology,
        'dimensions': dims,
        'componentCount': len(components),
        'components': components,
        'zones': [{'id': c['id'], 'role': c['role'], 'bounds': deepcopy(c['bounds'])} for c in components if c.get('zone')],
        'camera': camera,
        'nexSceneSpec': {'schema': scene['schema'], 'sceneId': scene['sceneId'], 'sceneHash': scene_hash(scene), 'entityCount': len(scene['entities'])},
        'worldProjection': world_summary,
        'shotProjection': shot,
        'projectionContract': {
            'worldSpace': 'Y_UP_RIGHT_HANDED',
            'drawMode': 'WHITEBOARD_SET_CONSTRUCTION',
            'componentGeometryAuthority': True,
            'bakedTextInsideSetForbidden': True,
            'wholeIllustrationStructuralAuthority': False,
            'assetBankRole': 'OPTIONAL_STYLE_MATERIAL_ONLY',
        },
    }


ROLE_BINDING_RULES: Dict[str, Dict[str, List[str]]] = {
    'support_fixture': {'tags': ['support_surface', 'storage'], 'primitives': ['storage', 'work_surface', 'surface']},
    'transaction_station': {'tags': ['service_station', 'support_surface'], 'primitives': ['work_surface', 'equipment']},
    'merchandise_context': {'tags': ['display', 'storage'], 'primitives': ['storage']},
    'generic_destination': {'tags': ['container_receiver', 'support_surface'], 'primitives': ['container', 'work_surface', 'surface']},
}


def _story_primitive_needs(story: Dict[str, Any]) -> List[str]:
    needs = ['opening', 'path']
    role_to_primitives = {
        'support_fixture': ['storage', 'surface'],
        'transaction_station': ['work_surface', 'equipment'],
        'merchandise_context': ['storage'],
        'generic_destination': ['container', 'work_surface'],
    }
    for prop in story.get('props', []):
        needs.extend(role_to_primitives.get(prop.get('semanticRole'), []))
    for action in story.get('actions', []):
        op = action.get('operation')
        if op in {'PICKUP', 'PLACE'}:
            needs.extend(['surface', 'storage'])
        elif op in {'OPEN', 'CLOSE'}:
            needs.extend(['opening', 'fixture'])
        elif op == 'USE':
            needs.append('equipment')
        elif op == 'READ':
            needs.extend(['seat', 'surface'])
    return list(dict.fromkeys(needs))


def _component_score(c: Dict[str, Any], rule: Dict[str, List[str]]) -> float:
    tags = set(c.get('semanticTags', []))
    wanted_tags = rule.get('tags', [])
    wanted_primitives = rule.get('primitives', [])
    score = sum(2.0 for t in wanted_tags if t in tags)
    if c.get('primitive') in wanted_primitives:
        score += 1.2 + max(0, len(wanted_primitives) - wanted_primitives.index(c['primitive'])) * .05
    if c.get('zone'):
        score += .1
    return score


def _best_component(composition: Dict[str, Any], *, tags: Optional[Iterable[str]] = None,
                    primitives: Optional[Iterable[str]] = None, exclude: Optional[set] = None) -> Optional[Dict[str, Any]]:
    rule = {'tags': list(tags or []), 'primitives': list(primitives or [])}
    exclude = exclude or set()
    scored = [(round(_component_score(c, rule), 6), c['id'], c) for c in composition['components'] if c['id'] not in exclude]
    scored = [x for x in scored if x[0] > 0]
    return max(scored, key=lambda x: (x[0], x[1]))[2] if scored else None


def _anchor_position(component: Dict[str, Any], roles: Iterable[str]) -> Dict[str, float]:
    wanted = list(roles)
    for role in wanted:
        hit = next((a for a in component.get('anchors', []) if a.get('role') == role), None)
        if hit:
            return deepcopy(hit['position'])
    return _center(component['bounds'])


def _story_module():
    if str(LAYER1) not in sys.path:
        sys.path.insert(0, str(LAYER1))
    from story_scene_composer import compose_story
    return compose_story


def ground_story_environment(story_text: str) -> Dict[str, Any]:
    compose_story = _story_module()
    story = compose_story(story_text, 'layer3-grounding-scene')
    env_id = story['scene']['environment']
    _, profiles = _aliases_and_profiles()
    known = normalize_environment_id(env_id) in profiles
    primitive_needs = _story_primitive_needs(story)
    composition = compose_environment(env_id, requested_primitives=None if known else primitive_needs)

    placements: List[Dict[str, Any]] = []
    prop_bindings: Dict[str, str] = {}
    used_components: set = set()

    # Structural story props bind to components by capabilities, never by their labels/nouns.
    for prop in story.get('props', []):
        role = prop.get('semanticRole')
        rule = ROLE_BINDING_RULES.get(role)
        if not rule:
            continue
        candidate = _best_component(composition, tags=rule['tags'], primitives=rule['primitives'], exclude=used_components)
        if not candidate:
            candidate = _best_component(composition, tags=rule['tags'], primitives=rule['primitives'])
        if candidate:
            prop_bindings[prop['id']] = candidate['id']
            used_components.add(candidate['id'])
            placements.append({'entityId': prop['id'], 'label': prop['label'], 'semanticRole': role, 'binding': 'ENVIRONMENT_COMPONENT', 'componentId': candidate['id'], 'position': _anchor_position(candidate, ['support_surface', 'container_receiver', 'use'])})

    actor_path = _best_component(composition, tags=['actor_path', 'walkable'], primitives=['path']) or composition['components'][0]
    actor_pos = _anchor_position(actor_path, ['actor_path'])
    cast = story.get('cast', [])
    if cast:
        placements.append({'entityId': cast[0]['id'], 'label': cast[0]['label'], 'semanticRole': 'primary_actor', 'binding': 'ACTOR_PATH', 'componentId': actor_path['id'], 'position': actor_pos})
    for member in cast[1:]:
        if 'service_staff' in member.get('semanticTags', []):
            station = _best_component(composition, tags=['service_station'], primitives=['work_surface'])
            if station:
                pos = _anchor_position(station, ['staff', 'approach'])
                placements.append({'entityId': member['id'], 'label': member['label'], 'semanticRole': 'service_staff', 'binding': 'SERVICE_STATION', 'componentId': station['id'], 'position': pos})
                continue
        placements.append({'entityId': member['id'], 'label': member['label'], 'semanticRole': 'secondary_actor', 'binding': 'ACTOR_PATH', 'componentId': actor_path['id'], 'position': vec(actor_pos['x'] + .8, actor_pos['y'], actor_pos['z'] + .3)})

    # Portable carry containers remain props; place them near the primary actor rather than turning them into set geometry.
    for prop in story.get('props', []):
        if prop.get('semanticRole') == 'carry_container':
            placements.append({'entityId': prop['id'], 'label': prop['label'], 'semanticRole': 'carry_container', 'binding': 'NEAR_PRIMARY_ACTOR', 'componentId': actor_path['id'], 'position': vec(actor_pos['x'] - .55, .28, actor_pos['z'] + .30)})

    # Relationship grounding: target-item support follows the semantic support prop's component binding.
    by_prop = {p['id']: p for p in story.get('props', [])}
    for block in story.get('blocking', []):
        if block.get('relation') != 'supported_by':
            continue
        target_id, support_id = block.get('subjectId'), block.get('objectId')
        target = by_prop.get(target_id)
        component_id = prop_bindings.get(support_id)
        component = next((c for c in composition['components'] if c['id'] == component_id), None)
        if target and component:
            placements.append({'entityId': target_id, 'label': target['label'], 'semanticRole': target.get('semanticRole'), 'binding': 'SUPPORTED_BY_ENVIRONMENT_COMPONENT', 'componentId': component['id'], 'position': _anchor_position(component, ['support_surface'])})

    placed_ids = {p['entityId'] for p in placements}
    for prop in story.get('props', []):
        if prop['id'] in placed_ids:
            continue
        if prop.get('semanticRole') == 'target_item':
            support = _best_component(composition, tags=['support_surface'], primitives=['surface', 'work_surface', 'storage'])
            if support:
                placements.append({'entityId': prop['id'], 'label': prop['label'], 'semanticRole': 'target_item', 'binding': 'GENERIC_SUPPORT_SURFACE', 'componentId': support['id'], 'position': _anchor_position(support, ['support_surface'])})

    return {
        'schema': 'WhiteboardStoryEnvironmentGroundingV2',
        'storyText': story_text,
        'storyComposition': story,
        'environmentComposition': composition,
        'entityPlacements': placements,
        'primitiveNeeds': primitive_needs,
        'integrationNotes': {
            'bindingAuthority': 'SEMANTIC_CAPABILITY_MATCHING',
            'storyNounDispatch': False,
            'wholeIllustrationAssetsStructuralAuthority': False,
            'environmentConstructedFromDrawableComponents': True,
            'textRectanglesUsedAsSetSubstitutes': False,
        },
    }
