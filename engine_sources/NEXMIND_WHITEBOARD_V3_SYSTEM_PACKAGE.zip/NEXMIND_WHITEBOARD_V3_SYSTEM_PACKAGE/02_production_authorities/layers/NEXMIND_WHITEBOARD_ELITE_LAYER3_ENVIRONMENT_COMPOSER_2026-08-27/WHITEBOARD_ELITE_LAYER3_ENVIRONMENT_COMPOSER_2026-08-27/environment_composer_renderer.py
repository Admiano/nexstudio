from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

sys.dont_write_bytecode = True

import cairosvg
import svgwrite

from environment_composer import compose_environment, ground_story_environment

W, H = 1280, 720
PAPER = '#fbfbf8'
INK = '#222222'
LIGHT = '#8b8b8b'


def _projection_params(comp: Dict[str, Any]) -> Tuple[float, Tuple[float, float]]:
    dims = comp['dimensions']
    span = max(dims['x'] + dims['z'] * .72, dims['y'] * 1.8)
    scale = min(90.0, 900.0 / max(1.0, span))
    return scale, (W * .51, H * .83)


def _proj(point: Dict[str, float], scale: float, origin: Tuple[float, float]) -> Tuple[float, float]:
    ox, oy = origin
    x, y, z = point['x'], point['y'], point['z']
    return ox + x * scale - z * scale * .72, oy - y * scale - z * scale * .26


def _corners(bounds: Dict[str, Any]) -> Dict[str, Dict[str, float]]:
    mn, mx = bounds['min'], bounds['max']
    return {
        f'{xi}{yi}{zi}': {'x': x, 'y': y, 'z': z}
        for xi, x in enumerate((mn['x'], mx['x']))
        for yi, y in enumerate((mn['y'], mx['y']))
        for zi, z in enumerate((mn['z'], mx['z']))
    }


def _line(dwg, a, b, width=2.2, opacity=1.0, dash=None):
    kw = dict(stroke=INK, stroke_width=width, stroke_linecap='round', opacity=opacity)
    if dash:
        kw['stroke_dasharray'] = dash
    dwg.add(dwg.line(a, b, **kw))


def _box(dwg, c: Dict[str, Any], scale, origin, width=2.0, opacity=.95):
    pts = _corners(c['bounds'])
    pairs = [('000','100'),('000','010'),('100','110'),('010','110'),('001','101'),('001','011'),('101','111'),('011','111'),('000','001'),('100','101'),('010','011'),('110','111')]
    for a,b in pairs:
        _line(dwg, _proj(pts[a], scale, origin), _proj(pts[b], scale, origin), width, opacity)


def _plane(dwg, c, scale, origin, width=2.2, opacity=.92):
    b=c['bounds']; mn,mx=b['min'],b['max']
    # choose the thinnest axis as plane normal
    sizes=[mx[k]-mn[k] for k in ('x','y','z')]
    axis=min(range(3),key=lambda i:sizes[i])
    if axis==1:
        y=(mn['y']+mx['y'])/2
        ps=[{'x':mn['x'],'y':y,'z':mn['z']},{'x':mx['x'],'y':y,'z':mn['z']},{'x':mx['x'],'y':y,'z':mx['z']},{'x':mn['x'],'y':y,'z':mx['z']}]
    elif axis==0:
        x=(mn['x']+mx['x'])/2
        ps=[{'x':x,'y':mn['y'],'z':mn['z']},{'x':x,'y':mx['y'],'z':mn['z']},{'x':x,'y':mx['y'],'z':mx['z']},{'x':x,'y':mn['y'],'z':mx['z']}]
    else:
        z=(mn['z']+mx['z'])/2
        ps=[{'x':mn['x'],'y':mn['y'],'z':z},{'x':mx['x'],'y':mn['y'],'z':z},{'x':mx['x'],'y':mx['y'],'z':z},{'x':mn['x'],'y':mx['y'],'z':z}]
    pp=[_proj(p,scale,origin) for p in ps]
    for i in range(4): _line(dwg,pp[i],pp[(i+1)%4],width,opacity)


def _path(dwg,c,scale,origin):
    b=c['bounds'];mn,mx=b['min'],b['max']; y=(mn['y']+mx['y'])/2
    ps=[{'x':mn['x'],'y':y,'z':mn['z']},{'x':mx['x'],'y':y,'z':mn['z']},{'x':mx['x'],'y':y,'z':mx['z']},{'x':mn['x'],'y':y,'z':mx['z']}]
    pp=[_proj(p,scale,origin) for p in ps]
    for i in range(4): _line(dwg,pp[i],pp[(i+1)%4],1.35,.48,'7,7' if c.get('zone') else None)
    lanes=int(c.get('geometry',{}).get('laneLines',0) or 0)
    if lanes:
        for j in range(1,lanes+1):
            frac=j/(lanes+1)
            z=mn['z']+(mx['z']-mn['z'])*frac
            _line(dwg,_proj({'x':mn['x'],'y':y+.01,'z':z},scale,origin),_proj({'x':mx['x'],'y':y+.01,'z':z},scale,origin),1.1,.38,'10,8')


def _opening(dwg,c,scale,origin):
    b=c['bounds'];mn,mx=b['min'],b['max']
    # frame on the dominant vertical plane
    if (mx['x']-mn['x']) < (mx['z']-mn['z']):
        x=(mn['x']+mx['x'])/2
        ps=[{'x':x,'y':mn['y'],'z':mn['z']},{'x':x,'y':mx['y'],'z':mn['z']},{'x':x,'y':mx['y'],'z':mx['z']},{'x':x,'y':mn['y'],'z':mx['z']}]
    else:
        z=(mn['z']+mx['z'])/2
        ps=[{'x':mn['x'],'y':mn['y'],'z':z},{'x':mn['x'],'y':mx['y'],'z':z},{'x':mx['x'],'y':mx['y'],'z':z},{'x':mx['x'],'y':mn['y'],'z':z}]
    pp=[_proj(p,scale,origin) for p in ps]
    for i in range(4): _line(dwg,pp[i],pp[(i+1)%4],2.5,.95)
    mullions=int(c.get('geometry',{}).get('mullions',0) or 0)
    if mullions:
        for j in range(1,mullions+1):
            frac=j/(mullions+1)
            if (mx['x']-mn['x']) >= (mx['z']-mn['z']):
                x=mn['x']+(mx['x']-mn['x'])*frac; z=(mn['z']+mx['z'])/2
                _line(dwg,_proj({'x':x,'y':mn['y'],'z':z},scale,origin),_proj({'x':x,'y':mx['y'],'z':z},scale,origin),1.2,.55)
            else:
                z=mn['z']+(mx['z']-mn['z'])*frac; x=(mn['x']+mx['x'])/2
                _line(dwg,_proj({'x':x,'y':mn['y'],'z':z},scale,origin),_proj({'x':x,'y':mx['y'],'z':z},scale,origin),1.2,.55)


def _storage(dwg,c,scale,origin):
    _box(dwg,c,scale,origin,2.0,.92)
    b=c['bounds'];mn,mx=b['min'],b['max']; levels=max(0,int(c.get('geometry',{}).get('levels',0) or 0))
    for j in range(1,levels+1):
        y=mn['y']+(mx['y']-mn['y'])*j/(levels+1)
        for x in (mn['x'],mx['x']):
            _line(dwg,_proj({'x':x,'y':y,'z':mn['z']},scale,origin),_proj({'x':x,'y':y,'z':mx['z']},scale,origin),1.3,.65)
    doors=max(0,int(c.get('geometry',{}).get('doorLines',0) or 0))
    if doors:
        z=mx['z']
        for j in range(1,doors+1):
            x=mn['x']+(mx['x']-mn['x'])*j/(doors+1)
            _line(dwg,_proj({'x':x,'y':mn['y'],'z':z},scale,origin),_proj({'x':x,'y':mx['y'],'z':z},scale,origin),1.2,.58)


def _work_surface(dwg,c,scale,origin):
    b=c['bounds'];mn,mx=b['min'],b['max']; y=mx['y']
    ps=[{'x':mn['x'],'y':y,'z':mn['z']},{'x':mx['x'],'y':y,'z':mn['z']},{'x':mx['x'],'y':y,'z':mx['z']},{'x':mn['x'],'y':y,'z':mx['z']}]
    pp=[_proj(p,scale,origin) for p in ps]
    for i in range(4):_line(dwg,pp[i],pp[(i+1)%4],2.35,.98)
    if c.get('geometry',{}).get('legs',True):
        for p in ps:
            _line(dwg,_proj({'x':p['x'],'y':mn['y'],'z':p['z']},scale,origin),_proj(p,scale,origin),1.75,.9)
    else:
        _box(dwg,c,scale,origin,1.45,.62)


def _seat(dwg,c,scale,origin):
    b=c['bounds'];mn,mx=b['min'],b['max']; seat_y=mn['y']+(mx['y']-mn['y'])*.48
    for z in (mn['z'],mx['z']):
        _line(dwg,_proj({'x':mn['x'],'y':seat_y,'z':z},scale,origin),_proj({'x':mx['x'],'y':seat_y,'z':z},scale,origin),1.9,.92)
    for x in (mn['x'],mx['x']):
        for z in (mn['z'],mx['z']):
            _line(dwg,_proj({'x':x,'y':mn['y'],'z':z},scale,origin),_proj({'x':x,'y':seat_y,'z':z},scale,origin),1.6,.85)
    if c.get('geometry',{}).get('back',True):
        z=mn['z']
        _line(dwg,_proj({'x':mn['x'],'y':seat_y,'z':z},scale,origin),_proj({'x':mn['x'],'y':mx['y'],'z':z},scale,origin),1.9,.92)
        _line(dwg,_proj({'x':mx['x'],'y':seat_y,'z':z},scale,origin),_proj({'x':mx['x'],'y':mx['y'],'z':z},scale,origin),1.9,.92)
        _line(dwg,_proj({'x':mn['x'],'y':mx['y'],'z':z},scale,origin),_proj({'x':mx['x'],'y':mx['y'],'z':z},scale,origin),1.7,.8)


def _surface(dwg,c,scale,origin):
    _box(dwg,c,scale,origin,1.9,.88)
    if c.get('geometry',{}).get('headboard'):
        b=c['bounds'];mn,mx=b['min'],b['max']; z=mn['z']
        _line(dwg,_proj({'x':mn['x'],'y':mx['y'],'z':z},scale,origin),_proj({'x':mn['x'],'y':mx['y']+.45,'z':z},scale,origin),2.1,.9)
        _line(dwg,_proj({'x':mn['x'],'y':mx['y']+.45,'z':z},scale,origin),_proj({'x':mx['x'],'y':mx['y']+.45,'z':z},scale,origin),1.9,.85)


def _container(dwg,c,scale,origin):
    array_count=max(0,int(c.get('geometry',{}).get('arrayCount',0) or 0))
    if not array_count:
        return _box(dwg,c,scale,origin,1.7,.75)
    b=c['bounds'];mn,mx=b['min'],b['max']; y0=mn['y']; y1=mx['y']; z=(mn['z']+mx['z'])/2
    for j in range(array_count):
        frac=(j+.5)/array_count
        x=mn['x']+(mx['x']-mn['x'])*frac
        half=(mx['x']-mn['x'])/array_count*.27
        _line(dwg,_proj({'x':x-half,'y':y0,'z':z},scale,origin),_proj({'x':x-half,'y':y1,'z':z},scale,origin),1.1,.58)
        _line(dwg,_proj({'x':x+half,'y':y0,'z':z},scale,origin),_proj({'x':x+half,'y':y1,'z':z},scale,origin),1.1,.58)
        _line(dwg,_proj({'x':x-half,'y':y1,'z':z},scale,origin),_proj({'x':x+half,'y':y1,'z':z},scale,origin),1.0,.52)


def _equipment_or_fixture(dwg,c,scale,origin):
    _box(dwg,c,scale,origin,1.8,.82)
    g=c.get('geometry',{})
    b=c['bounds'];mn,mx=b['min'],b['max']; ctr=c['position']; front=mx['z']
    if g.get('display'):
        p=_proj({'x':ctr['x'],'y':mn['y']+(mx['y']-mn['y'])*.68,'z':front+.01},scale,origin)
        dwg.add(dwg.rect(insert=(p[0]-12,p[1]-7),size=(24,14),fill='none',stroke=INK,stroke_width=1.3,opacity=.7))
    controls=max(0,int(g.get('controls',0) or 0))
    for j in range(controls):
        x=ctr['x']+(j-(controls-1)/2)*max(.08,(mx['x']-mn['x'])/(controls+1))
        p=_proj({'x':x,'y':mn['y']+(mx['y']-mn['y'])*.36,'z':front+.01},scale,origin)
        dwg.add(dwg.circle(center=p,r=3.2,fill='none',stroke=INK,stroke_width=1.1,opacity=.72))
    if g.get('basin'):
        p=_proj({'x':ctr['x'],'y':mx['y']+.01,'z':ctr['z']},scale,origin)
        dwg.add(dwg.ellipse(center=p,r=(16,7),fill='none',stroke=INK,stroke_width=1.2,opacity=.65))
    if g.get('roof'):
        _line(dwg,_proj({'x':mn['x']-.1,'y':mx['y']+.1,'z':mn['z']},scale,origin),_proj({'x':mx['x']+.1,'y':mx['y']+.1,'z':mn['z']},scale,origin),2.2,.88)


def _signage(dwg,c,scale,origin):
    _plane(dwg,c,scale,origin,1.8,.72)
    if c.get('geometry',{}).get('post'):
        ctr=c['position']; b=c['bounds']; mn=b['min']
        _line(dwg,_proj({'x':ctr['x'],'y':0,'z':ctr['z']},scale,origin),_proj({'x':ctr['x'],'y':mn['y'],'z':ctr['z']},scale,origin),1.7,.72)


DRAWERS = {
    'wall': _plane,
    'path': _path,
    'opening': _opening,
    'storage': _storage,
    'work_surface': _work_surface,
    'seat': _seat,
    'surface': _surface,
    'container': _container,
    'equipment': _equipment_or_fixture,
    'fixture': _equipment_or_fixture,
    'signage': _signage,
}


def render_composition_svg(comp: Dict[str, Any], out_path: str) -> str:
    out=Path(out_path); out.parent.mkdir(parents=True,exist_ok=True)
    dwg=svgwrite.Drawing(str(out),size=(W,H)); dwg.add(dwg.rect(insert=(0,0),size=(W,H),fill=PAPER))
    scale,origin=_projection_params(comp)
    for c in sorted(comp['components'],key=lambda x:(x['position']['z'],x['position']['y'],x['id'])):
        DRAWERS.get(c['primitive'],_box)(dwg,c,scale,origin)
    # Deliberately no text elements: set identity is communicated by geometry, not labels.
    dwg.save(); return str(out)


def render_composition_png(comp: Dict[str, Any], out_path: str) -> Dict[str, str]:
    out=Path(out_path); out.parent.mkdir(parents=True,exist_ok=True); svg=out.with_suffix('.svg')
    render_composition_svg(comp,str(svg)); cairosvg.svg2png(url=str(svg),write_to=str(out))
    return {'svg':str(svg),'png':str(out)}


def render_environment_png(environment_id: str, out_path: str, *, requested_primitives: Iterable[str] | None = None) -> Dict[str, str]:
    return render_composition_png(compose_environment(environment_id,requested_primitives=list(requested_primitives or []) or None),out_path)


def render_story_environment_png(story_text: str, out_path: str) -> Dict[str, Any]:
    grounded=ground_story_environment(story_text)
    return {'render':render_composition_png(grounded['environmentComposition'],out_path),'grounding':grounded}
