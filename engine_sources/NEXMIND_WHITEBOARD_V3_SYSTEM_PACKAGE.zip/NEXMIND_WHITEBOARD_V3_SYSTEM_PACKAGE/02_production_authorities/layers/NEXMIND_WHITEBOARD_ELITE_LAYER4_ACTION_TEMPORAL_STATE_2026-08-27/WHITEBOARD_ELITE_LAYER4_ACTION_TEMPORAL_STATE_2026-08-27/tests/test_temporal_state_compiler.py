import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from temporal_state_compiler import compile_temporal_activity,compile_story_temporal,normalize_action,validate_sequence

def B(cx,cy,cz,sx,sy,sz):
    return {'min':{'x':cx-sx/2,'y':cy-sy/2,'z':cz-sz/2},'max':{'x':cx+sx/2,'y':cy+sy/2,'z':cz+sz/2}}
def E(i,kind,pos,size=(.3,.3,.3),tags=()):
    return {'id':i,'kind':kind,'label':i,'constructor':None,'transform':{'position':{'x':pos[0],'y':pos[1],'z':pos[2]},'rotation':{'x':0,'y':0,'z':0},'scale':{'x':1,'y':1,'z':1}},'spatial':{'bounds':B(*pos,*size),'collisionVolumes':[B(*pos,*size)],'supportPlanes':[]},'interaction':{'graspRegions':[],'insertionSockets':[],'handRequirement':'either'},'semanticTags':list(tags)}

def fixture():
    ents=[E('actor_0','person',(-.8,.84,.1),(.6,1.68,.35)),E('actor_1','person',(.8,.84,.1),(.6,1.68,.35)),E('item_0','rigid_object',(-.3,.8,.25),(.18,.12,.14),('graspable','portable')),E('source_0','environment_structure',(-.3,.65,.25),(.9,.7,.5),('support_surface',)),E('receiver_0','rigid_object',(.3,.5,.25),(.45,.35,.4),('container','item_receiver')),E('fixture_0','articulated_object',(-.3,.95,.25),(.65,1.2,.22),('articulated','openable')),E('surface_0','environment_structure',(-.3,.78,.25),(.9,.12,.55),('support_surface',)),E('seat_0','environment_structure',(0,.48,.1),(.55,.12,.55),('seat',)),E('control_0','rigid_object',(-.3,.95,.25),(.12,.08,.06),('device',))]
    ids=['item_0','receiver_0','fixture_0','surface_0','seat_0','control_0']
    sockets=[];reach=[]
    for i,eid in enumerate(ids):
        pos={'x':-.3 if eid not in ('receiver_0','seat_0') else (.3 if eid=='receiver_0' else 0),'y':.8 if eid not in ('fixture_0','control_0','seat_0') else (.95 if eid in ('fixture_0','control_0') else .48),'z':.25 if eid!='seat_0' else .1}
        kind='insertion' if eid=='receiver_0' else 'grip_center'
        sid=f'{eid}:{kind}:0';sockets.append({'entityId':eid,'socketId':sid,'kind':kind,'position':pos,'normal':{'x':0,'y':0,'z':1},'radius':.05,'handRequirement':'either'})
        reach.append({'entityId':eid,'socketId':sid,'heightClass':'mid','preferredHand':'right','stagingPosition':{'x':0,'y':0,'z':0},'facingYawDeg':0,'targetPosition':pos,'maxReachM':1.55,'requiresReposition':False})
    return {'scene':{'schema':'NexSceneSpecV1','sceneId':'generic-fixture','scene':{'environmentType':'generic','dimensions':{'x':4,'y':3,'z':4},'cameraSpace':{'position':{'x':0,'y':2,'z':5},'target':{'x':0,'y':1,'z':0},'fov':45},'worldCoordinateSystem':'Y_UP_RIGHT_HANDED','perspectiveMode':'perspective','styleFamily':'whiteboard-clean-line','aspectRatio':'16:9'},'entities':ents,'relationships':[]},'world':{'schema':'NexWorldProjectionV1','interactionSockets':sockets,'reachability':reach}}

CASES={
 'pickup':{'targetId':'item_0','itemId':'item_0','sourceId':'source_0'},
 'remove':{'targetId':'item_0','itemId':'item_0','sourceId':'receiver_0'},
 'place':{'targetId':'receiver_0','destinationId':'receiver_0','itemId':'item_0','toolId':'item_0'},
 'insert':{'targetId':'receiver_0','destinationId':'receiver_0','itemId':'item_0','toolId':'item_0'},
 'carry':{'targetId':'item_0','itemId':'item_0'},
 'give':{'targetId':'item_0','itemId':'item_0','partnerId':'actor_1'},
 'receive':{'targetId':'item_0','itemId':'item_0','partnerId':'actor_1'},
 'open':{'targetId':'fixture_0'},'close':{'targetId':'fixture_0'},
 'pour':{'targetId':'item_0','itemId':'item_0','destinationId':'receiver_0'},
 'sit':{'targetId':'seat_0','destinationId':'seat_0'},
 'type':{'targetId':'surface_0'},'write':{'targetId':'surface_0'},
 'drink':{'targetId':'item_0','itemId':'item_0'},
 'push':{'targetId':'fixture_0','actuationVector':[0,0,.25]},'pull':{'targetId':'fixture_0','actuationVector':[0,0,-.25]},
 'press':{'targetId':'control_0'},'point':{'targetId':'control_0'},'read':{'targetId':'item_0'}
}

def test_aliases_are_action_semantics_not_scenarios():
    assert normalize_action('pick up')=='pickup'; assert normalize_action('hand over')=='give'; assert normalize_action('sip')=='drink'

def test_all_requested_action_families_compile():
    f=fixture()
    for action,payload in CASES.items():
        out=compile_temporal_activity({'action':action,**payload},world_projection=f['world'],scene_spec=f['scene'],actor_id='actor_0',partner_id='actor_1')
        assert out['action']==action
        assert len(out['frames'])>=5
        assert out['scenarioSpecificLogic'] is False
        assert out['continuity']['actorIdentityStable']
        assert out['continuity']['objectIdentityStable']
        assert out['universalActivityPlan']['execution']=='PHYSICAL_PLAN', (action,out['universalActivityPlan'])
        assert out['performanceBinding']['status']=='PROJECTED_FROM_EXECUTABLE_NEXSTICK', (action,out['performanceBinding'])

def test_contact_gates_ownership_for_acquire_and_release():
    f=fixture()
    for action,payload in [('pickup',CASES['pickup']),('place',CASES['place']),('give',CASES['give'])]:
        out=compile_temporal_activity({'action':action,**payload},world_projection=f['world'],scene_spec=f['scene'],actor_id='actor_0',partner_id='actor_1')
        assert validate_sequence(out['frames'])['contactBeforeOwnershipChange'], action

def test_object_identity_does_not_change_during_transform_actions():
    f=fixture()
    for action in ('open','close','push','pull','press'):
        out=compile_temporal_activity({'action':action,**CASES[action]},world_projection=f['world'],scene_spec=f['scene'],actor_id='actor_0')
        ids=[o['entityId'] for fr in out['frames'] for o in fr['objects']]
        assert len(set(ids))==1

def test_articulation_is_continuous_and_directional():
    f=fixture()
    op=compile_temporal_activity({'action':'open',**CASES['open']},world_projection=f['world'],scene_spec=f['scene'],actor_id='actor_0')
    cl=compile_temporal_activity({'action':'close',**CASES['close']},world_projection=f['world'],scene_spec=f['scene'],actor_id='actor_0')
    a=[fr['objects'][0]['articulation']['progress'] for fr in op['frames']]; b=[fr['objects'][0]['articulation']['progress'] for fr in cl['frames']]
    assert a==sorted(a);assert b==sorted(b)
    assert op['frames'][-1]['objects'][0]['articulation']['semanticState']=='open'
    assert cl['frames'][-1]['objects'][0]['articulation']['semanticState']=='closed'

def test_story_transfer_is_eight_identity_stable_states():
    out=compile_story_temporal('Ada walks into the shop and takes bread from the shelf.')
    assert len(out['states'])==8
    assert [x['temporalLabel'] for x in out['states']]==[f'T{i}' for i in range(8)]
    assert out['invariants']['pass']
    ids=[x['objects'][0]['entityId'] for x in out['states'] if x['objects']]
    assert len(set(ids))==1
    assert out['states'][-1]['objects'][0]['owner']==out['destinationId']

def test_unseen_nouns_do_not_change_temporal_logic():
    f=fixture(); sigs=[]
    for label in ['quorin','velastra','mephtal','zorvane']:
        out=compile_temporal_activity({'action':'pickup','targetId':'item_0','itemId':'item_0','sourceId':'source_0','semanticLabel':label},world_projection=f['world'],scene_spec=f['scene'],actor_id='actor_0')
        sigs.append([(x['normalizedTime'],x['contacts']['active'],x['objects'][0]['owner']) for x in out['frames']])
    assert all(s==sigs[0] for s in sigs)

def test_story_render_stream_has_no_hidden_staging_teleport():
    out=compile_story_temporal('Ada walks into the shop and takes bread from the shelf.')
    assert out['transitBridgeFrames']>=3
    assert out['renderInvariants']['pass']
    assert out['spatialContinuity']['pass'], out['spatialContinuity']
    assert out['spatialContinuity']['maxAdjacentStepM']<=out['spatialContinuity']['thresholdM']
