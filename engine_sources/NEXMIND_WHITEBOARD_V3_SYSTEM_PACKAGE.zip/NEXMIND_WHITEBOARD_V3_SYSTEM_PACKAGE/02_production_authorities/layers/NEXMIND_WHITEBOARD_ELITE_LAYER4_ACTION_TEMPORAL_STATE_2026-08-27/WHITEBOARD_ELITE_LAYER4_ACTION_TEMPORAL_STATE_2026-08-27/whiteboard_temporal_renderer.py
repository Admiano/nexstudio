from __future__ import annotations
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

def render_timeline(sequence,out_path):
    states=sequence.get('states') or sequence.get('frames') or []
    W,H=1320,420; im=Image.new('RGB',(W,H),'white');d=ImageDraw.Draw(im);font=ImageFont.load_default();n=max(1,len(states));pad=45;cw=(W-2*pad)/n
    d.text((pad,18),sequence.get('schema','Whiteboard temporal sequence'),fill='black',font=font)
    for i,f in enumerate(states):
        x0=pad+i*cw;x1=pad+(i+1)*cw-8; y0=70;y1=350
        d.rounded_rectangle((x0,y0,x1,y1),radius=10,outline='black',width=2)
        o=(f.get('objects') or [{}])[0]; owner=str(o.get('owner','—')); action=f.get('action',''); label=f.get('temporalLabel','T'+str(i));
        d.text((x0+10,y0+12),label+'  '+action,fill='black',font=font);d.text((x0+10,y0+40),'same entity: '+str(o.get('entityId','actor')),fill='black',font=font);d.text((x0+10,y0+60),'owner: '+owner,fill='black',font=font)
        active=f.get('contacts',{}).get('active');d.text((x0+10,y0+80),'contact: '+str(active),fill='black',font=font)
        pf=f.get('performer') or {}; actor=pf.get('actors',{}) if isinstance(pf,dict) else {}; status=pf.get('status') if isinstance(pf,dict) else None
        d.text((x0+10,y0+100),'performer: '+str(status or ('pair' if actor else '')),fill='black',font=font)
        if i<n-1:d.line((x1+2,(y0+y1)/2,x1+7,(y0+y1)/2),fill='black',width=2)
    im.save(out_path);return out_path
