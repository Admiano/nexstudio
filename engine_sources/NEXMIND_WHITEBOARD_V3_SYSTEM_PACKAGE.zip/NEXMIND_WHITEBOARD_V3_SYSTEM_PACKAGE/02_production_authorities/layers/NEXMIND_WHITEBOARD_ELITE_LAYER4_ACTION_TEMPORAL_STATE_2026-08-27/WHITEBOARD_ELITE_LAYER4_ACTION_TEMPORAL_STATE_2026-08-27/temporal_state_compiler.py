from __future__ import annotations
import hashlib,json,math,subprocess,sys
from copy import deepcopy
from pathlib import Path
from typing import Any,Dict,List,Optional
ROOT=Path(__file__).resolve().parent
CANONICAL=Path('/mnt/data/nexmind-runtime/current').resolve()
LAYER1=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER1_STORY_SCENE_COMPOSER_2026-08-27')
LAYER2=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER2_WHITEBOARD_PERFORMER_2026-08-27')
VC_ROOT=CANONICAL/'VC_RUNTIME'
for p in (str(LAYER1),str(LAYER2),str(VC_ROOT)):
    if p not in sys.path: sys.path.insert(0,p)
from story_scene_composer import compose_story
from whiteboard_performer import project_performance_state,_sample_nexstick
from src.articulated_runtime import descriptor_for_entity,joint_value,semantic_state,world_handle_position
PROFILES=json.loads((ROOT/'action_temporal_profiles.json').read_text())['actions']
BATCH_SOURCE=ROOT/'nexstick_temporal_batch_source.js'

def _canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def _hash(x): return hashlib.sha256(_canon(x).encode()).hexdigest()
def _v3(v):
    if isinstance(v,dict): return [float(v['x']),float(v['y']),float(v['z'])]
    return [float(v[0]),float(v[1]),float(v[2])]
def _mix(a,b,t): return [round(a[i]+(b[i]-a[i])*float(t),6) for i in range(3)]
def _smooth(t): t=max(0,min(1,float(t))); return t*t*(3-2*t)
def _entity(scene_spec,eid): return next((e for e in (scene_spec or {}).get('entities',[]) if e.get('id')==eid),None)
def _entity_pos(scene_spec,eid):
    e=_entity(scene_spec,eid); return _v3(e['transform']['position']) if e else None
def _socket(world,eid,kind=None):
    xs=[s for s in (world or {}).get('interactionSockets',[]) if s.get('entityId')==eid]
    if kind: xs=[s for s in xs if s.get('kind')==kind]
    return xs[0] if xs else None
def _reach(world,eid,prefer_insertion=False):
    xs=[r for r in (world or {}).get('reachability',[]) if r.get('entityId')==eid]
    if prefer_insertion:
        q=next((r for r in xs if ':insertion:' in str(r.get('socketId'))),None)
        if q:return q
    return xs[0] if xs else None
def _local_target(reach):
    if not reach:return None
    t,s,yaw=reach['targetPosition'],reach['stagingPosition'],float(reach.get('facingYawDeg',0)); dx,dy,dz=t['x']-s['x'],t['y']-s.get('y',0),t['z']-s['z']; a=math.radians(-yaw);c,si=math.cos(a),math.sin(a); return [c*dx+si*dz,dy,-si*dx+c*dz]

def _actor_local_to_world(local,reach):
    if not local or not reach:return local
    lx,ly,lz=[float(v) for v in local]; st=reach['stagingPosition']; yaw=math.radians(float(reach.get('facingYawDeg',0))); c,si=math.cos(yaw),math.sin(yaw)
    return [round(float(st['x'])+c*lx+si*lz,6),round(float(st.get('y',0))+ly,6),round(float(st['z'])-si*lx+c*lz,6)]

def normalize_action(action:str)->str:
    q=' '.join(str(action or '').lower().replace('_',' ').split())
    if q in PROFILES:return q
    for k,p in PROFILES.items():
        if q in p.get('aliases',[]): return k
    raise ValueError('UNSUPPORTED_TEMPORAL_ACTION:'+q)

def _uac(activity,world,profile):
    mapped=profile['uacAction']; payload=deepcopy(activity); payload['action']=mapped
    if mapped=='place':
        dest=activity.get('destinationId') or activity.get('targetId'); item=activity.get('itemId') or activity.get('toolId') or activity.get('targetId');payload.update({'targetId':dest,'destinationId':dest,'toolId':item})
        s=_socket(world,dest,'insertion') or _socket(world,dest); payload['socketId']=s.get('socketId') if s else None
    else:
        target=activity.get('targetId') or activity.get('itemId') or activity.get('destinationId'); payload['targetId']=target
        s=_socket(world,target); payload['socketId']=s.get('socketId') if s else None
    js="const U=require(process.argv[1]);const a=JSON.parse(process.argv[2]),w=JSON.parse(process.argv[3]);console.log(JSON.stringify(U.compile(a,{world:w})));"
    u=CANONICAL/'CAPABILITY_RUNTIME/runtime/universal-activity-compiler.js'
    p=subprocess.run(['node','-e',js,str(u),json.dumps(payload,separators=(',',':')),json.dumps(world or {},separators=(',',':'))],capture_output=True,text=True,check=True)
    return json.loads(p.stdout)

def _motion_request(action,activity,world,scene_spec,profile):
    m=profile['motionAction']; target=activity.get('destinationId') if profile['effectType']=='RELEASE_TO_DESTINATION' else activity.get('targetId') or activity.get('itemId')
    reach=_reach(world,target,prefer_insertion=profile['effectType']=='RELEASE_TO_DESTINATION'); local=_local_target(reach)
    hand=activity.get('activeHand') or (reach or {}).get('preferredHand') or 'right'
    if local and abs(float(local[0]))>.06: hand='left' if float(local[0])>0 else 'right'
    req={'action':m,'activeHand':hand}
    if m in {'pickup','place','carry'}:
        eid=activity.get('itemId') or activity.get('toolId') or activity.get('targetId'); e=_entity(scene_spec,eid); b=(e or {}).get('spatial',{}).get('bounds'); size=[.18,.12,.14]
        if b:
            mn,mx=_v3(b['min']),_v3(b['max']);size=[max(.02,mx[i]-mn[i]) for i in range(3)]
        req['grip']={'position':local or [-.30,.78,.24],'approachNormal':[0,0,-1],'object':{'id':eid or 'item','size':size},'loadClass':activity.get('loadClass','light')}
    elif m in {'mid_reach','low_reach','high_reach'}: req['target']=local or [-.30,.78,.24]
    elif m=='press': req['button']={'id':target or 'control','position':local or [-.30,.90,.24],'normal':[0,0,-1],'radius':.04,'depression':.012}
    elif m=='sit':
        e=_entity(scene_spec,target); b=(e or {}).get('spatial',{}).get('bounds'); c=_entity_pos(scene_spec,target) or [0,.48,.10]; width=.55;depth=.55
        if b:
            mn,mx=_v3(b['min']),_v3(b['max']);width=max(.3,mx[0]-mn[0]);depth=max(.3,mx[2]-mn[2]);c=[(mn[0]+mx[0])/2,mx[1],(mn[2]+mx[2])/2]
        req['seat']={'id':target or 'seat','seatCenter':c,'seatNormal':[0,1,0],'width':width,'depth':depth,'floorY':0}
    return req,reach

def _batch_envelopes(req,fracs):
    times=[max(0,float(f))*_duration_hint(req['action']) for f in fracs]
    p=subprocess.run(['node',str(BATCH_SOURCE)],input=json.dumps({'request':req,'times':times}),capture_output=True,text=True,check=True)
    return json.loads(p.stdout)

def _project_single_envelope(env,actor_id):
    try:return project_performance_state(env,actor_id=actor_id)
    except Exception as exc:return {'schema':'WhiteboardPerformerFrameV1','status':'NEXSTICK_PERFORMANCE_BLOCKED','actorId':actor_id,'failure':str(exc),'request':env.get('request')}

def _sample_single(req,frac,actor_id):
    env=_sample_nexstick(req,max(0,float(frac))*_duration_hint(req['action']))
    try:return project_performance_state(env,actor_id=actor_id)
    except Exception as exc:return {'schema':'WhiteboardPerformerFrameV1','status':'NEXSTICK_PERFORMANCE_BLOCKED','actorId':actor_id,'failure':str(exc),'request':req}
def _duration_hint(action):
    return {'pickup':1.55,'place':1.45,'carry':1.2,'press':1.3,'point':1.55,'mid_reach':1.55,'low_reach':1.55,'high_reach':1.55,'sit':1.3,'typing_leanback':19.666667,'consume':1.333333,'use_item':1.6,'presenter_papers':27.4}.get(action,1.6)

def _pair_frame(req,frac,giver_id,receiver_id):
    env=_sample_nexstick(req,1.7*float(frac)); st=env.get('state') or {}
    if st.get('blocked'): return {'status':'NEXSTICK_PERFORMANCE_BLOCKED','failure':st.get('failure'),'actors':{}}
    out={}
    for role,aid in [('giver',giver_id),('receiver',receiver_id)]:
        sub=st.get('actors',{}).get(role)
        if sub: out[aid]=project_performance_state({**env,'state':sub},actor_id=aid)
    return {'status':'OK','actors':out,'prop':st.get('prop'),'phase':st.get('phase')}

def _owner_token(token,activity,actor_id,partner_id):
    return {'source':activity.get('sourceId'),'destination':activity.get('destinationId'),'actorHand':actor_id+'.'+activity.get('activeHand','right')+'Hand','actor':actor_id,'partnerHand':(partner_id+'.leftHand' if partner_id else None),'partner':partner_id}.get(token,token)

def _effect_state(effect,frac,idx,total,activity,actor_id,partner_id,profile,performer,scene_spec,reach=None):
    p=idx/max(1,total-1); item=activity.get('itemId') or activity.get('toolId') or activity.get('targetId'); source=activity.get('sourceId'); dest=activity.get('destinationId'); target=activity.get('targetId');
    state={'entityId':item,'identityStable':True,'owner':None,'support':None,'positionWorld3d':None,'articulation':None,'contents':None}
    contact=p>=.40 and p<=.82
    hand=activity.get('activeHand','right'); hand_owner=f'{actor_id}.{hand}Hand'
    if effect=='ACQUIRE':
        state['owner']=source or 'world';state['support']=source or 'world';state['positionWorld3d']=_entity_pos(scene_spec,item)
        if p>=.66: state.update(owner=hand_owner,support=hand_owner)
    elif effect=='RELEASE_TO_DESTINATION':
        state.update(owner=hand_owner,support=hand_owner,positionWorld3d=_entity_pos(scene_spec,item))
        if p>=.82: state.update(owner=dest or 'world',support=dest or 'world',positionWorld3d=_entity_pos(scene_spec,dest))
    elif effect=='MAINTAIN_HELD': state.update(owner=hand_owner,support=hand_owner,positionWorld3d=_entity_pos(scene_spec,item))
    elif effect=='HANDOFF':
        state.update(owner=f'{actor_id}.rightHand',support=f'{actor_id}.rightHand',positionWorld3d=_entity_pos(scene_spec,item))
        if .50<=p<.78: state.update(owner='shared',support=f'{actor_id}+{partner_id}')
        elif p>=.78: state.update(owner=f'{partner_id}.leftHand' if partner_id else 'receiverHand',support=f'{partner_id}.leftHand' if partner_id else 'receiverHand')
    elif effect=='ARTICULATE':
        e=_entity(scene_spec,target); desc=descriptor_for_entity(e) if e else None; progress=_smooth(max(0,(p-.36)/.46)); direction=profile.get('direction','open'); frac_joint=progress if direction=='open' else 1-progress
        state={'entityId':target,'identityStable':True,'owner':'world','support':'fixture','positionWorld3d':_entity_pos(scene_spec,target),'articulation':{'progress':round(progress,5),'direction':direction,'semanticState':semantic_state(progress,direction),'jointValue':joint_value(desc,frac_joint) if desc else None,'descriptor':desc},'contents':None}
    elif effect=='CONTENT_TRANSFER':
        progress=_smooth(max(0,(p-.38)/.46));state.update(owner=hand_owner,support=hand_owner,positionWorld3d=_entity_pos(scene_spec,item),contents={'from':item,'to':dest,'transferProgress':round(progress,5),'conserved':True})
    elif effect=='CONTENT_TO_ACTOR':
        progress=_smooth(max(0,(p-.38)/.46));state.update(owner=hand_owner,support=hand_owner,positionWorld3d=_entity_pos(scene_spec,item),contents={'from':item,'to':actor_id,'transferProgress':round(progress,5),'conserved':True})
    elif effect=='SUPPORT_TRANSFER':
        progress=_smooth(max(0,(p-.30)/.52));state={'entityId':actor_id,'identityStable':True,'owner':actor_id,'support':dest or target if progress>.6 else 'feet','positionWorld3d':None,'articulation':None,'contents':None,'seatTransferProgress':round(progress,5)}
    elif effect=='SURFACE_CONTACT_CYCLE': state={'entityId':actor_id,'identityStable':True,'owner':actor_id,'support':'feet_or_seat','positionWorld3d':None,'articulation':None,'contents':None,'contactCycleProgress':round(p,5),'targetId':target}
    elif effect=='TRANSLATE_CONTACT':
        start=_entity_pos(scene_spec,target); d=activity.get('actuationVector') or [0,0,.28*float(profile.get('directionSign',1))]; progress=_smooth(max(0,(p-.38)/.46));state={'entityId':target,'identityStable':True,'owner':'world','support':'world','positionWorld3d':_mix(start,[start[i]+float(d[i]) for i in range(3)],progress) if start else None,'articulation':None,'contents':None,'transformProgress':round(progress,5)}
    elif effect=='BUTTON_ACTUATION':
        amount=max(0,1-abs(p-.66)/.28);state={'entityId':target,'identityStable':True,'owner':'world','support':'fixture','positionWorld3d':_entity_pos(scene_spec,target),'articulation':None,'contents':None,'pressAmount':round(max(0,min(1,amount)),5)}
    elif effect=='ATTENTION': state={'entityId':target or actor_id,'identityStable':True,'owner':'world' if target else actor_id,'support':None,'positionWorld3d':_entity_pos(scene_spec,target),'articulation':None,'contents':None,'attentionProgress':round(_smooth(min(1,p/.5)),5)}
    # When NexStick publishes the same prop, its event-gated owner/position outranks derived interpolation.
    pf=performer if isinstance(performer,dict) else {}; held=pf.get('heldObjects') or []
    if item and held:
        h=next((x for x in held if x.get('id')==item),None)
        if h:
            if h.get('owner') in ('actor','giver','receiver','shared'): state['owner']={'actor':hand_owner,'giver':f'{actor_id}.rightHand','receiver':f'{partner_id}.leftHand' if partner_id else 'receiverHand','shared':'shared'}.get(h.get('owner'),state['owner'])
            pos=h.get('position') or {}
            if isinstance(pos,dict):
                local_pos=pos.get('actorLocal3d') or pos.get('world3d')
                if local_pos is not None: state['positionWorld3d']=_actor_local_to_world(local_pos,reach) if reach else local_pos
    return state,contact

def compile_temporal_activity(activity:Dict[str,Any], *, world_projection=None, scene_spec=None, actor_id='actor_0', partner_id=None)->Dict[str,Any]:
    action=normalize_action(activity.get('action')); profile=PROFILES[action]; a={**activity,'action':action}; uac=_uac(a,world_projection,profile)
    req,reach=_motion_request(action,a,world_projection,scene_spec,profile); frames=[]; pair=profile['effectType']=='HANDOFF'
    if pair:
        req={'action':profile['motionAction'],'activeHand':a.get('activeHand','right'),'partnerId':partner_id or a.get('partnerId') or 'actor_1','prop':{'id':a.get('itemId') or a.get('targetId') or 'item'}}
        if a.get('handoffTarget') is not None: req['target']=a.get('handoffTarget')
        partner_id=partner_id or a.get('partnerId') or 'actor_1'
    envelopes=_batch_envelopes(req,profile['checkpoints'])
    for i,(frac,env) in enumerate(zip(profile['checkpoints'],envelopes)):
        if pair:
            st=env.get('state') or {}
            if st.get('blocked'): perf={'status':'NEXSTICK_PERFORMANCE_BLOCKED','failure':st.get('failure'),'actors':{}}
            else:
                actors={}
                for role,aid in [('giver',actor_id),('receiver',partner_id)]:
                    sub=st.get('actors',{}).get(role)
                    if sub: actors[aid]=_project_single_envelope({**env,'state':sub},aid)
                perf={'status':'OK','actors':actors,'prop':st.get('prop'),'phase':st.get('phase')}
        else: perf=_project_single_envelope(env,actor_id)
        performer_for_effect=(perf.get('actors',{}).get(actor_id) if pair else perf)
        obj,contact=_effect_state(profile['effectType'],frac,i,len(profile['checkpoints']),a,actor_id,partner_id,profile,performer_for_effect,scene_spec,reach)
        if not pair and isinstance(perf,dict) and perf.get('status')=='OK':
            hand_contacts=[c for c in (perf.get('contacts') or []) if c.get('kind')!='foot_plant']
            if hand_contacts: contact=any(bool(c.get('applied')) for c in hand_contacts)
        if pair and perf.get('prop'):
            prop=perf['prop']; obj['owner']={'giver':f'{actor_id}.rightHand','receiver':f'{partner_id}.leftHand','shared':'shared'}.get(prop.get('owner'),obj.get('owner'));obj['positionWorld3d']=prop.get('position') or obj.get('positionWorld3d')
        frame={'schema':'WhiteboardTemporalFrameV1','index':i,'normalizedTime':frac,'action':action,'actorIds':[actor_id]+([partner_id] if pair else []),'performer':perf,'objects':[obj] if obj.get('entityId') else [],'contacts':{'required':profile['effectType'] not in {'ATTENTION'},'active':bool(contact),'targetId':a.get('targetId')},'stateAuthority':{'performance':'NEXSTICK','activity':'UniversalActivityCompiler','temporal':'WhiteboardLayer4GenericStateMachine'}}
        frame['frameHash']=_hash(frame);frames.append(frame)
    continuity={'actorIdentityStable':len({tuple(f['actorIds']) for f in frames})==1,'objectIdentityStable':len({o.get('entityId') for f in frames for o in f['objects']})<=1,'noTeleportClaim':'positions are NexStick-published or continuous state interpolation; same entity ID is retained','ownershipTransitions':[f['objects'][0].get('owner') for f in frames if f['objects']]}
    return {'schema':'WhiteboardTemporalActionSequenceV1','action':action,'effectType':profile['effectType'],'activity':a,'universalActivityPlan':uac,'performanceBinding':{'motionAction':profile['motionAction'],'request':req,'reachability':reach,'status':'PROJECTED_FROM_EXECUTABLE_NEXSTICK' if all((f['performer'].get('status')=='OK' if not pair else f['performer'].get('status')=='OK') for f in frames) else 'PARTIAL_OR_BLOCKED'},'frames':frames,'continuity':continuity,'scenarioSpecificLogic':False,'sequenceHash':_hash([f['frameHash'] for f in frames])}


def _short_yaw_mix(a,b,t):
    a=float(a or 0);b=float(b or 0);d=((b-a+180)%360)-180
    return round(a+d*float(t),6)

def _held_transit_frames(item,actor_id,start_pos,end_pos,start_reach,end_reach,count=5):
    if not start_pos or not end_pos:return []
    req={'action':'carry','activeHand':'right','grip':{'position':[-.30,.82,.24],'approachNormal':[0,0,-1],'object':{'id':item,'size':[.18,.12,.14]},'loadClass':'light'}}
    fracs=[(i+1)/(count+1) for i in range(count)]; envs=_batch_envelopes(req,fracs); out=[]
    ss=(start_reach or {}).get('stagingPosition') or {'x':0,'y':0,'z':0}; es=(end_reach or {}).get('stagingPosition') or ss
    for i,(f,env) in enumerate(zip(fracs,envs)):
        perf=_project_single_envelope(env,actor_id); w=_smooth(f); pos=_mix(start_pos,end_pos,w)
        root=[round(float(ss.get('x',0))+(float(es.get('x',0))-float(ss.get('x',0)))*w,6),round(float(ss.get('y',0))+(float(es.get('y',0))-float(ss.get('y',0)))*w,6),round(float(ss.get('z',0))+(float(es.get('z',0))-float(ss.get('z',0)))*w,6)]
        frame={'schema':'WhiteboardTemporalFrameV1','index':i,'normalizedTime':round(f,6),'action':'carry','actorIds':[actor_id],'performer':perf,'worldActorTransform':{'positionWorld3d':root,'facingYawDeg':_short_yaw_mix((start_reach or {}).get('facingYawDeg',0),(end_reach or {}).get('facingYawDeg',0),w)},'objects':[{'entityId':item,'identityStable':True,'owner':actor_id+'.rightHand','support':actor_id+'.rightHand','positionWorld3d':pos,'articulation':None,'contents':None}],'contacts':{'required':True,'active':True,'targetId':item,'kind':'persistent_grip'},'stateAuthority':{'performance':'NEXSTICK_CARRY','activity':'UniversalActivityCompiler continuity bridge','temporal':'WhiteboardLayer4GenericStateMachine'},'bridge':{'kind':'HELD_OBJECT_RESTAGE','progress':round(w,6),'scenarioSpecificLogic':False}}
        frame['frameHash']=_hash(frame);out.append(frame)
    return out

def validate_spatial_continuity(frames,threshold_m=.65):
    pts=[];jumps=[]
    for f in frames:
        os=f.get('objects') or []
        if not os:continue
        p=os[0].get('positionWorld3d')
        if isinstance(p,list) and len(p)==3: pts.append((f.get('renderIndex',f.get('index')),p))
    for (ia,a),(ib,b) in zip(pts,pts[1:]):
        d=math.sqrt(sum((float(a[k])-float(b[k]))**2 for k in range(3)))
        if d>threshold_m:jumps.append({'from':ia,'to':ib,'distanceM':round(d,6)})
    return {'thresholdM':threshold_m,'samples':len(pts),'maxAdjacentStepM':round(max([math.sqrt(sum((float(a[k])-float(b[k]))**2 for k in range(3))) for (_,a),(_,b) in zip(pts,pts[1:])] or [0]),6),'jumps':jumps,'pass':not jumps}

def compile_story_temporal(story_text:str)->Dict[str,Any]:
    comp=compose_story(story_text,'layer4-temporal-story'); actor=(comp.get('cast') or [{'id':'actor_0'}])[0]['id']; continuity=(comp.get('continuity') or [{}])[0]; chain=continuity.get('ownershipChain') or []; item=continuity.get('entityId'); source=chain[0].get('holderId') if chain and chain[0].get('state')=='supported' else None; dest=chain[-1].get('holderId') if len(chain)>=3 else None
    if item and source and dest:
        pickup=compile_temporal_activity({'action':'pickup','targetId':item,'itemId':item,'sourceId':source},world_projection=comp['worldProjection'],scene_spec=comp['nexSceneSpec'],actor_id=actor)
        place=compile_temporal_activity({'action':'place','targetId':dest,'destinationId':dest,'itemId':item,'toolId':item},world_projection=comp['worldProjection'],scene_spec=comp['nexSceneSpec'],actor_id=actor)
        # Canonical eight-state transfer view: semantic milestones sampled from the two physical sequences.
        pidx=[0,1,2,3,5,6]; qidx=[3,6]; selected=[pickup['frames'][i] for i in pidx]+[place['frames'][i] for i in qidx]
        for i,f in enumerate(selected): f=deepcopy(f);f['index']=i;f['temporalLabel']='T'+str(i);selected[i]=f
        # Force final receiver ownership from scene continuity; identity is unchanged.
        selected[-1]['objects'][0]['owner']=dest;selected[-1]['objects'][0]['support']=dest;selected[-1]['frameHash']=_hash(selected[-1])
        bridge=_held_transit_frames(item,actor,pickup['frames'][-1]['objects'][0].get('positionWorld3d'),place['frames'][0]['objects'][0].get('positionWorld3d'),pickup['performanceBinding'].get('reachability'),place['performanceBinding'].get('reachability'))
        render_frames=[deepcopy(f) for f in pickup['frames']+bridge+place['frames']]
        for i,f in enumerate(render_frames): f['renderIndex']=i
        spatial=validate_spatial_continuity(render_frames)
        return {'schema':'WhiteboardStoryTemporalSequenceV1','sourceText':story_text,'composition':{'scene':comp['scene'],'camera':comp['camera']},'entityId':item,'actorId':actor,'sourceId':source,'destinationId':dest,'states':selected,'renderFrames':render_frames,'transitBridgeFrames':len(bridge),'invariants':validate_sequence(selected),'renderInvariants':validate_sequence(render_frames),'spatialContinuity':spatial,'sourceSequences':[pickup['sequenceHash'],place['sequenceHash']]}
    # General fallback: compile each executable activity independently rather than inventing a transfer chain.
    seqs=[]
    for plan in comp.get('compiledActivities',[]):
        act=plan.get('activity') or {}; action=act.get('action')
        if action in PROFILES: seqs.append(compile_temporal_activity(act,world_projection=comp['worldProjection'],scene_spec=comp['nexSceneSpec'],actor_id=actor))
    return {'schema':'WhiteboardStoryTemporalSequenceV1','sourceText':story_text,'composition':{'scene':comp['scene'],'camera':comp['camera']},'sequences':seqs,'invariants':{'scenarioSpecificLogic':False}}

def validate_sequence(frames:List[Dict[str,Any]])->Dict[str,Any]:
    actor_sets=[tuple(f.get('actorIds') or []) for f in frames]; ids=[o.get('entityId') for f in frames for o in f.get('objects',[]) if o.get('entityId')]; owners=[o.get('owner') for f in frames for o in f.get('objects',[]) if o.get('entityId')]
    contact_seen=False; violations=[]
    prev=None
    for f in frames:
        if f.get('contacts',{}).get('active'): contact_seen=True
        os=f.get('objects') or []
        if os:
            owner=os[0].get('owner')
            if prev is not None and owner!=prev and not contact_seen: violations.append({'frame':f.get('index'),'kind':'OWNERSHIP_CHANGED_BEFORE_CONTACT','from':prev,'to':owner})
            prev=owner
    return {'actorIdentityStable':len(set(actor_sets))<=1,'objectIdentityStable':len(set(ids))<=1,'contactBeforeOwnershipChange':not violations,'ownershipViolations':violations,'ownershipTrace':owners,'scenarioSpecificLogic':False,'pass':len(set(actor_sets))<=1 and len(set(ids))<=1 and not violations}
