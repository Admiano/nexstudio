from __future__ import annotations
import json, sys
from pathlib import Path
from typing import Any, Dict
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from semantic_drawable_projection import compile_drawable_story, drawable_capabilities
from whiteboard_semantic_renderer import render_contact_sheet, render_proof_reel, render_shot_frame

def visual_realization_story(text:str)->Dict[str,Any]:
    d=compile_drawable_story(text)
    return {'schema':'WhiteboardVisualRealizationStoryV1','sceneId':d['sceneId'],'shotCount':len(d['shots']),'shots':[{'shotId':s['shotId'],'shotType':s['shotType'],'lod':s['lod'],'drawableCount':len(s['drawableSpecs']),'methods':sorted(set((x.get('method') or {}).get('method','UNKNOWN') for x in s['drawableSpecs']))} for s in d['shots']],'invariants':d['invariants']}

def capabilities():return drawable_capabilities()
