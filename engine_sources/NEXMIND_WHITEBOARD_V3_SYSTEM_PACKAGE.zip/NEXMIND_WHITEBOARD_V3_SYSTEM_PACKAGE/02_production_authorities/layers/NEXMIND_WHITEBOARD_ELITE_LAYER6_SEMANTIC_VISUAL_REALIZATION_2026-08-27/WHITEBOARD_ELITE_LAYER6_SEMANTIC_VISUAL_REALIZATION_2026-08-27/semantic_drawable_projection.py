from __future__ import annotations
import json, math, sys
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
REGISTRY=ROOT/'drawable_registry.json'
L5=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER5_CINEMATOGRAPHY_CHOREOGRAPHY_2026-08-27')
L3=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LAYER3_ENVIRONMENT_COMPOSER_2026-08-27')
FOUNDATION=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_VISUAL_FOUNDATION_ASSET_ARTIST_2026-08-27')
for p in (L5,L3,FOUNDATION):
    if str(p) not in sys.path: sys.path.insert(0,str(p))
from physical_scene_fusion import compile_unified_story_temporal
from cinema_choreography import compile_story_cinema
from environment_composer import compose_environment
from asset_fitness_resolver import resolve_asset

SCHEMA='WhiteboardDrawableSceneV1'
DRAWABLE_SCHEMA='WhiteboardDrawableSpecV1'
GENERIC_PRIMITIVES={'wall','opening','surface','storage','seat','work_surface','path','container','fixture','signage','equipment'}
SHOT_LOD={'WIDE_ESTABLISHING':'wide','MEDIUM_ACTION':'medium','MEDIUM_CONSEQUENCE':'medium','TWO_SHOT':'medium','CLOSE_HAND':'close','INSERT_STATE':'insert'}


def _registry()->Dict[str,Any]: return json.loads(REGISTRY.read_text())
def _slug(v:Any)->str:
    import re
    return re.sub(r'[^a-z0-9]+','_',str(v or '').lower()).strip('_')
def _primitive(entity:Mapping[str,Any])->Optional[str]:
    c=str(entity.get('constructor') or '')
    if c.startswith('primitive:'):
        p=c.split(':',1)[1]
        return p if p in GENERIC_PRIMITIVES else None
    tags={str(x) for x in entity.get('semanticTags',[])}
    for p in GENERIC_PRIMITIVES:
        if p in tags:return p
    return None

def resolve_reusable_form(label:str,tags:Iterable[str])->Dict[str,Any]:
    norm=_slug(label); tagset={_slug(x) for x in tags}
    fallback=None
    for row in _registry().get('forms',[]):
        aliases={_slug(x) for x in row.get('aliases',[])}
        if norm and norm in aliases:
            return {'status':'REUSABLE_FORM_FOUND','form':row['form'],'style':deepcopy(row.get('style',{})),'source':'certified_reusable_drawable_registry'}
        hints={_slug(x) for x in row.get('semanticHints',[])}
        if row.get('form')=='generic_graspable' and hints and hints.issubset(tagset): fallback=row
    if fallback:
        return {'status':'REUSABLE_FORM_FOUND','form':fallback['form'],'style':deepcopy(fallback.get('style',{})),'source':'semantic_hint_fallback'}
    return {'status':'UNSUPPORTED_DRAWABLE_FORM','form':None}

def _asset_candidates(entity:Mapping[str,Any])->List[Dict[str,Any]]:
    rows=entity.get('assetCandidates') or entity.get('visual',{}).get('assetCandidates') or []
    return [dict(x) for x in rows if isinstance(x,Mapping)]

def _resolve_visual_method(entity:Mapping[str,Any], primitive:Optional[str])->Dict[str,Any]:
    # Assets must pass the strong multidimensional gate; no evidence means construction.
    candidates=_asset_candidates(entity)
    if candidates:
        decision=resolve_asset(candidates,structural=True)
        if decision.get('status')=='ASSET_SELECTED':
            return {'method':'FIT_ASSET','decision':decision}
    # Story props first use the reusable drawable registry; primitive tags remain affordance truth, not forced visual form.
    if entity.get('kind')=='rigid_object' and not str(entity.get('constructor') or '').startswith('primitive:'):
        form=resolve_reusable_form(str(entity.get('label') or ''),entity.get('semanticTags',[]))
        if form['status']=='REUSABLE_FORM_FOUND':
            return {'method':'REUSABLE_DRAWABLE_FORM','form':form['form'],'style':form.get('style',{}),'decision':form}
    if primitive:
        return {'method':'GENERIC_CONSTRUCTOR','constructor':primitive,'decision':{'status':'CONSTRUCT_REQUIRED'}}
    form=resolve_reusable_form(str(entity.get('label') or ''),entity.get('semanticTags',[]))
    if form['status']=='REUSABLE_FORM_FOUND':
        return {'method':'REUSABLE_DRAWABLE_FORM','form':form['form'],'style':form.get('style',{}),'decision':form}
    return {'method':'ARTIST_REQUIRED','decision':{'status':'ARTIST_REQUIRED','role':'OBJECT_ARTIST'}}

def _component_map(temporal:Mapping[str,Any])->Dict[str,Any]:
    comp=temporal['environmentGrounding']['environmentComposition']
    return {c['id']:c for c in comp.get('components',[])}

def _active_frame(temporal:Mapping[str,Any],shot:Mapping[str,Any])->Mapping[str,Any]:
    lo,hi=shot['sourceFrameRange']; idx=max(0,min(len(temporal['renderFrames'])-1,(lo+hi)//2))
    return temporal['renderFrames'][idx]

def _focus_world(temporal:Mapping[str,Any],shot:Mapping[str,Any])->Tuple[float,float,float]:
    fr=_active_frame(temporal,shot)
    obj=(fr.get('objects') or [{}])[0]
    if isinstance(obj.get('positionWorld3d'),list) and len(obj['positionWorld3d'])==3:
        return tuple(float(x) for x in obj['positionWorld3d'])
    tr=fr.get('worldActorTransform') or {}; p=tr.get('positionWorld3d') or [0,0,0]
    return tuple(float(x) for x in p)

def _distance_to_focus(e:Mapping[str,Any],focus:Tuple[float,float,float])->float:
    p=(e.get('transform') or {}).get('position') or {}
    if not p:return 999.0
    return math.dist((float(p.get('x',0)),float(p.get('y',0)),float(p.get('z',0))),focus)

def _environment_selection(scene:Mapping[str,Any],temporal:Mapping[str,Any],shot:Mapping[str,Any])->List[Mapping[str,Any]]:
    lod=SHOT_LOD.get(shot['camera']['shotType'],'medium'); focus=_focus_world(temporal,shot)
    env=[e for e in scene['entities'] if e.get('kind')=='environment_structure' and 'semantic_geometry_proxy' not in set(e.get('semanticTags',[]))]
    # Product/display children are rendered semantically by their parent storage constructor, not as independent boxes.
    env=[e for e in env if e.get('label') not in {'product_row'}]
    if lod=='wide':
        # Choose a small, spatially separated storage sample instead of drawing every repeated bank.
        storages=[e for e in env if _primitive(e)=='storage']
        chosen_storage=[]
        if storages:
            first=min(storages,key=lambda x:_distance_to_focus(x,focus)); chosen_storage=[first]
            if len(storages)>1:
                p0=(first.get('transform') or {}).get('position') or {}
                second=max((e for e in storages if e is not first),key=lambda e: math.hypot(float(((e.get('transform') or {}).get('position') or {}).get('x',0))-float(p0.get('x',0)),float(((e.get('transform') or {}).get('position') or {}).get('z',0))-float(p0.get('z',0))))
                chosen_storage.append(second)
        out=[]
        chosen_ids={e['id'] for e in chosen_storage}
        for e in sorted(env,key=lambda x:_distance_to_focus(x,focus)):
            p=_primitive(e); tags=set(e.get('semanticTags',[]))
            if p=='path' and 'floor_edge' not in tags: continue
            if p=='storage' and e['id'] not in chosen_ids: continue
            if p=='wall' and e.get('id') not in {'shell:back'}: continue
            out.append(e)
        return out[:12]
    radius={'medium':4.0,'close':1.55,'insert':1.25}[lod]
    nearby=[e for e in env if _distance_to_focus(e,focus)<=radius]
    nearby.sort(key=lambda x:_distance_to_focus(x,focus))
    # Detail shots receive only one support/environment context form plus a floor cue if available.
    if lod in {'close','insert'}:
        support=[e for e in nearby if _primitive(e) in {'storage','work_surface','surface','container','fixture','equipment'}]
        return support[:1]
    # Medium: at most three relevant pieces, prioritizing semantic furniture over walls.
    ranked=sorted(nearby,key=lambda e:(0 if _primitive(e) in {'storage','work_surface','container','fixture','equipment','seat'} else 1,_distance_to_focus(e,focus)))
    return ranked[:1]

def compile_drawable_story(story_text:str)->Dict[str,Any]:
    temporal=compile_unified_story_temporal(story_text)
    cinema=compile_story_cinema(story_text)
    scene=temporal['nexSceneSpec']; comp_map=_component_map(temporal)
    entity_map={e['id']:e for e in scene['entities']}
    shots=[]
    for shot in cinema['shots']:
        lod=SHOT_LOD.get(shot['camera']['shotType'],'medium')
        selected_env=_environment_selection(scene,temporal,shot)
        specs=[]
        for e in selected_env:
            p=_primitive(e); method=_resolve_visual_method(e,p); c=comp_map.get(e['id'],{})
            specs.append({
                'schema':DRAWABLE_SCHEMA,'entityId':e['id'],'kind':e.get('kind'),'label':e.get('label'),
                'drawableRole':p or 'environment_form','structuralTruthRef':e['id'],'method':method,
                'worldBounds':deepcopy(e.get('spatial',{}).get('bounds')),'worldTransform':deepcopy(e.get('transform')),
                'semanticTags':deepcopy(e.get('semanticTags',[])),'semanticGeometry':deepcopy(c.get('geometry',{})),
                'shotLOD':lod,'rawBoundsRenderable':False,'textLabelStructuralAuthority':False,
            })
        # Persistent story props receive reusable-form / artist resolution, never a random whole-body asset.
        # Include nearby/static story props too (e.g. destination containers); renderer/camera culls what is outside the shot.
        for e in scene['entities']:
            if e.get('kind')!='rigid_object' or 'semantic_geometry_proxy' in set(e.get('semanticTags',[])) or str(e.get('id','')).startswith('set:'):
                continue
            p=_primitive(e); method=_resolve_visual_method(e,p)
            specs.append({'schema':DRAWABLE_SCHEMA,'entityId':e['id'],'kind':e.get('kind'),'label':e.get('label'),'drawableRole':p or 'story_object','structuralTruthRef':e['id'],'method':method,'worldBounds':deepcopy(e.get('spatial',{}).get('bounds')),'worldTransform':deepcopy(e.get('transform')),'semanticTags':deepcopy(e.get('semanticTags',[])),'semanticGeometry':{},'shotLOD':lod,'rawBoundsRenderable':False,'textLabelStructuralAuthority':False})
        shots.append({'shotId':shot['shotId'],'shotType':shot['camera']['shotType'],'lod':lod,'sourceFrameRange':shot['sourceFrameRange'],'drawableSpecs':specs,'camera':deepcopy(shot['camera']),'subjectIds':deepcopy(shot.get('subjectIds',[]))})
    return {'schema':SCHEMA,'sourceText':story_text,'sceneId':scene['sceneId'],'nexSceneSpec':scene,'temporal':temporal,'cinema':cinema,'shots':shots,'invariants':{'rawPhysicalBoundsAreHiddenTruth':True,'lowConfidenceAssetFailsClosed':True,'wholeBodyAssetsStructuralAuthority':False,'samePhysicalWorldAuthority':True}}


def drawable_capabilities()->Dict[str,Any]:
    return {'schema':'WhiteboardDrawableCapabilitiesV1','genericPrimitives':sorted(GENERIC_PRIMITIVES),'shotLOD':deepcopy(SHOT_LOD),'assetPolicy':'MULTIDIMENSIONAL_FITNESS_OR_CONSTRUCT','unknownFormPolicy':'ARTIST_REQUIRED','rawBoundsProductionRendering':False}


def compile_drawable_environment(environment_id:str, requested_primitives:Optional[Iterable[str]]=None, topology:Optional[str]=None)->Dict[str,Any]:
    comp=compose_environment(environment_id, requested_primitives=requested_primitives, topology=topology)
    specs=[]
    for c in comp.get('components',[]):
        primitive=c.get('primitive')
        if primitive not in GENERIC_PRIMITIVES: continue
        specs.append({'schema':DRAWABLE_SCHEMA,'entityId':c['id'],'kind':'environment_structure','label':c.get('role'),'drawableRole':primitive,'structuralTruthRef':c['id'],'method':{'method':'GENERIC_CONSTRUCTOR','constructor':primitive,'decision':{'status':'CONSTRUCT_REQUIRED'}},'worldBounds':deepcopy(c.get('bounds')),'worldTransform':{'position':deepcopy(c.get('position'))},'semanticTags':deepcopy(c.get('semanticTags',[])),'semanticGeometry':deepcopy(c.get('geometry',{})),'shotLOD':'wide','rawBoundsRenderable':False,'textLabelStructuralAuthority':False})
    return {'schema':'WhiteboardDrawableEnvironmentV1','environmentId':comp.get('environmentId'),'sourceMode':comp.get('constructionMode'),'drawableSpecs':specs,'constructorSignature':[x['drawableRole'] for x in specs]}
