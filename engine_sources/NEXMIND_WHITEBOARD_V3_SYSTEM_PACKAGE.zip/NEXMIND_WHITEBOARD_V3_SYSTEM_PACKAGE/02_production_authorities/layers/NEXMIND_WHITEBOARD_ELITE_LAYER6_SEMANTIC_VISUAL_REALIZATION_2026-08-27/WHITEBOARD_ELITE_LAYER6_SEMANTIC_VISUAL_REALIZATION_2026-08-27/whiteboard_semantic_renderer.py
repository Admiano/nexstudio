from __future__ import annotations
import json, math, os, subprocess, sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
from PIL import Image, ImageDraw, ImageFont

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from semantic_drawable_projection import compile_drawable_story

W,H=1280,720
INK=(22,25,30); SECONDARY=(95,102,110); FAINT=(194,199,204); ACCENT=(246,183,45); PAPER=(253,252,248)


def _font(size:int,bold=False):
    paths=['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf']
    for p in paths:
        if Path(p).exists():return ImageFont.truetype(p,size)
    return ImageFont.load_default()

def _lerp(a,b,t):return a+(b-a)*t
def _crop_pt(p,v):
    sx=max(1e-6,v['max']['x']-v['min']['x']);sy=max(1e-6,v['max']['y']-v['min']['y'])
    return ((p[0]-v['min']['x'])/sx*W,(p[1]-v['min']['y'])/sy*H)
def _raw_project(p,d):
    x=p[0]/max(.001,d['x']);y=p[1]/max(.001,d['y']);z=p[2]/max(.001,d['z'])
    return [.50+x*.72-z*.34,.86-y*.68-z*.22]
def _projection_fit(comp):
    d=comp['dimensions'];pts=[]
    for c in comp['components']:
        b=c['bounds']
        for x in (b['min']['x'],b['max']['x']):
            for y in (b['min']['y'],b['max']['y']):
                for z in (b['min']['z'],b['max']['z']):pts.append(_raw_project([x,y,z],d))
    xmin=min(p[0] for p in pts);xmax=max(p[0] for p in pts);ymin=min(p[1] for p in pts);ymax=max(p[1] for p in pts);m=.055
    def f(p):return [m+(p[0]-xmin)/max(1e-6,xmax-xmin)*(1-2*m),m+(p[1]-ymin)/max(1e-6,ymax-ymin)*(1-2*m)]
    return lambda p:f(_raw_project(p,d))

def _bounds_points(bounds):
    mn,mx=bounds['min'],bounds['max']
    return [[x,y,z] for x in (mn['x'],mx['x']) for y in (mn['y'],mx['y']) for z in (mn['z'],mx['z'])]
def _project_bbox(bounds,project,v):
    pts=[_crop_pt(tuple(project(p)),v) for p in _bounds_points(bounds)]
    xs=[p[0] for p in pts]; ys=[p[1] for p in pts]
    return (min(xs),min(ys),max(xs),max(ys))
def _clamp_rect(r,pad=2):
    x0,y0,x1,y1=r; x0,x1=sorted((float(x0),float(x1))); y0,y1=sorted((float(y0),float(y1))); return (x0,y0,x1,y1)
def _line(d,pts,fill=INK,width=4):
    if len(pts)>=2:d.line(pts,fill=fill,width=width,joint='curve')
def _white_underlay(d,pts,width):
    if len(pts)>=2:d.line(pts,fill=PAPER,width=width+9,joint='curve')
def _rounded(d,r,radius=10,outline=INK,width=4,fill=None):
    d.rounded_rectangle(_clamp_rect(r),radius=max(2,int(radius)),fill=fill,outline=outline,width=max(1,int(width)))
def _ellipse(d,r,outline=INK,width=4,fill=None):d.ellipse(_clamp_rect(r),fill=fill,outline=outline,width=max(1,int(width)))

def _draw_storage(d,r,lod,geom,tags,focus_y=None):
    x0,y0,x1,y1=r; w=max(1,x1-x0);h=max(1,y1-y0)
    if lod in {'close','insert'}:
        yy=float(focus_y if focus_y is not None else y0+h*.34)+48
        yy=max(y0+18,min(y1-18,yy))
        _line(d,[(x0,yy),(x1,yy)],width=6)
        _line(d,[(x0+10,yy-65),(x0+10,yy+38)],fill=SECONDARY,width=3)
        _line(d,[(x1-10,yy-65),(x1-10,yy+38)],fill=SECONDARY,width=3)
        return
    # Open shelf/rack: no enclosing rectangle; use uprights + shelves + small contents.
    _line(d,[(x0+0.08*w,y1),(x0+0.08*w,y0+0.04*h)],width=5)
    _line(d,[(x1-0.08*w,y1),(x1-0.08*w,y0+0.04*h)],width=5)
    levels=max(2,int(geom.get('levels',4)))
    for i in range(levels+1):
        yy=y1-(h*.10+i*(h*.78/levels)); _line(d,[(x0+0.04*w,yy),(x1-0.02*w,yy)],width=4)
    if lod in {'wide','medium'}:
        rows=levels if lod=='medium' else min(3,levels)
        cols=5 if lod=='medium' else 3
        for j in range(rows):
            yy=y1-h*.16-j*(h*.78/max(1,levels))
            for i in range(cols):
                cx=x0+w*(.18+i*(.64/max(1,cols-1)))
                bw=max(5,w*.08); bh=max(8,h*.055)
                _rounded(d,(cx-bw/2,yy-bh, cx+bw/2,yy),radius=3,outline=SECONDARY,width=2)

def _draw_work_surface(d,r,lod,geom,tags):
    x0,y0,x1,y1=r;w=x1-x0;h=y1-y0; yy=y0+h*.30
    _line(d,[(x0,yy),(x1,yy)],width=6)
    _line(d,[(x0+w*.12,yy),(x0+w*.12,y1)],width=4);_line(d,[(x1-w*.12,yy),(x1-w*.12,y1)],width=4)
    if lod=='wide': _line(d,[(x0+w*.12,y1),(x1-w*.12,y1)],fill=FAINT,width=2)

def _draw_opening(d,r,lod,geom,tags):
    x0,y0,x1,y1=r;w=x1-x0;h=y1-y0
    _line(d,[(x0,y1),(x0,y0),(x1,y0),(x1,y1)],width=5)
    if lod!='wide':
        _line(d,[(x0+w*.56,y0+h*.06),(x0+w*.56,y1)],fill=SECONDARY,width=3)
        _ellipse(d,(x0+w*.48,y0+h*.50,x0+w*.52,y0+h*.54),outline=SECONDARY,width=2)

def _draw_wall(d,r,lod,geom,tags):
    x0,y0,x1,y1=r
    # Only a clean architectural baseline/corner; never a bounding rectangle.
    _line(d,[(x0,y1),(x1,y1)],fill=SECONDARY,width=3)
    if lod=='wide':_line(d,[(x0,y1),(x0,y0+0.18*(y1-y0))],fill=FAINT,width=2)

def _draw_surface(d,r,lod,geom,tags):
    x0,y0,x1,y1=r; _line(d,[(x0,y1),(x1,y1)],fill=SECONDARY,width=3)

def _draw_path(d,r,lod,geom,tags):
    if lod=='wide':
        x0,y0,x1,y1=r;_line(d,[(x0,y1),(x1,y1)],fill=FAINT,width=2)

def _draw_seat(d,r,lod,geom,tags):
    x0,y0,x1,y1=r;w=x1-x0;h=y1-y0;sy=y0+h*.55
    _line(d,[(x0+w*.15,sy),(x1-w*.12,sy)],width=5)
    _line(d,[(x0+w*.2,sy),(x0+w*.14,y1)],width=4);_line(d,[(x1-w*.18,sy),(x1-w*.10,y1)],width=4)
    _line(d,[(x0+w*.18,sy),(x0+w*.15,y0+h*.12)],width=4);_line(d,[(x0+w*.15,y0+h*.12),(x1-w*.25,y0+h*.12)],width=4)

def _draw_container(d,r,lod,geom,tags):
    x0,y0,x1,y1=r;w=x1-x0;h=y1-y0
    poly=[(x0+w*.08,y0+h*.25),(x1-w*.08,y0+h*.25),(x1-w*.18,y1),(x0+w*.18,y1)]
    _line(d,poly+[poly[0]],width=4)
    if lod!='wide':
        _line(d,[(x0+w*.28,y0+h*.25),(x0+w*.40,y0-h*.05),(x1-w*.40,y0-h*.05),(x1-w*.28,y0+h*.25)],fill=SECONDARY,width=3)

def _draw_fixture(d,r,lod,geom,tags):
    x0,y0,x1,y1=r;w=x1-x0;h=y1-y0
    if geom.get('panel') or 'presentation_surface' in tags:
        _rounded(d,(x0,y0,x1,y1),radius=4,outline=SECONDARY,width=4)
        if lod=='medium':_line(d,[(x0+w*.12,y0+h*.65),(x1-w*.18,y0+h*.65)],fill=FAINT,width=2)
    else:
        _line(d,[(x0+w*.5,y0),(x0+w*.5,y1)],width=5);_ellipse(d,(x0+w*.24,y0,x0+w*.76,y0+h*.28),outline=SECONDARY,width=3)

def _draw_signage(d,r,lod,geom,tags):
    x0,y0,x1,y1=r; _rounded(d,(x0,y0,x1,y1),radius=6,outline=SECONDARY,width=3)
    # blank visual rhythm, no baked words
    if lod!='insert':
        _line(d,[(x0+(x1-x0)*.18,y0+(y1-y0)*.50),(x1-(x1-x0)*.18,y0+(y1-y0)*.50)],fill=FAINT,width=2)

def _draw_equipment(d,r,lod,geom,tags):
    x0,y0,x1,y1=r;w=x1-x0;h=y1-y0
    _rounded(d,(x0,y0,x1,y1),radius=7,outline=INK,width=4)
    _rounded(d,(x0+w*.16,y0+h*.14,x1-w*.16,y0+h*.48),radius=4,outline=SECONDARY,width=2)
    if lod!='wide':
        for i in range(2):_ellipse(d,(x0+w*(.30+i*.28),y0+h*.65,x0+w*(.38+i*.28),y0+h*.73),outline=SECONDARY,width=2)

_ENV_DRAW={'storage':_draw_storage,'work_surface':_draw_work_surface,'opening':_draw_opening,'wall':_draw_wall,'surface':_draw_surface,'path':_draw_path,'seat':_draw_seat,'container':_draw_container,'fixture':_draw_fixture,'signage':_draw_signage,'equipment':_draw_equipment}

def _draw_environment_spec(d,spec,project,v,focus_px=None):
    b=spec.get('worldBounds');
    if not b:return
    r=_project_bbox(b,project,v); prim=spec.get('drawableRole');fn=_ENV_DRAW.get(prim)
    if fn:
        if prim=='storage': fn(d,r,spec.get('shotLOD','medium'),spec.get('semanticGeometry') or {},set(spec.get('semanticTags',[])),(focus_px or (None,None))[1])
        else: fn(d,r,spec.get('shotLOD','medium'),spec.get('semanticGeometry') or {},set(spec.get('semanticTags',[])))

def _bounded_viewport(center, width, height):
    cx,cy=center; width=min(1.0,max(.16,width)); height=min(1.0,max(.16,height))
    x0=max(0.0,min(1.0-width,cx-width/2)); y0=max(0.0,min(1.0-height,cy-height/2))
    return {"min":{"x":x0,"y":y0},"max":{"x":x0+width,"y":y0+height}}

def _visual_viewport(shot,fr,project):
    lod=shot['lod']; base=shot['camera']['viewport']
    if lod=='wide': return base
    obj=(fr.get('objects') or [{}])[0]; opos=obj.get('positionWorld3d')
    tr=fr.get('worldActorTransform') or {}; root=tr.get('positionWorld3d') or [0,0,0]
    oq=project(opos) if isinstance(opos,list) else project(root)
    if lod=='medium':
        rq=project([root[0],1.0,root[2]]); center=((oq[0]+rq[0])/2,(oq[1]+rq[1])/2); return _bounded_viewport(center,.58,.58)
    # Detail shots center on the actual physical interaction object, with enough room for wrist/support context.
    return _bounded_viewport((oq[0],oq[1]),.34 if lod=='close' else .29,.29 if lod=='close' else .25)

def _actor_world_point(point,transform):
    local=(point or {}).get('actorLocal3d') or (point or {}).get('world3d')
    if not local:return None
    root=(transform or {}).get('positionWorld3d') or [0,0,0];yaw=math.radians(float((transform or {}).get('facingYawDeg',0)));c,s=math.cos(yaw),math.sin(yaw)
    x=float(root[0])+c*float(local[0])+s*float(local[2]);z=float(root[2])-s*float(local[0])+c*float(local[2]);y=float(root[1])+float(local[1])
    return [x,y,z]

def _actor_point(perf,key,transform,project,v):
    src=perf.get(key)
    if not src:return None
    w=_actor_world_point(src,transform);return _crop_pt(tuple(project(w)),v) if w else None

def _draw_performer(d,perf,transform,project,v,lod='medium',focus_world=None):
    if not isinstance(perf,Mapping) or perf.get('status')!='OK':return
    def P(k):return _actor_point(perf,k,transform,project,v)
    if lod in {'close','insert'}:
        focus_px=_crop_pt(tuple(project(focus_world)),v) if isinstance(focus_world,list) else None
        candidates=[]
        for side in ('L','R'):
            w=P('wrist'+side)
            if w: candidates.append((math.dist(w,focus_px) if focus_px else 0,side,w))
        if candidates:
            _,side,wrist=min(candidates,key=lambda x:x[0]); elbow=P('elbow'+side); shoulder=P('shoulder'+side)
            pts=[p for p in (shoulder,elbow,wrist) if p]
            if len(pts)>=2:_white_underlay(d,pts,8);_line(d,pts,width=8)
            f=perf.get('fingers'+side) or {}; _ellipse(d,(wrist[0]-12,wrist[1]-9,wrist[0]+12,wrist[1]+9),outline=PAPER,width=9,fill=PAPER);_ellipse(d,(wrist[0]-10,wrist[1]-7,wrist[0]+10,wrist[1]+7),outline=INK,width=3)
            # Readable five-digit fan anchored at the certified wrist. Direction follows the physical target; it cannot change wrist/contact truth.
            if focus_px:
                vx,vy=focus_px[0]-wrist[0],focus_px[1]-wrist[1]; mag=max(1.0,math.hypot(vx,vy)); ux,uy=vx/mag,vy/mag; px,py=-uy,ux
                state=str(f.get('semanticState') or 'open')
                length=38 if state=='grip' else 48
                spreads=[-0.42,-0.20,0.0,0.20,0.38]
                for k,sp in enumerate(spreads):
                    L=length*(0.78+0.06*k if k<3 else 0.94-0.06*(k-3)); ex=wrist[0]+ux*L+px*sp*18; ey=wrist[1]+uy*L+py*sp*18
                    pts=[(wrist[0]+px*sp*5,wrist[1]+py*sp*5),(wrist[0]+ux*L*.55+px*sp*12,wrist[1]+uy*L*.55+py*sp*12),(ex,ey)]
                    _white_underlay(d,pts,2);_line(d,pts,width=3)
            else:
                for digit in f.get('digits',[]):
                    qpts=digit.get('polyline') or []
                    if len(qpts)<2:continue
                    palm=f.get('palmCenter') or qpts[0]; scale_px=55
                    dpts=[(wrist[0]+(q[0]-palm[0])*scale_px,wrist[1]-(q[1]-palm[1])*scale_px) for q in qpts]
                    _white_underlay(d,dpts,2);_line(d,dpts,width=3)
        return
    torso=[]
    for k in ('neck','chest','spine','pelvis'):
        src=perf.get('torso',{}).get(k)
        if src:
            w=_actor_world_point(src,transform);torso.append(_crop_pt(tuple(project(w)),v))
    segs=[]
    if len(torso)>1:segs.append(torso)
    for a,b in [('shoulderL','elbowL'),('elbowL','wristL'),('shoulderR','elbowR'),('elbowR','wristR'),('hipL','kneeL'),('hipR','kneeR')]:
        pa,pb=P(a),P(b)
        if pa and pb:segs.append([pa,pb])
    for side in ('L','R'):
        knee=P('knee'+side);foot=(perf.get('foot'+side) or {}).get('ankle')
        if knee and foot:
            fw=_actor_world_point(foot,transform);segs.append([knee,_crop_pt(tuple(project(fw)),v)])
    for pts in segs:_white_underlay(d,pts,7)
    for pts in segs:_line(d,pts,width=7)
    head=P('head')
    if head:
        scale=max(.35,min(2.2,1/max(.18,v['max']['x']-v['min']['x'])))
        r=22*scale;_ellipse(d,(head[0]-r,head[1]-r,head[0]+r,head[1]+r),outline=PAPER,width=12,fill=PAPER);_ellipse(d,(head[0]-r,head[1]-r,head[0]+r,head[1]+r),outline=INK,width=5)
        # face/gaze cue
        _ellipse(d,(head[0]+r*.20,head[1]-r*.10,head[0]+r*.30,head[1]),outline=INK,width=2,fill=INK)
        _line(d,[(head[0]+r*.08,head[1]+r*.30),(head[0]+r*.32,head[1]+r*.28)],fill=SECONDARY,width=2)
    # Hands and fingers are white-masked to keep background lines from reading through them.
    if lod in {'close','insert','medium'}:
        for side in ('L','R'):
            f=perf.get('fingers'+side) or {}; wrist=P('wrist'+side)
            if not wrist:continue
            _ellipse(d,(wrist[0]-8,wrist[1]-8,wrist[0]+8,wrist[1]+8),outline=PAPER,width=8,fill=PAPER);_ellipse(d,(wrist[0]-6,wrist[1]-6,wrist[0]+6,wrist[1]+6),outline=INK,width=3)
            # Digit polylines are actor-local XY. Lift them near their actual wrist; preserve semantic state, not motion authorship.
            for digit in f.get('digits',[]):
                pts=digit.get('polyline') or []
                if len(pts)<2:continue
                palm=f.get('palmCenter') or pts[0]; scale_px=38 if lod in {'close','insert'} else 22
                dpts=[(wrist[0]+(q[0]-palm[0])*scale_px,wrist[1]-(q[1]-palm[1])*scale_px) for q in pts]
                _white_underlay(d,dpts,2);_line(d,dpts,width=2)

def _object_rect(center_px,size,lod):
    scale={'wide':.55,'medium':.85,'close':1.7,'insert':2.1}.get(lod,1.0);w=max(18,size[0]*scale);h=max(12,size[1]*scale)
    return (center_px[0]-w/2,center_px[1]-h/2,center_px[0]+w/2,center_px[1]+h/2)

def _draw_object_form(d,form,center,lod,style=None,highlight=False):
    style=style or {}; base={'wide':(32,18),'medium':(48,28),'close':(96,55),'insert':(112,62)}[lod];r=_object_rect(center,base,lod)
    x0,y0,x1,y1=r;w=x1-x0;h=y1-y0
    # white occlusion halo first
    _rounded(d,(x0-7,y0-7,x1+7,y1+7),radius=14,outline=PAPER,width=10,fill=PAPER)
    if form=='loaf':
        _rounded(d,r,radius=int(h*.45),outline=INK,width=5,fill=PAPER)
        for f in (.34,.50,.66):_line(d,[(x0+w*f,y0+h*.18),(x0+w*(f-.05),y0+h*.48)],fill=SECONDARY,width=2)
    elif form=='carry_container':
        poly=[(x0+w*.08,y0+h*.28),(x1-w*.08,y0+h*.28),(x1-w*.18,y1),(x0+w*.18,y1),(x0+w*.08,y0+h*.28)]
        _line(d,poly,width=5);_line(d,[(x0+w*.27,y0+h*.28),(x0+w*.39,y0-h*.18),(x1-w*.39,y0-h*.18),(x1-w*.27,y0+h*.28)],width=4)
        for f in (.32,.5,.68):_line(d,[(x0+w*f,y0+h*.35),(x0+w*f,y1-h*.08)],fill=FAINT,width=2)
    elif form=='book':
        _line(d,[(x0,y0+h*.12),(x0+w*.48,y0),(x0+w*.5,y1),(x0,y1-h*.10),(x0,y0+h*.12)],width=4);_line(d,[(x1,y0+h*.12),(x0+w*.52,y0),(x0+w*.5,y1),(x1,y1-h*.10),(x1,y0+h*.12)],width=4)
    elif form=='phone':
        _rounded(d,r,radius=8,outline=INK,width=5,fill=PAPER);_line(d,[(x0+w*.24,y1-h*.13),(x1-w*.24,y1-h*.13)],fill=SECONDARY,width=2)
    elif form=='cup':
        _line(d,[(x0+w*.15,y0),(x1-w*.15,y0),(x1-w*.24,y1),(x0+w*.24,y1),(x0+w*.15,y0)],width=4);_ellipse(d,(x1-w*.20,y0+h*.30,x1+w*.12,y0+h*.75),outline=INK,width=4)
    elif form=='bottle':
        _line(d,[(x0+w*.38,y0),(x0+w*.62,y0),(x0+w*.62,y0+h*.22),(x1-w*.10,y0+h*.36),(x1-w*.12,y1),(x0+w*.12,y1),(x0+w*.10,y0+h*.36),(x0+w*.38,y0+h*.22),(x0+w*.38,y0)],width=4)
    elif form=='ball':_ellipse(d,r,outline=INK,width=5,fill=PAPER)
    elif form=='writing_tool':_line(d,[(x0,y1),(x1,y0)],width=6)
    elif form=='terminal':_draw_equipment(d,r,lod,{'display':True},{'equipment'})
    elif form=='bag':
        _rounded(d,(x0,y0+h*.25,x1,y1),radius=10,outline=INK,width=5,fill=PAPER);_line(d,[(x0+w*.25,y0+h*.25),(x0+w*.34,y0),(x1-w*.34,y0),(x1-w*.25,y0+h*.25)],width=4)
    else:_rounded(d,r,radius=12,outline=INK,width=5,fill=PAPER)
    if highlight:_rounded(d,(x0-12,y0-12,x1+12,y1+12),radius=18,outline=ACCENT,width=4)

def _entity_form(spec):
    m=spec.get('method') or {}
    if m.get('method')=='REUSABLE_DRAWABLE_FORM':return m.get('form'),m.get('style',{})
    if m.get('method')=='GENERIC_CONSTRUCTOR':return m.get('constructor'),{}
    return 'generic_graspable',{}

def _object_state(frame,eid):
    for o in frame.get('objects') or []:
        if o.get('entityId')==eid:return o
    return None

def render_shot_frame(drawable:Mapping[str,Any],shot_index:int,frame_index:Optional[int]=None,*,include_debug_text=False)->Tuple[Image.Image,Dict[str,Any]]:
    shot=drawable['shots'][shot_index]; temporal=drawable['temporal']; scene=drawable['nexSceneSpec']; comp=temporal['environmentGrounding']['environmentComposition']; project=_projection_fit(comp);lod=shot['lod']
    lo,hi=shot['sourceFrameRange']; idx=(lo+hi)//2 if frame_index is None else max(lo,min(hi,int(frame_index)));fr=temporal['renderFrames'][idx];v=_visual_viewport(shot,fr,project)
    im=Image.new('RGB',(W,H),PAPER);d=ImageDraw.Draw(im)
    # subtle ground cue only
    if lod=='wide':_line(d,[(45,H-70),(W-45,H-70)],fill=FAINT,width=2)
    env_specs=[s for s in shot['drawableSpecs'] if s.get('kind')=='environment_structure']
    active_obj=(fr.get('objects') or [{}])[0]; active_pos=active_obj.get('positionWorld3d'); focus_px=_crop_pt(tuple(project(active_pos)),v) if isinstance(active_pos,list) else None
    # Draw far-to-near environment; renderer is semantic, not raw bounds.
    def depth(s):
        p=(s.get('worldTransform') or {}).get('position') or {};return float(p.get('z',0))
    for spec in sorted(env_specs,key=depth):_draw_environment_spec(d,spec,project,v,focus_px)
    # Secondary cast from scene may be shown in wide/medium with a simple idle performer glyph, but never replaces primary performer authority.
    if lod=='wide':
        for e in scene['entities']:
            if e.get('kind')=='person' and e.get('id')!='actor_0':
                p=(e.get('transform') or {}).get('position') or {}; q=_crop_pt(tuple(project([p.get('x',0),.9,p.get('z',0)])),v)
                if -50<q[0]<W+50 and -50<q[1]<H+50:
                    _ellipse(d,(q[0]-15,q[1]-72,q[0]+15,q[1]-42),outline=PAPER,width=10,fill=PAPER);_ellipse(d,(q[0]-14,q[1]-72,q[0]+14,q[1]-44),outline=SECONDARY,width=3);_line(d,[(q[0],q[1]-43),(q[0],q[1]+10)],fill=SECONDARY,width=4);_line(d,[(q[0],q[1]-18),(q[0]-18,q[1]+4)],fill=SECONDARY,width=3);_line(d,[(q[0],q[1]-18),(q[0]+18,q[1]+4)],fill=SECONDARY,width=3)
    # Primary actor, with paper underlay, gives real occlusion against scenery.
    _draw_performer(d,fr.get('performer'),fr.get('worldActorTransform'),project,v,lod,((fr.get('objects') or [{}])[0]).get('positionWorld3d'))
    # Persistent active object is drawn AFTER performer at state position, preserving entity identity.
    active_ids={o.get('entityId') for o in (fr.get('objects') or [])}
    for spec in shot['drawableSpecs']:
        if spec.get('kind')!='rigid_object' or spec.get('entityId','').startswith('set:'):continue
        state=_object_state(fr,spec['entityId'])
        pos=(state or {}).get('positionWorld3d')
        if not isinstance(pos,list):
            p=(spec.get('worldTransform') or {}).get('position') or {};pos=[p.get('x',0),p.get('y',0),p.get('z',0)]
        q=_crop_pt(tuple(project(pos)),v)
        form,style=_entity_form(spec);highlight=(spec['entityId'] in active_ids) and (bool((fr.get('contacts') or {}).get('active')) or ('CONTACT' in str(fr.get('stateAuthority','')).upper()))
        _draw_object_form(d,form,q,lod,style,highlight=highlight)
    # Close/insert contact cue: restrained accent arc, not text.
    if lod in {'close','insert'} and fr.get('contacts'):
        obj=(fr.get('objects') or [{}])[0];pos=obj.get('positionWorld3d')
        if isinstance(pos,list):
            q=_crop_pt(tuple(project(pos)),v);_ellipse(d,(q[0]-72,q[1]-48,q[0]+72,q[1]+48),outline=ACCENT,width=4)
    if include_debug_text:
        d.rectangle((0,0,W,42),fill=PAPER);d.text((16,8),f"{shot['shotType']}  physical frames {lo}-{hi}",font=_font(20,bold=True),fill=SECONDARY)
    meta={'shotId':shot['shotId'],'shotType':shot['shotType'],'lod':lod,'frameIndex':idx,'environmentDrawableCount':len(env_specs),'rawBoundsDrawn':0,'textLabelsUsedAsStructure':0}
    return im,meta

def render_contact_sheet(story_text:str,out_path:Path)->Dict[str,Any]:
    drawable=compile_drawable_story(story_text);ims=[];metas=[]
    for i in range(len(drawable['shots'])):
        im,m=render_shot_frame(drawable,i);ims.append(im);metas.append(m)
    cols=3;cellw=420;cellh=260;rows=math.ceil(len(ims)/cols);sheet=Image.new('RGB',(cols*cellw,rows*cellh),PAPER);sd=ImageDraw.Draw(sheet)
    for i,im in enumerate(ims):
        thumb=im.copy();thumb.thumbnail((cellw,232));x=(i%cols)*cellw+(cellw-thumb.width)//2;y=(i//cols)*cellh;sheet.paste(thumb,(x,y));sd.text(((i%cols)*cellw+10,y+234),f"Shot {i+1} · {metas[i]['shotType']}",font=_font(14),fill=SECONDARY)
    sheet.save(out_path)
    return {'schema':'WhiteboardContactSheetProofV1','path':str(out_path),'shots':len(ims),'shotMetrics':metas}

def render_proof_reel(story_text:str,out_mp4:Path,fps:int=24)->Dict[str,Any]:
    drawable=compile_drawable_story(story_text);tmp=out_mp4.parent/'_layer6_frames';tmp.mkdir(exist_ok=True);n=0
    for si,shot in enumerate(drawable['shots']):
        lo,hi=shot['sourceFrameRange'];count=max(14,int(float(drawable['cinema']['shots'][si]['durationHintSeconds'])*fps))
        for j in range(count):
            t=j/max(1,count-1);idx=lo if hi<=lo else lo+round((hi-lo)*max(0,min(1,(t-.28)/.62)))
            im,_=render_shot_frame(drawable,si,idx)
            # Choreography draw-on: reveal from left without exposing wireframe geometry.
            if t<.24:
                mask=Image.new('L',(W,H),0);md=ImageDraw.Draw(mask);md.rectangle((0,0,int(W*(t/.24)),H),fill=255)
                paper=Image.new('RGB',(W,H),PAPER);im=Image.composite(im,paper,mask)
                dd=ImageDraw.Draw(im);x=int(W*(t/.24));dd.line((x-16,50,x+30,68),fill=SECONDARY,width=8);dd.ellipse((x+23,62,x+39,78),fill=SECONDARY)
            im.save(tmp/f'{n:05d}.png');n+=1
    subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate',str(fps),'-i',str(tmp/'%05d.png'),'-c:v','libx264','-pix_fmt','yuv420p',str(out_mp4)],check=True)
    for p in tmp.glob('*.png'):
        p.unlink()
    tmp.rmdir()
    return {'schema':'WhiteboardVisualProofReelV1','path':str(out_mp4),'frames':n,'fps':fps,'shots':len(drawable['shots'])}
