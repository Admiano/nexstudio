from __future__ import annotations
from typing import Any, Dict, Mapping

def critique_render_evidence(contact_sheet_metrics:Mapping[str,Any], *, human_visual_scores:Mapping[str,float]|None=None)->Dict[str,Any]:
    rows=contact_sheet_metrics.get('shotMetrics',[])
    close=[r for r in rows if r.get('lod') in {'close','insert'}]
    wide=[r for r in rows if r.get('lod')=='wide']
    wide_n=max([r.get('environmentDrawableCount',0) for r in wide] or [0]);close_n=max([r.get('environmentDrawableCount',0) for r in close] or [0])
    structural={
        'rawBoundsSuppressed':all(r.get('rawBoundsDrawn')==0 for r in rows),
        'textLabelStructuralSubstitutionAbsent':all(r.get('textLabelsUsedAsStructure')==0 for r in rows),
        'closeLODReduced':(close_n < wide_n) if wide else True,
        'wideEnvironmentDrawableCount':wide_n,
        'closeMaxEnvironmentDrawableCount':close_n,
    }
    scores=dict(human_visual_scores or {})
    minimum=min(scores.values()) if scores else None
    return {'schema':'RenderedPixelArtCriticV1','pixelEvidenceReviewed':True,'structuralChecks':structural,'visualScores':scores,'minimumVisualScore':minimum,'eliteVisualBar':9.0,'visualGatePassed':bool(scores) and minimum>=9.0 and all(v for k,v in structural.items() if isinstance(v,bool))}
