from __future__ import annotations
import json, sys
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
for p in [ROOT,Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_VISUAL_FOUNDATION_ASSET_ARTIST_2026-08-27')]:
    if str(p) not in sys.path:sys.path.insert(0,str(p))
from semantic_drawable_projection import compile_drawable_story, compile_drawable_environment, resolve_reusable_form, drawable_capabilities, _resolve_visual_method
from whiteboard_semantic_renderer import _ENV_DRAW, render_shot_frame
from asset_fitness_resolver import resolve_asset
from truth_constrained_artists import build_artist_work_orders, validate_artist_result
from art_critic import critique_render_evidence

STORY='Ada walks into the shop and takes bread from the shelf.'

def test_all_required_generic_constructor_families_present():
    assert set(_ENV_DRAW)=={'wall','opening','surface','storage','seat','work_surface','path','container','fixture','signage','equipment'}

def test_drawable_story_never_authorizes_raw_bounds():
    d=compile_drawable_story(STORY)
    assert d['invariants']['rawPhysicalBoundsAreHiddenTruth'] is True
    assert all(s['rawBoundsRenderable'] is False for sh in d['shots'] for s in sh['drawableSpecs'])

def test_close_lod_is_materially_sparser_than_wide():
    d=compile_drawable_story(STORY)
    wide=max(len([x for x in sh['drawableSpecs'] if x['kind']=='environment_structure']) for sh in d['shots'] if sh['lod']=='wide')
    close=max(len([x for x in sh['drawableSpecs'] if x['kind']=='environment_structure']) for sh in d['shots'] if sh['lod'] in {'close','insert'})
    assert close < wide/2

def test_story_props_resolve_to_reusable_forms_without_whole_body_authority():
    d=compile_drawable_story(STORY)
    forms={(x['label'],x['method'].get('form')) for sh in d['shots'] for x in sh['drawableSpecs'] if x['kind']=='rigid_object'}
    assert ('bread','loaf') in forms and ('basket','carry_container') in forms
    assert d['invariants']['wholeBodyAssetsStructuralAuthority'] is False

def test_low_confidence_asset_must_construct():
    c={'assetId':'polished_wrong','semantic':.98,'pose':.42,'action':.91,'style':.88,'camera':.82,'editability':.35,'cleanliness':.94,'nonRemovableBackground':True}
    out=resolve_asset([c],structural=True)
    assert out['status']=='CONSTRUCT_REQUIRED'

def test_unknown_object_form_fails_to_artist_not_box():
    e={'id':'x','kind':'rigid_object','label':'unregistered_zeta_form','constructor':None,'semanticTags':['portable']}
    out=_resolve_visual_method(e,None)
    assert out['method']=='ARTIST_REQUIRED'

def test_unseen_environment_uses_same_primitive_compiler():
    requested=['wall','opening','surface','storage','seat','work_surface','path','container','fixture','signage','equipment']
    a=compile_drawable_environment('orbital habitat alpha',requested_primitives=requested)
    b=compile_drawable_environment('subterranean archive beta',requested_primitives=requested)
    assert a['sourceMode']=='GENERIC_PRIMITIVE_SYNTHESIS'
    assert b['sourceMode']=='GENERIC_PRIMITIVE_SYNTHESIS'
    assert a['constructorSignature']==b['constructorSignature']

def test_known_and_unseen_both_emit_generic_constructor_methods():
    known=compile_drawable_environment('classroom')
    unseen=compile_drawable_environment('floating observatory q',requested_primitives=['opening','storage','seat','equipment'])
    assert all(x['method']['method']=='GENERIC_CONSTRUCTOR' for x in known['drawableSpecs'])
    assert all(x['method']['method']=='GENERIC_CONSTRUCTOR' for x in unseen['drawableSpecs'])

def test_artist_dispatch_is_typed_and_contact_guard_rejects_change():
    truth={'sceneId':'s','performerFrames':[{'schema':'f'}],'identityContract':{'id':'a'},'environmentComposition':{'components':[1]},'affordanceObjects':[{'id':'o'}],'certifiedInteractions':[{'id':'i'}],'renderedFrames':['frame.png']}
    orders=build_artist_work_orders(truth,{})
    assert set(orders['roles'])=={'CHARACTER_ARTIST','ENVIRONMENT_ARTIST','OBJECT_ARTIST','INTERACTION_POSE_ARTIST','ART_CRITIC'}
    order=next(x for x in orders['orders'] if x['role']=='INTERACTION_POSE_ARTIST')
    result={'role':'INTERACTION_POSE_ARTIST','preservedTruth':order['immutable'],'enhancements':['silhouetteReadability'],'changedContactAnchors':True}
    assert validate_artist_result(order,result)['reason']=='ARTIST_CHANGED_CERTIFIED_CONTACT'

def test_rendered_frame_contains_no_debug_text_by_default():
    d=compile_drawable_story(STORY); im,m=render_shot_frame(d,0)
    assert im.size==(1280,720); assert m['rawBoundsDrawn']==0 and m['textLabelsUsedAsStructure']==0

def test_close_frame_environment_count_is_one():
    d=compile_drawable_story(STORY)
    for i,sh in enumerate(d['shots']):
        if sh['lod'] in {'close','insert'}:
            _,m=render_shot_frame(d,i); assert m['environmentDrawableCount']<=1

def test_capabilities_forbid_raw_bounds():
    c=drawable_capabilities(); assert c['rawBoundsProductionRendering'] is False and c['unknownFormPolicy']=='ARTIST_REQUIRED'

def test_art_critic_cannot_pass_without_real_scores():
    r=critique_render_evidence({'shotMetrics':[{'lod':'wide','environmentDrawableCount':8,'rawBoundsDrawn':0,'textLabelsUsedAsStructure':0},{'lod':'close','environmentDrawableCount':1,'rawBoundsDrawn':0,'textLabelsUsedAsStructure':0}]})
    assert r['visualGatePassed'] is False

def test_visual_gate_requires_every_score_nine_or_more():
    scores={'scene readability':9.3,'interaction clarity':8.9}
    r=critique_render_evidence({'shotMetrics':[{'lod':'wide','environmentDrawableCount':8,'rawBoundsDrawn':0,'textLabelsUsedAsStructure':0},{'lod':'close','environmentDrawableCount':1,'rawBoundsDrawn':0,'textLabelsUsedAsStructure':0}]},human_visual_scores=scores)
    assert r['visualGatePassed'] is False and r['minimumVisualScore']==8.9
