from __future__ import annotations
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
POST=Path('/mnt/data/nexmind-runtime/overlays/WHITEBOARD_ELITE_LOCAL_ILLUSTRATION_TO_WHITEBOARD_V1_2026-09-05/src')
for p in [HERE,POST]:
    if str(p) not in sys.path: sys.path.insert(0,str(p))
from semantic_group_bridge import compile_semantic_group_manifest
from pipeline import run_pipeline

def run_bound(story:str,illustration:Path,bindings:Path,out_dir:Path,visual_candidate_path:Path|None=None,beat_ids=None,duration=6.0,fps=25,strict_contact=True):
    visual=None
    if visual_candidate_path:
        data=json.loads(Path(visual_candidate_path).read_text())
        visual=data.get('candidate') or data
    manifest=compile_semantic_group_manifest(story,Path(bindings),visual, set(beat_ids or ['B1']), strict_contact=strict_contact)
    out_dir=Path(out_dir); out_dir.mkdir(parents=True,exist_ok=True)
    sem=out_dir/'SEMANTIC_GROUP_MANIFEST_V2.json'; sem.write_text(json.dumps(manifest,indent=2)+'\n')
    metrics=run_pipeline(Path(illustration),out_dir,duration,fps,sem)
    trace={
      'schema':'NexMindWhiteboardSemanticBoundExecutionV1',
      'story':story,'illustration':str(illustration),'bindings':str(bindings),
      'semanticManifest':str(sem),'groupingMode':metrics.get('groupingMode'),
      'semanticGroupOrder':[{'order':g['order_index'],'label':g['label'],'phase':g.get('drawPhase'),'role':g['role'],'entityIds':g.get('entityIds',[]),'contactCritical':g.get('contactCritical',False)} for g in manifest['groups']],
      'contactBindingRequired':manifest['semanticAuthority']['contactBindingRequired'],
      'contactBindingMatched':manifest['semanticAuthority']['contactBindingMatched'],
      'visualDirectorStatus':manifest['semanticAuthority']['visualDirector'],
      'sceneConception':manifest['semanticAuthority'].get('sceneConception'),
      'technicalPass':metrics.get('technicalPass'),
      'metrics':metrics,
      'truthBoundary':'This proves semantic authority -> pixel group -> draw-order binding. It does not prove live P1/P2 model inference or source illustration quality.'
    }
    (out_dir/'SEMANTIC_EXECUTION_TRACE.json').write_text(json.dumps(trace,indent=2)+'\n')
    return trace

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('story'); ap.add_argument('illustration'); ap.add_argument('bindings'); ap.add_argument('out'); ap.add_argument('--duration',type=float,default=6); ap.add_argument('--fps',type=int,default=25); ap.add_argument('--allow-missing-contact',action='store_true')
    a=ap.parse_args(); print(json.dumps(run_bound(a.story,Path(a.illustration),Path(a.bindings),Path(a.out),duration=a.duration,fps=a.fps,strict_contact=not a.allow_missing_contact),indent=2))
