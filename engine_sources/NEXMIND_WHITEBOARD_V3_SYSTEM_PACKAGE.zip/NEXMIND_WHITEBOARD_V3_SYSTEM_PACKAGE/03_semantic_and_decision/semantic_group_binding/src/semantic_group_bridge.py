from __future__ import annotations
import json, sys, hashlib
from pathlib import Path
from copy import deepcopy
from typing import Any

OVERLAYS=Path('/mnt/data/nexmind-runtime/overlays')
L1=OVERLAYS/'WHITEBOARD_ELITE_LAYER1_STORY_SCENE_COMPOSER_2026-08-27'
L2=OVERLAYS/'WHITEBOARD_ELITE_LAYER2_WHITEBOARD_PERFORMER_2026-08-27'
L3=OVERLAYS/'WHITEBOARD_ELITE_LAYER3_ENVIRONMENT_COMPOSER_2026-08-27'
L4=OVERLAYS/'WHITEBOARD_ELITE_LAYER4_ACTION_TEMPORAL_STATE_2026-08-27'
L5=OVERLAYS/'WHITEBOARD_ELITE_LAYER5_CINEMATOGRAPHY_CHOREOGRAPHY_2026-08-27'
P12=Path(__file__).resolve().parents[1]/'authorities/p1p2/nexmind-god-mode-p1p2/src'
for p in [L1,L2,L3,L4,L5,P12]:
    if str(p) not in sys.path: sys.path.insert(0,str(p))

from story_scene_composer import compose_story
from whiteboard_performer import story_performer_sequence
from environment_composer import ground_story_environment
from temporal_state_compiler import compile_story_temporal
from physical_scene_fusion import compile_unified_story_temporal
from cinema_choreography import compile_story_cinema
from nexmind_god_mode.contracts import validate_visual_candidate

CANVAS=(1280,720)


def stable(obj:Any)->str:
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()

def _transform_bbox(bbox, source_size, canvas=CANVAS):
    sw,sh=source_size; cw,ch=canvas
    scale=min((cw-40)/sw,(ch-30)/sh,1.0)
    nw,nh=round(sw*scale),round(sh*scale)
    ox,oy=(cw-nw)//2,(ch-nh)//2
    x0,y0,x1,y1=bbox
    return [round(ox+x0*scale),round(oy+y0*scale),round(ox+x1*scale),round(oy+y1*scale)]

def _load_bindings(path:Path):
    d=json.loads(Path(path).read_text())
    if d.get('schema')!='NexMindIllustrationPixelBindingsV1': raise ValueError('PIXEL_BINDING_SCHEMA_REQUIRED')
    source_size=tuple(d.get('sourceSize') or CANVAS)
    mode=d.get('coordinateSpace','SOURCE_PIXELS')
    def conv(b): return _transform_bbox(b,source_size) if mode=='SOURCE_PIXELS' else [round(x) for x in b]
    entities={k:{**v,'bbox':conv(v['bbox'])} for k,v in (d.get('entities') or {}).items()}
    interactions=[]
    for row in d.get('interactions') or []:
        interactions.append({**row,'bbox':conv(row['bbox'])})
    return d,entities,interactions

def _semantic_weight(op:str)->int:
    return {'CONTACT':100,'PICKUP':90,'PLACE':85,'REACH':80,'APPROACH':65,'READ':70,'USE':70,'OPEN':75,'CLOSE':75,'PUSH':80,'PULL':80,'CARRY':75,'GIVE':90,'RECEIVE':90}.get(op,50)

def compile_semantic_group_manifest(story_text:str,pixel_bindings:Path,visual_candidate:dict|None=None,beat_ids:set[str]|None=None,strict_contact:bool=True)->dict:
    story=compose_story(story_text,'semantic-bound-scene')
    performer=story_performer_sequence(story_text)
    env=ground_story_environment(story_text)
    temporal=compile_story_temporal(story_text)
    unified=compile_unified_story_temporal(story_text)
    cinema=compile_story_cinema(story_text)
    raw,bindings,interaction_bindings=_load_bindings(pixel_bindings)

    if visual_candidate is not None:
        visual_candidate=validate_visual_candidate(visual_candidate,beat_ids or {'B1'})
    visual_links=raw.get('visualLinks') or {}

    entity_meta={}
    for c in story.get('cast') or []:
        entity_meta[c['id']]={'label':c.get('label',c['id']),'kind':'person','semanticRole':'primary_actor' if 'primary_actor' in (c.get('semanticTags') or []) else 'support_actor'}
    for p in story.get('props') or []:
        entity_meta[p['id']]={'label':p.get('label',p['id']),'kind':'object','semanticRole':p.get('semanticRole','prop')}

    unknown_bindings=set(bindings)-set(entity_meta)
    unknown_visual=(set(visual_links.get('heroEntityIds') or []) | set(visual_links.get('transformationEntityIds') or []))-set(entity_meta)
    unknown_interactions={x for it in interaction_bindings for x in (it.get('participants') or []) if x not in entity_meta}
    if unknown_bindings or unknown_visual or unknown_interactions:
        raise ValueError('UNKNOWN_SEMANTIC_ENTITY_BINDING: '+json.dumps({'bindings':sorted(unknown_bindings),'visualLinks':sorted(unknown_visual),'interactions':sorted(unknown_interactions)}))

    action_scores={k:0 for k in entity_meta}
    contact_targets=set(); state_targets=set(); action_ledger=[]
    actor_id=(story.get('cast') or [{}])[0].get('id')
    for idx,a in enumerate(story.get('actions') or []):
        op=str(a.get('operation','')).upper(); ids=[]
        for key in ('targetId','itemId','destinationId'):
            if a.get(key): ids.append(a[key])
        if actor_id: ids.append(actor_id)
        weight=_semantic_weight(op)
        for eid in ids: action_scores[eid]=max(action_scores.get(eid,0),weight)
        if op=='CONTACT': contact_targets.update(ids)
        if op in {'PICKUP','PLACE','OPEN','CLOSE','GIVE','RECEIVE'}: state_targets.update(ids)
        action_ledger.append({'index':idx,'operation':op,'entityIds':list(dict.fromkeys(ids)),'weight':weight})

    # Layer5 CONTACT/STATE_CHANGE shots are authoritative reinforcement, not invented labels.
    cinema_contact=set(); cinema_state=set(); shot_ledger=[]
    for shot in cinema.get('shots') or []:
        role=shot.get('role'); ids=shot.get('subjectIds') or []
        if role=='CONTACT': cinema_contact.update(ids)
        if role=='STATE_CHANGE': cinema_state.update(ids)
        shot_ledger.append({'shotId':shot.get('shotId'),'role':role,'subjectIds':ids,'camera':shot.get('camera'),'drawingChoreography':shot.get('drawingChoreography')})
    contact_targets |= cinema_contact; state_targets |= cinema_state

    hero_ids=set(visual_links.get('heroEntityIds') or [])
    transform_ids=set(visual_links.get('transformationEntityIds') or [])
    if not hero_ids and actor_id: hero_ids.add(actor_id)

    groups=[]; gid=0
    # Catch-all preserves every unbound pixel but is deliberately last.
    groups.append({'id':gid,'label':'unbound_scene_remainder','role':'ENVIRONMENT_STRUCTURE','bbox':[0,0,CANVAS[0],CANVAS[1]],'order_index':900,'salience':0.1,
                   'semanticRole':'REMAINDER','entityIds':[],'drawPhase':'SUPPORT','sourceAuthorities':['SEMANTIC_BINDING_FALLBACK_CATCHALL']}); gid+=1

    # Main entities: hero first, then environment support, then action target/detail. Nested interaction boxes override path assignment later.
    entity_rows=[]
    for eid,b in bindings.items():
        if eid not in entity_meta: continue
        m=entity_meta[eid]; score=action_scores.get(eid,0)
        if eid in hero_ids: phase='HERO'; order=10; role='FOCAL'; sal=4.0
        elif m['semanticRole'] in {'support_fixture','transaction_station','merchandise_context'}: phase='ENVIRONMENT'; order=20; role='ENVIRONMENT_STRUCTURE'; sal=1.2
        elif score>=80 or eid in transform_ids: phase='ACTION'; order=30; role='SECONDARY'; sal=3.0
        else: phase='SUPPORT'; order=50; role='SECONDARY'; sal=1.5
        if eid in state_targets: order=min(order,35); sal=max(sal,2.8)
        entity_rows.append({'id':gid,'label':m['label'],'role':role,'bbox':b['bbox'],'order_index':order,'salience':sal,
                            'semanticRole':m['semanticRole'],'entityIds':[eid],'drawPhase':phase,'actionScore':score,
                            'contactCritical':eid in contact_targets,'continuityCritical':eid in state_targets,
                            'sourceAuthorities':['LAYER1_STORY_SCENE_COMPOSER','P1P2_VISUAL_CONCEPT' if visual_candidate else 'P1P2_VISUAL_INTERFACE_BOUND_PROVIDER_INACTIVE']})
        gid+=1
    groups.extend(entity_rows)

    matched_contact=0
    for it in interaction_bindings:
        participants=it.get('participants') or []
        kind=str(it.get('kind','INTERACTION')).upper()
        relevant=kind=='CONTACT' or any(x in contact_targets for x in participants)
        if relevant: matched_contact+=1
        groups.append({'id':gid,'label':it.get('label') or f'{kind.lower()}_'+'_'.join(participants),'role':'DETAIL_CLUSTER','bbox':it['bbox'],
                       'order_index':40 if relevant else 45,'salience':5.0 if relevant else 2.5,'semanticRole':kind,
                       'entityIds':participants,'drawPhase':'CONTACT_DETAIL' if relevant else 'INTERACTION_DETAIL','contactCritical':relevant,
                       'continuityCritical':any(x in state_targets for x in participants),
                       'sourceAuthorities':['LAYER1_ACTION_SEMANTICS','LAYER2_PERFORMER_CONTACT_STATE','LAYER4_TEMPORAL_STATE','LAYER5_CONTACT_SHOT']}); gid+=1

    contact_required=bool(contact_targets)
    if strict_contact and contact_required and matched_contact==0:
        raise ValueError('CONTACT_PIXEL_BINDING_REQUIRED: action/cinema semantics require a contact region but illustration bindings provide none.')

    # Stable ordering: explicit semantic order, more salient first within phase.
    groups.sort(key=lambda g:(g['order_index'],-float(g.get('salience',1))))
    for i,g in enumerate(groups): g['order_index']=i

    visual_trace=None
    if visual_candidate:
        visual_trace={'candidateId':visual_candidate['candidate_id'],'representation':visual_candidate['representation'],'visualThesis':visual_candidate['visual_thesis'],
                      'heroKind':visual_candidate['hero_kind'],'transformation':visual_candidate['transformation'],'cameraIdea':visual_candidate['camera_idea'],
                      'styleIntent':visual_candidate.get('style_intent')}

    scene_conception={
        'representation': visual_candidate['representation'] if visual_candidate else 'AUTHORED_ILLUSTRATION',
        'visualThesis': visual_candidate['visual_thesis'] if visual_candidate else 'Use the approved authored illustration as the scene conception; semantic authorities determine reveal hierarchy.',
        'heroEntityIds': sorted(hero_ids),
        'environmentEntityIds': sorted(eid for eid,m in entity_meta.items() if m['semanticRole'] in {'support_fixture','transaction_station','merchandise_context'}),
        'actionFocusEntityIds': sorted(eid for eid,score in action_scores.items() if score>=70),
        'contactFocusEntityIds': sorted(contact_targets),
        'continuityEntityIds': sorted(state_targets),
        'cameraIdea': visual_candidate['camera_idea'] if visual_candidate else 'SUBORDINATE_TO_SEMANTIC_GROUPS_AND_LAYER5_SHOT_INTENT',
        'sourceAuthorities':['P1P2_VISUAL_CONCEPT_INTERFACE','LAYER1_STORY_SCENE_COMPOSITION','LAYER2_PERFORMER','LAYER4_TEMPORAL_STATE','LAYER5_CINEMA_CHOREOGRAPHY']
    }
    manifest={'schema':'NexMindWhiteboardSemanticGroupManifestV2','groups':groups,
              'semanticAuthority':{'storyText':story_text,'storyHash':stable(story),'performerHash':stable(performer),'environmentHash':stable(env),'temporalHash':stable(temporal),'unifiedHash':stable(unified),'cinemaHash':stable(cinema),
                                   'visualDirector':visual_trace or {'status':'INTERFACE_BOUND_NO_LIVE_PROVIDER_OUTPUT'},
                                   'sceneConception':scene_conception,
                                   'actionLedger':action_ledger,'contactEntityIds':sorted(contact_targets),'stateChangeEntityIds':sorted(state_targets),'shotLedger':shot_ledger,
                                   'pixelBindingHash':stable(raw),'contactBindingRequired':contact_required,'contactBindingMatched':matched_contact},
              'drawOrderContract':{'policy':'SEMANTICS_FIRST_THEN_LOCAL_STROKE_ECONOMY','phases':['HERO','ENVIRONMENT','ACTION','CONTACT_DETAIL','INTERACTION_DETAIL','SUPPORT','REMAINDER'],
                                   'rule':'Visual/scene/action/contact authority assigns semantic group order. Local renderer may optimize pen travel only inside a semantic group; it may not reorder groups.'},
              'truthBoundary':'Semantic authority is live from recovered Layers1-5. P1/P2 Visual Director is wired as a validated input interface but no live creative provider is configured in this runtime. Pixel-region binding is supplied by the approved illustration package and is not inferred here.'}
    return manifest

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('story'); ap.add_argument('bindings'); ap.add_argument('out'); ap.add_argument('--allow-missing-contact',action='store_true')
    a=ap.parse_args(); d=compile_semantic_group_manifest(a.story,Path(a.bindings),strict_contact=not a.allow_missing_contact); Path(a.out).write_text(json.dumps(d,indent=2)+'\n'); print(json.dumps({'out':a.out,'groups':len(d['groups']),'contact':d['semanticAuthority']['contactBindingMatched']},indent=2))
