from __future__ import annotations
import argparse,json,sys
from pathlib import Path
if __package__ in {None,''}:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    from semantic_authority_v1.director import BeatSemanticDirector
    from semantic_authority_v1.provider import RecordedSemanticProvider,LiveSemanticProvider
    from decision_layer_v1.cli import run as run_decision
else:
    from .director import BeatSemanticDirector
    from .provider import RecordedSemanticProvider,LiveSemanticProvider
    from decision_layer_v1.cli import run as run_decision

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--out'); ap.add_argument('--provider',choices=['live','recorded'],default='live'); ap.add_argument('--responses')
    a=ap.parse_args(); payload=json.loads(Path(a.input).read_text()); prod=str(payload.get('production_id') or 'whiteboard-production')
    if a.provider=='recorded':
        if not a.responses: raise ValueError('RECORDED_PROVIDER_RESPONSES_REQUIRED')
        provider=RecordedSemanticProvider(json.loads(Path(a.responses).read_text()))
    else: provider=LiveSemanticProvider()
    semantic=BeatSemanticDirector(provider).analyze(prod,payload.get('narration') or {},payload.get('semantic_doctrine') or {})
    decision_input={'beats':semantic['beats'],'capability':payload.get('capability',{}),'variety_pressure':payload.get('variety_pressure',.85)}
    decision=run_decision(decision_input)
    result={'schema':'NexMindWhiteboardAutonomousSemanticDecisionPlanV1','production_id':prod,'semantic_authority':semantic,'decision_layer':decision,'provider_mode':a.provider,'manual_semantic_labels':False,'manual_representation_choice':False,'manual_timing_choice':False}
    raw=json.dumps(result,indent=2)+'\n';
    if a.out: Path(a.out).write_text(raw)
    print(json.dumps(result,separators=(',',':')))
if __name__=='__main__': main()
