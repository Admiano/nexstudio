from __future__ import annotations
import hashlib, json, os, time, urllib.request, urllib.error
from typing import Any, Dict, Protocol

class SemanticProviderError(RuntimeError): pass
class SemanticProvider(Protocol):
    def complete(self, task:str, request:Dict[str,Any])->Dict[str,Any]: ...

class RecordedSemanticProvider:
    """Test-only provider. Fixture content is data, never production routing logic."""
    def __init__(self, response:Dict[str,Any]): self.response=json.loads(json.dumps(response)); self.calls=[]
    def complete(self, task:str, request:Dict[str,Any])->Dict[str,Any]:
        if task!='whiteboard_beat_semantics': raise SemanticProviderError('unsupported task:'+task)
        self.calls.append({'task':task,'request_sha256':hashlib.sha256(json.dumps(request,sort_keys=True,separators=(',',':')).encode()).hexdigest()})
        return json.loads(json.dumps(self.response))

class LiveSemanticProvider:
    """Strict live semantic authority. No fallback provider/model and no topic heuristics."""
    def __init__(self, timeout_s:float=90.0): self.timeout_s=timeout_s; self.audits=[]
    def complete(self, task:str, request:Dict[str,Any])->Dict[str,Any]:
        if task!='whiteboard_beat_semantics': raise SemanticProviderError('unsupported task:'+task)
        key=os.getenv('OPENAI_API_KEY','').strip(); model=os.getenv('NEXMIND_WHITEBOARD_SEMANTIC_MODEL','').strip()
        base=os.getenv('OPENAI_BASE_URL','https://api.openai.com/v1').rstrip('/')
        if not key: raise SemanticProviderError('LIVE_SEMANTIC_PROVIDER_BLOCKED_MISSING_CREDENTIAL:OPENAI_API_KEY')
        if not model: raise SemanticProviderError('LIVE_SEMANTIC_PROVIDER_BLOCKED_MISSING_MODEL:NEXMIND_WHITEBOARD_SEMANTIC_MODEL')
        from .schema import SEMANTIC_OUTPUT_SCHEMA
        payload={
            'model':model,
            'reasoning':{'effort':os.getenv('NEXMIND_WHITEBOARD_SEMANTIC_REASONING','high'),'context':'current_turn'},
            'instructions':(
                'You are NexMind Whiteboard Beat Semantic Director, subordinate to Story/Visual authority. '
                'Infer only semantic structure and narration cue ownership. Do not choose a visual representation, camera, layout, style, asset, renderer, or coordinates. '
                'Topic labels are provenance/asset-lookup hints only. Describe whether the idea structurally involves human agency, objects, data, process, network, comparison, space, transformation, handoff, approval, outcome, uncertainty, continuity, mechanism, causality, time, or metaphor opportunity. '
                'Return every narration segment exactly once, in order, grouped only when one coherent thought spans adjacent segments.'
            ),
            'input':[{'role':'user','content':[{'type':'input_text','text':json.dumps(request,ensure_ascii=False)}]}],
            'text':{'format':{'type':'json_schema','name':'nexmind_whiteboard_beat_semantics_v1','schema':SEMANTIC_OUTPUT_SCHEMA,'strict':True}},
            'store':False,
        }
        started=time.monotonic(); raw=json.dumps(payload).encode(); req=urllib.request.Request(base+'/responses',data=raw,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
        try:
            with urllib.request.urlopen(req,timeout=self.timeout_s) as resp: data=json.loads(resp.read().decode())
            text=data.get('output_text')
            if not isinstance(text,str):
                chunks=[]
                for item in data.get('output',[]) or []:
                    for c in item.get('content',[]) or []:
                        if isinstance(c.get('text'),str): chunks.append(c['text'])
                text=''.join(chunks)
            if not text: raise SemanticProviderError('LIVE_SEMANTIC_PROVIDER_EMPTY_OUTPUT')
            out=json.loads(text); self.audits.append({'status':'PASS','model':str(data.get('model') or model),'duration_ms':int((time.monotonic()-started)*1000)})
            return out
        except (urllib.error.URLError,urllib.error.HTTPError,TimeoutError,json.JSONDecodeError) as e:
            self.audits.append({'status':'FAIL','model':model,'duration_ms':int((time.monotonic()-started)*1000),'error':str(e)[:500]})
            raise SemanticProviderError('LIVE_SEMANTIC_PROVIDER_FAILED:'+str(e))
