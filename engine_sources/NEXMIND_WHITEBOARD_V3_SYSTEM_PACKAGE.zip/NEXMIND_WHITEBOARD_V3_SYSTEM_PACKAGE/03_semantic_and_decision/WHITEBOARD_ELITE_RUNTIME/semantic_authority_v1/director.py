from __future__ import annotations
import re
from typing import Any, Dict, List
from .contracts import validate_segments, validate_semantic_output

_SPLIT=re.compile(r'(?<=[.!?;])\s+|\s+[—–]\s+')

def normalize_narration(payload:Dict[str,Any])->List[Dict[str,Any]]:
    if isinstance(payload.get('segments'),list) and payload['segments']:
        return validate_segments(payload['segments'])
    script=str(payload.get('script') or '').strip(); duration=float(payload.get('duration_seconds') or 0)
    if not script: raise ValueError('NARRATION_SCRIPT_OR_SEGMENTS_REQUIRED')
    if duration<=0: raise ValueError('NARRATION_DURATION_REQUIRED_WHEN_SEGMENTS_ABSENT')
    chunks=[x.strip() for x in _SPLIT.split(script) if x.strip()]
    if not chunks: chunks=[script]
    weights=[max(1,len(re.findall(r"\b\w+(?:['’-]\w+)?\b",x))) for x in chunks]; total=sum(weights)
    out=[]; cur=0.0
    for i,(text,w) in enumerate(zip(chunks,weights)):
        end=duration if i==len(chunks)-1 else cur+duration*w/total
        out.append({'segment_id':f's{i+1:02d}','text':text,'start_seconds':round(cur,6),'end_seconds':round(end,6)})
        cur=end
    return validate_segments(out)

class BeatSemanticDirector:
    def __init__(self, provider): self.provider=provider
    def analyze(self, production_id:str, narration:Dict[str,Any], doctrine:Dict[str,Any]|None=None)->Dict[str,Any]:
        segments=normalize_narration(narration)
        request={
          'production_id':production_id,
          'narration_segments':segments,
          'semantic_contract':'NexMindWhiteboardBeatSemanticsV1',
          'doctrine':doctrine or {},
          'instruction':{
            'goal':'Infer abstract semantic structure and narration cue ownership for Whiteboard planning.',
            'must':['cover every narration segment exactly once and in order','describe structure rather than topic category','emit visual units as semantic responsibilities, not chosen illustration forms','use topic_labels only for later asset lookup/provenance'],
            'forbidden':['representation choice','camera choice','layout','coordinates','style choice','asset IDs','renderer instructions','scenario-specific routing']
          }
        }
        raw=self.provider.complete('whiteboard_beat_semantics',request)
        valid=validate_semantic_output(raw,segments)
        by={s['segment_id']:s for s in segments}; order=[s['segment_id'] for s in segments]
        beats=[]
        for b in valid['beats']:
            ids=b['segment_ids']; first=by[ids[0]]; last=by[ids[-1]]; beat_start=float(first['start_seconds']); beat_end=float(last['end_seconds'])
            text=' '.join(by[x]['text'] for x in ids)
            units=[]
            for u in b['visual_units']:
                cue_seg=by[u['cue_segment_id']]; abs_cue=float(cue_seg['start_seconds'])+(float(cue_seg['end_seconds'])-float(cue_seg['start_seconds']))*float(u['cue_within_segment_fraction'])
                row={k:u[k] for k in ['unit_id','semantic_role','complexity','importance','draw_policy','dependencies','persistent']}
                row['cue_seconds']=round(max(0.0,abs_cue-beat_start),6); units.append(row)
            beats.append({
              'beat_id':b['beat_id'],'duration_seconds':round(beat_end-beat_start,6),'features':b['features'],'semantic_relations':b['semantic_relations'],
              'board_change':b['board_change'],'continuity_object':b['continuity_object'],'structural_necessity':b['structural_necessity'],'idea_complexity':b['idea_complexity'],
              'narration_text':text,'topic_labels':b['topic_labels'],'visual_units':units,
              'source_segments':ids,'source_start_seconds':beat_start,'source_end_seconds':beat_end
            })
        return {'schema':'NexMindWhiteboardBeatSemanticsAuthorityV1','production_id':production_id,'segments':segments,'beats':beats,'visual_authority_leakage':False,'topic_labels_are_representation_inputs':False}
