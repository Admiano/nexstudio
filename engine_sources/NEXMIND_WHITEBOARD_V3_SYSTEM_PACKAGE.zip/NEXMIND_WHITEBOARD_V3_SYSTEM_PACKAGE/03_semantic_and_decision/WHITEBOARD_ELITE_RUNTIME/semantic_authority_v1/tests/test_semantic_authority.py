from pathlib import Path
import json,sys,pytest
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from semantic_authority_v1.director import normalize_narration,BeatSemanticDirector
from semantic_authority_v1.provider import RecordedSemanticProvider,LiveSemanticProvider,SemanticProviderError
from semantic_authority_v1.contracts import validate_semantic_output,SemanticContractViolation
from decision_layer_v1.contracts import SEMANTIC_FEATURES

def features(**kw):
    d={k:0.0 for k in SEMANTIC_FEATURES}; d.update(kw); return d

def base_response(seg_ids):
    return {'beats':[{'beat_id':'b1','segment_ids':seg_ids,'features':features(object_centricity=.8,transformation_strength=.8,causal_strength=.8),'idea_complexity':.5,'structural_necessity':False,'board_change':'changes-state','semantic_relations':['TRANSFORMS'],'continuity_object':'entity','topic_labels':['alpha'],'visual_units':[{'unit_id':'u1','semantic_role':'HERO','complexity':.5,'importance':.9,'draw_policy':'DRAW','cue_segment_id':seg_ids[0],'cue_within_segment_fraction':.1,'dependencies':[],'persistent':True}]}]}

def test_raw_script_normalizes_without_topic_routing():
    seg=normalize_narration({'script':'First state changes. Second state follows.','duration_seconds':4.0})
    assert [x['segment_id'] for x in seg]==['s01','s02']
    assert abs(seg[-1]['end_seconds']-4.0)<1e-6

def test_every_segment_must_be_covered_exactly_once():
    seg=normalize_narration({'script':'A happens. B happens.','duration_seconds':3.0})
    with pytest.raises(SemanticContractViolation): validate_semantic_output(base_response(['s01']),seg)

def test_semantic_authority_cannot_choose_representation():
    seg=normalize_narration({'script':'A happens.','duration_seconds':2.0})
    r=base_response(['s01']); r['beats'][0]['representation']='diagram'
    with pytest.raises(SemanticContractViolation): validate_semantic_output(r,seg)

def test_provider_result_derives_narration_and_cues_not_provider_copy():
    narration={'script':'A changes. B follows.','duration_seconds':4.0}
    r=base_response(['s01','s02']); r['beats'][0]['visual_units'][0]['cue_segment_id']='s02'; r['beats'][0]['visual_units'][0]['cue_within_segment_fraction']=.5
    out=BeatSemanticDirector(RecordedSemanticProvider(r)).analyze('p1',narration)
    b=out['beats'][0]
    assert b['narration_text']=='A changes. B follows.'
    assert 2.0 < b['visual_units'][0]['cue_seconds'] < 4.0
    assert out['visual_authority_leakage'] is False

def test_live_provider_fails_closed_without_configuration(monkeypatch):
    monkeypatch.delenv('OPENAI_API_KEY',raising=False); monkeypatch.delenv('NEXMIND_WHITEBOARD_SEMANTIC_MODEL',raising=False)
    with pytest.raises(SemanticProviderError): LiveSemanticProvider().complete('whiteboard_beat_semantics',{'production_id':'x'})

def test_production_source_has_no_benchmark_or_domain_dispatch_tokens():
    files=['contracts.py','provider.py','schema.py','director.py','plan_cli.py']
    src='\n'.join((Path(__file__).resolve().parents[1]/f).read_text().lower() for f in files)
    forbidden=['virtuals','robinhood','bitcoin','crypto','wallet','doctor','patient','kitchen','classroom','warehouse','bakery','glucose','invoice','robot','benchmark_id','scenario_id']
    assert not [x for x in forbidden if x in src]
