from __future__ import annotations
from copy import deepcopy
from typing import Any, Dict, List

from decision_layer_v1.contracts import SEMANTIC_FEATURES

SEMANTIC_ROLES={'HERO','PRIMARY','SUPPORT','EVIDENCE','ANNOTATION','CONNECTOR','DETAIL','SYMBOL'}
DRAW_POLICIES={'DRAW','GROUP_REVEAL','INSTANT_REVEAL','ANNOTATE'}
FORBIDDEN_OUTPUT_KEYS={
    'representation','representation_class','representation_family','camera','camera_move','shot','shot_scale',
    'layout','coordinates','bbox','x','y','width','height','renderer','render_mode','asset_id','style','visual_style'
}

class SemanticContractViolation(ValueError):
    pass

def _exact(obj:Dict[str,Any], required:set[str], optional:set[str], label:str):
    if not isinstance(obj,dict): raise SemanticContractViolation(label+' must be object')
    missing=required-set(obj); extra=set(obj)-required-optional
    if missing: raise SemanticContractViolation(f'{label} missing keys: {sorted(missing)}')
    if extra: raise SemanticContractViolation(f'{label} unexpected keys: {sorted(extra)}')

def _walk_keys(obj:Any):
    if isinstance(obj,dict):
        for k,v in obj.items():
            yield str(k).lower(); yield from _walk_keys(v)
    elif isinstance(obj,list):
        for v in obj: yield from _walk_keys(v)

def reject_visual_authority_leakage(payload:Any):
    for k in _walk_keys(payload):
        if k in FORBIDDEN_OUTPUT_KEYS:
            raise SemanticContractViolation('VISUAL_AUTHORITY_LEAKAGE:'+k)

def validate_segments(segments:List[Dict[str,Any]])->List[Dict[str,Any]]:
    if not isinstance(segments,list) or not segments: raise SemanticContractViolation('narration segments required')
    out=[]; seen=set(); prev_end=-1e-9
    for i,s in enumerate(segments):
        _exact(s,{'segment_id','text','start_seconds','end_seconds'},set(),f'segment[{i}]')
        sid=str(s['segment_id']); text=str(s['text']).strip(); st=float(s['start_seconds']); en=float(s['end_seconds'])
        if not sid or sid in seen: raise SemanticContractViolation('segment ids must be unique non-empty')
        if not text: raise SemanticContractViolation('segment text must be non-empty')
        if st < -1e-9 or en <= st: raise SemanticContractViolation('invalid segment timing:'+sid)
        if st < prev_end-1e-6: raise SemanticContractViolation('segments must be chronological and non-overlapping')
        seen.add(sid); prev_end=en; out.append({'segment_id':sid,'text':text,'start_seconds':st,'end_seconds':en})
    return out

def validate_semantic_output(payload:Dict[str,Any], segments:List[Dict[str,Any]])->Dict[str,Any]:
    reject_visual_authority_leakage(payload)
    _exact(payload,{'beats'},{'director_notes'},'semantic output')
    beats=payload['beats']
    if not isinstance(beats,list) or not beats: raise SemanticContractViolation('semantic output requires beats')
    seg_order=[s['segment_id'] for s in segments]; seg_set=set(seg_order); assigned=[]; beat_ids=set()
    for bi,b in enumerate(beats):
        _exact(b,{'beat_id','segment_ids','features','idea_complexity','structural_necessity','board_change','semantic_relations','continuity_object','topic_labels','visual_units'},set(),f'beat[{bi}]')
        bid=str(b['beat_id']);
        if not bid or bid in beat_ids: raise SemanticContractViolation('beat_id must be unique non-empty')
        beat_ids.add(bid)
        ids=b['segment_ids']
        if not isinstance(ids,list) or not ids: raise SemanticContractViolation(bid+': segment_ids required')
        if any(x not in seg_set for x in ids): raise SemanticContractViolation(bid+': unknown segment id')
        idx=[seg_order.index(x) for x in ids]
        if idx != list(range(min(idx),max(idx)+1)): raise SemanticContractViolation(bid+': segments must be contiguous')
        assigned.extend(ids)
        f=b['features'];
        if not isinstance(f,dict): raise SemanticContractViolation(bid+': features must be object')
        extra=set(f)-set(SEMANTIC_FEATURES); missing=set(SEMANTIC_FEATURES)-set(f)
        if extra or missing: raise SemanticContractViolation(bid+f': feature mismatch missing={sorted(missing)} extra={sorted(extra)}')
        for k,v in f.items():
            if not isinstance(v,(int,float)) or not 0<=float(v)<=1: raise SemanticContractViolation(bid+': feature out of range:'+k)
        if not 0<=float(b['idea_complexity'])<=1: raise SemanticContractViolation(bid+': idea_complexity out of range')
        if not isinstance(b['structural_necessity'],bool): raise SemanticContractViolation(bid+': structural_necessity must be boolean')
        if b['continuity_object'] is not None and not isinstance(b['continuity_object'],str): raise SemanticContractViolation(bid+': continuity_object invalid')
        if not isinstance(b['semantic_relations'],list) or not all(isinstance(x,str) for x in b['semantic_relations']): raise SemanticContractViolation(bid+': semantic_relations invalid')
        if not isinstance(b['topic_labels'],list) or not all(isinstance(x,str) for x in b['topic_labels']): raise SemanticContractViolation(bid+': topic_labels invalid')
        units=b['visual_units'];
        if not isinstance(units,list) or not units: raise SemanticContractViolation(bid+': visual_units required')
        unit_ids=set()
        for ui,u in enumerate(units):
            _exact(u,{'unit_id','semantic_role','complexity','importance','draw_policy','cue_segment_id','cue_within_segment_fraction','dependencies','persistent'},set(),f'{bid}.visual_unit[{ui}]')
            uid=str(u['unit_id'])
            if not uid or uid in unit_ids: raise SemanticContractViolation(bid+': visual unit ids unique non-empty')
            unit_ids.add(uid)
            if u['semantic_role'] not in SEMANTIC_ROLES: raise SemanticContractViolation(bid+': invalid semantic role')
            if u['draw_policy'] not in DRAW_POLICIES: raise SemanticContractViolation(bid+': invalid draw policy')
            for k in ('complexity','importance','cue_within_segment_fraction'):
                if not isinstance(u[k],(int,float)) or not 0<=float(u[k])<=1: raise SemanticContractViolation(bid+': '+k+' out of range')
            if u['cue_segment_id'] not in ids: raise SemanticContractViolation(bid+': unit cue must belong to beat segment')
            if not isinstance(u['dependencies'],list) or not all(isinstance(x,str) for x in u['dependencies']): raise SemanticContractViolation(bid+': dependencies invalid')
            if not isinstance(u['persistent'],bool): raise SemanticContractViolation(bid+': persistent invalid')
        for u in units:
            unknown=set(u['dependencies'])-unit_ids
            if unknown: raise SemanticContractViolation(bid+': unknown unit dependency '+','.join(sorted(unknown)))
    if assigned != seg_order:
        raise SemanticContractViolation('BEAT_SEGMENT_COVERAGE_MUST_BE_EXACT_AND_ORDERED')
    return deepcopy(payload)
