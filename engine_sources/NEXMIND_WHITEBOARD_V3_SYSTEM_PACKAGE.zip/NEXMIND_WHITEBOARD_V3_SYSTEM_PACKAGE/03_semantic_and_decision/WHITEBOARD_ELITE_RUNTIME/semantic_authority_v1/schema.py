from __future__ import annotations
from decision_layer_v1.contracts import SEMANTIC_FEATURES

FEATURE_PROPERTIES={k:{'type':'number','minimum':0,'maximum':1} for k in SEMANTIC_FEATURES}
SEMANTIC_OUTPUT_SCHEMA={
 'type':'object','additionalProperties':False,'required':['beats'],'properties':{
  'beats':{'type':'array','minItems':1,'items':{
   'type':'object','additionalProperties':False,
   'required':['beat_id','segment_ids','features','idea_complexity','structural_necessity','board_change','semantic_relations','continuity_object','topic_labels','visual_units'],
   'properties':{
    'beat_id':{'type':'string','minLength':1}, 'segment_ids':{'type':'array','minItems':1,'items':{'type':'string'}},
    'features':{'type':'object','additionalProperties':False,'required':list(SEMANTIC_FEATURES),'properties':FEATURE_PROPERTIES},
    'idea_complexity':{'type':'number','minimum':0,'maximum':1}, 'structural_necessity':{'type':'boolean'},
    'board_change':{'type':'string'}, 'semantic_relations':{'type':'array','items':{'type':'string'}},
    'continuity_object':{'type':['string','null']}, 'topic_labels':{'type':'array','items':{'type':'string'}},
    'visual_units':{'type':'array','minItems':1,'items':{
      'type':'object','additionalProperties':False,
      'required':['unit_id','semantic_role','complexity','importance','draw_policy','cue_segment_id','cue_within_segment_fraction','dependencies','persistent'],
      'properties':{
       'unit_id':{'type':'string','minLength':1}, 'semantic_role':{'type':'string','enum':['HERO','PRIMARY','SUPPORT','EVIDENCE','ANNOTATION','CONNECTOR','DETAIL','SYMBOL']},
       'complexity':{'type':'number','minimum':0,'maximum':1}, 'importance':{'type':'number','minimum':0,'maximum':1},
       'draw_policy':{'type':'string','enum':['DRAW','GROUP_REVEAL','INSTANT_REVEAL','ANNOTATE']},
       'cue_segment_id':{'type':'string'}, 'cue_within_segment_fraction':{'type':'number','minimum':0,'maximum':1},
       'dependencies':{'type':'array','items':{'type':'string'}}, 'persistent':{'type':'boolean'}
      }
    }}
  }},
  'director_notes':{'type':'string'}
 }}
}
