# NexMind Whiteboard Semantic Authority V1

Production seam: raw narration/VO segments -> Story/Visual semantic authority -> `NexMindWhiteboardBeatSemanticsV1` -> Variety + Comprehension Decision Layer.

Hard boundary:
- semantic authority may understand content;
- it may not choose representation, camera, layout, style, asset IDs, renderer, or coordinates;
- topic labels are preserved only for later governed asset lookup;
- representation is chosen only by the downstream Variety Director from abstract semantic features;
- live inference fails closed when credentials/model are not configured;
- recorded provider exists only for executable regression and is never an automatic production fallback.
