from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

SEMANTIC_FEATURES = (
    'human_presence','human_interaction','object_centricity','environment_need',
    'metaphor_opportunity','product_surface','data_density','process_depth',
    'network_density','comparison_strength','spatial_strength','transformation_strength',
    'handoff_strength','approval_strength','outcome_strength','uncertainty',
    'continuity_strength','mechanism_strength','causal_strength','temporal_strength',
)

REPRESENTATION_CLASSES = (
    'human-situation','human-interaction','object-story','environment-fragment',
    'physical-metaphor','product-interaction','data-in-context','meaningful-process',
    'meaningful-network','comparison','spatial-map','transformation','handoff',
    'review-approval','outcome-publish','hybrid',
)

@dataclass
class BeatSemantics:
    beat_id: str
    duration_seconds: float
    features: Dict[str, float]
    semantic_relations: List[str] = field(default_factory=list)
    board_change: str = 'adds-evidence'
    continuity_object: Optional[str] = None
    structural_necessity: bool = False
    idea_complexity: float = 0.5
    narration_text: str = ''
    topic_labels: List[str] = field(default_factory=list)  # provenance/debug only; NEVER scored

    def normalized_features(self) -> Dict[str, float]:
        return {k: max(0.0, min(1.0, float(self.features.get(k, 0.0)))) for k in SEMANTIC_FEATURES}

@dataclass
class CapabilityEnvelope:
    supported_representations: List[str] = field(default_factory=lambda: list(REPRESENTATION_CLASSES))
    native_character_available: bool = True
    data_visual_available: bool = True
    spatial_map_available: bool = True
    authored_object_available: bool = True
    max_major_objects: int = 7
    max_sequential_units: int = 7

@dataclass
class RepresentationDecision:
    beat_id: str
    representation: str
    representation_family: str
    base_fit: float
    adjusted_fit: float
    confidence: float
    structural_necessity: bool
    repetition_penalty: float
    alternatives: List[Dict[str, Any]]
    rationale: List[str]
    replan_required: bool = False
    replan_reason: Optional[str] = None

    def to_dict(self):
        return asdict(self)

@dataclass
class VisualUnit:
    unit_id: str
    semantic_role: str
    complexity: float = 0.5
    draw_policy: str = 'DRAW'  # DRAW | GROUP_REVEAL | INSTANT_REVEAL | ANNOTATE
    cue_fraction: Optional[float] = None
    cue_seconds: Optional[float] = None
    dependencies: List[str] = field(default_factory=list)
    persistent: bool = True
    importance: float = 0.5

@dataclass
class ScheduledUnit:
    unit_id: str
    start_seconds: float
    draw_end_seconds: float
    semantic_role: str
    draw_policy: str
    cue_seconds: Optional[float]
    grouped: bool

@dataclass
class ComprehensionSchedule:
    beat_id: str
    duration_seconds: float
    target_completion_seconds: float
    visual_completion_seconds: float
    comprehension_hold_seconds: float
    units: List[ScheduledUnit]
    replan_required: bool
    replan_reason: Optional[str]
    warnings: List[str]

    def to_dict(self):
        d = asdict(self)
        return d
