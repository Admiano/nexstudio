# NexMind Whiteboard Variety + Comprehension Decision Layer V1

Purpose: choose a fitting Whiteboard representation and a narration-aware draw schedule from **abstract semantic structure**, not from domain/topic keywords.

## Authority boundary

Input semantics come from NexMind Story/Visual authorities. `topic_labels` are retained only for provenance/debug and are never scored. The Director sees structural features such as comparison, transformation, handoff, process depth, data density, human agency, spatiality and uncertainty.

## Variety doctrine

Variety is a tie-breaker among semantically near-equivalent representations. It is never allowed to force a weak metaphor, human scene, chart or diagram just because the preceding scene looked similar.

## Comprehension doctrine

Narration does not define how long the pen must remain active. The visual should become readable early, then persist while narration continues. Exact later semantic cues may schedule later additions. Minor micro-detail may group-reveal instead of consuming narration with serial strokes.

## Anti-hardcoding

Forbidden routing inputs: benchmark ID, scene ID, product/company name, domain name, specific noun vocabulary, file name, prior showcase identity. The test suite mutates labels into nonsense tokens and requires identical decisions.
