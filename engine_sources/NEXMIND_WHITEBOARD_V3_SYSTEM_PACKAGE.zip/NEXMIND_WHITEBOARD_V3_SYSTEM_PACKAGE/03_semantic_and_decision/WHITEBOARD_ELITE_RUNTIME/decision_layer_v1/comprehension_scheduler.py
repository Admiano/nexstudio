from __future__ import annotations
from typing import Dict, List
from .contracts import BeatSemantics, VisualUnit, ScheduledUnit, ComprehensionSchedule, CapabilityEnvelope

ROLE_WEIGHT={'HERO':1.0,'PRIMARY':.9,'SUPPORT':.72,'EVIDENCE':.74,'ANNOTATION':.54,'CONNECTOR':.38,'DETAIL':.34,'SYMBOL':.40}
POLICY_MULT={'DRAW':1.0,'ANNOTATE':.75,'GROUP_REVEAL':.46,'INSTANT_REVEAL':.20}


def _base_draw_seconds(u:VisualUnit)->float:
    c=max(0.0,min(1.0,u.complexity)); imp=max(0.0,min(1.0,u.importance))
    role=ROLE_WEIGHT.get(u.semantic_role.upper(),.62)
    # Whiteboard form doctrine: main contours selective, micro-detail grouped/revealed.
    raw=.24 + .78*c*role + .20*imp
    return max(.12,min(1.18,raw*POLICY_MULT.get(u.draw_policy,1.0)))


def _topological(units:List[VisualUnit])->List[VisualUnit]:
    by={u.unit_id:u for u in units}; done=set(); out=[]; pending=list(units)
    while pending:
        progressed=False
        for u in list(pending):
            if all(d in done or d not in by for d in u.dependencies):
                out.append(u); done.add(u.unit_id); pending.remove(u); progressed=True
        if not progressed:
            # Fail deterministic but do not silently reorder a dependency cycle.
            raise ValueError('VISUAL_UNIT_DEPENDENCY_CYCLE:'+','.join(u.unit_id for u in pending))
    return out


def schedule_beat(beat:BeatSemantics, units:List[VisualUnit], capability:CapabilityEnvelope|None=None)->ComprehensionSchedule:
    capability=capability or CapabilityEnvelope(); dur=max(.2,float(beat.duration_seconds)); warnings=[]
    if not units:
        return ComprehensionSchedule(beat.beat_id,dur,0,0,dur,[],True,'NO_VISUAL_UNITS',warnings)
    if len(units)>max(1,capability.max_major_objects+4): warnings.append('VISUAL_UNIT_COUNT_HIGH')
    try: ordered=_topological(units)
    except ValueError as e:
        return ComprehensionSchedule(beat.beat_id,dur,0,0,dur,[],True,str(e),warnings)

    # Desired hold scales with complexity, but never consumes so much of a short beat that drawing is impossible.
    complexity=max(0.0,min(1.0,beat.idea_complexity))
    hold_target=min(max(.60,.72+.90*complexity),dur*.42)
    target_completion=max(.25,dur-hold_target)
    # For long simple beats, finish even earlier; for dense beats, allow more of the narration window.
    frac=.48 + .18*complexity
    target_completion=min(target_completion,dur*frac)

    # Convert low-importance late detail into grouped reveal before compressing meaningful units.
    work=[]
    for u in ordered:
        q=VisualUnit(**u.__dict__)
        if q.semantic_role.upper() in {'DETAIL','SYMBOL','CONNECTOR'} and q.complexity>.55 and q.draw_policy=='DRAW':
            q.draw_policy='GROUP_REVEAL'; warnings.append('MICRO_DETAIL_GROUPED:'+q.unit_id)
        work.append(q)

    cue_times={}
    for u in work:
        if u.cue_seconds is not None: cue=max(0.0,min(dur,float(u.cue_seconds)))
        elif u.cue_fraction is not None: cue=max(0.0,min(dur,dur*float(u.cue_fraction)))
        else: cue=None
        cue_times[u.unit_id]=cue

    # First pass: draw briskly and never stretch to fill narration.
    times=[]; cur=0.0
    for u in work:
        ds=_base_draw_seconds(u)
        cue=cue_times[u.unit_id]
        # Begin slightly before an exact spoken cue so the concept is becoming readable as it is named.
        cue_start=max(0.0,cue-.16) if cue is not None else None
        start=max(cur,cue_start if cue_start is not None else cur)
        end=start+ds
        times.append([u,start,end,ds,cue])
        cur=end

    visual_end=max(x[2] for x in times)
    # If the no-cue portion runs past our comprehension target, compress draw durations only; never add delay.
    if visual_end>target_completion:
        fixed_late=max([x[1] for x in times if x[4] is not None],default=0.0)
        # Preserve cue anchors. Compress all durations uniformly down to a safe floor.
        excess=visual_end-target_completion
        scalable=sum(max(0.0,x[3]-.12) for x in times)
        if scalable>1e-9:
            ratio=max(0.0,min(1.0,1.0-excess/scalable))
            cur=0.0; new=[]
            for u,_,_,ds,cue in times:
                nd=.12+(ds-.12)*ratio
                cue_start=max(0.0,cue-.16) if cue is not None else None
                st=max(cur,cue_start if cue_start is not None else cur); en=st+nd
                new.append([u,st,en,nd,cue]); cur=en
            times=new; visual_end=max(x[2] for x in times)
    # A late spoken cue is allowed to produce a late addition, but there must still be some read time.
    read_floor=.38
    if visual_end>dur-read_floor:
        # Last chance: group low-importance supports at their dependency/cue boundary.
        for x in times:
            u=x[0]
            if u.semantic_role.upper() in {'DETAIL','SYMBOL','CONNECTOR','ANNOTATION'} and x[3]>.16:
                x[3]=.16; x[2]=x[1]+.16
        cur=0.0
        rebuilt=[]
        for u,_,_,ds,cue in times:
            cue_start=max(0.0,cue-.16) if cue is not None else None
            st=max(cur,cue_start if cue_start is not None else cur); en=st+ds
            rebuilt.append([u,st,en,ds,cue]); cur=en
        times=rebuilt; visual_end=max(x[2] for x in times)

    replan=visual_end>dur-read_floor+1e-6
    reason='INSUFFICIENT_COMPREHENSION_HOLD_REPLAN' if replan else None
    if replan: warnings.append('DO_NOT_STRETCH_DRAWING_TO_NARRATION_END')

    scheduled=[ScheduledUnit(u.unit_id,round(st,4),round(en,4),u.semantic_role,u.draw_policy,cue,u.draw_policy in {'GROUP_REVEAL','INSTANT_REVEAL'}) for u,st,en,ds,cue in times]
    hold=max(0.0,dur-visual_end)
    return ComprehensionSchedule(beat.beat_id,dur,round(target_completion,4),round(visual_end,4),round(hold,4),scheduled,replan,reason,warnings)
