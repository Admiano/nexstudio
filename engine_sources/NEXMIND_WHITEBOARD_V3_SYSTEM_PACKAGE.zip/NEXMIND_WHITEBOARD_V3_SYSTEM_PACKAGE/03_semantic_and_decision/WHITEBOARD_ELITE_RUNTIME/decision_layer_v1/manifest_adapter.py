from __future__ import annotations
from typing import Any, Dict, List
from .contracts import ComprehensionSchedule


def to_renderer_manifest(beat_id:str, narration_text:str, duration_seconds:float,
                         schedule:ComprehensionSchedule, groups:List[Dict[str,Any]])->Dict[str,Any]:
    by={x.unit_id:x for x in schedule.units}
    rows=[]
    for i,g in enumerate(groups):
        uid=str(g['unit_id'])
        if uid not in by: raise ValueError('UNSCHEDULED_RENDER_GROUP:'+uid)
        s=by[uid]
        bbox=g.get('bbox')
        if not bbox or len(bbox)!=4: raise ValueError('RENDER_GROUP_BBOX_REQUIRED:'+uid)
        rows.append({
            'id':int(g.get('id',i)), 'unit_id':uid, 'label':str(g.get('label',uid)),
            'role':str(g.get('role',s.semantic_role)), 'bbox':[int(round(v)) for v in bbox],
            'salience':float(g.get('salience',1.0)), 'order_index':int(g.get('order_index',i)),
            'start_seconds':float(s.start_seconds),
            'draw_seconds':max(.001,float(s.draw_end_seconds-s.start_seconds)),
            'hold_after_seconds':0.0,
            'draw_policy':s.draw_policy,
            'cue_seconds':s.cue_seconds,
        })
    return {
        'schema':'NexMindNarrationTimedSemanticManifestV5',
        'beat_id':beat_id,
        'policy':'VARIETY_DIRECTOR_PLUS_COMPREHENSION_SCHEDULER_V1',
        'narration':{'text':narration_text,'duration_seconds':float(duration_seconds),'final_hold_seconds':max(0.0,float(schedule.comprehension_hold_seconds))},
        'groups':rows,
        'decision_trace':{'target_completion_seconds':schedule.target_completion_seconds,'visual_completion_seconds':schedule.visual_completion_seconds,'comprehension_hold_seconds':schedule.comprehension_hold_seconds,'replan_required':schedule.replan_required,'warnings':schedule.warnings},
    }
