from __future__ import annotations
import math
from typing import Dict, List, Tuple
from .contracts import BeatSemantics, CapabilityEnvelope, RepresentationDecision, REPRESENTATION_CLASSES, SEMANTIC_FEATURES

# Profiles encode SEMANTIC STRUCTURE only. No domain/topic nouns are permitted here.
PROFILES: Dict[str, Dict[str, float]] = {
    'human-situation': {'human_presence':1.0,'human_interaction':.35,'environment_need':.45,'causal_strength':.25},
    'human-interaction': {'human_presence':.95,'human_interaction':1.0,'causal_strength':.45,'object_centricity':.25},
    'object-story': {'object_centricity':1.0,'causal_strength':.45,'transformation_strength':.30,'continuity_strength':.35},
    'environment-fragment': {'environment_need':1.0,'spatial_strength':.45,'human_presence':.20,'object_centricity':.25},
    'physical-metaphor': {'metaphor_opportunity':1.0,'transformation_strength':.55,'causal_strength':.45,'object_centricity':.30},
    'product-interaction': {'product_surface':1.0,'object_centricity':.60,'human_interaction':.35,'causal_strength':.45},
    'data-in-context': {'data_density':1.0,'comparison_strength':.35,'causal_strength':.25,'object_centricity':.20},
    'meaningful-process': {'process_depth':1.0,'temporal_strength':.75,'causal_strength':.70,'mechanism_strength':.30},
    'meaningful-network': {'network_density':1.0,'causal_strength':.45,'mechanism_strength':.55,'spatial_strength':.25},
    'comparison': {'comparison_strength':1.0,'data_density':.25,'object_centricity':.30,'uncertainty':.15},
    'spatial-map': {'spatial_strength':1.0,'environment_need':.25,'network_density':.20,'object_centricity':.20},
    'transformation': {'transformation_strength':1.0,'causal_strength':.60,'continuity_strength':.55,'object_centricity':.35},
    'handoff': {'handoff_strength':1.0,'human_interaction':.45,'continuity_strength':.70,'causal_strength':.45},
    'review-approval': {'approval_strength':1.0,'human_interaction':.25,'causal_strength':.45,'temporal_strength':.30},
    'outcome-publish': {'outcome_strength':1.0,'causal_strength':.40,'data_density':.20,'continuity_strength':.25},
    'hybrid': {'causal_strength':.45,'continuity_strength':.45,'object_centricity':.30,'transformation_strength':.30,'data_density':.20},
}

FAMILY = {
    'human-situation':'HUMAN','human-interaction':'HUMAN','handoff':'HUMAN',
    'object-story':'OBJECT','product-interaction':'OBJECT','environment-fragment':'SPATIAL',
    'physical-metaphor':'METAPHOR','data-in-context':'DATA','comparison':'DATA',
    'meaningful-process':'STRUCTURE','meaningful-network':'STRUCTURE','spatial-map':'SPATIAL',
    'transformation':'TRANSFORM','review-approval':'OUTCOME','outcome-publish':'OUTCOME','hybrid':'HYBRID'
}

# Some classes are only honest when a structural fact is present.
STRUCTURAL_CLASSES={'meaningful-process','meaningful-network'}


def _cosine(a: Dict[str,float], b: Dict[str,float]) -> float:
    dot=sum(a.get(k,0.0)*b.get(k,0.0) for k in SEMANTIC_FEATURES)
    na=math.sqrt(sum(a.get(k,0.0)**2 for k in SEMANTIC_FEATURES))
    nb=math.sqrt(sum(b.get(k,0.0)**2 for k in SEMANTIC_FEATURES))
    if na<=1e-9 or nb<=1e-9: return 0.0
    return dot/(na*nb)


def _eligibility(rep: str, beat: BeatSemantics, cap: CapabilityEnvelope) -> Tuple[bool,str]:
    if rep not in cap.supported_representations: return False,'capability-unavailable'
    f=beat.normalized_features()
    if rep in STRUCTURAL_CLASSES and not beat.structural_necessity:
        return False,'structural-necessity-not-declared'
    if rep in {'human-situation','human-interaction','handoff'} and not cap.native_character_available:
        return False,'native-character-unavailable'
    if rep in {'data-in-context','comparison'} and not cap.data_visual_available:
        return False,'data-visual-unavailable'
    if rep=='spatial-map' and not cap.spatial_map_available:
        return False,'spatial-map-unavailable'
    if rep in {'object-story','physical-metaphor','product-interaction','transformation'} and not cap.authored_object_available:
        return False,'authored-object-unavailable'
    # Reject semantically empty human casting. Presence alone is not enough for a human hero.
    if rep=='human-interaction' and f['human_interaction']<.40: return False,'human-interaction-too-weak'
    if rep=='handoff' and f['handoff_strength']<.45: return False,'handoff-too-weak'
    return True,''


def _repetition_penalty(rep: str, history: List[RepresentationDecision]) -> float:
    if not history: return 0.0
    family=FAMILY[rep]
    p=0.0
    recent=history[-3:]
    if recent[-1].representation==rep: p += .12
    if recent[-1].representation_family==family: p += .055
    if len(recent)>=2 and all(x.representation_family==family for x in recent[-2:]): p += .055
    if sum(1 for x in recent if x.representation==rep)>=2: p += .04
    return min(.20,p)


def choose_representation(beat: BeatSemantics, history: List[RepresentationDecision] | None=None,
                          capability: CapabilityEnvelope | None=None,
                          variety_pressure: float=.85) -> RepresentationDecision:
    history=history or []; capability=capability or CapabilityEnvelope(); f=beat.normalized_features()
    scored=[]; rejects=[]
    for rep in REPRESENTATION_CLASSES:
        if rep=='hybrid':
            continue  # evaluated only after two distinct strong families prove a genuine hybrid need
        ok,why=_eligibility(rep,beat,capability)
        if not ok:
            rejects.append((rep,why)); continue
        base=_cosine(f,PROFILES[rep])
        pen=_repetition_penalty(rep,history)*max(0.0,min(1.0,variety_pressure))
        scored.append([rep,base,pen,base-pen])
    # Hybrid is a composition decision, never a generic ambiguity fallback.
    ranked_nonhybrid=sorted(scored,key=lambda x:x[1],reverse=True)
    hybrid_evidence=[]
    for a in ranked_nonhybrid:
        for b in ranked_nonhybrid:
            if a[0]==b[0] or FAMILY[a[0]]==FAMILY[b[0]]: continue
            if a[1]>=.72 and b[1]>=.72 and abs(a[1]-b[1])<=.07:
                hybrid_evidence=[a,b]; break
        if hybrid_evidence: break
    if hybrid_evidence and 'hybrid' in capability.supported_representations:
        base=sum(x[1] for x in hybrid_evidence)/2 + .015
        pen=_repetition_penalty('hybrid',history)*max(0.0,min(1.0,variety_pressure))
        scored.append(['hybrid',min(1.0,base),pen,min(1.0,base)-pen])
    if not scored:
        return RepresentationDecision(beat.beat_id,'hybrid','HYBRID',0,0,0,beat.structural_necessity,0,[],[],True,'NO_ELIGIBLE_REPRESENTATION')
    scored.sort(key=lambda x:x[1],reverse=True)
    best_base=scored[0][1]
    # Variety can only choose among semantically near-equivalent candidates. It may not sacrifice fit.
    floor=max(.36,best_base*.86)
    admissible=[x for x in scored if x[1]>=floor]
    # If every fit is weak, keep the strongest candidate only as diagnostic evidence
    # and fail closed below. Never substitute a generic representation to avoid REPLAN.
    if not admissible:
        admissible=[scored[0]]
    admissible.sort(key=lambda x:(x[3],x[1]),reverse=True)
    win=admissible[0]
    confidence=max(0.0,min(1.0,win[1]))
    replan=win[1]<.34
    rationale=[f'semantic-fit={win[1]:.3f}',f'variety-penalty={win[2]:.3f}',f'family={FAMILY[win[0]]}',
               'topic-labels-excluded-from-scoring']
    alternatives=[{'representation':r,'base_fit':round(b,4),'adjusted_fit':round(a,4),'repetition_penalty':round(p,4),'family':FAMILY[r]} for r,b,p,a in sorted(scored,key=lambda x:x[3],reverse=True)[:5]]
    return RepresentationDecision(beat.beat_id,win[0],FAMILY[win[0]],win[1],win[3],confidence,beat.structural_necessity,win[2],alternatives,rationale,replan,'SEMANTIC_FIT_BELOW_FLOOR' if replan else None)
