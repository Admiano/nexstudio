from __future__ import annotations
from dataclasses import asdict
from typing import List
from .contracts import BeatSemantics, CapabilityEnvelope, VisualUnit, RepresentationDecision
from .variety_director import choose_representation
from .comprehension_scheduler import schedule_beat


def decide_sequence(beats:List[BeatSemantics], units_by_beat:dict[str,List[VisualUnit]], capability:CapabilityEnvelope|None=None, variety_pressure:float=.85):
    capability=capability or CapabilityEnvelope(); history:List[RepresentationDecision]=[]; out=[]
    for beat in beats:
        rep=choose_representation(beat,history,capability,variety_pressure)
        sched=schedule_beat(beat,units_by_beat.get(beat.beat_id,[]),capability)
        status='REPLAN_REQUIRED' if rep.replan_required or sched.replan_required else 'PASS'
        out.append({'beat_id':beat.beat_id,'status':status,'representation':rep.to_dict(),'schedule':sched.to_dict(),
                    'anti_hardcoding':{'topic_labels_scored':False,'domain_dispatch':False,'benchmark_dispatch':False,'scenario_id_dispatch':False}})
        if not rep.replan_required: history.append(rep)
    return {'schema':'NexMindWhiteboardVarietyComprehensionDecisionLayerV1','policy':{
        'representation':'SEMANTIC_STRUCTURE_COMPETITION_WITH_FIT_GUARD_AND_REPETITION_PENALTY',
        'timing':'NARRATION_CUE_EARLY_COMPLETION_THEN_COMPREHENSION_HOLD',
        'hardRules':['topic/domain nouns are not representation routing inputs','do not stretch drawing to fill narration','late semantic cues may add later units','micro-detail may group-reveal instead of serial tracing','variety never overrides materially stronger semantic fit']},
        'beats':out}
