from __future__ import annotations
import random, string, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from decision_layer_v1 import BeatSemantics, CapabilityEnvelope, VisualUnit, choose_representation, schedule_beat, decide_sequence


def beat(i, features, structural=False, duration=5.0, labels=None, complexity=.5):
    return BeatSemantics(f'b{i}',duration,features,structural_necessity=structural,topic_labels=labels or [],idea_complexity=complexity)


def test_semantic_classes():
    cases=[
      (beat(1,{'comparison_strength':1,'data_density':.4,'object_centricity':.3}),'comparison'),
      (beat(2,{'transformation_strength':1,'causal_strength':.8,'continuity_strength':.8,'object_centricity':.5}),'transformation'),
      (beat(3,{'handoff_strength':1,'human_interaction':.8,'human_presence':.7,'continuity_strength':.9}),'handoff'),
      (beat(4,{'data_density':1,'comparison_strength':.2,'causal_strength':.2}),'data-in-context'),
      (beat(5,{'spatial_strength':1,'environment_need':.3}),'spatial-map'),
      (beat(6,{'process_depth':1,'temporal_strength':.9,'causal_strength':.9},True),'meaningful-process'),
      (beat(7,{'network_density':1,'mechanism_strength':.8,'causal_strength':.5},True),'meaningful-network'),
      (beat(8,{'metaphor_opportunity':1,'transformation_strength':.7,'causal_strength':.6}),'physical-metaphor'),
      (beat(9,{'product_surface':1,'object_centricity':.8,'human_interaction':.4}),'product-interaction'),
      (beat(10,{'approval_strength':1,'causal_strength':.5}),'review-approval'),
      (beat(11,{'outcome_strength':1,'causal_strength':.5}),'outcome-publish'),
    ]
    for b,expected in cases:
        got=choose_representation(b).representation
        assert got==expected,(b.beat_id,expected,got)


def test_topic_labels_never_change_decision():
    f={'transformation_strength':.95,'causal_strength':.8,'continuity_strength':.7,'object_centricity':.55}
    a=beat(20,f,labels=['wallet','crypto','token'])
    b=beat(20,f,labels=['mitochondria','enzyme','cell'])
    c=beat(20,f,labels=['zorbax','quindle','frap'])
    da=choose_representation(a).to_dict(); db=choose_representation(b).to_dict(); dc=choose_representation(c).to_dict()
    for d in (db,dc):
        assert d['representation']==da['representation']
        assert abs(d['base_fit']-da['base_fit'])<1e-12
        assert abs(d['adjusted_fit']-da['adjusted_fit'])<1e-12


def test_variety_is_guarded_by_fit():
    strong=beat(30,{'comparison_strength':1,'data_density':.45,'object_centricity':.25})
    h=[]
    first=choose_representation(strong,h); h.append(first)
    second=choose_representation(strong,h)
    # Repetition penalty must not force a materially weaker non-comparison form.
    assert second.base_fit >= first.base_fit*.86
    assert second.representation in {'comparison','data-in-context'}


def test_structural_classes_require_structural_necessity():
    b=beat(40,{'process_depth':1,'temporal_strength':1,'causal_strength':1},False)
    d=choose_representation(b)
    assert d.representation!='meaningful-process'


def test_scheduler_finishes_early_and_holds():
    b=beat(50,{},duration=6.0,complexity=.5)
    units=[VisualUnit('hero','HERO',.7,importance=1),VisualUnit('support','SUPPORT',.5,dependencies=['hero']),VisualUnit('annotation','ANNOTATION',.3,dependencies=['support'])]
    s=schedule_beat(b,units)
    assert not s.replan_required
    assert s.visual_completion_seconds < 5.4
    assert s.comprehension_hold_seconds >= .6


def test_scheduler_respects_late_cue_without_stretching_all_units():
    b=beat(51,{},duration=8.0,complexity=.65)
    units=[VisualUnit('base','HERO',.65,importance=1),VisualUnit('late','ANNOTATION',.4,cue_fraction=.72,dependencies=['base'])]
    s=schedule_beat(b,units)
    base=s.units[0]; late=s.units[1]
    assert base.draw_end_seconds < 3.0
    assert late.start_seconds >= 8*.72-.17
    assert s.comprehension_hold_seconds >= .38


def test_microdetail_groups_instead_of_serial_trace():
    b=beat(52,{},duration=4.0,complexity=.6)
    units=[VisualUnit('hero','HERO',.65,importance=1),VisualUnit('micro','DETAIL',.9,dependencies=['hero'])]
    s=schedule_beat(b,units)
    micro=next(x for x in s.units if x.unit_id=='micro')
    assert micro.draw_policy=='GROUP_REVEAL'


def test_fuzz_noun_mutation_invariance():
    rng=random.Random(20260905)
    for i in range(1000):
        f={k:rng.random() for k in ['human_presence','human_interaction','object_centricity','environment_need','metaphor_opportunity','product_surface','data_density','process_depth','network_density','comparison_strength','spatial_strength','transformation_strength','handoff_strength','approval_strength','outcome_strength','uncertainty','continuity_strength','mechanism_strength','causal_strength','temporal_strength']}
        structural=bool(rng.randrange(2))
        labels1=[''.join(rng.choice(string.ascii_lowercase) for _ in range(9)) for _ in range(4)]
        labels2=[''.join(rng.choice(string.ascii_lowercase) for _ in range(11)) for _ in range(5)]
        a=beat(1000+i,f,structural=structural,labels=labels1)
        b=beat(1000+i,f,structural=structural,labels=labels2)
        da=choose_representation(a); db=choose_representation(b)
        assert da.representation==db.representation
        assert abs(da.base_fit-db.base_fit)<1e-12


def test_combined_sequence_receipt():
    bs=[beat(70,{'data_density':1},duration=4.2),beat(71,{'transformation_strength':1,'causal_strength':.8},duration=5.0)]
    units={'b70':[VisualUnit('metric','HERO',.55)],'b71':[VisualUnit('before','HERO',.45),VisualUnit('after','SUPPORT',.55,dependencies=['before'])]}
    r=decide_sequence(bs,units)
    assert r['schema']=='NexMindWhiteboardVarietyComprehensionDecisionLayerV1'
    assert all(x['anti_hardcoding']['topic_labels_scored'] is False for x in r['beats'])

if __name__=='__main__':
    tests=[v for k,v in list(globals().items()) if k.startswith('test_') and callable(v)]
    failures=[]
    for t in tests:
        try: t(); print('PASS',t.__name__)
        except Exception as e: failures.append((t.__name__,repr(e))); print('FAIL',t.__name__,repr(e))
    print(json.dumps({'passed':len(tests)-len(failures),'failed':len(failures),'failures':failures},indent=2))
    raise SystemExit(1 if failures else 0)
