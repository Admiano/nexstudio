from __future__ import annotations
import json, random, string, sys, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from decision_layer_v1 import BeatSemantics, VisualUnit, choose_representation, schedule_beat

rng=random.Random(560905)
features=['human_presence','human_interaction','object_centricity','environment_need','metaphor_opportunity','product_surface','data_density','process_depth','network_density','comparison_strength','spatial_strength','transformation_strength','handoff_strength','approval_strength','outcome_strength','uncertainty','continuity_strength','mechanism_strength','causal_strength','temporal_strength']

noun_mutation_pass=0
schedule_pass=0
replan_count=0
min_hold=999
for i in range(5000):
    f={k:rng.random() for k in features}; structural=bool(rng.getrandbits(1)); dur=rng.uniform(2.0,10.0); complexity=rng.random()
    lab1=[''.join(rng.choice(string.ascii_lowercase) for _ in range(8)) for _ in range(4)]
    lab2=[''.join(rng.choice(string.ascii_lowercase) for _ in range(13)) for _ in range(4)]
    a=BeatSemantics(f'x{i}',dur,f,structural_necessity=structural,topic_labels=lab1,idea_complexity=complexity)
    b=BeatSemantics(f'x{i}',dur,f,structural_necessity=structural,topic_labels=lab2,idea_complexity=complexity)
    da=choose_representation(a); db=choose_representation(b)
    if da.representation!=db.representation or abs(da.base_fit-db.base_fit)>1e-12: raise AssertionError('NOUN_MUTATION_CHANGED_DECISION')
    noun_mutation_pass+=1
    n=rng.randint(1,7); units=[]
    for j in range(n):
        role=rng.choice(['HERO','SUPPORT','EVIDENCE','ANNOTATION','CONNECTOR','DETAIL','SYMBOL'])
        cue=None if rng.random()<.72 else rng.uniform(.2,.82)
        units.append(VisualUnit(f'u{j}',role,rng.random(),cue_fraction=cue,dependencies=[f'u{j-1}'] if j else [],importance=rng.random()))
    s=schedule_beat(a,units)
    if s.replan_required: replan_count+=1
    else:
        if s.visual_completion_seconds>dur+1e-6: raise AssertionError('SCHEDULE_OVERFLOW')
        if s.comprehension_hold_seconds<.379: raise AssertionError('HOLD_BELOW_FLOOR')
        min_hold=min(min_hold,s.comprehension_hold_seconds)
    schedule_pass+=1

impl=ROOT/'decision_layer_v1'
forbidden=['virtuals','robinhood','wallet','crypto','bitcoin','robot','doctor','patient','invoice','kitchen','classroom','stockroom','hospital','grocery','benchmark-','scene_01','scene-01']
source_hits=[]
for p in impl.glob('*.py'):
    text=p.read_text().lower()
    for token in forbidden:
        if token in text: source_hits.append({'file':p.name,'token':token})
if source_hits: raise AssertionError('SCENARIO_TOKEN_IN_IMPLEMENTATION:'+json.dumps(source_hits))

report={'schema':'NexMindWhiteboardVarietyComprehensionQA_V1','seed':560905,'nounMutationCases':noun_mutation_pass,'schedulerFuzzCases':schedule_pass,'schedulerReplanCases':replan_count,'minimumPassingHoldSeconds':None if min_hold==999 else round(min_hold,4),'implementationScenarioTokenScan':'PASS','forbiddenTokensScanned':forbidden,'status':'PASS'}
print(json.dumps(report,indent=2))
