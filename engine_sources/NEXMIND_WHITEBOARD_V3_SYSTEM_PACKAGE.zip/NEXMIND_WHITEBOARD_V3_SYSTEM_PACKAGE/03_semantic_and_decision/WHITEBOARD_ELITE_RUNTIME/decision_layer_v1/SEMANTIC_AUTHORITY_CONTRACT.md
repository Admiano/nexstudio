# Semantic Authority Contract

The Variety + Comprehension layer does **not** infer topic meaning from nouns. NexMind Story/Visual authority must emit `NexMind Whiteboard Beat Semantics V1` as a sidecar for each narration beat.

The feature values describe the *structure of the idea*, not its domain. Examples of valid questions the upstream authority answers:

- Is a human actually causing/experiencing something, or merely mentioned?
- Is the beat primarily a transformation, comparison, handoff, spatial relation, process, network, evidence/data, product interaction, or physical metaphor opportunity?
- Does comprehension require environment context, or can the idea stand on a clean board?
- Does a process/network representation have genuine structural necessity?
- Which visual units correspond to later spoken cues, and which depend on earlier units?

`topic_labels` may carry names for provenance and asset lookup **after** representation is chosen. They are excluded from the representation vector by contract and test.

If upstream semantics are weak or contradictory, the layer returns `REPLAN_REQUIRED`. It may not repair missing meaning by defaulting to a chart, diagram, character, metaphor, or text card.
