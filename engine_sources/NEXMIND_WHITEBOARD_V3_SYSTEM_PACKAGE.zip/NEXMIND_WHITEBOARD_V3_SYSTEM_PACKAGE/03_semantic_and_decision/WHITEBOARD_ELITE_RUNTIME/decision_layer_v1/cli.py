from __future__ import annotations
import argparse, json, sys
from pathlib import Path
if __package__ in {None,''}:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    from decision_layer_v1.contracts import BeatSemantics, CapabilityEnvelope, VisualUnit
    from decision_layer_v1.combined import decide_sequence
else:
    from .contracts import BeatSemantics, CapabilityEnvelope, VisualUnit
    from .combined import decide_sequence


def _beat(row):
    allowed={'beat_id','duration_seconds','features','semantic_relations','board_change','continuity_object','structural_necessity','idea_complexity','narration_text','topic_labels'}
    return BeatSemantics(**{k:v for k,v in row.items() if k in allowed})

def _unit(row):
    allowed={'unit_id','semantic_role','complexity','draw_policy','cue_fraction','cue_seconds','dependencies','persistent','importance'}
    return VisualUnit(**{k:v for k,v in row.items() if k in allowed})

def run(payload):
    cap=CapabilityEnvelope(**payload.get('capability',{}))
    beats=[]; units={}
    for row in payload.get('beats',[]):
        b=_beat(row); beats.append(b); units[b.beat_id]=[_unit(x) for x in row.get('visual_units',[])]
    if not beats: raise ValueError('DECISION_LAYER_BEATS_REQUIRED')
    return decide_sequence(beats,units,cap,float(payload.get('variety_pressure',.85)))

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--out')
    a=ap.parse_args(); payload=json.loads(Path(a.input).read_text()); result=run(payload); raw=json.dumps(result,indent=2)+'\n'
    if a.out: Path(a.out).write_text(raw)
    print(json.dumps(result,separators=(',',':')))
