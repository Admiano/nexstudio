'use strict';
const path=require('path');
const fs=require('fs');
const crypto=require('crypto');
const {spawnSync}=require('child_process');
const ROOT=path.resolve(__dirname,'../..');
const CAP=require(path.join(ROOT,'CAPABILITY_RUNTIME/runtime'));
const SPEED=require(path.join(ROOT,'SPEED_RUNTIME/runtime'));
const CANDIDATE=path.resolve(ROOT);
const WHITEBOARD_RUNTIME=path.join(CANDIDATE,'WHITEBOARD_ELITE_RUNTIME','runtime.py');
const WHITEBOARD_DECISION=path.join(CANDIDATE,'WHITEBOARD_ELITE_RUNTIME','decision_layer_v1','cli.py');
function hashBytes(b){return crypto.createHash('sha256').update(b).digest('hex');}
function manifest(){
  return {
    schema:'NexMindSystemExecutionGatewayV1',
    rule:'Shared deterministic compiler/cache/router/DAG/quality seam. No scenario-specific execution keys.',
    determinism:!!CAP.determinism, compiler:!!CAP.compiler, universalActivity:!!CAP.universalActivity,
    fingerprint:!!SPEED.fingerprint, exactCache:!!SPEED.cache, router:!!SPEED.router, semanticIndex:!!SPEED.semantic,
    dag:!!SPEED.dag, structuredOutput:!!SPEED.structured, externalBackends:!!SPEED.backends,
    ffmpeg:!!SPEED.rawFfmpeg, qualityCost:!!SPEED.qualityCost,
    whiteboardElite:{available:fs.existsSync(WHITEBOARD_RUNTIME),modes:['static','render'],runtime:WHITEBOARD_RUNTIME,decisionLayer:{available:fs.existsSync(WHITEBOARD_DECISION),runtime:WHITEBOARD_DECISION,policy:'SEMANTIC_STRUCTURE_ONLY_NO_DOMAIN_DISPATCH'}}
  };
}
function activity(input,ctx={}){return CAP.universalActivity.compile(input,ctx);}
function whiteboardDecision(input,ctx={}){
  if(!input || typeof input!=='object') throw new Error('WHITEBOARD_DECISION_INPUT_OBJECT_REQUIRED');
  const outDir=path.resolve(ctx.outputDir||input.output_dir||path.join('/mnt/data','nexmind-whiteboard-decision')); fs.mkdirSync(outDir,{recursive:true});
  const clean=Object.assign({},input); delete clean.output_dir; const inputPath=path.join(outDir,'DECISION_INPUT.json'); fs.writeFileSync(inputPath,JSON.stringify(clean,null,2)+'\n');
  const outputPath=path.join(outDir,'WHITEBOARD_VARIETY_COMPREHENSION_DECISION.json'); const t0=Date.now();
  const r=spawnSync(process.env.PYTHON||'python',[WHITEBOARD_DECISION,'--input',inputPath,'--out',outputPath],{encoding:'utf8',env:Object.assign({},process.env,{PYTHONDONTWRITEBYTECODE:'1'})});
  if(r.status!==0) throw new Error('WHITEBOARD_DECISION_LAYER_FAILED:'+String(r.stderr||r.stdout).slice(-4000));
  const result=JSON.parse(fs.readFileSync(outputPath,'utf8'));
  const receipt={schema:'NexMindSystemGatewayWhiteboardDecisionReceiptV1',gateway:__filename,gatewaySha256:hashBytes(fs.readFileSync(__filename)),decisionRuntime:WHITEBOARD_DECISION,decisionRuntimeSha256:hashBytes(fs.readFileSync(WHITEBOARD_DECISION)),inputPath,inputSha256:hashBytes(fs.readFileSync(inputPath)),outputPath,elapsedMs:Date.now()-t0,result,domainDispatch:false,scenarioDispatch:false,benchmarkDispatch:false};
  fs.writeFileSync(path.join(outDir,'DECISION_GATEWAY_RECEIPT.json'),JSON.stringify(receipt,null,2)+'\n'); return Object.assign({},result,{gateway_receipt:path.join(outDir,'DECISION_GATEWAY_RECEIPT.json')});
}
function whiteboardElite(input,ctx={}){
  if(!input || typeof input!=='object') throw new Error('WHITEBOARD_ELITE_BRIEF_OBJECT_REQUIRED');
  const mode=(ctx.mode||input.execution_mode||'render').toLowerCase();
  if(!['static','render'].includes(mode)) throw new Error('WHITEBOARD_ELITE_MODE_INVALID:'+mode);
  const outDir=path.resolve(ctx.outputDir||input.output_dir||path.join('/mnt/data','nexmind-whiteboard-output'));
  fs.mkdirSync(outDir,{recursive:true});
  const brief=Object.assign({},input); delete brief.execution_mode; delete brief.output_dir;
  const briefBytes=Buffer.from(JSON.stringify(brief,null,2)+'\n');
  const briefPath=path.join(outDir,'GATEWAY_INPUT_BRIEF.json'); fs.writeFileSync(briefPath,briefBytes);
  const args=[WHITEBOARD_RUNTIME,'--mode',mode,'--out',outDir,'--brief',briefPath];
  const t0=Date.now();
  const r=spawnSync(process.env.PYTHON||'python',args,{encoding:'utf8',env:Object.assign({},process.env,{PYTHONDONTWRITEBYTECODE:'1',OMP_NUM_THREADS:'1',OPENBLAS_NUM_THREADS:'1',MKL_NUM_THREADS:'1',NUMEXPR_NUM_THREADS:'1'})});
  if(r.status!==0) throw new Error('WHITEBOARD_ELITE_RUNTIME_FAILED:'+String(r.stderr||r.stdout).slice(-4000));
  const lines=String(r.stdout||'').trim().split(/\n/).filter(Boolean); let result={};
  try{result=JSON.parse(lines[lines.length-1]);}catch(e){throw new Error('WHITEBOARD_ELITE_RESULT_PARSE_FAILED:'+String(r.stdout).slice(-2000));}
  const gatewayPath=__filename; const receipt={schema:'NexMindSystemGatewayWhiteboardEliteReceiptV1',gateway:gatewayPath,gatewaySha256:hashBytes(fs.readFileSync(gatewayPath)),whiteboardRuntime:WHITEBOARD_RUNTIME,whiteboardRuntimeSha256:hashBytes(fs.readFileSync(WHITEBOARD_RUNTIME)),mode,briefPath,briefSha256:hashBytes(briefBytes),outputDir:outDir,elapsedMs:Date.now()-t0,childExitCode:r.status,result,manualSceneAssembly:false,manualPoseSelection:false,manualPixelBinding:false};
  fs.writeFileSync(path.join(outDir,'GATEWAY_EXECUTION_RECEIPT.json'),JSON.stringify(receipt,null,2)+'\n');
  return Object.assign({},result,{gateway_receipt:path.join(outDir,'GATEWAY_EXECUTION_RECEIPT.json')});
}
module.exports={manifest,activity,whiteboardDecision,whiteboardElite,capability:CAP,speed:SPEED};
if(require.main===module){
  let raw=''; process.stdin.setEncoding('utf8'); process.stdin.on('data',c=>raw+=c); process.stdin.on('end',()=>{
    try{const payload=JSON.parse(raw||'{}'); const op=payload.operation||'manifest'; let out;
      if(op==='manifest') out=manifest();
      else if(op==='activity') out=activity(payload.input||{},payload.context||{});
      else if(op==='whiteboardDecision') out=whiteboardDecision(payload.input||{},payload.context||{});
      else if(op==='whiteboardElite') out=whiteboardElite(payload.input||{},payload.context||{});
      else throw new Error('UNKNOWN_GATEWAY_OPERATION:'+op);
      process.stdout.write(JSON.stringify(out)+'\n');
    }catch(e){process.stderr.write(String(e.stack||e)+'\n');process.exit(1);}
  });
}
