import copy,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from semantic_illustration_composer import compose

BASE={
 'beat_id':'mtest','representation_family':'metaphor',
 'entities':[{'id':'a','role':'system','label':'A','importance':.9},{'id':'b','role':'system','label':'B','importance':.8}],
 'relations':[{'type':'connects_to','source':'a','target':'b'}], 'evidence':[]
}
fixtures={
'bottleneck':dict(structure='constrained_flow',features={'flow_present':1,'constrained_capacity':1,'throughput_pressure':1},source_entity='a',target_entity='b'),
'bridge':dict(structure='cross_gap_transfer',features={'separated_domains':1,'connection_or_transfer_need':1},source_entity='a',target_entity='b'),
'pool':dict(structure='shared_pool',features={'shared_resource':1,'many_contributors':1,'redistribution_or_shared_access':1},resource_entity='a',contributor_entities=['a','b']),
'vault':dict(structure='protected_access',features={'protected_resource':1,'controlled_access':1},resource_entity='a'),
'widening_lanes':dict(structure='capacity_expansion',features={'flow_present':1,'capacity_expansion':1,'same_flow_preserved':1},source_entity='a',target_entity='b'),
'balance':dict(structure='equilibrium',features={'opposing_forces':1,'equilibrium_or_tradeoff':1},force_entities=['a','b']),
'fragmentation_reassembly':dict(structure='fragment_reassembly',features={'fragmented_state':1,'reassembly_or_integration':1},fragment_entities=['a','b']),
'stacking_compounding':dict(structure='compounding',features={'repeated_accumulation':1,'retained_gain':1,'multiplicative_or_reinvested_effect':1}),
'flywheel':dict(structure='feedback_cycle',features={'reinforcing_feedback':1,'closed_loop':1},cycle_entities=['a','b','c']),
'branching_paths':dict(structure='branching',features={'one_to_many_divergence':1,'alternative_paths':1},source_entity='a',branch_targets=['b','c']),
'sieve_filter':dict(structure='filtering',features={'many_to_few_selection':1,'selection_criteria':1},source_entity='a',target_entity='b'),
'relay_handoff':dict(structure='handoff_chain',features={'staged_transfer':1,'custody_or_state_handoff':1},stage_entities=['a','b','c']),
}

def test_all_12_forms_integrate():
    for form,ms in fixtures.items():
        x=copy.deepcopy(BASE); x['metaphor_semantics']=ms
        o=compose(x); assert o['status']=='PASS',(form,o)
        mm=o['metaphor_module']; assert mm['status']=='PASS' and mm['selected_form']==form,(form,mm)
        assert set(mm['renderer_bindings'])=={'16:9','1:1','9:16'}
        for b in mm['renderer_bindings'].values(): assert b['render_policies']['generic_metaphor_fallback']=='FORBIDDEN'

def test_metaphor_family_requires_semantics():
    o=compose(copy.deepcopy(BASE)); assert o['status']=='REPLAN_REQUIRED' and o['reason']=='METAPHOR_REPLAN_REQUIRED'

def test_weak_optional_metaphor_stays_literal_for_nonmetaphor_rep():
    x=copy.deepcopy(BASE); x['representation_family']='object'; x['metaphor_semantics']={'structure':'unknown','features':{}}
    o=compose(x); assert o['status']=='PASS'; assert o['metaphor_module']['status']=='LITERAL'

def test_labels_do_not_route_metaphor():
    x=copy.deepcopy(BASE); x['metaphor_semantics']=copy.deepcopy(fixtures['bridge']); x['metaphor_semantics']['label']='vault pool bottleneck flywheel'
    o=compose(x); assert o['metaphor_module']['selected_form']=='bridge'

if __name__=='__main__':
    funcs=[v for k,v in sorted(globals().items()) if k.startswith('test_')]
    for f in funcs: f(); print('PASS',f.__name__)
    print(f'{len(funcs)}/{len(funcs)} PASS')
