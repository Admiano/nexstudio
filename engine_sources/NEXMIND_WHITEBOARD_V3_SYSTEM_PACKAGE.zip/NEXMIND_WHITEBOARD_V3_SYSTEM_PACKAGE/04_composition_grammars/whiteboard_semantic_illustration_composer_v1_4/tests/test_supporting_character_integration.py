import copy,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from semantic_illustration_composer import compose

def base():
    return {
      "beat_id":"char-int",
      "representation_family":"human-interaction",
      "human_agency":0.95,
      "entities":[
        {"id":"p1","role":"actor","label":"Person","importance":0.8},
        {"id":"obj","role":"interface","label":"Device","importance":0.95},
      ],
      "relations":[{"source":"p1","target":"obj","type":"acts_on"}],
      "evidence":[]
    }

fixtures={
 "person_phone":{"structure":"handheld_interaction","actor_entities":["p1"],"device_entity":"obj","features":{"human_explanatory_value":1}},
 "person_laptop":{"structure":"workstation_interaction","actor_entities":["p1"],"device_entity":"obj","features":{"human_explanatory_value":1}},
 "operator_machine":{"structure":"machine_operation","actor_entities":["p1"],"machine_entity":"obj","features":{"human_explanatory_value":1}},
 "presenter":{"structure":"presentation","actor_entities":["p1"],"presentation_entity":"obj","features":{"human_explanatory_value":1}},
 "approver":{"structure":"approval","actor_entities":["p1"],"approval_target_entity":"obj","features":{"human_explanatory_value":1}},
}

def test_five_single_actor_forms_integrate():
    for form,s in fixtures.items():
        x=base(); x["supporting_character_semantics"]=copy.deepcopy(s)
        o=compose(x); assert o["status"]=="PASS",(form,o)
        m=o["supporting_character_module"]; assert m["status"]=="PASS" and m["selected_form"]==form
        assert m["integration_policy"]["character_scale_ceiling"]<=0.78
        for b in m["renderer_bindings"].values():
            assert b["render_policies"]["stock_doodle_fallback"]=="FORBIDDEN"

def test_giver_receiver_integrates():
    x=base()
    x["entities"]=[
      {"id":"p1","role":"actor","label":"A","importance":.8},
      {"id":"p2","role":"actor","label":"B","importance":.8},
      {"id":"item","role":"object","label":"Item","importance":.95},
    ]
    x["relations"]=[{"source":"p1","target":"p2","type":"hands_to"}]
    x["supporting_character_semantics"]={"structure":"person_transfer","actor_entities":["p1","p2"],"transfer_entity":"item","features":{"human_explanatory_value":1}}
    o=compose(x); assert o["supporting_character_module"]["selected_form"]=="giver_receiver"

def test_two_person_comparison_integrates():
    x=base()
    x["entities"]=[{"id":"p1","role":"actor","label":"A","importance":.8},{"id":"p2","role":"actor","label":"B","importance":.8}]
    x["relations"]=[{"source":"p1","target":"p2","type":"compares"}]
    x["supporting_character_semantics"]={"structure":"human_comparison","actor_entities":["p1","p2"],"features":{"human_explanatory_value":1}}
    o=compose(x); assert o["supporting_character_module"]["selected_form"]=="two_person_comparison"

def test_actor_component_scale_is_capped():
    x=base(); x["supporting_character_semantics"]=copy.deepcopy(fixtures["person_phone"])
    o=compose(x)
    chars=[c for c in o["components"] if c["kind"]=="native_whiteboard_character"]
    assert chars and max(c["scale_band"] for c in chars)<=0.78

def test_low_human_value_stays_object_led():
    x=base()
    s=copy.deepcopy(fixtures["person_phone"]); s["features"]["human_explanatory_value"]=0.2
    x["supporting_character_semantics"]=s
    o=compose(x); assert o["status"]=="PASS"
    assert o["supporting_character_module"]["status"]=="OBJECT_LED"

def test_recurring_identity_explicit_only():
    x=base(); s=copy.deepcopy(fixtures["person_laptop"])
    x["supporting_character_semantics"]=s
    o=compose(x); assert not o["supporting_character_module"]["decision"]["identity_policy"]["recurring_character"]
    s["continuity_required"]=True; s["continuity_reason"]="same_actor_across_beats"; s["continuity_entity_ids"]=["p1"]
    o=compose(x); assert o["supporting_character_module"]["decision"]["identity_policy"]["recurring_character"]

if __name__=="__main__":
    funcs=[v for k,v in sorted(globals().items()) if k.startswith("test_")]
    for f in funcs: f(); print("PASS",f.__name__)
    print(f"{len(funcs)}/{len(funcs)} PASS")
