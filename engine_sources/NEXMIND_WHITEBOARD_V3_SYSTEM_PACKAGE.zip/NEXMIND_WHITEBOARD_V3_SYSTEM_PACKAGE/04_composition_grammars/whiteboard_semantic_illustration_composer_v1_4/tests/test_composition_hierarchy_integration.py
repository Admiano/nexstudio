import copy,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from semantic_illustration_composer import compose

def base(rep='meaningful-process'):
 return {'beat_id':'h1','representation_family':rep,'human_agency':.1,
 'entities':[{'id':'a','role':'system','label':'A','importance':.95},{'id':'b','role':'object','label':'B','importance':.75},{'id':'c','role':'result','label':'C','importance':.7}],
 'relations':[{'source':'a','target':'b','type':'acts_on'},{'source':'b','target':'c','type':'produces'}],'evidence':[]}

def test_process_has_explicit_hierarchy():
 o=compose(base()); assert o['status']=='PASS'
 h=o['composition_hierarchy']; assert h['status']=='PASS'
 assert h['hero_illustration'].startswith('compound:')
 assert set(h['classification'].values()) <= {'hero_illustration','supporting_evidence','micro_annotation'}
 assert o['style_contract']['hero_support_micro_classes_required']

def test_data_beat_promotes_governed_data_not_naked_number():
 x=base('data-in-context'); x['evidence']=[{'shape':'comparison','values':[12,20],'labels':['x','y'],'importance':.95,'narrative_weight':1.0,'features':{'two_state_change':1.0}}]
 o=compose(x); assert o['status']=='PASS'
 assert o['composition_hierarchy']['hero_illustration']=='evidence:0'
 assert o['data_modules'][0]['composition_class']=='hero_illustration'

def test_supporting_character_is_never_top_level_hero():
 x=base('human-interaction'); x['human_agency']=1
 x['entities']=[{'id':'p','role':'actor','label':'Person','importance':.9},{'id':'m','role':'system','label':'Machine','importance':1.0}]
 x['relations']=[{'source':'p','target':'m','type':'operates'}]
 x['supporting_character_semantics']={'structure':'machine_operation','actor_entities':['p'],'machine_entity':'m','features':{'human_explanatory_value':1}}
 o=compose(x); assert o['status']=='PASS'
 assert o['supporting_character_module']['composition_class']=='supporting_evidence'
 assert o['composition_hierarchy']['hero_illustration']!='supporting-character:module'

def test_metaphor_beat_promotes_governed_metaphor():
 x=base('metaphor')
 x['metaphor_semantics']={'structure':'constrained_flow','entity_ids':['a','b'],'features':{'continuous_flow':1,'capacity_constraint':1,'throughput_pressure':1},'source_entity':'a','target_entity':'b'}
 o=compose(x); assert o['status']=='PASS',o
 assert o['composition_hierarchy']['hero_illustration']=='metaphor:module'
 assert o['metaphor_module']['composition_class']=='hero_illustration'

def test_ratio_area_budgets_preserve_hierarchy():
 o=compose(base()); h=o['composition_hierarchy']
 for a in ('16:9','1:1','9:16'):
  b=h['aspect_layouts'][a]['area_budget']; assert abs(sum(b.values())-1)<1e-9
  assert b['hero_illustration']>=.42 and b['micro_annotation_total_max']<=.08
  rb=o['composition_hierarchy_renderer_bindings'][a]
  assert rb['render_policies']['renderer_may_promote_or_demote_elements'] is False
  assert rb['render_policies']['vo_cue_remains_master_timeline'] is True

def test_internal_relation_cues_inherit_hero_class():
 o=compose(base())
 assert all(r['composition_class']=='hero_illustration' for r in o['relations'])

def test_true_annotations_are_micro():
 x=base(); x['annotations']=[{'id':'note:1','importance':.2,'essential':True}]
 o=compose(x); assert o['status']=='PASS'
 assert o['composition_hierarchy']['classification']['note:1']=='micro_annotation'

def test_hero_enrichment_contract_no_filler():
 x=base(); x['entities']=[{'id':'a','role':'object','label':'A','importance':1}]; x['relations']=[]
 o=compose(x); assert o['status']=='PASS'
 h=o['composition_hierarchy']; assert h['hero_enrichment_needed'] is True
 assert h['hero_enrichment_contract']['decorative_filler_forbidden'] is True

if __name__=='__main__':
 fs=[v for k,v in sorted(globals().items()) if k.startswith('test_')]
 for f in fs: f(); print('PASS',f.__name__)
 print(f'{len(fs)}/{len(fs)} PASS')
