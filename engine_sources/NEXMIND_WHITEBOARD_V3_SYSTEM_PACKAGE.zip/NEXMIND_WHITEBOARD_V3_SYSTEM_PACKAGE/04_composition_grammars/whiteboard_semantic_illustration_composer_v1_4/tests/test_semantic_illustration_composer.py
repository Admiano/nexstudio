import copy, json, random, string, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from semantic_illustration_composer import compose, normalized_structure, ComposeError

def base(rep='meaningful-process'):
    return {
      'beat_id':'blind-1','representation_family':rep,'human_agency':0.1,
      'entities':[
        {'id':'a','role':'system','label':'alpha','importance':0.9},
        {'id':'b','role':'object','label':'beta','importance':0.7},
        {'id':'c','role':'result','label':'gamma','importance':0.65},
      ],
      'relations':[
        {'source':'a','target':'b','type':'acts_on'},
        {'source':'b','target':'c','type':'produces'},
      ],
      'evidence':[]
    }

def test_compound_not_naked_icons():
    o=compose(base())
    assert o['status']=='PASS'
    assert any(g['kind']=='compound_illustration' and len(g['concept_ids'])>=3 for g in o['compound_groups'])
    assert o['style_contract']['compound_illustration_preferred_over_naked_icon'] is True

def test_no_stray_decorative_language():
    o=compose(base())
    s=o['style_contract']
    assert not s['decorative_satellites'] and not s['orphan_marks'] and not s['free_running_lines']
    for c in o['components']:
        assert not c['purity']['allow_decorative_satellites']
        assert not c['purity']['allow_free_connector']
    for r in o['relations']:
        assert r['connector_policy']['requires_two_valid_endpoints']
        assert r['connector_policy']['may_not_exist_before_destination']

def test_native_character_semantic_only():
    x=base('handoff'); x['human_agency']=0.9
    x['entities'][0]={'id':'a','role':'actor','label':'person-a','importance':0.8}
    x['entities'][1]={'id':'b','role':'actor','label':'person-b','importance':0.8}
    x['relations']=[{'source':'a','target':'b','type':'hands_to'}]
    o=compose(x)
    chars=[c for c in o['components'] if c['kind']=='native_whiteboard_character']
    assert len(chars)==2
    assert max(c['scale_band'] for c in chars) <= 1.0
    y=copy.deepcopy(x); y['human_agency']=0.1
    assert not [c for c in compose(y)['components'] if c['kind']=='native_whiteboard_character']

def test_data_is_contextual_not_naked_number():
    x=base('data-in-context')
    x['evidence']=[{'shape':'comparison','values':[12,20],'labels':['before','after'],'features':{'two_state_change':1.0}}]
    o=compose(x)
    assert o['data_modules'][0]['presentation']=='integrated_not_naked_number'
    assert o['data_modules'][0]['selected_form']=='before_after'
    assert o['style_contract']['data_must_be_contextual_when_evidence_exists']

def test_aspect_reflow_preserves_hierarchy():
    o=compose(base())
    assert set(o['aspect_layouts'])=={'16:9','1:1','9:16'}
    for v in o['aspect_layouts'].values():
        assert v['preserve_hierarchy'] and v['no_stretch'] and v['no_crop_labels']
        assert v['max_character_to_object_scale_ratio']<=1.10

def test_noun_mutation_invariance():
    x=base('transformation')
    target=normalized_structure(compose(x))
    rng=random.Random(7)
    for _ in range(1000):
        y=copy.deepcopy(x)
        for e in y['entities']:
            e['label']=''.join(rng.choice(string.ascii_letters) for _ in range(16))
        assert normalized_structure(compose(y))==target

def test_comparison_can_have_two_heroes():
    x=base('comparison'); x['relations']=[{'source':'a','target':'b','type':'compares'}]
    o=compose(x)
    assert o['hierarchy']['a']=='hero' and o['hierarchy']['b']=='hero'

def test_fail_closed_major_budget():
    x=base(); x['entities']=[]
    for i in range(8): x['entities'].append({'id':f'e{i}','role':'object','label':str(i),'importance':1-i*.01})
    x['relations']=[{'source':f'e{i}','target':f'e{i+1}','type':'connects_to'} for i in range(7)]
    # Hierarchy caps non-hero entities after first few as micro, so composer remains sparse.
    o=compose(x); assert o['status']=='PASS'
    assert sum(1 for c in o['components'] if c['hierarchy'] in {'hero','support'})<=4

def test_bad_relation_fails():
    x=base(); x['relations']=[{'source':'a','target':'missing','type':'flows_to'}]
    try: compose(x); assert False
    except ComposeError as e: assert 'RELATION_ENDPOINT_MISSING' in str(e)

if __name__=='__main__':
    funcs=[v for k,v in sorted(globals().items()) if k.startswith('test_')]
    for f in funcs: f(); print('PASS',f.__name__)
    print(f'{len(funcs)}/{len(funcs)} PASS')
