import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from semantic_illustration_composer import compose

CASES=[
 ('counter','scalar',[45000],{'single_total':1.0},{}),
 ('accumulation','accumulation',[10,30,60],{'cumulative':1.0},{}),
 ('before_after','comparison',[80,50],{'two_state_change':1.0},{}),
 ('bars','comparison',[10,20,15],{'categorical_comparison':1.0},{}),
 ('ratio','ratio',[3,1],{'ratio_relation':1.0},{}),
 ('percentage','ratio',[62,38],{'part_to_whole':1.0},{'normalized_total':100,'percentage_unit':True}),
 ('funnel','funnel',[1000,520,180,75],{'staged_attrition':1.0},{}),
 ('timeline','timeline',[1,2,3,4],{'chronological_sequence':1.0},{}),
 ('growth_decline','trend',[10,20,35],{'directional_change':1.0},{}),
 ('ranking','ranking',[90,80,70],{'ordered_rank':1.0},{}),
 ('value_flow','value_flow',[250],{'value_transfer':1.0},{'source_entity':'a','target_entity':'b'}),
]

def beat(shape,values,features,extra):
    return {
      'beat_id':'data-proof','representation_family':'data-in-context','human_agency':0.0,
      'entities':[{'id':'a','role':'system','label':'A','importance':0.9},{'id':'b','role':'result','label':'B','importance':0.7}],
      'relations':[{'source':'a','target':'b','type':'produces'}],
      'evidence':[{'shape':shape,'values':values,'labels':[f'L{i}' for i in range(len(values))],'features':features,**extra}]
    }

def test_all_forms_via_composer():
    for expected,shape,values,features,extra in CASES:
        o=compose(beat(shape,values,features,extra)); assert o['status']=='PASS',(expected,o)
        m=o['data_modules'][0]; assert m['selected_form']==expected,(expected,m['selected_form'])
        assert m['presentation']=='integrated_not_naked_number'
        d=m['data_grammar_decision']; assert d['routing_proof']['chart_is_default'] is False
        assert d['context_binding']['may_float_as_naked_number'] is False

def test_ambiguous_comparison_replans():
    x=beat('comparison',[10,20],{},{}); o=compose(x)
    assert o['status']=='REPLAN_REQUIRED' and o['reason']=='DATA_PRESENTATION_REPLAN_REQUIRED'

if __name__=='__main__':
    funcs=[v for k,v in sorted(globals().items()) if k.startswith('test_')]
    for f in funcs: f(); print('PASS',f.__name__)
    print(f'{len(funcs)}/{len(funcs)} PASS')
