#!/usr/bin/env python3
"""NexMind Whiteboard Metaphor Grammar V1.

Selects a reusable physical/visual mechanism from abstract semantic structure.
Content labels/nouns are payload only and never participate in selection.
"""
from __future__ import annotations
from typing import Any, Dict
import copy, json, math

VERSION = "1.0.0"

FORMS = (
    "bottleneck", "bridge", "pool", "vault", "widening_lanes", "balance",
    "fragmentation_reassembly", "stacking_compounding", "flywheel",
    "branching_paths", "sieve_filter", "relay_handoff"
)

FEATURES = (
    "flow_present", "constrained_capacity", "throughput_pressure",
    "separated_domains", "connection_or_transfer_need",
    "shared_resource", "many_contributors", "redistribution_or_shared_access",
    "protected_resource", "controlled_access", "threat_or_exposure",
    "capacity_expansion", "same_flow_preserved",
    "opposing_forces", "equilibrium_or_tradeoff",
    "fragmented_state", "reassembly_or_integration",
    "repeated_accumulation", "retained_gain", "multiplicative_or_reinvested_effect",
    "reinforcing_feedback", "closed_loop",
    "one_to_many_divergence", "alternative_paths",
    "many_to_few_selection", "selection_criteria",
    "staged_transfer", "custody_or_state_handoff"
)

ASPECTS = {
    "16:9": {"orientation":"horizontal", "major_scale":1.0},
    "1:1":  {"orientation":"compact", "major_scale":0.96},
    "9:16": {"orientation":"vertical", "major_scale":0.96},
}

class MetaphorGrammarError(ValueError):
    pass

def _clip01(x: Any, default: float=0.0) -> float:
    try:
        v=float(x)
        if not math.isfinite(v): return default
        return max(0.0,min(1.0,v))
    except Exception:
        return default

def _features(m: Dict[str,Any]) -> Dict[str,float]:
    raw=m.get("features",{}) or {}
    f={k:_clip01(raw.get(k,0.0)) for k in FEATURES}
    # Structural shape can provide weak priors. These are abstract mechanisms, not topic words.
    priors={
      "constrained_flow":{"flow_present":.72,"constrained_capacity":.78,"throughput_pressure":.68},
      "cross_gap_transfer":{"separated_domains":.78,"connection_or_transfer_need":.78},
      "shared_pool":{"shared_resource":.78,"many_contributors":.70,"redistribution_or_shared_access":.68},
      "protected_access":{"protected_resource":.80,"controlled_access":.78},
      "capacity_expansion":{"flow_present":.62,"capacity_expansion":.82,"same_flow_preserved":.74},
      "equilibrium":{"opposing_forces":.82,"equilibrium_or_tradeoff":.78},
      "fragment_reassembly":{"fragmented_state":.84,"reassembly_or_integration":.84},
      "compounding":{"repeated_accumulation":.80,"retained_gain":.80,"multiplicative_or_reinvested_effect":.68},
      "feedback_cycle":{"reinforcing_feedback":.84,"closed_loop":.82},
      "branching":{"one_to_many_divergence":.84,"alternative_paths":.78},
      "filtering":{"many_to_few_selection":.84,"selection_criteria":.80},
      "handoff_chain":{"staged_transfer":.84,"custody_or_state_handoff":.78},
    }
    for k,v in priors.get(m.get("structure"),{}).items():
        f[k]=max(f[k],v)
    return f

def _ids(m:Dict[str,Any], key:str):
    v=m.get(key,[])
    return v if isinstance(v,list) else []

def _validate(m:Dict[str,Any])->None:
    if not isinstance(m,dict): raise MetaphorGrammarError("METAPHOR_INPUT_MUST_BE_OBJECT")
    if "features" in m and not isinstance(m.get("features"),dict): raise MetaphorGrammarError("FEATURES_MUST_BE_OBJECT")
    for key in ("source_entity","target_entity","resource_entity"):
        if m.get(key) is not None and not isinstance(m.get(key),str): raise MetaphorGrammarError(f"{key.upper()}_MUST_BE_ID")
    for key in ("contributor_entities","force_entities","fragment_entities","cycle_entities","branch_targets","stage_entities"):
        v=m.get(key,[])
        if v is not None and (not isinstance(v,list) or any(not isinstance(x,str) for x in v)):
            raise MetaphorGrammarError(f"{key.upper()}_MUST_BE_ID_LIST")

def _eligibility(m:Dict[str,Any], f:Dict[str,float])->Dict[str,bool]:
    source=bool(m.get("source_entity")); target=bool(m.get("target_entity")); resource=bool(m.get("resource_entity"))
    return {
      "bottleneck": bool(source and target and f["flow_present"]>=.55),
      "bridge": bool(source and target and f["separated_domains"]>=.55),
      "pool": bool(resource and len(_ids(m,"contributor_entities"))>=2),
      "vault": bool(resource),
      "widening_lanes": bool(source and target and f["flow_present"]>=.55),
      "balance": len(_ids(m,"force_entities"))==2,
      "fragmentation_reassembly": len(_ids(m,"fragment_entities"))>=2,
      "stacking_compounding": True,
      "flywheel": len(_ids(m,"cycle_entities"))>=3,
      "branching_paths": bool(source and len(_ids(m,"branch_targets"))>=2),
      "sieve_filter": bool(source and target),
      "relay_handoff": len(_ids(m,"stage_entities"))>=3,
    }

def _scores(m:Dict[str,Any], f:Dict[str,float], eligible:Dict[str,bool])->Dict[str,float]:
    s={k:0.0 for k in FORMS}
    s["bottleneck"] = .40*f["constrained_capacity"]+.32*f["throughput_pressure"]+.20*f["flow_present"]+.08*(1-f["capacity_expansion"])
    s["bridge"] = .50*f["separated_domains"]+.42*f["connection_or_transfer_need"]+.08*f["flow_present"]
    s["pool"] = .38*f["shared_resource"]+.30*f["many_contributors"]+.27*f["redistribution_or_shared_access"]+.05*f["flow_present"]
    s["vault"] = .43*f["protected_resource"]+.42*f["controlled_access"]+.15*f["threat_or_exposure"]
    s["widening_lanes"] = .42*f["capacity_expansion"]+.28*f["same_flow_preserved"]+.18*f["flow_present"]+.12*f["throughput_pressure"]
    s["balance"] = .54*f["opposing_forces"]+.46*f["equilibrium_or_tradeoff"]
    s["fragmentation_reassembly"] = .50*f["fragmented_state"]+.50*f["reassembly_or_integration"]
    s["stacking_compounding"] = .38*f["repeated_accumulation"]+.35*f["retained_gain"]+.27*f["multiplicative_or_reinvested_effect"]
    s["flywheel"] = .53*f["reinforcing_feedback"]+.42*f["closed_loop"]+.05*f["repeated_accumulation"]
    s["branching_paths"] = .55*f["one_to_many_divergence"]+.45*f["alternative_paths"]
    s["sieve_filter"] = .54*f["many_to_few_selection"]+.46*f["selection_criteria"]
    s["relay_handoff"] = .53*f["staged_transfer"]+.42*f["custody_or_state_handoff"]+.05*f["flow_present"]
    for k in s:
        s[k]=max(0.0,min(1.0,s[k])) if eligible[k] else 0.0
    return s

def _presentation(form:str)->Dict[str,Any]:
    common={
      "form":form,
      "presentation":"semantic_mechanism_not_decorative_metaphor",
      "metaphor_is_explanatory":True,
      "literal_labels_may_annotate_mechanism":True,
      "no_decorative_satellites":True,
      "no_orphan_marks":True,
      "no_free_running_lines":True,
      "single_restrained_accent":True,
      "hero_rule":"the semantic mechanism is the hero; labels support it",
    }
    specs={
      "bottleneck":{"parts":["source_flow","wide_entry","narrow_constraint","queued_units","reduced_exit"],"motion":"flow establishes, pressure accumulates before the constraint, fewer units emerge after it","meaning":"capacity constraint limits an otherwise continuous flow"},
      "bridge":{"parts":["domain_a","visible_gap","bounded_bridge","domain_b","crossing_unit"],"motion":"separation establishes first; bridge resolves only when connection/transfer is introduced","meaning":"two separated domains become traversably connected"},
      "pool":{"parts":["multiple_contributors","shared_container","pooled_resource","shared_access_or_redistribution"],"motion":"contributors feed one bounded pool; access/distribution is shown from that same pool","meaning":"many inputs aggregate into a shared resource"},
      "vault":{"parts":["protected_resource","bounded_vault","lock_or_gate","authorized_access_cue"],"motion":"resource establishes, protection encloses it, authorized access opens only on the access cue","meaning":"valuable resource is protected and selectively accessible"},
      "widening_lanes":{"parts":["same_input_flow","narrow_capacity","transition_to_more_lanes","higher_throughput_exit"],"motion":"same flow persists while capacity visibly expands; throughput increases after widening","meaning":"capacity increases without changing the underlying flow"},
      "balance":{"parts":["force_a","force_b","shared_balance_axis","equilibrium_or_tilt_state"],"motion":"both forces establish before the balance resolves; neither side is decorative","meaning":"two opposing forces or objectives trade off toward equilibrium"},
      "fragmentation_reassembly":{"parts":["whole_or_origin","separated_fragments","integration_motion","reassembled_whole"],"motion":"fragments remain individually owned, then converge into one resolved whole","meaning":"a fragmented state is integrated or recomposed"},
      "stacking_compounding":{"parts":["initial_base","repeated_contributions","retained_gains","growing_stack_or_layers"],"motion":"each cycle builds on what remains from the previous cycle rather than resetting","meaning":"repeated retained gains accumulate and amplify over cycles"},
      "flywheel":{"parts":["3_plus_cycle_nodes","closed_loop_arrows","reinforcement_cue","stronger_return_state"],"motion":"cycle completes at least once before reinforcement is emphasized; arrows terminate at owned nodes","meaning":"outputs reinforce inputs in a positive feedback loop"},
      "branching_paths":{"parts":["single_origin","bounded_split_point","2_plus_destinations","distinct_path_outcomes"],"motion":"one route reaches a real decision/split and diverges to explicit destinations","meaning":"one origin diverges into multiple alternatives"},
      "sieve_filter":{"parts":["input_population","selection_boundary","explicit_criterion_cue","smaller_selected_output","rejected_or_excluded_remainder"],"motion":"many enter; criterion applies at the boundary; a smaller selected set exits","meaning":"selection criteria reduce a larger set to a qualifying subset"},
      "relay_handoff":{"parts":["3_plus_owned_stages","transferred_object_or_state","bounded_handoff_connectors","final_owner_or_state"],"motion":"the same owned object/state passes stage-to-stage; no connector exists without both adjacent stages","meaning":"custody or state moves through an explicit chain"},
    }
    common.update(specs[form]); return common

def _aspect_reflow(form:str)->Dict[str,Any]:
    out={}
    for ratio,b in ASPECTS.items():
        if ratio=="9:16":
            if form in {"bridge","widening_lanes","relay_handoff","bottleneck"}: grammar="vertical_mechanism"
            elif form in {"balance"}: grammar="stacked_balance_preserve_two_sides"
            elif form in {"flywheel"}: grammar="compact_vertical_cycle"
            else: grammar="vertical_compound"
        elif ratio=="1:1": grammar="compact_balanced_mechanism"
        else: grammar="horizontal_mechanism"
        out[ratio]={"orientation":b["orientation"],"layout_grammar":grammar,"major_scale":b["major_scale"],"preserve_mechanism_topology":True,"no_stretch":True,"no_crop_labels":True,"no_metaphor_microfication":True}
    return out

def select(m:Dict[str,Any])->Dict[str,Any]:
    _validate(m); f=_features(m); eligibility=_eligibility(m,f); s=_scores(m,f,eligibility)
    ranked=sorted(s.items(),key=lambda kv:(-kv[1],FORMS.index(kv[0])))
    winner,wscore=ranked[0]; second,sscore=ranked[1]
    # High bar: metaphors are optional. Weak or ambiguous semantics must stay literal/replan.
    if wscore < .68:
        return {"schema":"NexMindWhiteboardMetaphorDecisionV1","version":VERSION,"status":"LITERAL_OR_REPLAN","reason":"METAPHOR_SEMANTICS_TOO_WEAK","features":f,"eligibility":eligibility,"scores":s}
    if wscore-sscore < .07 and sscore>=.62:
        return {"schema":"NexMindWhiteboardMetaphorDecisionV1","version":VERSION,"status":"LITERAL_OR_REPLAN","reason":"AMBIGUOUS_METAPHOR","features":f,"eligibility":eligibility,"scores":s,"top_candidates":[winner,second]}
    return {
      "schema":"NexMindWhiteboardMetaphorDecisionV1","version":VERSION,"status":"PASS",
      "metaphor_id":m.get("id"),"selected_form":winner,"confidence":round(wscore,4),
      "runner_up":second,"runner_up_score":round(sscore,4),"features":f,"eligibility":eligibility,"scores":s,
      "presentation":_presentation(winner),"aspect_layouts":_aspect_reflow(winner),
      "semantic_bindings":{
        "source_entity":m.get("source_entity"),"target_entity":m.get("target_entity"),"resource_entity":m.get("resource_entity"),
        "contributor_entities":copy.deepcopy(_ids(m,"contributor_entities")),"force_entities":copy.deepcopy(_ids(m,"force_entities")),
        "fragment_entities":copy.deepcopy(_ids(m,"fragment_entities")),"cycle_entities":copy.deepcopy(_ids(m,"cycle_entities")),
        "branch_targets":copy.deepcopy(_ids(m,"branch_targets")),"stage_entities":copy.deepcopy(_ids(m,"stage_entities")),
      },
      "routing_proof":{
        "content_labels_used_for_selection":False,"keywords_used_for_selection":False,
        "selection_comes_from_semantic_structure":True,"metaphor_is_default":False,
        "fail_closed_when_weak_or_ambiguous":True,
      }
    }

def normalized_structure(out:Dict[str,Any])->Dict[str,Any]: return copy.deepcopy(out)

def main():
    import argparse,sys
    ap=argparse.ArgumentParser();ap.add_argument("input",nargs="?")
    a=ap.parse_args(); d=json.load(open(a.input)) if a.input else json.load(sys.stdin)
    print(json.dumps(select(d),indent=2))
if __name__=="__main__":main()
