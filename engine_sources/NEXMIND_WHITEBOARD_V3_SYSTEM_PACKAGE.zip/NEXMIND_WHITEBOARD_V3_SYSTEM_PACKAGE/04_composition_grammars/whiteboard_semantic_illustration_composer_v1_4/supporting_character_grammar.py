#!/usr/bin/env python3
"""NexMind Whiteboard Native Supporting Character Grammar V1.

Selects a small, native Whiteboard supporting-character interaction from
abstract human-action semantics. Labels/nouns are display payload only and
never participate in form selection.
"""
from __future__ import annotations
from typing import Any, Dict
import copy, json

VERSION = "1.0.0"

FORMS = (
    "person_phone",
    "person_laptop",
    "operator_machine",
    "giver_receiver",
    "presenter",
    "approver",
    "two_person_comparison",
)

FEATURES = (
    "human_explanatory_value",
    "handheld_interface_action",
    "workstation_interface_action",
    "machine_operation",
    "person_to_person_transfer",
    "presentation_to_others",
    "approval_or_authorization",
    "two_human_comparison",
)

STRUCTURE_PRIORS = {
    "handheld_interaction": {"handheld_interface_action": 0.94},
    "workstation_interaction": {"workstation_interface_action": 0.94},
    "machine_operation": {"machine_operation": 0.96},
    "person_transfer": {"person_to_person_transfer": 0.96},
    "presentation": {"presentation_to_others": 0.96},
    "approval": {"approval_or_authorization": 0.96},
    "human_comparison": {"two_human_comparison": 0.96},
}

ASPECTS = {
    "16:9": {"orientation": "horizontal", "character_scale": 0.70},
    "1:1":  {"orientation": "compact",    "character_scale": 0.69},
    "9:16": {"orientation": "vertical",   "character_scale": 0.68},
}

class SupportingCharacterGrammarError(ValueError):
    pass

def _clip01(v, default=0.0):
    try:
        return max(0.0, min(1.0, float(v)))
    except Exception:
        return default

def _features(s):
    raw = s.get("features", {}) or {}
    f = {k: _clip01(raw.get(k, 0.0)) for k in FEATURES}
    for k, v in STRUCTURE_PRIORS.get(s.get("structure"), {}).items():
        f[k] = max(f[k], v)
    return f

def _validate(s):
    if not isinstance(s, dict):
        raise SupportingCharacterGrammarError("CHARACTER_SEMANTICS_MUST_BE_OBJECT")
    actors = s.get("actor_entities", [])
    if not isinstance(actors, list):
        raise SupportingCharacterGrammarError("ACTOR_ENTITIES_MUST_BE_LIST")
    if len(set(actors)) != len(actors):
        raise SupportingCharacterGrammarError("ACTOR_ENTITIES_MUST_BE_UNIQUE")
    for key in ("device_entity", "machine_entity", "transfer_entity", "presentation_entity",
                "approval_target_entity", "comparison_anchor_entity"):
        if s.get(key) is not None and not isinstance(s.get(key), str):
            raise SupportingCharacterGrammarError(f"{key.upper()}_MUST_BE_ID")
    if s.get("continuity_required") and not s.get("continuity_reason"):
        raise SupportingCharacterGrammarError("CONTINUITY_REASON_REQUIRED")

def _eligible(form, s, f):
    actors = s.get("actor_entities", [])
    if f["human_explanatory_value"] < 0.55:
        return False
    if form == "person_phone":
        return len(actors) >= 1 and bool(s.get("device_entity")) and f["handheld_interface_action"] >= 0.70
    if form == "person_laptop":
        return len(actors) >= 1 and bool(s.get("device_entity")) and f["workstation_interface_action"] >= 0.70
    if form == "operator_machine":
        return len(actors) >= 1 and bool(s.get("machine_entity")) and f["machine_operation"] >= 0.70
    if form == "giver_receiver":
        return len(actors) >= 2 and bool(s.get("transfer_entity")) and f["person_to_person_transfer"] >= 0.70
    if form == "presenter":
        return len(actors) >= 1 and bool(s.get("presentation_entity")) and f["presentation_to_others"] >= 0.70
    if form == "approver":
        return len(actors) >= 1 and bool(s.get("approval_target_entity")) and f["approval_or_authorization"] >= 0.70
    if form == "two_person_comparison":
        return len(actors) >= 2 and f["two_human_comparison"] >= 0.70
    return False

def _scores(s, f):
    mapping = {
        "person_phone": "handheld_interface_action",
        "person_laptop": "workstation_interface_action",
        "operator_machine": "machine_operation",
        "giver_receiver": "person_to_person_transfer",
        "presenter": "presentation_to_others",
        "approver": "approval_or_authorization",
        "two_person_comparison": "two_human_comparison",
    }
    scores = {}
    for form, feat in mapping.items():
        if not _eligible(form, s, f):
            scores[form] = 0.0
        else:
            scores[form] = min(1.0, 0.78 * f[feat] + 0.22 * f["human_explanatory_value"])
    return scores

def _identity_policy(s):
    beat = s.get("beat_id") or "beat"
    actors = s.get("actor_entities", [])
    if not s.get("continuity_required", False):
        return {
            "recurring_character": False,
            "identity_scope": "beat_local",
            "identity_keys": {a: f"{beat}:{a}" for a in actors},
            "carry_visual_identity_forward": False,
        }
    reason = s.get("continuity_reason")
    if reason not in {"same_actor_across_beats", "before_after_same_actor", "tracked_actor_outcome"}:
        raise SupportingCharacterGrammarError("UNSUPPORTED_CONTINUITY_REASON")
    story_ids = s.get("continuity_entity_ids") or actors
    if not isinstance(story_ids, list) or not story_ids:
        raise SupportingCharacterGrammarError("CONTINUITY_ENTITY_IDS_REQUIRED")
    return {
        "recurring_character": True,
        "identity_scope": "story_semantic",
        "continuity_reason": reason,
        "identity_keys": {a: f"story:{a}" for a in story_ids},
        "carry_visual_identity_forward": True,
    }

def _presentation(form, s):
    common = {
        "form": form,
        "visual_language": "nexmind-whiteboard-clean-v1",
        "character_role": "supporting_not_hero",
        "max_character_scale_relative_to_hero_mechanism": 0.78,
        "same_line_weight_as_native_objects": True,
        "no_stock_doodle": True,
        "no_giant_character": True,
        "no_decorative_pose": True,
        "no_floating_props": True,
        "contact_points_must_be_owned": True,
        "hands_must_contact_target_when_action_requires_contact": True,
        "normal_neck_shoulder_hand_foot_geometry": True,
        "pose_must_preserve_clear_silhouette": True,
    }
    specs = {
        "person_phone": {
            "required_props": ["person", "handheld_interface"],
            "pose": "small standing_or_seated_three_quarter; one hand owns phone; gaze resolves to screen",
            "action_read": "human action is mediated through the handheld interface",
            "anti_failure": ["phone_not_floating", "wrist_not_twisted", "screen_not_hidden_by_hand"],
        },
        "person_laptop": {
            "required_props": ["person", "laptop", "support_surface_if_seated"],
            "pose": "small seated_or_standing_work posture; hands reach keyboard/trackpad; screen remains readable",
            "action_read": "human action is mediated through a workstation interface",
            "anti_failure": ["no_hunched_neck", "no_forearm_through_laptop", "feet_or_stance_grounded"],
        },
        "operator_machine": {
            "required_props": ["person", "machine", "control_contact"],
            "pose": "person remains subordinate in scale beside machine; one clear reach/contact to control",
            "action_read": "human operates a larger mechanism",
            "anti_failure": ["machine_remains_visual_hero", "no_body_machine_intersection", "reach_feasible"],
        },
        "giver_receiver": {
            "required_props": ["giver", "receiver", "owned_transfer_object"],
            "pose": "two small figures face interaction zone; object stays centered between owned hands",
            "action_read": "custody/value/state changes from one person to another",
            "anti_failure": ["object_never_floats", "hands_do_not_cross_bodies", "giver_receiver_roles_readable"],
        },
        "presenter": {
            "required_props": ["person", "presentation_surface_or_subject"],
            "pose": "person stays to side of content; open palm or bounded pointer indicates owned subject",
            "action_read": "human explains or presents existing information",
            "anti_failure": ["person_never_covers_content", "pointer_terminates_on_subject", "no_stage_doodle_scale"],
        },
        "approver": {
            "required_props": ["person", "approval_target"],
            "pose": "small figure adjacent to target; hand/action resolves to explicit approve control or document",
            "action_read": "human authorizes/rejects an owned target",
            "anti_failure": ["check_mark_attaches_to_target", "no_floating_sparkle_check", "decision_target_visible"],
        },
        "two_person_comparison": {
            "required_props": ["person_a", "person_b", "comparison_anchor_optional"],
            "pose": "equal-scale figures occupy parallel positions; differences belong to owned states/props",
            "action_read": "two human states/options are compared without implying a recurring cast",
            "anti_failure": ["equal_character_scale", "no_good_bad_caricature", "comparison_anchor_not_decorative"],
        },
    }
    common.update(specs[form])
    return common

def _aspect_reflow(form):
    out = {}
    for ratio, spec in ASPECTS.items():
        if ratio == "9:16":
            if form in {"giver_receiver", "two_person_comparison"}:
                grammar = "stacked_equal_figures_with_owned_center_relation"
            elif form == "presenter":
                grammar = "content_above_or_beside_small_presenter"
            elif form == "operator_machine":
                grammar = "machine_dominant_vertical_cluster"
            else:
                grammar = "vertical_action_cluster"
        elif ratio == "1:1":
            grammar = "compact_action_cluster"
        else:
            grammar = "lateral_action_cluster"
        out[ratio] = {
            "orientation": spec["orientation"],
            "layout_grammar": grammar,
            "character_scale": spec["character_scale"],
            "character_scale_ceiling": 0.78,
            "preserve_contact_topology": True,
            "preserve_role_direction": True,
            "no_stretch": True,
            "no_crop_hands_or_props": True,
            "no_character_enlargement_to_fill_canvas": True,
        }
    return out

def select(s):
    _validate(s)
    f = _features(s)
    scores = _scores(s, f)
    ranked = sorted(scores.items(), key=lambda kv: (-kv[1], FORMS.index(kv[0])))
    winner, w = ranked[0]
    second, sw = ranked[1]
    if w < 0.62:
        return {
            "schema": "NexMindWhiteboardSupportingCharacterDecisionV1",
            "version": VERSION,
            "status": "OBJECT_LED",
            "reason": "HUMAN_DOES_NOT_ADD_ENOUGH_EXPLANATORY_VALUE",
            "features": f,
            "scores": scores,
        }
    if sw >= 0.62 and (w - sw) < 0.06:
        return {
            "schema": "NexMindWhiteboardSupportingCharacterDecisionV1",
            "version": VERSION,
            "status": "REPLAN_REQUIRED",
            "reason": "AMBIGUOUS_CHARACTER_INTERACTION",
            "features": f,
            "scores": scores,
            "top_candidates": [winner, second],
        }
    return {
        "schema": "NexMindWhiteboardSupportingCharacterDecisionV1",
        "version": VERSION,
        "status": "PASS",
        "selected_form": winner,
        "confidence": round(w, 4),
        "features": f,
        "scores": scores,
        "presentation": _presentation(winner, s),
        "identity_policy": _identity_policy(s),
        "aspect_layouts": _aspect_reflow(winner),
        "routing_proof": {
            "content_labels_used_for_selection": False,
            "topic_or_domain_used_for_selection": False,
            "character_is_default": False,
            "human_must_add_explanatory_value": True,
            "recurrence_requires_explicit_story_semantics": True,
        },
    }

def main():
    import argparse, sys
    ap = argparse.ArgumentParser(); ap.add_argument("input", nargs="?")
    a = ap.parse_args()
    data = json.load(open(a.input)) if a.input else json.load(sys.stdin)
    print(json.dumps(select(data), indent=2))
if __name__ == "__main__":
    main()
