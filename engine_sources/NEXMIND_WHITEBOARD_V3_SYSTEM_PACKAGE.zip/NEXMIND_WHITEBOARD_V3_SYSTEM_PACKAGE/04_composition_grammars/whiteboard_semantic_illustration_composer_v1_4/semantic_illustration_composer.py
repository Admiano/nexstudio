#!/usr/bin/env python3
"""NexMind Whiteboard Semantic Illustration Composer V1.

Turns abstract beat semantics into a compound illustration blueprint.
Content labels are carried through only for asset retrieval/display; they never
participate in representation, hierarchy, layout, scale, or timing decisions.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple
import copy, json, math
from data_presentation_grammar import select as select_data_presentation, DataGrammarError
from data_presentation_execution_adapter import bind as bind_data_render
from metaphor_grammar import select as select_metaphor, MetaphorGrammarError
from metaphor_execution_adapter import bind as bind_metaphor_render
from supporting_character_grammar import select as select_supporting_character, SupportingCharacterGrammarError
from supporting_character_execution_adapter import bind as bind_supporting_character_render
from composition_hierarchy_grammar import plan as plan_composition_hierarchy, CompositionHierarchyError
from composition_hierarchy_execution_adapter import bind as bind_composition_hierarchy_render

VERSION = "1.4.0"

REPRESENTATION_TO_GRAMMAR = {
    "meaningful-process": "compound_process",
    "process": "compound_process",
    "network": "compound_process",
    "comparison": "comparative_illustration",
    "handoff": "contextual_human_interaction",
    "human": "contextual_human_interaction",
    "human-interaction": "contextual_human_interaction",
    "physical-metaphor": "metaphor_illustration",
    "metaphor": "metaphor_illustration",
    "data-in-context": "contextual_data_illustration",
    "data": "contextual_data_illustration",
    "transformation": "state_transformation",
    "spatial": "spatial_illustration",
    "object-story": "compound_object_story",
    "object": "compound_object_story",
    "outcome": "outcome_illustration",
}

ALLOWED_ENTITY_ROLES = {
    "actor", "object", "system", "value", "evidence", "container",
    "interface", "place", "state", "result", "resource"
}
ALLOWED_RELATIONS = {
    "acts_on", "operates", "transforms", "produces", "contains", "moves_to",
    "hands_to", "receives", "compares", "measures", "blocks", "enables",
    "returns_to", "depends_on", "connects_to", "flows_to", "before", "after",
    "part_of", "causes", "resolves_to"
}
SCALE_BANDS = {"hero": 1.00, "support": 0.72, "micro": 0.48}
ASPECTS = {
    "16:9": {"orientation":"horizontal", "hero":1.00, "support":0.72, "micro":0.48},
    "1:1":  {"orientation":"compact",    "hero":0.96, "support":0.72, "micro":0.50},
    "9:16": {"orientation":"vertical",   "hero":0.96, "support":0.74, "micro":0.52},
}

class ComposeError(ValueError):
    pass

def _clip01(x: Any, default: float=0.5) -> float:
    try: return max(0.0, min(1.0, float(x)))
    except Exception: return default

def _validate(inp: Dict[str, Any]) -> None:
    if not isinstance(inp, dict): raise ComposeError("INPUT_MUST_BE_OBJECT")
    rep = inp.get("representation_family")
    if rep not in REPRESENTATION_TO_GRAMMAR:
        raise ComposeError("UNSUPPORTED_REPRESENTATION_FAMILY")
    entities = inp.get("entities")
    if not isinstance(entities, list) or not entities:
        raise ComposeError("ENTITIES_REQUIRED")
    ids=[]
    for e in entities:
        if not isinstance(e,dict) or not e.get("id"): raise ComposeError("ENTITY_ID_REQUIRED")
        if e.get("role") not in ALLOWED_ENTITY_ROLES: raise ComposeError("UNSUPPORTED_ENTITY_ROLE")
        ids.append(e["id"])
    if len(ids)!=len(set(ids)): raise ComposeError("ENTITY_IDS_MUST_BE_UNIQUE")
    idset=set(ids)
    for r in inp.get("relations",[]):
        if r.get("type") not in ALLOWED_RELATIONS: raise ComposeError("UNSUPPORTED_RELATION")
        if r.get("source") not in idset or r.get("target") not in idset:
            raise ComposeError("RELATION_ENDPOINT_MISSING")
    for ev in inp.get("evidence",[]):
        if "shape" not in ev: raise ComposeError("EVIDENCE_SHAPE_REQUIRED")

def _centrality(entities: List[Dict[str,Any]], relations: List[Dict[str,Any]]) -> Dict[str,float]:
    degree={e["id"]:0.0 for e in entities}
    for r in relations:
        w=1.25 if r["type"] in {"transforms","produces","hands_to","causes","resolves_to"} else 1.0
        degree[r["source"]]+=w; degree[r["target"]]+=w
    m=max([1.0,*degree.values()])
    return {k:v/m for k,v in degree.items()}

def _rank_entities(entities: List[Dict[str,Any]], relations: List[Dict[str,Any]]) -> List[Tuple[float,int,Dict[str,Any]]]:
    cent=_centrality(entities,relations)
    ranked=[]
    for i,e in enumerate(entities):
        importance=_clip01(e.get("importance",0.5))
        narrative=_clip01(e.get("narrative_weight",importance))
        score=0.48*importance+0.32*narrative+0.20*cent[e["id"]]
        ranked.append((score,i,e))
    ranked.sort(key=lambda x:(-x[0],x[1]))
    return ranked

def _hierarchy(entities: List[Dict[str,Any]], relations: List[Dict[str,Any]]) -> Dict[str,str]:
    ranked=_rank_entities(entities,relations)
    h={}
    # One hero by default; a second hero is legal only when comparison is structurally explicit.
    comparison_pair=set()
    for r in relations:
        if r["type"]=="compares": comparison_pair.update([r["source"],r["target"]])
    for idx,(_,_,e) in enumerate(ranked):
        if idx==0: h[e["id"]]="hero"
        elif e["id"] in comparison_pair and ranked[0][2]["id"] in comparison_pair and idx==1:
            h[e["id"]]="hero"
        elif idx <= 3: h[e["id"]]="support"
        else: h[e["id"]]="micro"
    return h

def _contextual_character_allowed(inp: Dict[str,Any], e: Dict[str,Any], rep: str) -> bool:
    if e["role"]!="actor": return False
    human=_clip01(inp.get("human_agency",0.0),0.0)
    # Characters are semantic, never decorative. Handoff/human grammar has a lower threshold.
    threshold=0.45 if rep in {"handoff","human","human-interaction"} else 0.72
    return human >= threshold

def _component_for_entity(inp: Dict[str,Any], e: Dict[str,Any], tier: str) -> Dict[str,Any]:
    rep=inp["representation_family"]
    kind="native_whiteboard_character" if _contextual_character_allowed(inp,e,rep) else "semantic_object"
    if e["role"]=="evidence": kind="evidence_anchor"
    return {
        "id": f"component:{e['id']}",
        "concept_id": e["id"],
        "kind": kind,
        "semantic_role": e["role"],
        "hierarchy": tier,
        "scale_band": min(SCALE_BANDS[tier], 0.78) if kind=="native_whiteboard_character" else SCALE_BANDS[tier],
        "label": e.get("label",""),
        "asset_query": {
            "concept": e.get("label",""),
            "role": e["role"],
            "style_contract":"nexmind-whiteboard-clean-v1",
            "must_match_line_language": True,
            "decorative_satellites": False,
        },
        "purity": {
            "allow_decorative_satellites": False,
            "allow_orphan_marks": False,
            "allow_free_connector": False,
            "allow_unowned_detail": False,
        }
    }

def _evidence_modules(inp: Dict[str,Any], hierarchy: Dict[str,str]) -> List[Dict[str,Any]]:
    out=[]
    for idx,ev in enumerate(inp.get("evidence",[])):
        enriched=copy.deepcopy(ev)
        enriched.setdefault("id", f"evidence:{idx}")
        try:
            decision=select_data_presentation(enriched)
        except DataGrammarError as e:
            raise ComposeError(f"DATA_GRAMMAR_INVALID:{e}")
        if decision.get("status") != "PASS":
            return [{
              "id":f"evidence:{idx}", "kind":"contextual_data_module",
              "status":"REPLAN_REQUIRED", "reason":decision.get("reason"),
              "selection":decision,
            }]
        out.append({
          "id":f"evidence:{idx}", "kind":"contextual_data_module",
          "status":"PASS", "shape":ev.get("shape"),
          "presentation":"integrated_not_naked_number",
          "values":copy.deepcopy(ev.get("values",[])),
          "labels":copy.deepcopy(ev.get("labels",[])),
          "hierarchy":"support", "scale_band":0.70,
          "selected_form":decision["selected_form"],
          "data_grammar_decision":decision,
          "renderer_bindings":{ratio:bind_data_render(decision,ratio) for ratio in ("16:9","1:1","9:16")},
          "decorative_grid":False, "full_chart_chrome":False,
          "number_ownership":"visual_mark_or_semantic_object",
        })
    return out



def _metaphor_module(inp: Dict[str,Any]) -> Dict[str,Any] | None:
    rep=inp.get("representation_family")
    ms=inp.get("metaphor_semantics")
    if ms is None:
        if rep in {"metaphor","physical-metaphor"}:
            return {"status":"REPLAN_REQUIRED","reason":"METAPHOR_SEMANTICS_REQUIRED"}
        return None
    if not isinstance(ms,dict):
        raise ComposeError("METAPHOR_SEMANTICS_MUST_BE_OBJECT")
    enriched=copy.deepcopy(ms); enriched.setdefault("id",f"metaphor:{inp.get('beat_id') or 'beat'}")
    try:
        decision=select_metaphor(enriched)
    except MetaphorGrammarError as e:
        raise ComposeError(f"METAPHOR_GRAMMAR_INVALID:{e}")
    if decision.get("status")!="PASS":
        # Metaphor is optional for non-metaphor families; the planner may remain literal.
        if rep in {"metaphor","physical-metaphor"}:
            return {"status":"REPLAN_REQUIRED","reason":decision.get("reason"),"decision":decision}
        return {"status":"LITERAL","reason":decision.get("reason"),"decision":decision}
    return {
      "status":"PASS","kind":"semantic_metaphor_module","selected_form":decision["selected_form"],
      "decision":decision,
      "renderer_bindings":{ratio:bind_metaphor_render(decision,ratio) for ratio in ("16:9","1:1","9:16")},
      "integration_policy":{
        "metaphor_must_share_whiteboard_line_language":True,
        "metaphor_must_bind_to_existing_semantic_entities":True,
        "metaphor_may_not_be_decorative":True,
        "metaphor_may_not_replace_unrelated_literal_evidence":True,
      }
    }


def _derive_supporting_character_semantics(inp: Dict[str,Any]) -> Dict[str,Any] | None:
    """Derive only from explicit abstract relations/roles, never labels."""
    if inp.get("supporting_character_semantics") is not None:
        s=copy.deepcopy(inp["supporting_character_semantics"])
        s.setdefault("beat_id",inp.get("beat_id"))
        return s
    entities={e["id"]:e for e in inp.get("entities",[])}
    actors=[e["id"] for e in inp.get("entities",[]) if e.get("role")=="actor"]
    if not actors:
        return None
    human=_clip01(inp.get("human_agency",0.0),0.0)
    # Backward-compatible structural derivation from existing abstract relations only.
    for r in inp.get("relations",[]):
        st,src,tgt=r["type"],r["source"],r["target"]
        if st=="hands_to" and src in actors and tgt in actors:
            transfer=inp.get("handoff_entity")
            if transfer:
                return {"beat_id":inp.get("beat_id"),"structure":"person_transfer",
                        "actor_entities":[src,tgt],"transfer_entity":transfer,
                        "features":{"human_explanatory_value":human,"person_to_person_transfer":1.0}}
        if st=="operates" and src in actors and tgt in entities:
            return {"beat_id":inp.get("beat_id"),"structure":"machine_operation",
                    "actor_entities":[src],"machine_entity":tgt,
                    "features":{"human_explanatory_value":human,"machine_operation":1.0}}
        if st=="compares" and src in actors and tgt in actors:
            return {"beat_id":inp.get("beat_id"),"structure":"human_comparison",
                    "actor_entities":[src,tgt],
                    "features":{"human_explanatory_value":human,"two_human_comparison":1.0}}
    return None

def _supporting_character_module(inp: Dict[str,Any]) -> Dict[str,Any] | None:
    sem=_derive_supporting_character_semantics(inp)
    if sem is None:
        return None
    if not isinstance(sem,dict):
        raise ComposeError("SUPPORTING_CHARACTER_SEMANTICS_MUST_BE_OBJECT")
    # Explicit semantics inherit overall human-agency prior unless they supplied a stronger one.
    sem.setdefault("features",{})
    if "human_explanatory_value" not in sem["features"]:
        sem["features"]["human_explanatory_value"]=_clip01(inp.get("human_agency",0.0),0.0)
    try:
        decision=select_supporting_character(sem)
    except SupportingCharacterGrammarError as e:
        raise ComposeError(f"SUPPORTING_CHARACTER_GRAMMAR_INVALID:{e}")
    if decision.get("status")=="REPLAN_REQUIRED":
        return {"status":"REPLAN_REQUIRED","reason":decision.get("reason"),"decision":decision}
    if decision.get("status")!="PASS":
        return {"status":"OBJECT_LED","reason":decision.get("reason"),"decision":decision}
    return {
      "status":"PASS","kind":"native_supporting_character_module",
      "selected_form":decision["selected_form"],"decision":decision,
      "renderer_bindings":{ratio:bind_supporting_character_render(decision,ratio) for ratio in ("16:9","1:1","9:16")},
      "integration_policy":{
        "character_is_supporting_not_hero":True,
        "character_scale_ceiling":0.78,
        "native_whiteboard_language_only":True,
        "stock_doodles_forbidden":True,
        "explicit_composition_hierarchy":True,
        "hero_support_micro_classes_required":True,
        "decorative_density_forbidden":True,
        "vo_cue_remains_master_timeline":True,
        "character_must_explain_owned_action":True,
        "recurrence_requires_explicit_story_semantics":True,
      }
    }

def _relation_visual(r: Dict[str,Any]) -> Dict[str,Any]:
    # Relation geometry may exist only from explicit semantic endpoints.
    typ=r["type"]
    if typ in {"before","after","part_of"}:
        visibility="implicit_by_layout"
    elif typ in {"contains","operates","acts_on","receives","measures","blocks","enables"}:
        visibility="local_relation_cue"
    else:
        visibility="explicit_connector_if_needed"
    return {
      "id":f"relation:{r['source']}:{typ}:{r['target']}",
      "source":f"component:{r['source']}", "target":f"component:{r['target']}",
      "semantic_type":typ, "visibility":visibility,
      "connector_policy":{
          "requires_two_valid_endpoints":True,
          "no_decorative_path":True,
          "no_cross_scene_spoke":True,
          "terminate_at_object_boundaries":True,
          "may_not_exist_before_destination":True,
      }
    }

def _compound_groups(inp: Dict[str,Any], hierarchy: Dict[str,str]) -> List[Dict[str,Any]]:
    entities={e["id"]:e for e in inp["entities"]}
    relations=inp.get("relations",[])
    # Build connected components from semantically meaningful relations.
    adj={k:set() for k in entities}
    for r in relations:
        adj[r["source"]].add(r["target"]); adj[r["target"]].add(r["source"])
    seen=set(); groups=[]
    for eid in entities:
        if eid in seen: continue
        stack=[eid]; comp=[]; seen.add(eid)
        while stack:
            x=stack.pop(); comp.append(x)
            for y in adj[x]:
                if y not in seen: seen.add(y); stack.append(y)
        groups.append(comp)
    result=[]
    for i,ids in enumerate(groups):
        result.append({
          "id":f"compound:{i}",
          "concept_ids":ids,
          "kind":"compound_illustration" if len(ids)>1 else "single_semantic_form",
          "internal_relationship_count":sum(1 for r in relations if r["source"] in ids and r["target"] in ids),
          "coherence_rule":"read_as_one_visual_situation",
          "max_major_components":5,
        })
    return result


def _composition_hierarchy_context(inp: Dict[str,Any], components: List[Dict[str,Any]], groups: List[Dict[str,Any]], data_modules: List[Dict[str,Any]], metaphor: Dict[str,Any] | None, supporting_character: Dict[str,Any] | None, relation_visuals: List[Dict[str,Any]]) -> Dict[str,Any]:
    entities={e["id"]:e for e in inp["entities"]}
    relations=inp.get("relations",[])
    family=inp["representation_family"]
    elements=[]
    group_rows=[]
    for gi,g in enumerate(groups):
        ids=g["concept_ids"]
        vals=[entities[i] for i in ids]
        importance=max([_clip01(e.get("importance",0.5)) for e in vals] or [0.5])
        narrative=max([_clip01(e.get("narrative_weight",e.get("importance",0.5))) for e in vals] or [0.5])
        internal=g.get("internal_relationship_count",0)
        structural=min(1.0, internal/max(1,len(ids)-1))
        contains_comparison=any(r["type"]=="compares" and r["source"] in ids and r["target"] in ids for r in relations)
        group_score=.48*importance+.32*narrative+.20*structural+(.08 if contains_comparison else 0.0)
        group_rows.append((group_score,gi,g,importance,narrative,structural,contains_comparison))
    group_rows.sort(key=lambda x:(-x[0],x[1]))
    primary_group_id=group_rows[0][2]["id"] if group_rows else None
    governed_module_owns_hero=(family in {"data","data-in-context"} and data_modules) or (family in {"metaphor","physical-metaphor"} and metaphor and metaphor.get("status")=="PASS")
    for _,gi,g,importance,narrative,structural,contains_comparison in group_rows:
        hero_allowed=(not governed_module_owns_hero) and g["id"]==primary_group_id
        elements.append({
          "id":g["id"],"kind":"illustration_group","semantic_priority":importance,
          "narrative_centrality":narrative,"structural_centrality":structural,
          "can_be_hero":hero_allowed,"must_be_support":not hero_allowed,"semantic_part_count":len(g["concept_ids"]),
          "contains_explicit_comparison":contains_comparison,"related_to_hero":True,
          "shared_hero_cluster":g["id"] if contains_comparison else None,
        })
    for i,d in enumerate(data_modules):
        if d.get("status")!="PASS": continue
        source=(inp.get("evidence") or [{}])[i] if i<len(inp.get("evidence",[])) else {}
        hero_allowed=family in {"data","data-in-context"}
        elements.append({
          "id":d["id"],"kind":"data_module","semantic_priority":_clip01(source.get("importance",.78),.78),
          "narrative_centrality":_clip01(source.get("narrative_weight",.82 if hero_allowed else .68),.68),
          "evidence_strength":_clip01(d.get("data_grammar_decision",{}).get("confidence",.8),.8),
          "can_be_hero":hero_allowed,"must_be_support":not hero_allowed,"related_to_hero":True,
          "semantic_part_count":max(2,len(d.get("values",[]))),
        })
    if metaphor and metaphor.get("status")=="PASS":
        hero_allowed=family in {"metaphor","physical-metaphor"}
        elements.append({
          "id":"metaphor:module","kind":"metaphor_module","semantic_priority":.94 if hero_allowed else .68,
          "narrative_centrality":.96 if hero_allowed else .66,"structural_centrality":.9,
          "can_be_hero":hero_allowed,"must_be_support":not hero_allowed,"related_to_hero":True,
          "semantic_part_count":3,
        })
    if supporting_character and supporting_character.get("status")=="PASS":
        elements.append({
          "id":"supporting-character:module","kind":"supporting_character_module",
          "semantic_priority":.62,"narrative_centrality":.58,"can_be_hero":False,
          "must_be_support":True,"related_to_hero":True,"semantic_part_count":2,
        })
    # Internal relation cues belong to their compound illustration and do not consume micro budget.
    concept_group={cid:g["id"] for g in groups for cid in g["concept_ids"]}
    for rv in relation_visuals:
        if rv.get("visibility")=="implicit_by_layout": continue
        src=rv["source"].split("component:",1)[-1]; tgt=rv["target"].split("component:",1)[-1]
        if concept_group.get(src) and concept_group.get(src)==concept_group.get(tgt):
            continue
        elements.append({
          "id":rv["id"],"kind":"relation_cue","semantic_priority":.20,
          "annotation_only":True,"essential":rv.get("visibility")=="explicit_connector_if_needed",
          "can_be_hero":False,"related_to_hero":True,
        })
    for i,a in enumerate(inp.get("annotations",[]) or []):
        if not isinstance(a,dict): continue
        elements.append({
          "id":a.get("id",f"annotation:{i}"),"kind":"annotation",
          "semantic_priority":_clip01(a.get("importance",.18),.18),"annotation_only":True,
          "essential":bool(a.get("essential",False)),"can_be_hero":False,"related_to_hero":True,
        })
    return {"representation_family":family,"elements":elements}

def _apply_composition_classification(components: List[Dict[str,Any]], groups: List[Dict[str,Any]], data_modules: List[Dict[str,Any]], metaphor: Dict[str,Any] | None, supporting_character: Dict[str,Any] | None, relation_visuals: List[Dict[str,Any]], decision: Dict[str,Any]) -> None:
    cls=decision.get("classification",{})
    group_class={g["id"]:cls.get(g["id"]) for g in groups}
    concept_container={cid:g["id"] for g in groups for cid in g["concept_ids"]}
    for c in components:
        gid=concept_container.get(c["concept_id"])
        c["composition_class"]=group_class.get(gid,"micro_annotation")
        c["composition_container_id"]=gid
    for g in groups: g["composition_class"]=cls.get(g["id"])
    for d in data_modules: d["composition_class"]=cls.get(d["id"])
    if metaphor and metaphor.get("status")=="PASS": metaphor["composition_class"]=cls.get("metaphor:module")
    if supporting_character and supporting_character.get("status")=="PASS": supporting_character["composition_class"]=cls.get("supporting-character:module")
    concept_group={cid:g["id"] for g in groups for cid in g["concept_ids"]}
    for r in relation_visuals:
        if r["id"] in cls:
            r["composition_class"]=cls[r["id"]]
        else:
            src=r["source"].split("component:",1)[-1]; tgt=r["target"].split("component:",1)[-1]
            sg=concept_group.get(src); tg=concept_group.get(tgt)
            r["composition_class"]=cls.get(sg,"micro_annotation") if sg and sg==tg else "micro_annotation"

def _aspect_layouts(inp: Dict[str,Any], components: List[Dict[str,Any]], relations: List[Dict[str,Any]]) -> Dict[str,Any]:
    major=[c for c in components if c["hierarchy"] in {"hero","support"}]
    major_count=len(major)
    layouts={}
    for ratio,base in ASPECTS.items():
        orientation=base["orientation"]
        if orientation=="horizontal": grammar="left_to_right_compound" if major_count>2 else "balanced_cluster"
        elif orientation=="compact": grammar="compact_cluster_or_2x2" if major_count>3 else "balanced_compact"
        else: grammar="top_to_bottom_compound"
        layouts[ratio]={
          "orientation":orientation,
          "layout_grammar":grammar,
          "hero_scale":base["hero"], "support_scale":base["support"], "micro_scale":base["micro"],
          "preserve_hierarchy":True,
          "no_stretch":True,
          "no_crop_labels":True,
          "min_major_visual_occupancy":0.16,
          "max_character_to_object_scale_ratio":1.10,
        }
    return layouts

def compose(inp: Dict[str,Any]) -> Dict[str,Any]:
    _validate(inp)
    entities=copy.deepcopy(inp["entities"]); relations=copy.deepcopy(inp.get("relations",[]))
    hierarchy=_hierarchy(entities,relations)
    components=[_component_for_entity(inp,e,hierarchy[e["id"]]) for e in entities]
    # Keep the board sparse but rich: at most 7 major semantic forms before replanning.
    major=sum(1 for c in components if c["hierarchy"] in {"hero","support"})
    if major>7:
        return {"status":"REPLAN_REQUIRED","reason":"MAJOR_COMPONENT_BUDGET_EXCEEDED","major_components":major}
    evidence=_evidence_modules(inp,hierarchy)
    if any(d.get("status")=="REPLAN_REQUIRED" for d in evidence):
        return {"status":"REPLAN_REQUIRED","reason":"DATA_PRESENTATION_REPLAN_REQUIRED","data_modules":evidence}
    metaphor=_metaphor_module(inp)
    if metaphor and metaphor.get("status")=="REPLAN_REQUIRED":
        return {"status":"REPLAN_REQUIRED","reason":"METAPHOR_REPLAN_REQUIRED","metaphor_module":metaphor}
    supporting_character=_supporting_character_module(inp)
    if supporting_character and supporting_character.get("status")=="REPLAN_REQUIRED":
        return {"status":"REPLAN_REQUIRED","reason":"SUPPORTING_CHARACTER_REPLAN_REQUIRED","supporting_character_module":supporting_character}
    rel_visuals=[_relation_visual(r) for r in relations]
    groups=_compound_groups(inp,hierarchy)
    hierarchy_ctx=_composition_hierarchy_context(inp,components,groups,evidence,metaphor,supporting_character,rel_visuals)
    try:
        composition_hierarchy=plan_composition_hierarchy(hierarchy_ctx)
    except CompositionHierarchyError as e:
        raise ComposeError(f"COMPOSITION_HIERARCHY_INVALID:{e}")
    if composition_hierarchy.get("status")!="PASS":
        return {"status":"REPLAN_REQUIRED","reason":"COMPOSITION_HIERARCHY_REPLAN_REQUIRED","composition_hierarchy":composition_hierarchy}
    _apply_composition_classification(components,groups,evidence,metaphor,supporting_character,rel_visuals,composition_hierarchy)
    hierarchy_bindings={ratio:bind_composition_hierarchy_render(composition_hierarchy,ratio) for ratio in ("16:9","1:1","9:16")}
    out={
      "schema":"NexMindWhiteboardSemanticIllustrationBlueprintV1",
      "composer_version":VERSION,
      "status":"PASS",
      "beat_id":inp.get("beat_id"),
      "representation_family":inp["representation_family"],
      "illustration_grammar":REPRESENTATION_TO_GRAMMAR[inp["representation_family"]],
      "hierarchy":hierarchy,
      "components":components,
      "compound_groups":groups,
      "relations":rel_visuals,
      "data_modules":evidence,
      "metaphor_module":metaphor,
      "supporting_character_module":supporting_character,
      "composition_hierarchy":composition_hierarchy,
      "composition_hierarchy_renderer_bindings":hierarchy_bindings,
      "aspect_layouts":_aspect_layouts(inp,components,rel_visuals),
      "style_contract":{
        "visual_language":"nexmind-whiteboard-clean-v1",
        "stroke_family":"consistent-clean-ink",
        "accent_policy":"single_restrained_accent",
        "decorative_satellites":False,
        "orphan_marks":False,
        "free_running_lines":False,
        "generic_stock_doodle_hero":False,
        "native_character_only":True,
        "compound_illustration_preferred_over_naked_icon":True,
        "data_must_be_contextual_when_evidence_exists":bool(evidence),
        "metaphor_must_be_semantically_governed":True,
        "keyword_metaphor_dispatch":False,
        "supporting_character_scale_ceiling":0.78,
        "recurring_character_requires_story_semantics":True,
        "stock_doodles_forbidden":True,
        "explicit_composition_hierarchy":True,
        "hero_support_micro_classes_required":True,
        "decorative_density_forbidden":True,
        "vo_cue_remains_master_timeline":True,
      },
      "routing_proof":{
        "content_labels_used_for_layout":False,
        "content_labels_used_for_representation":False,
        "content_labels_used_for_scale":False,
        "content_labels_used_only_for_asset_query_and_display":True,
        "content_labels_used_for_composition_hierarchy":False,
      }
    }
    return out

def normalized_structure(out: Dict[str,Any]) -> Dict[str,Any]:
    """Remove content-bearing strings for invariance testing."""
    o=copy.deepcopy(out)
    for c in o.get("components",[]):
        c["label"]="<LABEL>"; c["asset_query"]["concept"]="<CONCEPT>"
    for d in o.get("data_modules",[]): d["labels"]=["<LABEL>" for _ in d.get("labels",[])]
    return o

def main():
    import argparse, sys
    ap=argparse.ArgumentParser(); ap.add_argument("input",nargs="?")
    args=ap.parse_args()
    data=json.load(open(args.input)) if args.input else json.load(sys.stdin)
    print(json.dumps(compose(data),indent=2))
if __name__=="__main__": main()
