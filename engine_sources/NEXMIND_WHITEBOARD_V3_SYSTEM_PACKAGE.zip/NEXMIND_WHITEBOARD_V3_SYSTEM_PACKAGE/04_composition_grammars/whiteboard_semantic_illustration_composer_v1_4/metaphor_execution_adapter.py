#!/usr/bin/env python3
"""Execution binding for NexMind Whiteboard Metaphor Grammar V1.
Renderer executes exactly the selected semantic mechanism; no keyword or generic-metaphor fallback.
"""
from __future__ import annotations
from typing import Any, Dict
import copy, json
from metaphor_grammar import FORMS
VERSION="1.0.0"
FORM_RENDER_GRAMMAR={
 "bottleneck":"bounded_throughput_constraint","bridge":"bounded_cross_gap_connection",
 "pool":"shared_resource_pool","vault":"protected_access_container","widening_lanes":"capacity_expansion_flow",
 "balance":"two_force_balance","fragmentation_reassembly":"fragment_to_whole_integration",
 "stacking_compounding":"retained_gain_stack","flywheel":"reinforcing_closed_loop",
 "branching_paths":"one_to_many_paths","sieve_filter":"criteria_selection_boundary","relay_handoff":"owned_stage_handoff"
}
class MetaphorExecutionError(ValueError): pass

def bind(decision:Dict[str,Any],aspect_ratio="16:9")->Dict[str,Any]:
    if not isinstance(decision,dict): raise MetaphorExecutionError("DECISION_REQUIRED")
    if decision.get("status")!="PASS":
        return {"status":"LITERAL_OR_REPLAN","reason":"METAPHOR_DECISION_NOT_PASS","source_status":decision.get("status")}
    form=decision.get("selected_form")
    if form not in FORMS or form not in FORM_RENDER_GRAMMAR: raise MetaphorExecutionError("UNKNOWN_OR_UNGOVERNED_METAPHOR")
    layouts=decision.get("aspect_layouts",{})
    if aspect_ratio not in layouts: raise MetaphorExecutionError("UNSUPPORTED_ASPECT_RATIO")
    p=decision.get("presentation",{})
    if p.get("presentation")!="semantic_mechanism_not_decorative_metaphor": raise MetaphorExecutionError("DECORATIVE_METAPHOR_FORBIDDEN")
    return {
      "schema":"NexMindWhiteboardMetaphorRenderContractV1","version":VERSION,"status":"PASS",
      "selected_form":form,"render_grammar":FORM_RENDER_GRAMMAR[form],"aspect_ratio":aspect_ratio,
      "aspect_layout":copy.deepcopy(layouts[aspect_ratio]),"parts":copy.deepcopy(p.get("parts",[])),"motion":p.get("motion"),
      "semantic_bindings":copy.deepcopy(decision.get("semantic_bindings",{})),
      "render_policies":{
        "generic_metaphor_fallback":"FORBIDDEN","keyword_to_metaphor_mapping":"FORBIDDEN","default_form":None,
        "renderer_may_change_form":False,"execute_selected_form_exactly":True,"free_running_lines":False,
        "decorative_satellites":False,"orphan_marks":False,"all_connectors_require_owned_endpoints":True,
      }
    }

def main():
    import argparse,sys
    ap=argparse.ArgumentParser();ap.add_argument("input",nargs="?");ap.add_argument("--aspect",default="16:9")
    a=ap.parse_args();d=json.load(open(a.input)) if a.input else json.load(sys.stdin)
    print(json.dumps(bind(d,a.aspect),indent=2))
if __name__=="__main__":main()
