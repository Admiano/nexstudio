#!/usr/bin/env python3
"""NexMind Whiteboard Data Presentation Grammar V1.

Selects and plans a contextual data visualization from abstract evidence semantics.
Content labels are payload only. They are never used for form selection.
"""
from __future__ import annotations
from typing import Any, Dict, List, Tuple
import copy, json, math

VERSION = "1.0.0"

FORMS = (
    "accumulation", "before_after", "bars", "ratio", "percentage", "counter",
    "funnel", "timeline", "growth_decline", "ranking", "value_flow"
)

FEATURES = (
    "single_total", "cumulative", "two_state_change", "categorical_comparison",
    "ratio_relation", "part_to_whole", "staged_attrition", "chronological_sequence",
    "directional_change", "ordered_rank", "value_transfer"
)

ASPECTS = {
    "16:9": {"orientation":"horizontal", "label_budget":18, "major_scale":1.0},
    "1:1": {"orientation":"compact", "label_budget":15, "major_scale":0.96},
    "9:16": {"orientation":"vertical", "label_budget":13, "major_scale":0.96},
}

class DataGrammarError(ValueError):
    pass

def _clip01(x: Any, default: float=0.0) -> float:
    try: return max(0.0, min(1.0, float(x)))
    except Exception: return default

def _features(ev: Dict[str,Any]) -> Dict[str,float]:
    raw=ev.get("features",{}) or {}
    f={k:_clip01(raw.get(k,0.0)) for k in FEATURES}
    # Structural evidence shape may supply only broad priors; labels/nouns never do.
    shape=ev.get("shape")
    priors={
      "scalar":{"single_total":0.78},
      "accumulation":{"cumulative":0.86},
      "comparison":{"categorical_comparison":0.58},
      "ratio":{"ratio_relation":0.72},
      "trend":{"directional_change":0.70},
      "timeline":{"chronological_sequence":0.82},
      "distribution":{"categorical_comparison":0.46},
      "ranking":{"ordered_rank":0.86},
      "funnel":{"staged_attrition":0.90},
      "value_flow":{"value_transfer":0.92},
      "percentage":{"part_to_whole":0.90},
      "before_after":{"two_state_change":0.90},
    }
    for k,v in priors.get(shape,{}).items(): f[k]=max(f[k],v)
    return f

def _validate(ev: Dict[str,Any]) -> None:
    if not isinstance(ev,dict): raise DataGrammarError("EVIDENCE_MUST_BE_OBJECT")
    values=ev.get("values")
    if not isinstance(values,list) or not values: raise DataGrammarError("VALUES_REQUIRED")
    for v in values:
        if not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(float(v)):
            raise DataGrammarError("VALUES_MUST_BE_FINITE_NUMBERS")
    labels=ev.get("labels",[])
    if labels and len(labels)!=len(values): raise DataGrammarError("LABEL_VALUE_LENGTH_MISMATCH")
    if len(values)>12: raise DataGrammarError("TOO_MANY_VALUES_REPLAN")
    if ev.get("source_entity") is not None and not isinstance(ev.get("source_entity"),str):
        raise DataGrammarError("SOURCE_ENTITY_MUST_BE_ID")
    if ev.get("target_entity") is not None and not isinstance(ev.get("target_entity"),str):
        raise DataGrammarError("TARGET_ENTITY_MUST_BE_ID")

def _scores(ev: Dict[str,Any], f: Dict[str,float]) -> Dict[str,float]:
    n=len(ev["values"])
    total=ev.get("normalized_total")
    percentage_unit=bool(ev.get("percentage_unit",False))
    has_endpoints=bool(ev.get("source_entity") and ev.get("target_entity"))
    s={k:0.0 for k in FORMS}
    # Strong semantic fits. Count/cardinality constrains but does not drive selection alone.
    s["counter"] = 0.90*f["single_total"] + (0.10 if n==1 else -0.25)
    s["accumulation"] = 0.88*f["cumulative"] + (0.08 if n>=2 else 0.0)
    s["before_after"] = 0.90*f["two_state_change"] + (0.10 if n==2 else -0.20)
    s["bars"] = 0.84*f["categorical_comparison"] + (0.10 if 2<=n<=6 else -0.16) - 0.28*f["chronological_sequence"] - 0.22*f["ordered_rank"]
    s["ratio"] = 0.90*f["ratio_relation"] + (0.08 if n==2 else -0.18) - 0.30*f["part_to_whole"]
    pct_struct=(percentage_unit or total==100 or (n>=2 and abs(sum(float(x) for x in ev["values"])-100.0)<1e-6))
    s["percentage"] = 0.92*f["part_to_whole"] + (0.08 if pct_struct else -0.12)
    s["funnel"] = 0.94*f["staged_attrition"] + (0.06 if 3<=n<=7 else -0.15)
    s["timeline"] = 0.91*f["chronological_sequence"] + (0.05 if n>=2 else -0.18) - 0.28*f["directional_change"]
    s["growth_decline"] = 0.91*f["directional_change"] + (0.06 if n>=2 else -0.18)
    s["ranking"] = 0.94*f["ordered_rank"] + (0.06 if 3<=n<=8 else -0.15)
    s["value_flow"] = (0.93*f["value_transfer"] + 0.07) if has_endpoints else 0.0
    return {k:max(0.0,min(1.0,v)) for k,v in s.items()}

def _format_policy(ev: Dict[str,Any]) -> Dict[str,Any]:
    return {
      "unit":ev.get("unit"),
      "prefix":ev.get("prefix"),
      "suffix":ev.get("suffix"),
      "compact_large_numbers":True,
      "max_significant_digits":3,
      "source_numbers_must_be_preserved":True,
      "no_invented_metric":True,
    }

def _presentation(form: str, ev: Dict[str,Any]) -> Dict[str,Any]:
    common={
      "form":form,
      "presentation":"contextual_not_naked_number",
      "number_ownership":"numbers_attach_to_visual_marks_or_semantic_object",
      "hero_rule":"the evidence relationship is the hero; number text is supporting evidence",
      "no_full_chart_chrome":True,
      "no_default_axes":True,
      "no_decorative_grid":True,
      "no_legend_unless_necessary":True,
      "no_stray_marks":True,
      "single_restrained_accent":True,
      "format":_format_policy(ev),
    }
    specs={
      "counter":{
        "marks":["context_object","count_field_or_counter","settled_total"],
        "motion":"small population/units accumulate; counter resolves early and holds",
        "best_for":"one important total or cardinality",
      },
      "accumulation":{
        "marks":["repeating_units_or_stack","progressive_fill","settled_total"],
        "motion":"visible accumulation causes the total; do not show a detached number",
        "best_for":"cumulative volume or repeated completed events",
      },
      "before_after":{
        "marks":["before_state","change_cue","after_state","delta_annotation"],
        "motion":"before establishes first; after arrives on change cue; delta resolves last",
        "best_for":"two-state change",
      },
      "bars":{
        "marks":["context_anchor","2_to_6_bars","direct_labels","optional_value_tags"],
        "motion":"bars grow in semantic order; labels stay attached to their bars",
        "best_for":"independent category comparison where magnitude matters",
      },
      "ratio":{
        "marks":["two_grouped_quantities","ratio_divider_or_balance","direct_ratio_label"],
        "motion":"both quantities establish; relation resolves as one compact ratio situation",
        "best_for":"direct A:B proportion",
      },
      "percentage":{
        "marks":["whole_container","filled_part","remainder","percentage_annotation"],
        "motion":"whole appears first; part fills to its share; percentage attaches to filled part",
        "best_for":"part-to-whole share",
      },
      "funnel":{
        "marks":["stage_shapes","stage_counts","loss_or_conversion_cues","final_outcome"],
        "motion":"stages resolve top-to-bottom/left-to-right with attrition visible between them",
        "best_for":"multi-stage conversion or attrition",
      },
      "timeline":{
        "marks":["bounded_time_path","milestones","short_time_labels","current_or_end_state"],
        "motion":"milestones appear in chronological order; no decorative path beyond endpoints",
        "best_for":"ordered events or milestones where time order is the message",
      },
      "growth_decline":{
        "marks":["start_value","compact_trend_path","end_value","direction_or_delta_annotation"],
        "motion":"trend draws once from start to end; end-state/delta settles before narration ends",
        "best_for":"direction and magnitude of change",
      },
      "ranking":{
        "marks":["ordered_rows_or_bars","rank_numbers","direct_labels","top_emphasis"],
        "motion":"items settle in rank order; top result is emphasized without giant scale jump",
        "best_for":"ordered comparison/top-N",
      },
      "value_flow":{
        "marks":["source_object","value_units","bounded_flow_path","destination_object","result_state"],
        "motion":"value visibly leaves source and arrives at destination; amount stays attached to the moving/settled value",
        "best_for":"transfer, payment, funding, settlement, or any source-to-destination quantity",
      },
    }
    common.update(specs[form]); return common

def _aspect_reflow(form:str) -> Dict[str,Any]:
    out={}
    for ratio,b in ASPECTS.items():
        if form in {"funnel","timeline"} and ratio=="9:16": grammar="vertical_sequence"
        elif form=="value_flow" and ratio=="9:16": grammar="vertical_source_to_destination"
        elif form in {"before_after","ratio","bars","ranking"} and ratio=="9:16": grammar="stacked_comparison"
        elif ratio=="1:1": grammar="compact_balanced"
        else: grammar="horizontal_or_compact_native"
        out[ratio]={
          "orientation":b["orientation"], "layout_grammar":grammar,
          "major_scale":b["major_scale"], "max_label_characters":b["label_budget"],
          "preserve_value_order":True, "preserve_relative_magnitude":True,
          "no_stretch":True, "no_crop_labels":True, "no_micro_charting":True,
        }
    return out

def select(ev: Dict[str,Any]) -> Dict[str,Any]:
    _validate(ev); f=_features(ev); s=_scores(ev,f)
    ranked=sorted(s.items(), key=lambda kv:(-kv[1],FORMS.index(kv[0])))
    winner,wscore=ranked[0]; second,sscore=ranked[1]
    # Fail closed rather than chart-by-default. Ties indicate insufficient semantic specificity.
    if wscore < 0.60:
        return {"schema":"NexMindWhiteboardDataPresentationDecisionV1","version":VERSION,"status":"REPLAN_REQUIRED","reason":"EVIDENCE_SEMANTICS_TOO_WEAK","scores":s,"features":f}
    if wscore-sscore < 0.055 and sscore >= 0.60:
        return {"schema":"NexMindWhiteboardDataPresentationDecisionV1","version":VERSION,"status":"REPLAN_REQUIRED","reason":"AMBIGUOUS_DATA_FORM","scores":s,"features":f,"top_candidates":[winner,second]}
    return {
      "schema":"NexMindWhiteboardDataPresentationDecisionV1", "version":VERSION,
      "status":"PASS", "evidence_id":ev.get("id"), "selected_form":winner,
      "confidence":round(wscore,4), "runner_up":second, "runner_up_score":round(sscore,4),
      "features":f, "scores":s,
      "presentation":_presentation(winner,ev), "aspect_layouts":_aspect_reflow(winner),
      "context_binding":{
        "source_entity":ev.get("source_entity"), "target_entity":ev.get("target_entity"),
        "must_attach_to_semantic_context":True, "may_float_as_naked_number":False,
      },
      "routing_proof":{
        "content_labels_used_for_selection":False,
        "content_labels_used_only_for_display":True,
        "chart_is_default":False,
        "fail_closed_when_ambiguous":True,
      }
    }

def normalized_structure(out:Dict[str,Any])->Dict[str,Any]:
    o=copy.deepcopy(out)
    # Labels are not surfaced in selection output, but keep helper for mutation tests.
    return o

def main():
    import argparse, sys
    ap=argparse.ArgumentParser(); ap.add_argument("input",nargs="?")
    args=ap.parse_args(); data=json.load(open(args.input)) if args.input else json.load(sys.stdin)
    print(json.dumps(select(data),indent=2))
if __name__=="__main__": main()
