#!/usr/bin/env python3
"""NexMind Whiteboard Composition Hierarchy Grammar V1.

Every visible element in a beat is classified into one of three composition
classes: hero_illustration, supporting_evidence, micro_annotation.
The planner operates on abstract semantic priority/structure only. Labels,
keywords and topic/domain text are payload and never influence hierarchy.
"""
from __future__ import annotations
from typing import Any, Dict, List
import copy, json

VERSION = "1.0.0"
CLASSES = ("hero_illustration", "supporting_evidence", "micro_annotation")

ASPECT_BUDGETS = {
    "16:9": {"hero":0.44, "support":0.26, "micro":0.08, "breathing_room":0.22, "flow":"lateral_or_centered"},
    "1:1":  {"hero":0.46, "support":0.27, "micro":0.08, "breathing_room":0.19, "flow":"compact_cluster"},
    "9:16": {"hero":0.42, "support":0.30, "micro":0.08, "breathing_room":0.20, "flow":"vertical_stack"},
}

class CompositionHierarchyError(ValueError):
    pass

def _clip01(v, default=0.0):
    try: return max(0.0, min(1.0, float(v)))
    except Exception: return default

def _validate(ctx: Dict[str,Any]) -> None:
    if not isinstance(ctx,dict): raise CompositionHierarchyError("CONTEXT_MUST_BE_OBJECT")
    elems=ctx.get("elements")
    if not isinstance(elems,list) or not elems: raise CompositionHierarchyError("ELEMENTS_REQUIRED")
    ids=[]
    for e in elems:
        if not isinstance(e,dict) or not e.get("id"): raise CompositionHierarchyError("ELEMENT_ID_REQUIRED")
        if e.get("kind") not in {"illustration_group","data_module","metaphor_module","supporting_character_module","relation_cue","annotation"}:
            raise CompositionHierarchyError("UNSUPPORTED_ELEMENT_KIND")
        ids.append(e["id"])
    if len(ids)!=len(set(ids)): raise CompositionHierarchyError("ELEMENT_IDS_MUST_BE_UNIQUE")

def _hero_score(e: Dict[str,Any], family: str) -> float:
    if not e.get("can_be_hero",False): return -1.0
    p=_clip01(e.get("semantic_priority",0.5),0.5)
    n=_clip01(e.get("narrative_centrality",p),p)
    c=_clip01(e.get("structural_centrality",0.5),0.5)
    ev=_clip01(e.get("evidence_strength",0.0),0.0)
    score=.44*p+.30*n+.18*c+.08*ev
    kind=e.get("kind")
    # Representation-family preference is abstract, not domain/topic routing.
    if family in {"data","data-in-context"} and kind=="data_module": score+=.18
    elif family in {"metaphor","physical-metaphor"} and kind=="metaphor_module": score+=.20
    elif family=="comparison" and e.get("contains_explicit_comparison"): score+=.14
    elif kind=="illustration_group": score+=.06
    return min(1.2,score)

def _support_score(e: Dict[str,Any]) -> float:
    p=_clip01(e.get("semantic_priority",0.4),0.4)
    ev=_clip01(e.get("evidence_strength",0.0),0.0)
    n=_clip01(e.get("narrative_centrality",p),p)
    return .45*p+.35*ev+.20*n

def plan(ctx: Dict[str,Any]) -> Dict[str,Any]:
    _validate(ctx)
    family=ctx.get("representation_family","")
    elems=copy.deepcopy(ctx["elements"])

    hero_candidates=[( _hero_score(e,family), i, e) for i,e in enumerate(elems) if e.get("can_be_hero",False)]
    hero_candidates.sort(key=lambda x:(-x[0],x[1]))
    if not hero_candidates or hero_candidates[0][0] < .46:
        return {"schema":"NexMindWhiteboardCompositionHierarchyDecisionV1","version":VERSION,"status":"REPLAN_REQUIRED","reason":"NO_CLEAR_HERO"}
    hero=hero_candidates[0][2]
    # If the top two unrelated hero candidates are nearly tied, the beat is doing too much.
    if len(hero_candidates)>1 and hero_candidates[1][0]>=.62 and (hero_candidates[0][0]-hero_candidates[1][0])<.045:
        a,b=hero_candidates[0][2],hero_candidates[1][2]
        if not (a.get("shared_hero_cluster") and a.get("shared_hero_cluster")==b.get("shared_hero_cluster")):
            return {"schema":"NexMindWhiteboardCompositionHierarchyDecisionV1","version":VERSION,"status":"REPLAN_REQUIRED","reason":"COMPETING_HERO_CANDIDATES","candidates":[a["id"],b["id"]]}

    classification={hero["id"]:"hero_illustration"}
    support=[]; micro=[]
    essential_support_overflow=[]
    for e in elems:
        if e["id"]==hero["id"]: continue
        if e.get("annotation_only") or e.get("kind") in {"relation_cue","annotation"}:
            micro.append(e); continue
        if e.get("must_be_support") or e.get("kind")=="supporting_character_module":
            support.append(e); continue
        ss=_support_score(e)
        if ss>=.50 and e.get("related_to_hero",True): support.append(e)
        else: micro.append(e)

    support.sort(key=lambda e:(-_support_score(e), e["id"]))
    # Never solve crowding by shrinking important evidence.
    if len(support)>3:
        for e in support[3:]:
            if _support_score(e)>=.62 or e.get("essential",False): essential_support_overflow.append(e["id"])
        if essential_support_overflow:
            return {"schema":"NexMindWhiteboardCompositionHierarchyDecisionV1","version":VERSION,"status":"REPLAN_REQUIRED","reason":"SUPPORTING_EVIDENCE_BUDGET_EXCEEDED","overflow":essential_support_overflow}
        micro.extend(support[3:]); support=support[:3]

    # Micro annotations are small because they are genuinely micro, not because we ran out of room.
    important_micro=[e["id"] for e in micro if _clip01(e.get("semantic_priority",0.0))>=.62 and not e.get("annotation_only") and e.get("kind") not in {"relation_cue","annotation"}]
    if important_micro:
        return {"schema":"NexMindWhiteboardCompositionHierarchyDecisionV1","version":VERSION,"status":"REPLAN_REQUIRED","reason":"IMPORTANT_ELEMENT_CANNOT_BE_MICRO","elements":important_micro}
    if len(micro)>6:
        essential=[e["id"] for e in micro[6:] if e.get("essential",False)]
        if essential:
            return {"schema":"NexMindWhiteboardCompositionHierarchyDecisionV1","version":VERSION,"status":"REPLAN_REQUIRED","reason":"MICRO_ANNOTATION_BUDGET_EXCEEDED","overflow":essential}
        micro=micro[:6]

    for e in support: classification[e["id"]]="supporting_evidence"
    for e in micro: classification[e["id"]]="micro_annotation"
    # All visible elements must be accounted for. Elements omitted due to nonessential micro cap are suppressed, never left unclassified.
    suppressed=[e["id"] for e in elems if e["id"] not in classification]

    hero_parts=max(1,int(hero.get("semantic_part_count",1)))
    enrichment_needed=hero_parts<2 and family not in {"data","data-in-context","metaphor","physical-metaphor"}

    aspect_layouts={}
    for ratio,b in ASPECT_BUDGETS.items():
        aspect_layouts[ratio]={
            "flow":b["flow"],
            "area_budget":{
                "hero_illustration":b["hero"],
                "supporting_evidence_total":b["support"],
                "micro_annotation_total_max":b["micro"],
                "breathing_room":b["breathing_room"],
            },
            "hero_scale_authority":1.0 if ratio=="16:9" else .96,
            "support_scale_ceiling":.74,
            "micro_scale_ceiling":.52,
            "max_support_items":3,
            "max_micro_items":6,
            "preserve_hierarchy":True,
            "reflow_not_stretch":True,
            "do_not_enlarge_character_to_fill_canvas":True,
        }

    reveal_order={
        "authority":"VO_CUE_FIRST",
        "within_same_semantic_cue":["hero_illustration_anchor","supporting_evidence","micro_annotation"],
        "rule":"Hierarchy never advances an element before its narration/semantic cue; it only orders simultaneous or same-cue reveals.",
        "hero_completion":"hero may finish before final spoken syllable but remains visible while the VO completes the idea",
    }

    return {
        "schema":"NexMindWhiteboardCompositionHierarchyDecisionV1",
        "version":VERSION,
        "status":"PASS",
        "hero_illustration":hero["id"],
        "supporting_evidence":[e["id"] for e in support],
        "micro_annotations":[e["id"] for e in micro],
        "suppressed_nonessential":[x for x in suppressed],
        "classification":classification,
        "hero_semantic_part_count":hero_parts,
        "hero_enrichment_needed":enrichment_needed,
        "hero_enrichment_contract":{
            "target_semantic_parts_min":2,
            "target_semantic_parts_max":5,
            "may_only_use_owned_semantic_parts":True,
            "decorative_filler_forbidden":True,
            "if_no_owned_part_exists":"KEEP_ATOMIC_OR_REPLAN; NEVER INVENT",
        },
        "density_contract":{
            "max_support_items":3,
            "max_micro_items":6,
            "richness_source":"semantic_density_not_decorative_density",
            "important_content_may_not_be_shrunk_to_micro":True,
            "white_space_is_intentional_not_default_emptiness":True,
        },
        "aspect_layouts":aspect_layouts,
        "reveal_order":reveal_order,
        "routing_proof":{
            "labels_used_for_hierarchy":False,
            "topic_or_domain_used_for_hierarchy":False,
            "semantic_priority_structure_and_evidence_only":True,
        },
    }

def main():
    import argparse,sys
    ap=argparse.ArgumentParser(); ap.add_argument("input",nargs="?")
    a=ap.parse_args(); data=json.load(open(a.input)) if a.input else json.load(sys.stdin)
    print(json.dumps(plan(data),indent=2))
if __name__=="__main__": main()
