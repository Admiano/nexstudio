#!/usr/bin/env python3
"""Renderer binding for Native Supporting Character Grammar V1."""
from __future__ import annotations
from typing import Any, Dict

VERSION = "1.0.0"
VALID_ASPECTS = {"16:9", "1:1", "9:16"}

class SupportingCharacterExecutionError(ValueError):
    pass

def bind(decision: Dict[str,Any], aspect: str) -> Dict[str,Any]:
    if aspect not in VALID_ASPECTS:
        raise SupportingCharacterExecutionError("UNSUPPORTED_ASPECT")
    if decision.get("status") != "PASS":
        raise SupportingCharacterExecutionError("CHARACTER_DECISION_NOT_PASS")
    form = decision.get("selected_form")
    layout = decision.get("aspect_layouts", {}).get(aspect)
    if not form or not layout:
        raise SupportingCharacterExecutionError("EXPLICIT_FORM_AND_LAYOUT_REQUIRED")
    return {
        "schema": "NexMindWhiteboardSupportingCharacterRenderBindingV1",
        "version": VERSION,
        "aspect": aspect,
        "form": form,
        "layout": layout,
        "presentation": decision["presentation"],
        "identity_policy": decision["identity_policy"],
        "render_policies": {
            "generic_character_fallback": "FORBIDDEN",
            "stock_doodle_fallback": "FORBIDDEN",
            "character_scale_ceiling": 0.78,
            "unowned_prop": "FORBIDDEN",
            "floating_hand_contact": "FORBIDDEN",
            "decorative_character": "FORBIDDEN",
            "recurring_identity_without_story_semantics": "FORBIDDEN",
            "renderer_may_change_selected_form": False,
            "renderer_may_invent_character": False,
        },
    }
