#!/usr/bin/env python3
"""Renderer binding for Composition Hierarchy Grammar V1."""
from __future__ import annotations
from typing import Any, Dict
VERSION="1.0.0"
VALID={"16:9","1:1","9:16"}
class CompositionHierarchyExecutionError(ValueError): pass

def bind(decision: Dict[str,Any], aspect: str)->Dict[str,Any]:
    if aspect not in VALID: raise CompositionHierarchyExecutionError("UNSUPPORTED_ASPECT")
    if decision.get("status")!="PASS": raise CompositionHierarchyExecutionError("HIERARCHY_DECISION_NOT_PASS")
    layout=decision.get("aspect_layouts",{}).get(aspect)
    if not layout: raise CompositionHierarchyExecutionError("EXPLICIT_ASPECT_LAYOUT_REQUIRED")
    return {
      "schema":"NexMindWhiteboardCompositionHierarchyRenderBindingV1","version":VERSION,
      "aspect":aspect,"hero_illustration":decision["hero_illustration"],
      "supporting_evidence":decision["supporting_evidence"],"micro_annotations":decision["micro_annotations"],
      "suppressed_nonessential":decision.get("suppressed_nonessential",[]),
      "layout":layout,"reveal_order":decision["reveal_order"],
      "render_policies":{
        "renderer_may_promote_or_demote_elements":False,
        "renderer_may_add_filler":False,
        "renderer_may_create_unclassified_visible_element":False,
        "important_content_may_be_shrunk_to_micro":False,
        "vo_cue_remains_master_timeline":True,
        "decorative_density":"FORBIDDEN",
        "stretch_to_fill":"FORBIDDEN",
      }
    }
