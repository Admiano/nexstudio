# NexMind Whiteboard Semantic Illustration Composer V1.2

V1.2 preserves the V1.1 governed data layer and adds Metaphor Grammar V1. Strong mechanism semantics can now produce a governed metaphor module with explicit renderer bindings for 16:9, 1:1 and 9:16. Weak metaphor suggestions remain literal for non-metaphor representation families; a requested metaphor family fails closed when its mechanism semantics are insufficient.

No keyword-to-metaphor routing and no generic metaphor fallback are available.

QA: 9/9 inherited Composer tests, 2/2 data integration tests, 4/4 metaphor integration tests PASS.


## V1.3 Native Supporting Characters
Added Native Supporting Character Grammar V1 and a strict renderer execution adapter.

Governed interaction families:
- person + phone
- person + laptop
- operator + machine
- giver / receiver
- presenter
- approver
- two-person comparison

Characters are supporting forms, never generic heroes. Maximum character scale relative to the hero mechanism is 0.78.
Character recurrence is beat-local by default and may carry forward only when explicit story continuity semantics require it.
No topic/keyword routing, no giant stock doodles, no floating props, and no generic character fallback.


## V1.4 Explicit Composition Hierarchy
Added Composition Hierarchy Grammar V1. Every beat now has explicit top-level classes: hero illustration, supporting evidence, micro annotation. One clear hero is required; unrelated competing heroes fail closed. Supporting evidence is capped at three; micro annotations at six / 8% area. Important overflow may not be shrunk into micro. The hierarchy is VO-subordinate: narration/semantic cue timing remains master. Supporting characters can participate inside a hero interaction but never become the top-level hero themselves.
