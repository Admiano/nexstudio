#!/usr/bin/env python3
"""Execution binding for NexMind Whiteboard Data Presentation Grammar V1.
No chart fallback exists. The renderer executes exactly the selected governed form.
"""
from __future__ import annotations
from typing import Any, Dict
import copy, json
from data_presentation_grammar import FORMS

VERSION='1.0.0'
FORM_RENDER_GRAMMAR={
 'counter':'context_counter', 'accumulation':'context_accumulation',
 'before_after':'paired_state_change', 'bars':'direct_label_magnitude_bars',
 'ratio':'grouped_ratio', 'percentage':'part_to_whole_fill', 'funnel':'bounded_stage_funnel',
 'timeline':'bounded_milestone_timeline', 'growth_decline':'compact_directional_trend',
 'ranking':'ordered_rank_rows', 'value_flow':'bounded_value_transfer'
}
class ExecutionBindingError(ValueError): pass

def bind(decision:Dict[str,Any], aspect_ratio='16:9')->Dict[str,Any]:
    if not isinstance(decision,dict): raise ExecutionBindingError('DECISION_REQUIRED')
    if decision.get('status')!='PASS':
        return {'status':'REPLAN_REQUIRED','reason':'DATA_DECISION_NOT_PASS','source_status':decision.get('status')}
    form=decision.get('selected_form')
    if form not in FORMS or form not in FORM_RENDER_GRAMMAR: raise ExecutionBindingError('UNKNOWN_OR_UNGOVERNED_DATA_FORM')
    layouts=decision.get('aspect_layouts',{})
    if aspect_ratio not in layouts: raise ExecutionBindingError('UNSUPPORTED_ASPECT_RATIO')
    p=decision.get('presentation',{})
    if p.get('presentation')!='contextual_not_naked_number': raise ExecutionBindingError('NAKED_NUMBER_PRESENTATION_FORBIDDEN')
    return {
      'schema':'NexMindWhiteboardDataRenderContractV1','version':VERSION,'status':'PASS',
      'selected_form':form,'render_grammar':FORM_RENDER_GRAMMAR[form],
      'aspect_ratio':aspect_ratio,'aspect_layout':copy.deepcopy(layouts[aspect_ratio]),
      'marks':copy.deepcopy(p.get('marks',[])),'motion':p.get('motion'),
      'context_binding':copy.deepcopy(decision.get('context_binding',{})),
      'render_policies':{
        'generic_chart_fallback':'FORBIDDEN','default_form':None,
        'full_chart_chrome':False,'decorative_grid':False,'free_running_lines':False,
        'stray_marks':False,'number_may_float':False,
        'execute_selected_form_exactly':True,'renderer_may_change_form':False,
      }
    }

def main():
    import argparse,sys
    ap=argparse.ArgumentParser();ap.add_argument('input',nargs='?');ap.add_argument('--aspect',default='16:9')
    a=ap.parse_args(); d=json.load(open(a.input)) if a.input else json.load(sys.stdin)
    print(json.dumps(bind(d,a.aspect),indent=2))
if __name__=='__main__':main()
