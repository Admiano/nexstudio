# NexMind Whiteboard V3 System Package

This package is a curated, Whiteboard-only reconstruction of the production system lineage that produced `NEXMIND_WHITEBOARD_V3_CLUSTER_TRAVEL_TEXTFIX_V2_TEST.mp4`. It intentionally excludes unrelated NexStudio, Paperbook, Stickman, NexMarkets, website, and generic project files.

## What is here

- `01_base_execution/` — the preserved Whiteboard execution body: compiler, persistent board world, board camera, stroke/freehand engines, pen travel, semantic draw order, connectors, diagram layout, annotations, erase/redraw, single-stroke text, data/mechanism/media skins, sound choreography, contracts, registries, QA, tests, production audio, normalized local SVG assets, benchmark renderer, semantic-performance runtime and the production family adapter.
- `02_production_authorities/` — the Whiteboard-specific production assembly and Layers 0–6: story/scene composition, performer truth, environments, temporal state, cinematography/draw choreography, visual-foundation asset fitness, semantic visual realization and the production gateway.
- `03_semantic_and_decision/` — the later V3 semantic authority, variety director, comprehension scheduler, renderer-manifest adapter, gateway seam and semantic-group/draw-order binding.
- `04_composition_grammars/` — Semantic Illustration Composer V1.4 with governed data, metaphor, supporting-character and composition-hierarchy grammars plus the clean-baseline policies.
- `05_compatibility_patches/` — preserved cross-platform Whiteboard font compatibility patch.
- `06_provenance/` — lineage receipts, the preserved V3 Cluster Travel narration pacing plan, and the exact-artifact gap record.
- `07_reference_output/` — the exact saved output that matches the user-provided MP4 byte-for-byte, plus its QA still.
- `docs/` — architecture, runbook, package-scope and dependency notes.

## Core system flow

`narration/script -> semantic authority -> representation/variety decision -> comprehension timing -> semantic illustration composition -> Whiteboard production authorities -> compiler/runtime manifest -> persistent board render + camera travel + draw choreography -> audio/encode -> QA`

The central design rule is separation of authority: semantic understanding may describe the meaning of a beat, but it does not select camera/layout/style/assets; the downstream decision layer chooses a fitting representation from abstract structure, and the renderer executes the approved plan.

## Important provenance boundary

The exact attached MP4 is preserved and verified. The same V3 renderer lineage is recorded as `WHITEBOARD_ELITE_RUNTIME/vendor/pipeline_v3_narration_timed.py` with SHA-256 `c91f2bc50cb634c993ff307ef01bb4177d9478a290bf0b4da042adee260f9c34`. That one renderer file and the one-off TEXTFIX_V2 patch body were not persisted as standalone Library files, so this package does **not** invent replacement source and does not falsely claim byte-complete recovery of those two ephemeral files. See `06_provenance/EXACT_ARTIFACT_GAP.json`.

Everything else included here is preserved source or documentation from the actual Whiteboard lineage; proof media, duplicated experiments and unrelated product systems were deliberately excluded.
