# Admission / exclusion rules

- Keep authentic proven authorities; adapt rather than replacing them casually.
- Typography is a primary storytelling channel, not a caption layer.
- Use icons only when they add semantic value; never reduce a causal idea to unrelated noun icons.
- Prefer existing certified assets → modular recomposition → parametric drawing → controlled authored-art fallback.
- Preserve deterministic frame addressing and frozen-progress QA.
- 9:16, 1:1 and 16:9 are native sibling compositions, never crops.
- Paper Motion mechanics are available, but overt page-turn/crumple/stack-shuffle language is not the default editorial identity.
- Appllama contribution is limited to useful choreography/QA concepts; reject its card-stack/glass/carousel aesthetic as the product style.
- UI design language must come from real NexStudio product states and elite UI cinematography; never invent product claims.
- The rejected Atlas creative treatment architecture is historical evidence only and is intentionally not included.
