# NexMind Elite Text-Led Editorial Motion Bundle — 2026-09-15

This is a curated engineering/design-language bundle for the next NexMind/NexStudio text-led editorial motion system.

## Included

1. **Paper Motion core / physicality / typography rules**
   - typography and motion explorers
   - Paper Motion motion profiles and typography rules
   - icon, creator, agent, business, scene-rig and one-prompt explorers
   - material, depth, deformation, shadow, environment, camera, parallax, action and continuity runtimes

2. **Authentic editorial authorities**
   - Kinetic Typography Performance Authority V3
   - Kinetic Typography Grammar V2
   - Editorial Scene Composition Authority V2
   - Editorial Motion Ensemble Director V1
   - Semantic Illustration Accuracy Authority V1
   - Scene Intelligence V1 lineage
   - Text Element Spatial Authority V1
   - Editorial Background System V1
   - NexStudio Illustration Resolver V1
   - Visual Realization Authority V1
   - authentic Paper Motion donor subset: typography, motion, media containers, icons, composition
   - selected native-aspect, frame-QA and spatial adapters

3. **UI / Appllama / scene-timing design language**
   - NexStudio V6 improvement research
   - clean-room capability registry and routing proof
   - shot plan and integration proof handoff
   - the local `vector_motion_local_v1` capability records Appllama/animated-card-stack only as a provenance/reference source for motion-slot/depth-ordering ideas; the package does **not** ship Appllama's card-stack/glass/carousel aesthetic as product design language.
   - LeaferJS and Scene.js are represented as research/architecture inputs rather than copied as the product's creative authority.

4. **NexMind architecture and drawing fallback**
   - Story → Visual → Coverage → Art → Motion → deterministic runtime contract
   - Whiteboard Drawing Artist construction levels
   - capability selection / role promotion / architecture documents

5. **Reference grammar and QA**
   - reusable reference-derived editorial motion grammar
   - reference transition/microstrip analysis
   - capability matrix, source maps, checksums and baseline QA evidence

## Deliberately excluded

- The rejected Atlas creative branch and its fake evidence/process UI treatment system.
- Atlas proof videos and source-specific treatment routing that caused the corporate explainer/deck failure.
- External third-party repository source code copied wholesale.
- Fonts.
- User reference videos; only compact analysis artifacts are included.

## Creative rule

The package is an execution substrate, not a template system. Real content/material and typography lead; icons, diagrams, illustrations, screenshots and UI are support material. No donor library becomes the creative director. NexMind remains responsible for story, visual, art and motion intent; deterministic runtimes own geometry, timing and pixels.
