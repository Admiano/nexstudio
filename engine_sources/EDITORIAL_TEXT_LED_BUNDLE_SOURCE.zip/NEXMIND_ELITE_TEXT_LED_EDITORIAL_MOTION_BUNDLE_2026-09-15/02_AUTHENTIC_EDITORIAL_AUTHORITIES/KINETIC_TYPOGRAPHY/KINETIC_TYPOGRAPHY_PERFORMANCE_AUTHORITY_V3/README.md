# KINETIC_TYPOGRAPHY_PERFORMANCE_AUTHORITY_V3

V3 upgrades typography from timing-only choreography to editorial art direction.

## Core change

The system no longer assumes every beat is a centered or top-aligned headline with an object beneath it.
Each beat chooses a **typographic composition motif** from structural properties such as beat type, phrase count, emphasis, replacement behavior, object presence, aspect ratio, and previous motif.

## Non-negotiables

- Hero copy and support copy never move with equal authority.
- Strong semantic words may become spatial anchors.
- Support copy can use controlled italic/off-axis behavior.
- Replacement beats may reconfigure the composition, not merely swap opacity.
- Text may become the transition carrier into the next beat.
- Consecutive beats must not default to the same motif when a viable alternative exists.
- Text remains inside the Step 1 spatial territory except for an explicit text-as-transition event.
