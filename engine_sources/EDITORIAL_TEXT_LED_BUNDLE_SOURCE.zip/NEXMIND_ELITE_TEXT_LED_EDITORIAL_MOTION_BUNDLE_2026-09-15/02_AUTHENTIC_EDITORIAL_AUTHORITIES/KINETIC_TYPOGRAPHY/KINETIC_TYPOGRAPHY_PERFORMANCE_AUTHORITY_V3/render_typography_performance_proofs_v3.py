from __future__ import annotations
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,sys,json
ROOT=Path('/mnt/data/KINETIC_TYPOGRAPHY_PERFORMANCE_AUTHORITY_V3')
sys.path.insert(0,str(ROOT))
from kinetic_typography_performance_authority_v3 import *
import kinetic_typography_performance_authority_v3 as KTP

FONT_BLACK='/usr/share/fonts/opentype/inter/Inter-Black.otf'
FONT_SEMI='/usr/share/fonts/opentype/inter/Inter-SemiBold.otf'
FONT_ITALIC='/usr/share/fonts/opentype/inter/Inter-SemiBoldItalic.otf'

SAMPLE_UNITS=[
 TextUnit('MAKE THE IDEA',role='hero',emphasis=.58,semantic_role='setup'),
 TextUnit('WORTH WATCHING',role='hero',emphasis=1.0,semantic_role='punch'),
 TextUnit('support arrives after the hero settles',role='support',emphasis=.28,semantic_role='qualifier',italic=True),
 TextUnit('NOTE',role='label',emphasis=.72,semantic_role='evidence'),
]

def fit_font(text,box,scale,weight,italic=False):
    base=64*scale
    font_path=FONT_ITALIC if italic else (FONT_BLACK if weight=='Black' else FONT_SEMI)
    size=max(12,int(base))
    while size>=10:
        f=ImageFont.truetype(font_path,size)
        d=ImageDraw.Draw(Image.new('RGB',(10,10)))
        # multiline by explicit word balancing
        words=text.split(); lines=[]; cur=''
        maxw=max(10,int(box['w']*.92))
        for w in words:
            test=(cur+' '+w).strip(); bb=d.textbbox((0,0),test,font=f)
            if bb[2]-bb[0]<=maxw or not cur: cur=test
            else: lines.append(cur);cur=w
        if cur:lines.append(cur)
        s='\n'.join(lines[:4])
        bb=d.multiline_textbbox((0,0),s,font=f,spacing=max(2,int(size*.06)))
        if bb[2]-bb[0]<=box['w']*.96 and bb[3]-bb[1]<=box['h']*.94:
            return f,s,bb
        size-=2
    return ImageFont.truetype(font_path,10),text,(0,0,box['w'],box['h'])

def render_blocks(aspect,motif):
    W,H=ASPECTS[aspect]
    im=Image.new('RGB',(W,H),(246,246,246)); d=ImageDraw.Draw(im)
    spatial=KTP._zones(aspect,'TEXT_LED',True,.58)
    # subtle illustration territory only for ownership context
    iz=spatial.illustration_zone
    d.rounded_rectangle((iz['x'],iz['y'],iz['x']+iz['w'],iz['y']+iz['h']),radius=max(12,int(min(W,H)*.018)),fill=(238,238,238),outline=(224,224,224),width=2)
    # abstract object mark in illustration territory
    cx=iz['x']+iz['w']*.52;cy=iz['y']+iz['h']*.52;r=min(iz['w'],iz['h'])*.17
    d.ellipse((cx-r,cy-r,cx+r,cy+r),outline=(35,35,35),width=max(3,int(min(W,H)*.005)))
    d.line((cx+r*.72,cy+r*.72,cx+r*1.55,cy+r*1.55),fill=(35,35,35),width=max(3,int(min(W,H)*.005)))
    blocks,w=KTP._layout_blocks(motif,aspect,SAMPLE_UNITS,spatial.text_zone,spatial.illustration_zone,1)
    for b in blocks:
        if b.style=='replace_stage_a':
            continue
        box=b.bbox
        f,txt,bb=fit_font(b.text,box,b.font_scale,b.weight,b.italic)
        if b.style=='black_label':
            pad=max(5,int(min(W,H)*.008)); d.rounded_rectangle((box['x'],box['y'],box['x']+box['w'],box['y']+box['h']),radius=pad,fill=(15,15,15))
            fill=(255,255,255)
        else: fill=(15,15,15)
        tx=box['x']+5
        if b.alignment=='center': tx=box['x']+box['w']/2-(bb[2]-bb[0])/2
        elif b.alignment=='right': tx=box['x']+box['w']-(bb[2]-bb[0])-5
        ty=box['y']+box['h']/2-(bb[3]-bb[1])/2-bb[1]
        if b.italic and b.style in {'off_axis_support','support_italic','side_note'}:
            layer=Image.new('RGBA',(int(box['w']+40),int(box['h']+40)),(0,0,0,0)); ld=ImageDraw.Draw(layer)
            ld.multiline_text((15,15),txt,font=f,fill=fill,spacing=max(2,int(f.size*.06)))
            layer=layer.rotate(ASPECT_RULES[aspect]['support_tilt_deg'],expand=True,resample=Image.Resampling.BICUBIC)
            im.paste(layer,(int(tx),int(ty)),layer)
        else:
            d.multiline_text((tx,ty),txt,font=f,fill=fill,spacing=max(2,int(f.size*.06)),align=b.alignment)
    # motif label, outside safe creative frame at very bottom
    lab=ImageFont.truetype(FONT_SEMI,max(12,int(min(W,H)*.018)))
    d.text((12,H-30),motif,font=lab,fill=(120,120,120))
    return im

def contact(aspect):
    cards=[]
    for m in MOTIFS:
        im=render_blocks(aspect,m)
        thumb=im.copy(); thumb.thumbnail((300,420 if aspect=='9x16' else 260))
        card=Image.new('RGB',(320,thumb.height+12),(232,232,232));card.paste(thumb,((320-thumb.width)//2,6));cards.append(card)
    cols=2 if aspect=='9x16' else 5
    rows=math.ceil(len(cards)/cols); ch=max(c.height for c in cards)
    sheet=Image.new('RGB',(cols*320,rows*ch),(226,226,226))
    for i,c in enumerate(cards):sheet.paste(c,((i%cols)*320,(i//cols)*ch))
    out=ROOT/f'PERFORMANCE_MOTIF_CONTACT_{aspect}.jpg';sheet.save(out,quality=94);return str(out)

# Story variety contact uses settled typography only; checks consecutive motif diversity visually.
STORY=[
 {'beat_type':'HOOK','duration_ms':3000,'units':[{'text':'THE SIMPLEST WAY','role':'hero','emphasis':.58,'semantic_role':'setup'},{'text':'TO START','role':'hero','emphasis':1,'semantic_role':'punch'},{'text':'begin with the signal','role':'support','emphasis':.26,'semantic_role':'qualifier','italic':True}]},
 {'beat_type':'SETUP','duration_ms':3000,'units':[{'text':'Most people begin here','role':'hero','emphasis':.72,'semantic_role':'setup'},{'text':'with the thing they want to say','role':'support','emphasis':.28,'semantic_role':'qualifier','italic':True}]},
 {'beat_type':'CONTRAST','duration_ms':3200,'units':[{'text':'PUSH HARDER','role':'hero','emphasis':.75,'semantic_role':'contrast','replace_group':'x'},{'text':'MATCH BETTER','role':'hero','emphasis':1,'semantic_role':'punch','replace_group':'x'}]},
 {'beat_type':'EXPLANATION','duration_ms':3500,'units':[{'text':'READ THE SIGNAL','role':'hero','emphasis':.82,'semantic_role':'statement'},{'text':'what is already wanted','role':'support','emphasis':.32,'semantic_role':'evidence','italic':True},{'text':'what is already compared','role':'support','emphasis':.28,'semantic_role':'evidence','italic':True}]},
 {'beat_type':'PROOF','duration_ms':3200,'units':[{'text':'THE PATTERN IS VISIBLE','role':'hero','emphasis':.88,'semantic_role':'proof'},{'text':'PROOF','role':'label','emphasis':.82,'semantic_role':'evidence'},{'text':'only when the evidence is real','role':'support','emphasis':.3,'semantic_role':'qualifier'}]},
 {'beat_type':'EMPHASIS','duration_ms':3000,'units':[{'text':'THIS PART MATTERS','role':'hero','emphasis':1,'semantic_role':'punch'},{'text':'because it changes the decision','role':'support','emphasis':.30,'semantic_role':'qualifier','italic':True}]},
 {'beat_type':'REFRAME','duration_ms':3100,'units':[{'text':'STOP PUSHING','role':'hero','emphasis':.72,'semantic_role':'contrast','replace_group':'y'},{'text':'START MATCHING','role':'hero','emphasis':1,'semantic_role':'punch','replace_group':'y'}]},
 {'beat_type':'PAYOFF','duration_ms':3000,'units':[{'text':'MAKE IT FEEL','role':'hero','emphasis':.58,'semantic_role':'setup'},{'text':'INEVITABLE','role':'hero','emphasis':1,'semantic_role':'punch'}]},
]

def story_contact(aspect='1x1'):
    plans=compile_story(STORY,aspect)
    cards=[]
    for idx,(beat,p) in enumerate(zip(STORY,plans)):
        # render selected motif with actual unit strings
        units=[TextUnit(**u) for u in beat['units']]
        W,H=ASPECTS[aspect]; im=Image.new('RGB',(W,H),(247,247,247));d=ImageDraw.Draw(im)
        spatial=KTP._zones(aspect,'TEXT_LED',True,.55)
        iz=spatial.illustration_zone; d.rounded_rectangle((iz['x'],iz['y'],iz['x']+iz['w'],iz['y']+iz['h']),radius=18,fill=(238,238,238),outline=(225,225,225),width=2)
        blocks,_=KTP._layout_blocks(p['motif'],aspect,units,spatial.text_zone,spatial.illustration_zone,p['metrics']['promoted_unit_index'])
        for b in blocks:
            if b.style=='replace_stage_a':
                continue
            box=b.bbox;f,txt,bb=fit_font(b.text,box,b.font_scale,b.weight,b.italic)
            fill=(15,15,15)
            if b.style=='black_label':
                d.rounded_rectangle((box['x'],box['y'],box['x']+box['w'],box['y']+box['h']),radius=10,fill=(15,15,15));fill=(255,255,255)
            tx=box['x']+5 if b.alignment=='left' else (box['x']+box['w']/2-(bb[2]-bb[0])/2 if b.alignment=='center' else box['x']+box['w']-(bb[2]-bb[0])-5)
            ty=box['y']+box['h']/2-(bb[3]-bb[1])/2-bb[1]
            d.multiline_text((tx,ty),txt,font=f,fill=fill,spacing=max(2,int(f.size*.06)),align=b.alignment)
        foot=ImageFont.truetype(FONT_SEMI,18);d.text((14,H-28),f'{idx+1}. {beat["beat_type"]} / {p["motif"]}',font=foot,fill=(115,115,115))
        im.thumbnail((340,340));cards.append(im)
    cols=4; rows=2; sheet=Image.new('RGB',(cols*350,rows*350),(228,228,228))
    for i,c in enumerate(cards):sheet.paste(c,((i%cols)*350+5,(i//cols)*350+5))
    out=ROOT/f'STORY_MOTIF_VARIETY_CONTACT_{aspect}.jpg';sheet.save(out,quality=94)
    (ROOT/f'STORY_MOTIF_VARIETY_PLAN_{aspect}.json').write_text(json.dumps(plans,indent=2))
    return str(out)

if __name__=='__main__':
    paths={a:contact(a) for a in ['9x16','1x1','16x9']}
    paths['story']=story_contact('1x1')
    print(json.dumps(paths,indent=2))
