import sys,random,json
from pathlib import Path
ROOT=Path('/mnt/data/KINETIC_TYPOGRAPHY_PERFORMANCE_AUTHORITY_V3')
sys.path.insert(0,str(ROOT))
from kinetic_typography_performance_authority_v3 import compile_performance, compile_story, MOTIFS

SAMPLES={
'HOOK':[
 {'text':'THE EASIEST WAY','role':'hero','emphasis':.55,'semantic_role':'setup'},
 {'text':'TO SELL','role':'hero','emphasis':1.0,'semantic_role':'punch'},
 {'text':'is not to convince harder','role':'support','emphasis':.25,'semantic_role':'qualifier','italic':True},
],
'SETUP':[
 {'text':'Most people start here','role':'hero','emphasis':.65,'semantic_role':'setup'},
 {'text':'with a message they want to push','role':'support','emphasis':.25,'semantic_role':'qualifier','italic':True},
],
'CONTRAST':[
 {'text':'PUSH HARDER','role':'hero','emphasis':.76,'semantic_role':'contrast','replace_group':'r'},
 {'text':'MATCH BETTER','role':'hero','emphasis':1.0,'semantic_role':'punch','replace_group':'r'},
 {'text':'same goal, different strategy','role':'support','emphasis':.32,'semantic_role':'qualifier','italic':True},
],
'EXPLANATION':[
 {'text':'Start with the signal','role':'hero','emphasis':.78,'semantic_role':'statement'},
 {'text':'what people already search for','role':'support','emphasis':.42,'semantic_role':'evidence','italic':True},
 {'text':'what they already compare','role':'support','emphasis':.36,'semantic_role':'evidence','italic':True},
],
'PROOF':[
 {'text':'THE PATTERN IS VISIBLE','role':'hero','emphasis':.88,'semantic_role':'proof'},
 {'text':'PROOF','role':'label','emphasis':.84,'semantic_role':'evidence'},
 {'text':'use evidence only when it is real','role':'support','emphasis':.30,'semantic_role':'qualifier'},
],
'LIST':[
 {'text':'READS','role':'hero','emphasis':.72,'semantic_role':'statement'},
 {'text':'SEARCHES','role':'support','emphasis':.40,'semantic_role':'statement','italic':True},
 {'text':'EXECUTES','role':'support','emphasis':.38,'semantic_role':'statement','italic':True},
 {'text':'EDITS','role':'support','emphasis':.36,'semantic_role':'statement','italic':True},
],
'REFRAME':[
 {'text':'STOP PUSHING','role':'hero','emphasis':.72,'semantic_role':'contrast','replace_group':'r'},
 {'text':'START MATCHING','role':'hero','emphasis':1.0,'semantic_role':'punch','replace_group':'r'},
],
'EMPHASIS':[
 {'text':'THIS PART MATTERS','role':'hero','emphasis':1.0,'semantic_role':'punch'},
 {'text':'because it changes the decision','role':'support','emphasis':.36,'semantic_role':'qualifier','italic':True},
],
'PAYOFF':[
 {'text':'MAKE IT FEEL','role':'hero','emphasis':.60,'semantic_role':'setup'},
 {'text':'INEVITABLE','role':'hero','emphasis':1.0,'semantic_role':'punch'},
],
'CTA':[
 {'text':'TRY THE BETTER PATH','role':'hero','emphasis':.95,'semantic_role':'action'},
 {'text':'NEXT','role':'label','emphasis':.80,'semantic_role':'action'},
],
}

def main():
    aspects=['9x16','1x1','16x9']; rows=[]
    # deterministic beat mapping
    for a in aspects:
        prev=None
        for beat,units in SAMPLES.items():
            out=compile_performance(beat,a,3200,units,object_present=True,prev_motif=prev)
            rows.append({'aspect':a,'beat':beat,'motif':out['motif'],'pass':out['pass_gate'],'warnings':out['warnings']})
            assert out['motif'] in MOTIFS
            assert out['pass_gate'], (a,beat,out['warnings'])
            prev=out['motif']
    # story diversity
    beats=[]
    for beat,units in SAMPLES.items():
        beats.append({'beat_type':beat,'duration_ms':3300,'units':units,'shot_role':'TEXT_LED','object_present':True})
    for a in aspects:
        story=compile_story(beats,a)
        for x,y in zip(story,story[1:]):
            assert x['motif']!=y['motif'], (a,x['motif'])
            assert y['pass_gate'], (a,y['warnings'])
    # randomized structural torture
    random.seed(44); tort=[]; fails=[]
    beat_types=list(SAMPLES)
    phrases=['MAKE THE IDEA CLEAR','THE SIGNAL IS ALREADY THERE','A BETTER WAY','THE RESULT CHANGES','WHAT MATTERS NEXT','NO EXTRA PUSHING','READ THE EVIDENCE','BUILD FROM THE NEED']
    supports=['a quieter supporting phrase','the context arrives after the hero settles','a small qualifier stays subordinate','support copy should never compete']
    for n in range(240):
        beat=random.choice(beat_types); aspect=random.choice(aspects)
        units=[{'text':random.choice(phrases),'role':'hero','emphasis':random.uniform(.55,1),'semantic_role':random.choice(['statement','setup','contrast','punch','proof','action'])}]
        if random.random()<.55:
            units.append({'text':random.choice(phrases),'role':'hero','emphasis':random.uniform(.65,1),'semantic_role':'punch'})
        if random.random()<.72:
            units.append({'text':random.choice(supports),'role':'support','emphasis':random.uniform(.2,.5),'semantic_role':'qualifier','italic':random.random()<.8})
        if random.random()<.18:
            units.append({'text':'NOTE','role':'label','emphasis':.72,'semantic_role':'evidence'})
        out=compile_performance(beat,aspect,random.randint(2400,5200),units,object_present=random.random()<.8,prev_motif=random.choice(MOTIFS) if random.random()<.4 else None)
        ok=out['pass_gate']
        tort.append({'n':n,'beat':beat,'aspect':aspect,'motif':out['motif'],'pass':ok,'warnings':out['warnings']})
        if not ok: fails.append(tort[-1])
    report={'deterministic_count':len(rows),'deterministic_pass':sum(x['pass'] for x in rows),'torture_count':len(tort),'torture_pass':sum(x['pass'] for x in tort),'torture_failures':fails[:20],'deterministic':rows}
    (ROOT/'TEST_REPORT.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:report[k] for k in ['deterministic_count','deterministic_pass','torture_count','torture_pass']},indent=2))

if __name__=='__main__': main()
