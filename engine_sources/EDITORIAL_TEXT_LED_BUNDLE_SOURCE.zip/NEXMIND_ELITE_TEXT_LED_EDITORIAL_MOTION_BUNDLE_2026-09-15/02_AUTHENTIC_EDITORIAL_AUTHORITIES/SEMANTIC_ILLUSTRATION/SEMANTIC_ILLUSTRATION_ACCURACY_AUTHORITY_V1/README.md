# SEMANTIC_ILLUSTRATION_ACCURACY_AUTHORITY_V1

Strict semantic/physical accuracy gate for icons, objects, metaphors and compound scenes.
