from typing import Dict,Any
WEIGHTS={'semantic_specificity':.28,'physical_logical_correctness':.22,'relationship_readability':.18,'visual_family_fit':.14,'detail_relevance':.10,'ambiguity_penalty':-.08}
TH={'LITERAL_OBJECT':.82,'MECHANISM':.82,'COMPOUND_SCENE':.80,'METAPHOR':.78,'DATA_VISUAL':.94,'TYPOGRAPHIC_OBJECT':.82}

def score(e:Dict[str,Any]):
    s=sum(float(e.get(k,0))*w for k,w in WEIGHTS.items())
    return round(max(0,min(1,s)),3)

def evaluate(e:Dict[str,Any]):
    rep=e.get('representation','LITERAL_OBJECT'); s=score(e); failures=[]
    if e.get('looks_quantitative') and not e.get('data_contract_valid'): failures.append('DATA_VISUAL_WITHOUT_TRUTH_CONTRACT')
    if e.get('physical_logical_correctness',0)<.75: failures.append('PHYSICAL_LOGICAL_INACCURACY')
    if e.get('semantic_specificity',0)<.75: failures.append('SEMANTIC_TOO_GENERIC')
    if e.get('visual_family_fit',0)<.72: failures.append('ART_FAMILY_MISMATCH')
    if s < TH.get(rep,.82): failures.append('ACCURACY_SCORE_BELOW_THRESHOLD')
    escalation=None
    if failures:
        if e.get('asset_candidates_remaining',0)>0: escalation='search_stronger_asset'
        elif rep=='LITERAL_OBJECT': escalation='upgrade_object_to_compound_scene'
        elif rep in ('MECHANISM','METAPHOR'): escalation='change_representation'
        else: escalation='fail_closed'
    return {'score':s,'pass':not failures,'failures':failures,'escalation':escalation}
