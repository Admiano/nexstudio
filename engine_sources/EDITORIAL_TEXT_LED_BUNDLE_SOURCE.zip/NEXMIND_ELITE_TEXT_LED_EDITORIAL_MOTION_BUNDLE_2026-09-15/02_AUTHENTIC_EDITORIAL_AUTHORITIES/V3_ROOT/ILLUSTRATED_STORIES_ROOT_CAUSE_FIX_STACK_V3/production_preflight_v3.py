from pathlib import Path
import sys
ROOT=Path('/mnt/data')
for d in ['ASPECT_NATIVE_COMPOSITION_AUTHORITY_V1','SEMANTIC_SCENE_REALIZATION_AUTHORITY_V2','ROLE_PRIORITY_LAYOUT_SOLVER_V1','CHARACTER_EMPHASIS_USAGE_AUTHORITY_V1','GLOBAL_VISIBILITY_QA_V2','LEGIBILITY_QA_V1','SEMANTIC_ACCURACY_QA_V1','DIRECTIONAL_HARMONY_QA_V1']:
    sys.path.insert(0,str(ROOT/d))
from aspect_native_composition_authority_v1 import AspectNativeCompositionAuthorityV1,Request
from semantic_scene_realization_authority_v2 import SemanticSceneRealizationAuthorityV2,SemanticBeat
from role_priority_layout_solver_v1 import RolePriorityLayoutSolverV1
from character_emphasis_usage_authority_v1 import CharacterEmphasisUsageAuthorityV1,CharacterNeed
from global_visibility_qa_v2 import GlobalVisibilityQAV2,Item
from legibility_qa_v1 import LegibilityQAV1,TextSpec
from semantic_accuracy_qa_v1 import SemanticAccuracyQAV1,SemanticContract,Candidate
from directional_harmony_qa_v1 import DirectionalHarmonyQAV1,DirectionSpec

class IllustratedStoriesProductionPreflightV3:
    def __init__(self):
        self.aspect=AspectNativeCompositionAuthorityV1(); self.realize=SemanticSceneRealizationAuthorityV2(); self.roles=RolePriorityLayoutSolverV1(); self.characters=CharacterEmphasisUsageAuthorityV1(); self.visibility=GlobalVisibilityQAV2(); self.legibility=LegibilityQAV1(); self.accuracy=SemanticAccuracyQAV1(); self.direction=DirectionalHarmonyQAV1()
    def plan_beat(self,semantic:dict,text_load=.5,illustration_load=.5):
        r=self.realize.realize(SemanticBeat(**semantic))
        cneed=CharacterNeed(emotion=semantic.get('human_emotion',0),reaction=semantic.get('human_reaction',0),decision=semantic.get('human_decision',0),relatability=semantic.get('relatability',0),data_density=semantic.get('data_evidence',0),object_specificity=semantic.get('object_specificity',0),information_only=semantic.get('document_evidence',0))
        cd=self.characters.decide(cneed); use=bool(r['character_needed'] and cd['use_character'])
        role='CHARACTER_EMPHASIS' if use else ('TEXT_LED' if r['representation']=='TYPOGRAPHY_LED' else 'ILLUSTRATION_LED' if r['representation'] in {'OBJECT_STAGE','DATA_VISUAL'} else 'HYBRID')
        plans={}
        for a in ('16x9','1x1','9x16'):
            comp=self.aspect.solve(Request(a,role,text_load,illustration_load,use,semantic.get('relation_density',.4)))
            roles=self.roles.solve(comp,'character' if use else 'text',True,use)
            plans[a]={'composition':comp,'roles':roles}
        return {'realization':r,'character':cd,'plans':plans}
