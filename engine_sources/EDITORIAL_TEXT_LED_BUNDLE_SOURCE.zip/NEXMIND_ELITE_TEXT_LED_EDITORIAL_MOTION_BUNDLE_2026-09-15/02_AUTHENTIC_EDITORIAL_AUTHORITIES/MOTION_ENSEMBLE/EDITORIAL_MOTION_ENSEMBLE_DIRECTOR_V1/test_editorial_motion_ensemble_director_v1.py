import sys,random,json
from pathlib import Path
ROOT=Path('/mnt/data/EDITORIAL_MOTION_ENSEMBLE_DIRECTOR_V1');sys.path.insert(0,str(ROOT))
from editorial_motion_ensemble_director_v1 import *

def main():
  A=EditorialMotionEnsembleDirectorV1();roles=['TEXT_LED','ILLUSTRATION_LED','HYBRID','CHARACTER_EMPHASIS','PAYOFF'];rows=[]
  for role in roles:
    for char in [False,True] if role in {'HYBRID','PAYOFF','CHARACTER_EMPHASIS'} else [False]:
      req=EnsembleRequest(4200,role,character_present=char,illustration_motion_count=2,support_motion_count=2,transition_mode='TEXT_MASK' if role=='PAYOFF' else 'OBJECT_EXPAND')
      out=A.plan(req);rows.append({'role':role,'char':char,'pass':out.pass_gate,'warnings':out.warnings});assert out.pass_gate,(role,char,out.warnings)
  random.seed(123);tort=[];fails=[]
  for n in range(400):
    role=random.choice(roles);char=(role=='CHARACTER_EMPHASIS') or (role in {'HYBRID','PAYOFF'} and random.random()<.35)
    req=EnsembleRequest(duration_ms=random.randint(2600,6200),shot_role=role,hero_motion_count=random.randint(1,2),support_motion_count=random.randint(0,3),illustration_motion_count=random.randint(1,3),character_present=char,background_stage_motion=random.random()<.9,transition_mode=random.choice(['TEXT_MASK','OBJECT_EXPAND','CLEAN_REPLACE']),beat_energy=random.random(),audio_accent_times=[random.randint(200,2200) for _ in range(random.randint(0,3))])
    out=A.plan(req);ok=out.pass_gate;rec={'n':n,'role':role,'duration':req.duration_ms,'pass':ok,'warnings':out.warnings};tort.append(rec)
    if not ok:fails.append(rec)
  rep={'deterministic_count':len(rows),'deterministic_pass':sum(x['pass'] for x in rows),'torture_count':len(tort),'torture_pass':sum(x['pass'] for x in tort),'failures':fails[:30]}
  (ROOT/'TEST_REPORT.json').write_text(json.dumps(rep,indent=2));print(json.dumps({k:rep[k] for k in ['deterministic_count','deterministic_pass','torture_count','torture_pass']},indent=2))
if __name__=='__main__':main()
