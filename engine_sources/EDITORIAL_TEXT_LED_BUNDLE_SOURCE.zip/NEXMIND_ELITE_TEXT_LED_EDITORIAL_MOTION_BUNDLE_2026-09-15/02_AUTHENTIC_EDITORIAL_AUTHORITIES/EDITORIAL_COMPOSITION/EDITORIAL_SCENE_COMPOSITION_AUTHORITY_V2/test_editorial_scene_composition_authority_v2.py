import sys,random,json
from pathlib import Path
ROOT=Path('/mnt/data/EDITORIAL_SCENE_COMPOSITION_AUTHORITY_V2')
sys.path.insert(0,str(ROOT))
from editorial_scene_composition_authority_v2 import *

def main():
  aspects=['9x16','1x1','16x9']; roles=['TEXT_LED','ILLUSTRATION_LED','HYBRID','CHARACTER_EMPHASIS','PAYOFF']
  rows=[]
  presets=[
    dict(evidence_density=.8,object_count=1),dict(evidence_density=.8,object_count=3),dict(technical_density=.8),
    dict(character_present=True,depth_need=.7),dict(character_present=True,depth_need=.3),dict(object_formality=.8),
    dict(transition_energy=.9,crop_tolerance=.8),dict(text_motif='WORD_OBJECT_BRIDGE'),dict(depth_need=.8),dict(illustration_load=.2)
  ]
  for a in aspects:
    for pr in presets:
      role='CHARACTER_EMPHASIS' if pr.get('character_present') else ('TEXT_LED' if pr.get('illustration_load')==.2 else 'HYBRID')
      req=SceneCompositionRequest(aspect=a,shot_role=role,**pr)
      out=EditorialSceneCompositionAuthorityV2().plan(req)
      rows.append({'aspect':a,'comp':out.composition,'pass':out.status=='PASS','warnings':out.warnings})
      assert out.status=='PASS',(a,pr,out.warnings)
  random.seed(88); tort=[];fails=[]
  motifs=[None,'WORD_OBJECT_BRIDGE','SPLIT_SCALE_LOCKUP','PROMOTED_WORD_STACK','FULL_FRAME_HIT']
  for n in range(300):
    role=random.choice(roles); char=role=='CHARACTER_EMPHASIS'
    req=SceneCompositionRequest(
      aspect=random.choice(aspects),shot_role=role,text_load=random.random(),illustration_load=random.random(),character_present=char,
      evidence_density=random.random(),technical_density=random.random(),depth_need=random.random(),object_formality=random.random(),
      transition_energy=random.random(),object_count=random.randint(1,4),text_motif=random.choice(motifs),object_dominance=random.uniform(.35,.9),crop_tolerance=random.random())
    out=EditorialSceneCompositionAuthorityV2().plan(req);ok=out.status=='PASS'
    rec={'n':n,'aspect':req.aspect,'role':role,'comp':out.composition,'pass':ok,'warnings':out.warnings}
    tort.append(rec)
    if not ok:fails.append(rec)
  report={'deterministic_count':len(rows),'deterministic_pass':sum(x['pass'] for x in rows),'torture_count':len(tort),'torture_pass':sum(x['pass'] for x in tort),'failures':fails[:30]}
  (ROOT/'TEST_REPORT.json').write_text(json.dumps(report,indent=2))
  print(json.dumps({k:report[k] for k in ['deterministic_count','deterministic_pass','torture_count','torture_pass']},indent=2))

if __name__=='__main__':main()
