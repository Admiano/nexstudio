from __future__ import annotations
import json,re,math,hashlib,os
from pathlib import Path
from dataclasses import dataclass,asdict
from typing import List,Dict,Any,Optional,Tuple
from PIL import Image,ImageOps,ImageDraw,ImageFont
import numpy as np
import cairosvg

ROOT=Path('/mnt/data/ILLUSTRATED_STORIES_VISUAL_REALIZATION_V1')
SCENE_ROOT=Path('/mnt/data/ILLUSTRATED_STORIES_SCENE_INTELLIGENCE_V1')
PEEP_ROOT=Path('/mnt/data/NEXMIND_WHITEBOARD_AUTHORED_HUMAN_AUTHORITY_V1_1_CURATED')
AEV=ROOT/'vendor/aev1/NexStudio_Autonomous_Explainer_V1_Curated_200/assets'
IRA=ROOT/'vendor/ira/SVG/Outline/Objects'
HUMSCENE=ROOT/'vendor/humaaans/Flat Assets/Single Pieces/Scene'
OPEN_TEMPL=ROOT/'vendor/open_peeps/Flat Assets/Templates'
CACHE=ROOT/'cache_v2'; CACHE.mkdir(exist_ok=True)
BENCH=ROOT/'benchmark_v2'; BENCH.mkdir(exist_ok=True)
REPORTS=ROOT/'reports'; REPORTS.mkdir(exist_ok=True)
ASPECTS={'16x9':(1280,720),'1x1':(1080,1080),'9x16':(1080,1920)}
INK=(17,17,17); WHITE=(255,255,255)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

@dataclass
class Asset:
 id:str; path:str; provider:str; role:str; tags:List[str]; quality:float; detail:float; hero_ok:bool; family:str='editorial_bw'

def toks(s): return [x for x in re.split(r'[^a-z0-9]+',s.lower()) if x and not x.isdigit() and not x.startswith('aev')]

def complexity_svg(p:Path)->float:
 t=p.read_text(errors='ignore'); n=sum(t.count('<'+x) for x in ['path','rect','circle','ellipse','polygon','polyline','line'])
 return min(1.0,.12+.025*n+min(.5,len(t)/24000))

# General semantic tags for literal donor objects. These describe donor affordance, never story-topic layout.
IRA_SEM={
 'bag':['bag','carry','container','purchase'], 'bench':['bench','seat'], 'books':['books','learning','knowledge','skill'],
 'brush':['brush','creative','tool'], 'calendar':['calendar','time','schedule'], 'card':['card','option','choice','payment','information'],
 'chair':['chair','seat'], 'coffee cup':['cup','drink','coffee'], 'computer':['computer','interface','service','system','screen'],
 'fire':['fire','risk','urgent'], 'flower':['flower','plant'], 'inbox':['inbox','message','queue','request'], 'lamp':['lamp','light','idea'],
 'laptop':['laptop','interface','service','system','screen','work'], 'motorcycle':['motorcycle','transport'], 'phone':['phone','interface','service','message','screen'],
 'photos':['photos','image','evidence'], 'pig':['pig','savings','money'], 'pin':['pin','location','destination'], 'rocket':['rocket','launch','growth'],
 'sofa':['sofa','seat','home'], 'table':['table','surface','workspace'], 'tag':['tag','price','label'], 'tools':['tools','skill','work','action'], 'wallet':['wallet','money','payment']
}

REL_ASSET_HINTS={
 'looks_at':['computer','laptop','phone','dashboard','monitor'],
 'acts_on':['tools','computer','laptop','workspace','assembly'],
 'blocks':['bottleneck','blocked','obstacle','corridor','door'],
 'hands_to':['handoff','relay','baton','table'], 'receives_from':['handoff','relay','baton','table'],
 'resolves_to':['staircase','bridge','inspection','monitor','destination'],
 'moves_toward':['bridge','staircase','destination','pin'],
 'compares':['dashboard','monitor','evidence','photos','card'],
 'transforms_into':['assembly','pipeline','expansion'],
 'rests_on':['table','desk'], 'surrounds':['chamber','expansion'], 'inside':['workspace','console'], 'gestures_to':['card','computer','clipboard','paper']
}
KIND_HINTS={
 'evidence':['evidence','photos','dashboard','monitor','card','clipboard'], 'system':['computer','dashboard','console','monitor','server'],
 'state':['bridge','staircase','destination','inspection'], 'object':['card','computer','tools','phone','workspace'], 'group':['handoff','relay']
}

# Relation-first visual semantics. These are abstract relationship forms, not script-topic routes.
# A None value means this authority deliberately fails closed rather than substituting weak geometry.
RELATION_EXACT_PRIORITY={
 'hands_to':['IRA-card'], 'receives_from':['IRA-card'],
 'looks_at':['IRA-computer','IRA-laptop','IRA-phone'],
 'acts_on':['IRA-computer','IRA-tools','IRA-laptop'],
 'compares':['AEV1-193-deployment-monitor','IRA-photos','IRA-card'],
 'moves_toward':['IRA-pin','AEV1-151-bridge'],
 'blocks':[],
 'resolves_to':[],
}

class AssetRegistry:
 def __init__(self): self.assets=self._build()
 def _build(self):
  a=[]
  # Curated Open Peeps visible character authority only.
  allowed=json.load(open(PEEP_ROOT/'APPROVED_CHARACTER_ALLOWLIST_V1_1.json')).get('assets',[])
  for x in allowed:
   p=PEEP_ROOT/'assets'/(x['id']+'.svg')
   if p.exists():
    tags=toks(x['id'])+toks(x.get('pose_source_id',''))+toks(x.get('head_source_id',''))+toks(x.get('face_source_id',''))+['person','human','character']
    a.append(Asset(x['id'],str(p),'OPEN_PEEPS','character',sorted(set(tags)),.91,.88,True,'open_peeps_bw'))
  # IRA authored literal objects: stronger visible support than icon-like AEV props where semantically apt.
  for p in IRA.glob('*.svg'):
   stem=p.stem.lower(); tags=toks(stem)+IRA_SEM.get(stem,[]); c=complexity_svg(p)
   a.append(Asset('IRA-'+stem.replace(' ','-'),str(p),'IRA','prop',sorted(set(tags)),min(.93,.78+.12*c),c,True,'ira_outline_bw'))
  # AEV relationship/metaphor/mechanism/env bank.
  for role,pat,base in [('metaphor','objects/metaphors/*.svg',.72),('prop','objects/props/*.svg',.68),('environment','environments/*.svg',.79),('mechanism','mechanisms/*.svg',.80)]:
   for p in AEV.glob(pat):
    c=complexity_svg(p); tags=toks(p.stem); q=min(.93,base+.10*c)
    a.append(Asset(p.stem,str(p),'AEV1',role,sorted(set(tags)),q,c,q>=.76 or role in ('environment','mechanism'),'aev_editorial_bw'))
  # Humaaans scene donors only as environment support, never character authority.
  for p in HUMSCENE.glob('*.svg'):
   c=complexity_svg(p);a.append(Asset('HUMSCENE-'+p.stem.lower(),str(p),'HUMAAANS','environment',toks(p.stem)+['environment','scene'],.78,c,False,'humaaans_scene_bw'))
  json.dump([asdict(x) for x in a],open(ROOT/'ASSET_REGISTRY_V1_1.json','w'),indent=2)
  return a
 def find(self,entity,relations,representation,hero=False,exclude=None):
  exclude=exclude or set(); label=set(toks(entity.get('label',''))); kind=entity.get('kind','object'); eid=entity['id']
  hints=[]
  for r in relations:
   if r['source']==eid or r['target']==eid: hints+=REL_ASSET_HINTS.get(r['type'],[])
  hints+=KIND_HINTS.get(kind,[]); hset=set(sum((toks(x) for x in hints),[]))
  scores=[]
  for x in self.assets:
   if x.role=='character' or x.id in exclude or (hero and not x.hero_ok): continue
   tag=set(x.tags)
   lexical=len(label&tag)/max(1,len(label)) if label else 0
   functional=len(hset&tag)/max(1,min(5,len(hset))) if hset else 0
   rep=.0
   if representation=='data_in_context' and x.role in ('mechanism','environment'): rep=.13
   elif representation in ('object_led','state_transformation') and x.role in ('metaphor','mechanism'): rep=.14
   elif representation in ('character_led','character_object') and x.provider=='IRA': rep=.14
   elif representation=='relationship_led' and any(k in tag for k in ('handoff','relay','baton')): rep=.16
   provider=.08 if x.provider=='IRA' and (lexical>0 or functional>0) else 0
   score=.38*lexical+.31*functional+.17*x.quality+.08*x.detail+rep+provider
   scores.append((score,x))
  return sorted(scores,key=lambda z:z[0],reverse=True)

REG=AssetRegistry()

# Persistent protagonist is an identity-family, not arbitrary person swaps. We only group curated templates that share a head identity.
def build_identity_families():
 allow=json.load(open(PEEP_ROOT/'APPROVED_CHARACTER_ALLOWLIST_V1_1.json')).get('assets',[])
 fam={}
 for x in allow:
  head=x.get('head_source_id','head/unknown').split('/')[-1]
  fam.setdefault(head,[]).append({'id':x['id'],'pose':x.get('pose_source_id'),'face':x.get('face_source_id'),'posture':x.get('posture')})
 # require >=2 admitted visible states; identity stays fail-closed if requested state cannot be met.
 fam={k:v for k,v in fam.items() if len(v)>=2}
 # diversity score = count of distinct pose names + posture diversity
 out=[]
 for k,v in fam.items():
  ds=len(set(x['pose'] for x in v))+.5*len(set(x['posture'] for x in v))
  out.append({'identity_family':k,'states':v,'coverage_score':ds,'policy':'same_head_identity_only; never swap outside family mid-story'})
 out.sort(key=lambda q:q['coverage_score'],reverse=True)
 json.dump({'schema':'PersistentProtagonistIdentityFamiliesV1','families':out,'fail_closed':True},open(ROOT/'PERSISTENT_PROTAGONIST_FAMILIES_V1.json','w'),indent=2)
 return out
IDENTITY_FAMILIES=build_identity_families()

# Role requests prefer poses, but a story-level identity family is a hard constraint.
ROLE_POSE_WORDS={
 'PRESENT_POINT':['pointing','resting'], 'EXPLAIN_CONVERSE':['resting','robot','easing'], 'CONFIDENT_HOLD':['crossed','blazer'], 'ARRIVE_WALK':['walking'],
 'NEUTRAL_STANDING':['blazer','shirt','resting'], 'SEATED_THINK_LISTEN':['closed','one_leg','hands_back'], 'SEATED_CONVERSE_RELAX':['crossed_legs','mid'],
 'FLOOR_THINK':['one_leg','hands_back'], 'SEATED_PRESENT':['mid','crossed_legs']
}

def choose_story_identity(role='NEUTRAL_STANDING'):
 wants=ROLE_POSE_WORDS.get(role,[])
 ranked=[]
 for f in IDENTITY_FAMILIES:
  hit=sum(any(w in (s.get('pose') or '') for w in wants) for s in f['states'])
  ranked.append((hit,f['coverage_score'],f))
 return sorted(ranked,key=lambda x:(x[0],x[1]),reverse=True)[0][2] if ranked else None

def character_asset(identity,role):
 if not identity:return None
 wants=ROLE_POSE_WORDS.get(role,[])
 c=[]
 for s in identity['states']:
  score=sum(w in (s.get('pose') or '') for w in wants)
  c.append((score,s))
 c.sort(key=lambda x:x[0],reverse=True)
 aid=c[0][1]['id'] if c else None
 return next((a for a in REG.assets if a.id==aid),None)

# ---------- style normalization ----------
def normalize_svg(src:Path,asset_id)->Path:
 out=CACHE/(re.sub(r'[^A-Za-z0-9_.-]','_',asset_id)+'_bw.svg')
 if out.exists():return out
 txt=src.read_text(errors='ignore')
 # CSS and attribute colors -> pure ink/paper. Gray is quantized to one of two values.
 def hx(m):
  h=m.group(1)[:6]
  try:r,g,b=int(h[:2],16),int(h[2:4],16),int(h[4:],16);lum=.2126*r+.7152*g+.0722*b
  except:return m.group(0)
  return '#111111' if lum<132 else '#FFFFFF'
 txt=re.sub(r'#([0-9A-Fa-f]{6})',hx,txt)
 txt=re.sub(r'(?i)stroke-width="([0-9.]+)"',lambda m:'stroke-width="'+str(max(1.4,min(4.0,float(m.group(1)))))+'"',txt)
 out.write_text(txt);return out

def render_asset(asset,maxw,maxh,facing='neutral'):
 key=f'{asset.id}_{maxw}_{maxh}_{facing}.png'.replace(' ','_');out=CACHE/key
 if out.exists():return Image.open(out).convert('RGBA')
 if asset.path.lower().endswith('.png'):
  im=Image.open(asset.path).convert('RGBA')
 else:
  norm=normalize_svg(Path(asset.path),asset.id);raw=CACHE/(re.sub(r'[^A-Za-z0-9_.-]','_',asset.id)+'_raw.png')
  if not raw.exists():cairosvg.svg2png(url=str(norm),write_to=str(raw),output_width=1600)
  im=Image.open(raw).convert('RGBA')
 bb=im.getbbox();im=im.crop(bb) if bb else im
 if facing=='left' and asset.role=='character':im=ImageOps.mirror(im)
 s=min(maxw/max(1,im.width),maxh/max(1,im.height));im=im.resize((max(1,int(im.width*s)),max(1,int(im.height*s))),Image.LANCZOS);im.save(out);return im

# ---------- generic compound visual roles ----------
def relation_type(inp): return inp['relations'][0]['type'] if inp.get('relations') else None

def pick_relation_asset(inp,representation,exclude=None):
 # Relation-first resolver: select only from explicitly admitted visual forms for the abstract relation.
 r=inp['relations'][0] if inp.get('relations') else None
 if not r:return None
 exclude=exclude or set(); pri=RELATION_EXACT_PRIORITY.get(r['type'])
 if pri is not None:
  for aid in pri:
   if aid in exclude: continue
   a=next((x for x in REG.assets if x.id==aid),None)
   if a and a.quality>=.78 and a.detail>=.34: return (1.0,a)
  return None
 pseudo={'id':'__relation__','kind':'object','label':r['type'].replace('_',' ')}
 cand=REG.find(pseudo,inp['relations'],representation,hero=True,exclude=exclude)
 cand=[x for x in cand if x[1].quality>=.80 and x[1].detail>=.40]
 return cand[0] if cand else None

def pick_entity_asset(e,inp,representation,hero=False,exclude=None):
 cand=REG.find(e,inp['relations'],representation,hero=hero,exclude=exclude)
 return cand[0] if cand else None

# ---------- aspect-native composition realizer ----------
def placements(inp,result,aspect,identity):
 W,H=ASPECTS[aspect]; rep=result['aspects'][('16:9' if aspect=='16x9' else '9:16' if aspect=='9x16' else '1:1')]['plan']['representation']
 ents=inp['entities']; persons=[e for e in ents if e['kind']=='person']; others=[e for e in ents if e['kind']!='person']; rel=relation_type(inp)
 role=result.get('character_pose_role_request') or 'NEUTRAL_STANDING'
 out=[]
 # Relative placement rules are representation-level, never domain/topic-specific.
 if rep=='character_led' and persons:
  pa=character_asset(identity,role)
  pface='right'
  if aspect=='16x9': pbox=(.10,.18,.43,.86); obox=(.53,.24,.91,.78)
  elif aspect=='1x1': pbox=(.08,.20,.48,.88); obox=(.53,.26,.94,.75)
  else: pbox=(.04,.21,.56,.68); obox=(.53,.28,.96,.62)
  out.append(('entity',persons[0],pa,pbox,pface,'hero'))
  if others:
   pick=pick_entity_asset(others[0],inp,rep,hero=False); asset=pick[1] if pick else None
   out.append(('entity',others[0],asset,obox,'neutral','support'))
 elif rep=='relationship_led' and len(persons)>=2:
  # explicit human-human relation is the only multi-character exception.
  # Keep two admitted characters visually distinct; story protagonist identity remains the hero side.
  pa=character_asset(identity,role)
  alt=next((a for a in REG.assets if a.role=='character' and a.id!=pa.id),None)
  if aspect=='16x9': b1=(.08,.18,.40,.86);b2=(.60,.18,.92,.86)
  elif aspect=='1x1': b1=(.04,.22,.43,.85);b2=(.57,.22,.96,.85)
  else:b1=(.03,.25,.45,.68);b2=(.55,.25,.97,.68)
  out.append(('entity',persons[0],pa,b1,'right','hero'));out.append(('entity',persons[1],alt,b2,'left','support'))
  pr=pick_relation_asset(inp,rep,exclude={pa.id,alt.id});
  if pr:
   box=(.42,.40,.58,.58) if aspect!='9x16' else (.38,.46,.62,.57)
   out.append(('relation',{'id':'__relation__','kind':'object','label':rel},pr[1],box,'neutral','relation'))
 elif rep in ('object_led','state_transformation'):
  pr=pick_relation_asset(inp,rep)
  if pr:
   box=(.18,.14,.82,.87) if aspect!='9x16' else (.08,.24,.92,.75)
   out.append(('relation',{'id':'__relation__','kind':'object','label':rel},pr[1],box,'neutral','hero_relation'))
  else:
   for i,e in enumerate(others[:2]):
    pick=pick_entity_asset(e,inp,rep,hero=i==0);a=pick[1] if pick else None
    box=(.10+.43*i,.22,.47+.43*i,.80) if aspect!='9x16' else (.10,.12+.40*i,.90,.45+.40*i)
    out.append(('entity',e,a,box,'neutral','hero' if i==0 else 'support'))
 elif rep=='data_in_context':
  used=set()
  for i,e in enumerate(others[:2]):
   pick=pick_entity_asset(e,inp,rep,hero=(i==0),exclude=used);a=pick[1] if pick else None
   if a:used.add(a.id)
   box=(.08+.47*i,.20,.45+.47*i,.79) if aspect!='9x16' else (.10,.12+.43*i,.90,.45+.43*i)
   out.append(('entity',e,a,box,'neutral','hero' if i==0 else 'support'))
 else:
  # General fallback: honor entity importance with large authored assets; never icons/primitive placeholders.
  for i,e in enumerate(ents[:2]):
   if e['kind']=='person':a=character_asset(identity,role)
   else:
    pick=pick_entity_asset(e,inp,rep,hero=(i==0));a=pick[1] if pick else None
   box=(.08+.47*i,.19,.45+.47*i,.81) if aspect!='9x16' else (.10,.12+.43*i,.90,.45+.43*i)
   out.append(('entity',e,a,box,'right' if e['kind']=='person' else 'neutral','hero' if i==0 else 'support'))
 return rep,out

# ---------- contact / semantic geometry constraints ----------
def image_box(box,W,H):return tuple(int(v*m) for v,m in zip(box,(W,H,W,H)))
def paste_fit(canvas,asset,box,facing):
 W,H=canvas.size;x0,y0,x1,y1=image_box(box,W,H);bw=x1-x0;bh=y1-y0;im=render_asset(asset,int(bw*.95),int(bh*.95),facing);px=x0+(bw-im.width)//2;py=y0+(bh-im.height)//2;layer=Image.new('RGBA',(W,H),(0,0,0,0));layer.alpha_composite(im,(px,py));canvas.alpha_composite(layer);mask=np.array(layer.getchannel('A'))>20;return mask,(px,py,px+im.width,py+im.height)

def visual_qa(canvas,items,inp,rep):
 arr=np.array(canvas.convert('RGB'));fails=[];warn=[];scores={}
 # monochrome
 sat=arr.max(2)-arr.min(2);col=float(np.mean(sat>5));scores['colored_fraction']=col
 if col>.001:fails.append('COLOR_NOT_BLACK_WHITE')
 ink=arr.mean(2)<240; inkfrac=float(np.mean(ink));scores['ink_fraction']=inkfrac
 if inkfrac<.025:fails.append('SCENE_TOO_EMPTY')
 # occupancy per visible asset; prevent person+tiny-sticker failure
 for it in items:
  frac=float(np.mean(it['mask']));it['pixel_occupancy']=round(frac,4)
  if it['hierarchy']=='hero' and frac<.035:fails.append('HERO_TOO_SMALL:'+it['id'])
  if it['hierarchy'] in ('support','relation') and frac<.006:warn.append('SUPPORT_TOO_SMALL:'+it['id'])
 # duplicate visual assets only allowed for human-human multi-character when IDs differ
 ids=[it['asset_id'] for it in items if it['asset_id']]
 if len(ids)!=len(set(ids)):fails.append('DUPLICATED_DONOR_ASSET')
 # unintended overlaps
 allowed=set()
 for r in inp['relations']:
  if r['type'] in ('holds','acts_on','blocks','inside','surrounds','hands_to','receives_from','rests_on'):allowed.add(tuple(sorted((r['source'],r['target']))))
 ent_items=[x for x in items if x['semantic_kind']=='entity']
 for i in range(len(ent_items)):
  for j in range(i+1,len(ent_items)):
   a,b=ent_items[i],ent_items[j];inter=np.count_nonzero(a['mask']&b['mask']);small=max(1,min(np.count_nonzero(a['mask']),np.count_nonzero(b['mask'])));f=inter/small
   if f>.045 and tuple(sorted((a['id'],b['id']))) not in allowed:fails.append(f'UNOWNED_OVERLAP:{a["id"]}:{b["id"]}:{f:.3f}')
 # semantic relation direction readability proxy
 r=inp['relations'][0] if inp.get('relations') else None
 # Some relation-led/object-led representations require a relation-readable authored element.
 if r and rep in ('relationship_led','object_led','state_transformation'):
  relation_items=[x for x in items if x['semantic_kind']=='relation']
  if not relation_items:
   fails.append('NO_ELITE_RELATION_ART:'+r['type'])
 if r and r['type'] in ('looks_at','gestures_to','moves_toward'):
  src=next((x for x in items if x['id']==r['source']),None);tar=next((x for x in items if x['id']==r['target']),None)
  if src and tar and src['center'][0] < tar['center'][0] and src.get('facing')=='left':fails.append('FACING_AWAY_FROM_TARGET')
  if src and tar and src['center'][0] > tar['center'][0] and src.get('facing')=='right':fails.append('FACING_AWAY_FROM_TARGET')
 # asset-detail score -- elite visual gate is intentionally much stricter than structural pass
 details=[x['detail'] for x in items if x.get('detail') is not None];qualities=[x['quality'] for x in items if x.get('quality') is not None]
 scores['mean_asset_detail']=round(float(np.mean(details)) if details else 0,3);scores['mean_asset_quality']=round(float(np.mean(qualities)) if qualities else 0,3)
 # scene visual richness: multiple authored elements or one compound relation asset + adequate occupancy.
 scores['authored_element_count']=len(items)
 elite=(not fails and scores['mean_asset_quality']>=.79 and inkfrac>=.035 and all(x['pixel_occupancy']>=.006 for x in items if x['hierarchy']!='support' or x['semantic_kind']=='relation'))
 return fails,warn,scores,elite

def realize(casefile:Path,aspect,story_identity=None):
 d=json.load(open(casefile));inp=d['input'];result=d['result'];W,H=ASPECTS[aspect]
 role=result.get('character_pose_role_request') or 'NEUTRAL_STANDING'; identity=story_identity or choose_story_identity(role)
 rep,pls=placements(inp,result,aspect,identity)
 canvas=Image.new('RGBA',(W,H),WHITE+(255,));items=[];fails=[]
 for semkind,e,a,box,facing,hier in pls:
  if not a:
   fails.append('NO_ADMITTED_AUTHORED_ASSET:'+e['id']);continue
  mask,pix=paste_fit(canvas,a,box,facing);cx=(pix[0]+pix[2])/2;cy=(pix[1]+pix[3])/2
  items.append({'id':e['id'],'semantic_kind':semkind,'asset_id':a.id,'provider':a.provider,'role':a.role,'quality':a.quality,'detail':a.detail,'facing':facing,'hierarchy':hier,'mask':mask,'pixel_box':pix,'center':(cx,cy)})
 qf,qw,scores,elite=visual_qa(canvas,items,inp,rep);fails+=qf
 outdir=BENCH/aspect;outdir.mkdir(parents=True,exist_ok=True);out=outdir/(inp['beat_id']+'.png');canvas.convert('RGB').save(out)
 serial=[]
 for x in items:
  y={k:v for k,v in x.items() if k!='mask'};serial.append(y)
 return {'beat_id':inp['beat_id'],'aspect':aspect,'representation':rep,'structural_status':'PASS' if not fails else 'FAIL','elite_visual_status':'PASS' if elite and not fails else 'FAIL','failures':fails,'warnings':qw,'scores':scores,'story_identity_family':identity['identity_family'] if identity else None,'assignments':serial,'output':str(out)}

def contact(aspect,recs):
 cards=[]
 cellw=420;maximg=520 if aspect=='9x16' else 290
 for r in recs:
  im=Image.open(r['output']).convert('RGB');im.thumbnail((400,maximg));card=Image.new('RGB',(cellw,im.height+72),(247,247,247));card.paste(im,((cellw-im.width)//2,0));dr=ImageDraw.Draw(card);dr.text((8,im.height+7),r['beat_id'],font=ImageFont.truetype(FONT,16),fill='black');dr.text((8,im.height+31),f"struct:{r['structural_status']} elite:{r['elite_visual_status']} · {r['representation']}",font=ImageFont.truetype(FONT,11),fill='black');dr.text((8,im.height+50),f"identity:{r['story_identity_family'] or '-'}",font=ImageFont.truetype(FONT,10),fill='black');cards.append(card)
 cols=2 if aspect=='9x16' else 4;rows=math.ceil(len(cards)/cols);ch=max(c.height for c in cards);s=Image.new('RGB',(cols*cellw,rows*ch),(232,232,232));
 for i,c in enumerate(cards):s.paste(c,((i%cols)*cellw,(i//cols)*ch))
 out=BENCH/f'BLIND_8_VISUAL_REALIZATION_V1_{aspect}.jpg';s.save(out,quality=93);return str(out)

def run_benchmark():
 cases=sorted((SCENE_ROOT/'examples/blind_outputs').glob('*.json'));allr=[];contacts={}
 for a in ASPECTS:
  rr=[realize(c,a) for c in cases];allr+=rr;contacts[a]=contact(a,rr)
 report={'schema':'IllustratedStoriesVisualRealizationAuthorityV1BlindBenchmark','truth_boundary':'Structural pass and elite visual pass are separate. Elite pass is intentionally fail-closed and is not equivalent to final human pixel review.','render_count':len(allr),'structural_pass':sum(x['structural_status']=='PASS' for x in allr),'elite_visual_pass':sum(x['elite_visual_status']=='PASS' for x in allr),'contacts':contacts,'results':allr}
 json.dump(report,open(REPORTS/'VISUAL_REALIZATION_V1_BLIND_BENCHMARK.json','w'),indent=2);return report

if __name__=='__main__':
 r=run_benchmark();print(json.dumps({k:r[k] for k in ['render_count','structural_pass','elite_visual_pass','contacts']},indent=2))
