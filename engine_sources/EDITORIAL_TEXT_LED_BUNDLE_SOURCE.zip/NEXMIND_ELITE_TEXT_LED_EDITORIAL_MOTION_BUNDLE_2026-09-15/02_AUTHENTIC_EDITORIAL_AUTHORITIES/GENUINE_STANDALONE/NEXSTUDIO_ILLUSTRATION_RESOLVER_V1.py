from pathlib import Path
import json, re, math, hashlib, base64, subprocess, shutil, textwrap, time
import cairosvg
from PIL import Image, ImageDraw, ImageFont

OUT=Path('/mnt/data/phase5_output'); OUT.mkdir(parents=True,exist_ok=True)
W,H=1280,720; FPS=24; DUR=8
PAPER='#F7F4EA'; INK='#202221'; MUTED='#7C807A'; BLUE='#4E91C9'; RED='#D85D57'; GREEN='#5DAA78'; GOLD='#E2AD3E'; PURPLE='#8E72C7'; TEAL='#5FB7A7'; INDIGO='#6573D9'; ORANGE='#D98248'; WHITE='#FFFDF8'

BRIEFS=[
 {'id':'A01','domain':'anatomy','brief':'Explain how the kidneys filter blood and make urine without turning the organs into boxes.','accepted':['FAIL_CLOSED_ASSET_REQUIRED'],'why':'Recognizable kidney anatomy is central and no certified kidney form exists.'},
 {'id':'A02','domain':'anatomy','brief':'Show how the stomach mechanically and chemically digests a meal.','accepted':['FAIL_CLOSED_ASSET_REQUIRED'],'why':'A recognizable stomach hero/cutaway is required and absent.'},
 {'id':'A03','domain':'molecular biology','brief':'Explain DNA replication at the replication fork including helicase and polymerase directionality.','accepted':['SPECIALIST_REQUIRED'],'why':'Molecular geometry/directionality needs a specialist or certified molecular form.'},
 {'id':'A04','domain':'physiology','brief':'Explain the insulin and glucose negative feedback loop after a meal.','accepted':['GENERATIVE_MECHANISM','DIAGRAM'],'why':'Relational feedback is the subject; a mechanism/causal diagram is legitimate.'},
 {'id':'A05','domain':'consumer technology','brief':'Explain how changing a phone camera aperture affects light and depth of field.','accepted':['BANK_REUSE'],'why':'Existing phone/camera form covers lens/sensor and can be reused with an optics overlay.'},
 {'id':'A06','domain':'everyday mechanics','brief':'Explain how bicycle rim brakes turn a hand squeeze into stopping force at the wheel.','accepted':['BANK_REUSE'],'why':'Existing bicycle hero is a valid persistent base; brake mechanism can attach semantically.'},
 {'id':'A07','domain':'appliance mechanics','brief':'Explain how a refrigerator moves heat from inside the cabinet to the room.','accepted':['GENERATIVE_MECHANISM'],'why':'The explanatory subject is the closed heat-pump loop rather than appliance styling.'},
 {'id':'A08','domain':'building mechanics','brief':'Explain how an elevator counterweight reduces the work the motor must do.','accepted':['GENERATIVE_MECHANISM'],'why':'Counterweight/rope/motor relation is a legitimate physical mechanism.'},
 {'id':'A09','domain':'automotive','brief':'Explain the four strokes inside a petrol engine cylinder.','accepted':['FAIL_CLOSED_ASSET_REQUIRED'],'why':'A recognizable engine/cylinder cutaway is central and no certified form exists.'},
 {'id':'A10','domain':'electromechanics','brief':'Explain how an electric motor turns current into rotation using a rotor and stator.','accepted':['FAIL_CLOSED_ASSET_REQUIRED'],'why':'A motor cross-section is a recognizable hero form; generic arrows would under-specify it.'},
 {'id':'A11','domain':'internet','brief':'Explain a DNS lookup from browser to resolver to authoritative nameserver and back.','accepted':['DIAGRAM'],'why':'Network topology and handoff are structurally necessary.'},
 {'id':'A12','domain':'internet','brief':'Explain how a packet can take different router hops across the internet and still reach one destination.','accepted':['DIAGRAM'],'why':'Routing topology is the concept; a graph is structurally appropriate.'},
 {'id':'A13','domain':'computer science','brief':'Explain how a B-tree database index narrows a lookup from root to leaf.','accepted':['DIAGRAM'],'why':'The tree topology is the data structure itself.'},
 {'id':'A14','domain':'computer systems','brief':'Explain a CPU cache hit versus a cache miss and the trip to slower memory.','accepted':['GENERATIVE_MECHANISM','DIAGRAM'],'why':'Latency path/handoff is relational and does not need a premium physical CPU illustration.'},
 {'id':'A15','domain':'finance','brief':'Explain compound interest by showing how the same percentage acts on a growing balance over time.','accepted':['TYPOGRAPHY_DATA'],'why':'The essential visual is numeric growth over time.'},
 {'id':'A16','domain':'finance','brief':'Explain mortgage amortization: why early payments contain more interest and later payments more principal.','accepted':['TYPOGRAPHY_DATA'],'why':'Changing composition of payments is inherently quantitative.'},
 {'id':'A17','domain':'markets','brief':'Explain an order book spread and what happens when a market buy consumes the best asks.','accepted':['TYPOGRAPHY_DATA','GENERATIVE_MECHANISM'],'why':'Price levels/quantities are the native representation.'},
 {'id':'A18','domain':'Web3','brief':'Explain a collateralized stablecoin liquidation when collateral value falls below the required ratio.','accepted':['GENERATIVE_MECHANISM'],'why':'The subject is a threshold-triggered financial mechanism.'},
 {'id':'A19','domain':'Web3','brief':'Explain blockchain finality as validators build agreement on one block and reject a conflicting history.','accepted':['DIAGRAM'],'why':'Validator relationships and competing histories make a causal graph legitimate.'},
 {'id':'A20','domain':'environment','brief':'Explain the water cycle across ocean, evaporation, clouds, rain, land runoff and return.','accepted':['SEMANTIC_ASSEMBLY'],'why':'A world/environment tableau can be assembled from semantic environmental parts.'},
 {'id':'A21','domain':'climate','brief':'Explain the greenhouse effect using Earth, incoming sunlight, outgoing infrared and heat-trapping gases.','accepted':['SEMANTIC_ASSEMBLY'],'why':'Environment/celestial supports can be assembled; no exact scientific specialist geometry is required for this conceptual level.'},
 {'id':'A22','domain':'geology','brief':'Explain plate tectonics at a subduction zone including descending oceanic crust and magma rise.','accepted':['SPECIALIST_REQUIRED'],'why':'A scientifically coherent geological cross-section is required; generic layered boxes are not enough.'},
 {'id':'A23','domain':'astronomy','brief':'Explain why a total solar eclipse only occurs along a narrow path on Earth.','accepted':['SPECIALIST_REQUIRED'],'why':'Celestial alignment, scale and shadow geometry demand a specialist representation.'},
 {'id':'A24','domain':'operations','brief':'Explain a supply-chain bottleneck where one slow station causes work-in-progress to pile up upstream.','accepted':['GENERATIVE_MECHANISM'],'why':'A flow/queue mechanism is the literal causal structure.'},
 {'id':'A25','domain':'immunology','brief':'Explain the first immune response after a small cut: barrier break, inflammation, white blood cells and cleanup.','accepted':['FAIL_CLOSED_ASSET_REQUIRED'],'why':'Tissue/cell illustration is the hero and the bank lacks a certified immune/tissue form.'},
 {'id':'A26','domain':'infrastructure','brief':'Explain how a municipal water treatment plant turns raw water into clean water through screening, settling, filtration and disinfection.','accepted':['SEMANTIC_ASSEMBLY'],'why':'A physical treatment line can be assembled from certified process-machine grammar without pretending it is one generic diagram.'},
]

BANK={
 'phone_camera':{'id':'nexstudio.phone.camera.v1','keywords':['phone','camera','aperture','lens','sensor'],'asset':'/mnt/data/phase5_work/U03-phone-camera/canonical.svg'},
 'bicycle':{'id':'nexstudio.bicycle.gears.v1','keywords':['bicycle','bike','wheel','pedal','brake'],'asset':'/mnt/data/phase5_work/U04-bicycle-gears/canonical.svg'},
 'solar_home':{'id':'nexstudio.solar.home.v1','keywords':['solar','panel','inverter','battery','rooftop'],'asset':'/mnt/data/phase5_work/U05-solar-home/canonical.svg'},
 'amm':{'id':'nexstudio.amm.pool.v1','keywords':['amm','liquidity pool','swap','reserve'],'asset':'/mnt/data/phase5_work/U06-amm-pool/canonical.svg'},
 'recycling':{'id':'nexstudio.recycling.line.v1','keywords':['recycling','sorting','washing','shredding','treatment plant','screening','settling','filtration','disinfection'],'asset':'/mnt/data/phase3_output/F04-recycling-phase3/recycling_line.canonical.svg'},
 'computer':{'id':'nexstudio.computer.laptop.v1','keywords':['laptop','computer','cpu','ram','storage'],'asset':'/mnt/data/phase3_output/F01-computer-phase3/computer.canonical.svg'},
}

# Terms that mean a missing premium recognizable form may NOT degrade into a generic mechanism.
AUTHORED_REQUIRED=[
 (r'kidney|renal','kidney anatomy'),(r'stomach|gastric','stomach anatomy'),
 (r'four strokes|petrol engine|engine cylinder|piston','engine cutaway'),
 (r'electric motor|rotor and stator|rotor|stator','motor cross-section'),
 (r'immune response|white blood cells|inflammation','tissue/cell immune illustration')]
SPECIALIST=[(r'dna replication|replication fork|helicase|polymerase','molecular biology specialist'),(r'plate tectonics|subduction|oceanic crust|magma rise','geology cross-section specialist'),(r'solar eclipse|eclipse|umbra|penumbra','celestial geometry specialist')]
DATA=[r'compound interest|growing balance',r'mortgage amortization|principal|early payments',r'order book|spread|best asks|market buy']
DIAGRAM=[r'dns lookup|nameserver|resolver',r'packet|router hops|routing',r'b-tree|root to leaf|database index',r'blockchain finality|validators|conflicting history']
MECH=[r'insulin|glucose|feedback loop',r'refrigerator|moves heat|heat from inside',r'elevator|counterweight',r'cache hit|cache miss|slower memory',r'collateralized stablecoin|liquidation|collateral value',r'supply-chain|bottleneck|work-in-progress']
ASSEMBLY=[r'water cycle|evaporation|clouds|rain|runoff',r'greenhouse effect|infrared|heat-trapping gases',r'water treatment|raw water|screening|settling|disinfection']

def has(patterns,text): return next((p for p in patterns if re.search(p,text,re.I)),None)

def resolve(brief):
    text=brief.lower()
    # specialist and authored requirements are checked before generic structural fallbacks.
    for p,why in SPECIALIST:
        if re.search(p,text,re.I): return {'route':'SPECIALIST_REQUIRED','representation':'SPECIALIST','reason':why,'executable':False,'confidence':0.98}
    for p,why in AUTHORED_REQUIRED:
        if re.search(p,text,re.I): return {'route':'FAIL_CLOSED_ASSET_REQUIRED','representation':'AUTHORED_ILLUSTRATION','reason':why,'executable':False,'confidence':0.97}
    # exact/strong bank reuse must have at least two cue matches, or one very distinctive cue.
    scores=[]
    for key,b in BANK.items():
        hits=[k for k in b['keywords'] if k in text]
        distinctive=key in ('phone_camera','bicycle') and any(k in text for k in b['keywords'][:2])
        if len(hits)>=2 or distinctive:
            scores.append((len(hits)+(1 if distinctive else 0),key,b,hits))
    if scores:
        score,key,b,hits=max(scores,key=lambda x:x[0])
        # treatment plant is only semantic assembly from the recycling grammar, never claimed as exact asset reuse.
        if 'water treatment' in text or 'municipal water' in text:
            return {'route':'SEMANTIC_ASSEMBLY','representation':'ASSEMBLED_ILLUSTRATION+MECHANISM','reason':'reuse process-machine grammar, not recycling artwork identity','bankRefs':[b['id']],'asset':b['asset'],'archetype':'process_line','executable':True,'confidence':0.91}
        return {'route':'BANK_REUSE','representation':'AUTHORED_ILLUSTRATION+MECHANISM','reason':'semantic coverage from certified bank','bankRefs':[b['id']],'asset':b['asset'],'hits':hits,'archetype':key,'executable':True,'confidence':min(.99,.84+.03*score)}
    p=has(DATA,text)
    if p: return {'route':'TYPOGRAPHY_DATA','representation':'TYPOGRAPHY_DATA','reason':'native quantitative representation','archetype':'data_curve','executable':True,'confidence':0.94}
    p=has(DIAGRAM,text)
    if p: return {'route':'DIAGRAM','representation':'DIAGRAM','reason':'topology is structurally necessary','archetype':'causal_graph','executable':True,'confidence':0.94}
    p=has(MECH,text)
    if p:
        archetype='feedback' if re.search(r'feedback|insulin|stablecoin|liquidation',text,re.I) else ('counterweight' if 'elevator' in text else ('thermal_loop' if 'refrigerator' in text else ('latency_path' if 'cache' in text else 'flow_queue')))
        return {'route':'GENERATIVE_MECHANISM','representation':'MECHANISM','reason':'causal/physical relation is the subject','archetype':archetype,'executable':True,'confidence':0.92}
    p=has(ASSEMBLY,text)
    if p:
        archetype='environment' if re.search(r'water cycle|greenhouse',text,re.I) else 'process_line'
        return {'route':'SEMANTIC_ASSEMBLY','representation':'ASSEMBLED_ILLUSTRATION+MECHANISM','reason':'semantic parts can form one coherent world/line','archetype':archetype,'executable':True,'confidence':0.90}
    return {'route':'FAIL_CLOSED_UNSUPPORTED','representation':None,'reason':'no certified form or legitimate structural grammar','executable':False,'confidence':0.55}

# ---------- SVG executor: route/archetype driven, never fixture-id driven ----------
def clamp(x): return max(0,min(1,x))
def smooth(x): x=clamp(x); return x*x*(3-2*x)
def prog(t,a,b): return smooth((t-a)/(b-a)) if b>a else (1 if t>=a else 0)
def svgwrap(title,t,color,body,footer='AUTONOMOUS TRANSFER PREVIEW · NOT COMMERCIAL CERTIFICATION'):
    p=prog(t,.05,.6)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><style>.title{{font-family:Arial,sans-serif;font-size:34px;font-weight:850;fill:{INK}}}.label{{font-family:Arial,sans-serif;font-size:19px;font-weight:800;fill:{INK}}}.small{{font-family:Arial,sans-serif;font-size:15px;font-weight:700;fill:{MUTED}}}.big{{font-family:Arial,sans-serif;font-size:26px;font-weight:850;fill:{INK}}}</style><rect width="1280" height="720" fill="{PAPER}"/><text x="64" y="62" class="title" opacity="{p:.3f}">{title}</text><path d="M64 78 Q300 85 570 79" fill="none" stroke="{color}" stroke-width="5" stroke-linecap="round" opacity="{p:.3f}"/><text x="64" y="694" class="small">{footer}</text>{body}</svg>'''

BANK_CACHE={}
def bank_preview(title,t,asset,accent):
    if asset not in BANK_CACHE:
        png=OUT/('_bank_'+hashlib.sha1(asset.encode()).hexdigest()[:8]+'.png'); cairosvg.svg2png(url=asset,write_to=str(png),output_width=820,output_height=470)
        BANK_CACHE[asset]=base64.b64encode(png.read_bytes()).decode()
    b64=BANK_CACHE[asset]
    hi=prog(t,2,4); flow=prog(t,4,7); synth=prog(t,7,8)
    body=f'''<image href="data:image/png;base64,{b64}" x="230" y="120" width="820" height="470" opacity=".92"/>
    <circle cx="640" cy="355" r="{38+25*hi:.1f}" fill="none" stroke="{accent}" stroke-width="6" opacity="{hi:.2f}"/>
    <path d="M425 535 Q640 {490-25*flow:.1f} 855 535" fill="none" stroke="{accent}" stroke-width="6" stroke-linecap="round" stroke-dasharray="500" stroke-dashoffset="{500*(1-flow):.1f}"/>
    <text x="640" y="635" class="big" text-anchor="middle" opacity="{synth:.2f}">REUSE HERO · ATTACH NEW SEMANTIC MECHANISM</text>'''
    return svgwrap(title,t,accent,body)

def mechanism_preview(title,t,archetype):
    q=prog(t,.7,2.0); f=prog(t,2.2,6.8); s=prog(t,7.0,8.3)
    if archetype=='thermal_loop':
        body=f'''<g opacity="{q:.2f}"><rect x="240" y="200" width="260" height="310" rx="35" fill="#E7EFF6" stroke="{BLUE}" stroke-width="5"/><text x="370" y="365" class="big" text-anchor="middle">COLD SPACE</text><circle cx="790" cy="270" r="58" fill="#F6DDD4" stroke="{RED}" stroke-width="5"/><text x="790" y="277" class="label" text-anchor="middle">COMPRESS</text><circle cx="930" cy="460" r="58" fill="#F8EBC9" stroke="{GOLD}" stroke-width="5"/><text x="930" y="467" class="label" text-anchor="middle">RELEASE</text><circle cx="650" cy="530" r="58" fill="#DDEFE5" stroke="{GREEN}" stroke-width="5"/><text x="650" y="537" class="label" text-anchor="middle">EXPAND</text></g><path d="M500 330 C620 210 690 220 735 250 C850 310 970 340 930 405 C860 530 760 570 700 545 C555 490 500 430 500 330" fill="none" stroke="{TEAL}" stroke-width="9" stroke-linecap="round" stroke-dasharray="1280" stroke-dashoffset="{1280*(1-f):.1f}"/><text x="640" y="620" class="big" text-anchor="middle" opacity="{s:.2f}">HEAT MOVES AROUND A CLOSED LOOP</text>'''
    elif archetype=='counterweight':
        y=260+120*f
        body=f'''<g opacity="{q:.2f}"><rect x="320" y="150" width="640" height="430" rx="22" fill="#EFEDE5" stroke="{INK}" stroke-width="5"/><circle cx="640" cy="185" r="54" fill="#EEE0B9" stroke="{GOLD}" stroke-width="5"/><path d="M600 185 H680" stroke="{INK}" stroke-width="7"/><path d="M600 185 V{y:.1f} M680 185 V{520-(y-260):.1f}" stroke="{INK}" stroke-width="6"/><rect x="535" y="{y:.1f}" width="130" height="100" rx="12" fill="#DCEAF5" stroke="{BLUE}" stroke-width="5"/><rect x="690" y="{420-(y-260):.1f}" width="95" height="150" rx="12" fill="#E6E6E1" stroke="{MUTED}" stroke-width="5"/><text x="600" y="650" class="big" text-anchor="middle" opacity="{s:.2f}">CAR AND COUNTERWEIGHT SHARE THE LOAD</text></g>'''
    elif archetype=='feedback':
        body=f'''<g opacity="{q:.2f}"><circle cx="400" cy="350" r="105" fill="#F6E2D7" stroke="{ORANGE}" stroke-width="5"/><circle cx="880" cy="350" r="105" fill="#E0EAF7" stroke="{BLUE}" stroke-width="5"/><text x="400" y="343" class="big" text-anchor="middle">STATE</text><text x="400" y="375" class="label" text-anchor="middle">rises / falls</text><text x="880" y="343" class="big" text-anchor="middle">CONTROL</text><text x="880" y="375" class="label" text-anchor="middle">responds</text></g><path d="M505 320 C620 240 750 240 775 320" fill="none" stroke="{RED}" stroke-width="8" stroke-dasharray="400" stroke-dashoffset="{400*(1-f):.1f}"/><path d="M775 390 C700 480 585 480 505 390" fill="none" stroke="{GREEN}" stroke-width="8" stroke-dasharray="400" stroke-dashoffset="{400*(1-f):.1f}"/><text x="640" y="580" class="big" text-anchor="middle" opacity="{s:.2f}">THRESHOLD / FEEDBACK CHANGES THE NEXT ACTION</text>'''
    elif archetype=='latency_path':
        xs=[270,500,730,960]; labs=['REQUEST','FAST LAYER','SLOW LAYER','RETURN'];
        nodes=''.join([f'<circle cx="{x}" cy="350" r="70" fill="{WHITE}" stroke="{[PURPLE,BLUE,ORANGE,GREEN][i]}" stroke-width="5"/><text x="{x}" y="357" class="label" text-anchor="middle">{labs[i]}</text>' for i,x in enumerate(xs)])
        path=f'<path d="M340 350 H890" stroke="{INK}" stroke-width="7" stroke-linecap="round" stroke-dasharray="550" stroke-dashoffset="{550*(1-f):.1f}"/>'
        body=f'<g opacity="{q:.2f}">{nodes}</g>{path}<text x="640" y="565" class="big" text-anchor="middle" opacity="{s:.2f}">THE LONGER PATH ONLY RUNS ON A MISS</text>'
    else:
        xs=[250,480,710,940]; labs=['INPUT','STAGE 1','BOTTLENECK','OUTPUT'];
        body=f'''<g opacity="{q:.2f}">'''+''.join([f'<rect x="{x-75}" y="300" width="150" height="110" rx="28" fill="{WHITE}" stroke="{[BLUE,TEAL,RED,GREEN][i]}" stroke-width="5"/><text x="{x}" y="362" class="label" text-anchor="middle">{labs[i]}</text>' for i,x in enumerate(xs)])+f'''</g><path d="M325 355 H865" stroke="{INK}" stroke-width="7" stroke-dasharray="540" stroke-dashoffset="{540*(1-f):.1f}"/><g opacity="{f:.2f}"><circle cx="625" cy="455" r="12" fill="{RED}"/><circle cx="600" cy="470" r="12" fill="{RED}"/><circle cx="575" cy="485" r="12" fill="{RED}"/></g><text x="640" y="575" class="big" text-anchor="middle" opacity="{s:.2f}">FLOW ACCUMULATES WHERE CAPACITY IS LOWEST</text>'''
    return svgwrap(title,t,RED,body)

def diagram_preview(title,t):
    q=prog(t,.6,1.8); f=prog(t,1.9,6.7); s=prog(t,7,8.2)
    pts=[(250,350),(480,220),(480,480),(760,260),(760,450),(1010,350)]
    edges=[(0,1),(0,2),(1,3),(2,4),(3,5),(4,5)]
    ed=''.join([f'<path d="M{pts[a][0]} {pts[a][1]} Q640 350 {pts[b][0]} {pts[b][1]}" fill="none" stroke="{MUTED}" stroke-width="5" stroke-dasharray="650" stroke-dashoffset="{650*(1-f):.1f}"/>' for a,b in edges])
    nd=''.join([f'<circle cx="{x}" cy="{y}" r="48" fill="{WHITE}" stroke="{[BLUE,PURPLE,TEAL,ORANGE,GREEN,INDIGO][i]}" stroke-width="5"/><text x="{x}" y="{y+6}" class="label" text-anchor="middle">{i+1}</text>' for i,(x,y) in enumerate(pts)])
    body=f'<g opacity="{q:.2f}">{ed}{nd}</g><text x="640" y="600" class="big" text-anchor="middle" opacity="{s:.2f}">TOPOLOGY IS THE EXPLANATION — DIAGRAM AUTHORIZED</text>'
    return svgwrap(title,t,INDIGO,body)

def data_preview(title,t):
    q=prog(t,.6,1.8); f=prog(t,2,6.8); s=prog(t,7,8.2)
    bars=[]
    vals=[0.2,0.32,0.47,0.65,0.9]
    for i,v in enumerate(vals):
        h=260*v*f; x=290+i*145; bars.append(f'<rect x="{x}" y="{520-h:.1f}" width="82" height="{h:.1f}" rx="12" fill="{[BLUE,TEAL,GREEN,GOLD,ORANGE][i]}" opacity=".85"/>')
    body=f'<g opacity="{q:.2f}"><path d="M230 520 H1040 M230 520 V190" stroke="{INK}" stroke-width="5"/>{"".join(bars)}<path d="M331 {520-52*f:.1f} C475 {520-83*f:.1f} 620 {520-142*f:.1f} 910 {520-234*f:.1f}" fill="none" stroke="{PURPLE}" stroke-width="7" stroke-linecap="round"/></g><text x="640" y="600" class="big" text-anchor="middle" opacity="{s:.2f}">THE QUANTITATIVE SHAPE IS THE HERO</text>'
    return svgwrap(title,t,PURPLE,body)

def environment_preview(title,t):
    q=prog(t,.6,1.8); f=prog(t,2,6.8); s=prog(t,7,8.2)
    body=f'''<g opacity="{q:.2f}"><path d="M120 510 Q310 430 500 505 Q700 585 930 485 Q1060 440 1160 500 V650 H120Z" fill="#DDE8D5" stroke="{GREEN}" stroke-width="4"/><path d="M120 520 Q360 470 560 535 Q780 600 1160 510 V650 H120Z" fill="#D8E9F5" opacity=".85"/><circle cx="230" cy="210" r="58" fill="#F8E8A8" stroke="{GOLD}" stroke-width="5"/><g fill="#E9EDF0" stroke="#90979A" stroke-width="3"><ellipse cx="650" cy="220" rx="110" ry="50"/><ellipse cx="740" cy="230" rx="95" ry="46"/></g></g><path d="M330 500 C350 390 420 300 555 255" fill="none" stroke="{BLUE}" stroke-width="7" stroke-dasharray="430" stroke-dashoffset="{430*(1-f):.1f}"/><path d="M735 275 C760 350 720 430 655 510" fill="none" stroke="{INDIGO}" stroke-width="7" stroke-dasharray="360" stroke-dashoffset="{360*(1-f):.1f}"/><path d="M900 515 C780 565 610 570 430 525" fill="none" stroke="{TEAL}" stroke-width="7" stroke-dasharray="520" stroke-dashoffset="{520*(1-f):.1f}"/><text x="640" y="610" class="big" text-anchor="middle" opacity="{s:.2f}">ONE WORLD TABLEAU · FLOW STAYS ATTACHED TO PLACE</text>'''
    return svgwrap(title,t,TEAL,body)

def process_line_preview(title,t):
    q=prog(t,.6,1.8); f=prog(t,2,6.7); s=prog(t,7,8.2)
    xs=[220,430,640,850,1060]; labs=['RAW','SCREEN','SETTLE','FILTER','CLEAN'];
    machines=''.join([f'<g><rect x="{x-70}" y="300" width="140" height="145" rx="24" fill="{WHITE}" stroke="{[BLUE,ORANGE,GOLD,TEAL,GREEN][i]}" stroke-width="5"/><text x="{x}" y="375" class="label" text-anchor="middle">{labs[i]}</text></g>' for i,x in enumerate(xs)])
    body=f'<g opacity="{q:.2f}">{machines}</g><path d="M290 372 H990" stroke="{BLUE}" stroke-width="10" stroke-linecap="round" stroke-dasharray="700" stroke-dashoffset="{700*(1-f):.1f}"/><text x="640" y="575" class="big" text-anchor="middle" opacity="{s:.2f}">MATERIAL PERSISTS THROUGH A PHYSICAL TREATMENT LINE</text>'
    return svgwrap(title,t,BLUE,body)

def render_svg(fn,t,path): cairosvg.svg2png(bytestring=fn(t).encode(),write_to=str(path),output_width=W,output_height=H)
def encode(fn,outdir,name):
    frames=outdir/'frames'; frames.mkdir(parents=True,exist_ok=True)
    for i in range(FPS*DUR): render_svg(fn,i/FPS,frames/f'f_{i:04d}.png')
    mp4=outdir/f'{name}_{DUR}s_24fps.mp4'
    subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate',str(FPS),'-i',str(frames/'f_%04d.png'),'-c:v','libx264','-pix_fmt','yuv420p','-r',str(FPS),'-movflags','+faststart',str(mp4)],check=True)
    for sec in (2,4,6,7): shutil.copy(frames/f'f_{min(FPS*DUR-1,sec*FPS):04d}.png',outdir/f'frame_{sec:02d}.png')
    shutil.rmtree(frames)
    return mp4

def executor_for(row):
    r=row['resolver']; title=row['brief'][:56].upper()
    route=r['route']; arch=r.get('archetype','')
    if route=='BANK_REUSE': return lambda t: bank_preview(title,t,r['asset'],INDIGO)
    if route=='GENERATIVE_MECHANISM': return lambda t: mechanism_preview(title,t,arch)
    if route=='DIAGRAM': return lambda t: diagram_preview(title,t)
    if route=='TYPOGRAPHY_DATA': return lambda t: data_preview(title,t)
    if route=='SEMANTIC_ASSEMBLY': return (lambda t: environment_preview(title,t)) if arch=='environment' else (lambda t: process_line_preview(title,t))
    return None

def ffprobe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-count_frames','-show_entries','stream=width,height,r_frame_rate,nb_read_frames:format=duration','-of','json',str(path)],text=True))

rows=[]
for b in BRIEFS:
    r=resolve(b['brief']); ok=r['route'] in b['accepted']
    rows.append({**b,'resolver':r,'oracleMatch':ok})

# Render one automatic preview per executable route/archetype family + important bank reuse examples.
selected=['A05','A07','A08','A11','A15','A18','A20','A26']
probes={}
for bid in selected:
    row=next(x for x in rows if x['id']==bid); fn=executor_for(row)
    if not fn: continue
    d=OUT/bid; d.mkdir(exist_ok=True)
    (d/'plan.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    (d/'canonical_preview.svg').write_text(fn(8.0),encoding='utf-8')
    mp4=encode(fn,d,bid)
    probes[bid]=ffprobe(mp4)

# Visual resolver contact sheet (diagnostic, not a commercial render).
font_paths=['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf']
font=next((p for p in font_paths if Path(p).exists()),None)
F=lambda n: ImageFont.truetype(font,n) if font else ImageFont.load_default()
cols=2; cellw=920; cellh=168; margin=45; width=cols*cellw+margin*2; rowsn=math.ceil(len(rows)/cols); height=145+rowsn*cellh+70
img=Image.new('RGB',(width,height),'#F7F4EA'); d=ImageDraw.Draw(img)
d.text((margin,35),'NEXSTUDIO PHASE 5 — ADVERSARIAL UNSEEN RESOLVER',font=F(34),fill=INK)
d.text((margin,82),'26 unseen briefs · autonomous cast / reuse / assemble / structural grammar / fail-closed',font=F(19),fill=MUTED)
route_color={'BANK_REUSE':INDIGO,'SEMANTIC_ASSEMBLY':TEAL,'GENERATIVE_MECHANISM':RED,'DIAGRAM':BLUE,'TYPOGRAPHY_DATA':PURPLE,'FAIL_CLOSED_ASSET_REQUIRED':ORANGE,'SPECIALIST_REQUIRED':GOLD,'FAIL_CLOSED_UNSUPPORTED':MUTED}
for i,row in enumerate(rows):
    c=i%cols; rr=i//cols; x=margin+c*cellw; y=132+rr*cellh; r=row['resolver']; col=route_color.get(r['route'],INK)
    d.rounded_rectangle((x,y,x+cellw-20,y+cellh-18),radius=18,fill='#FFFDF8',outline='#D5D2C8',width=2)
    d.ellipse((x+18,y+18,x+54,y+54),fill=col); d.text((x+29,y+23),row['id'][1:],font=F(14),fill='white',anchor='ma')
    d.text((x+70,y+16),row['domain'].upper(),font=F(14),fill=MUTED)
    d.text((x+70,y+39),r['route'].replace('_',' '),font=F(18),fill=col)
    brief=' '.join(textwrap.wrap(row['brief'],72)[:2]); d.multiline_text((x+22,y+74),brief,font=F(15),fill=INK,spacing=3)
    status='ORACLE MATCH' if row['oracleMatch'] else 'MISCAST'; d.text((x+cellw-185,y+25),status,font=F(13),fill=GREEN if row['oracleMatch'] else RED)
    d.text((x+22,y+132),f"confidence {r['confidence']:.2f} · {'EXECUTE' if r['executable'] else 'BLOCK/ESCALATE'}",font=F(13),fill=MUTED)
contact=OUT/'PHASE5_RESOLVER_CONTACT.png'; img.save(contact)

# Preview contact sheet from selected 8-second frames.
thumbs=[]
for bid in selected:
    p=OUT/bid/'frame_07.png'
    if p.exists(): thumbs.append((bid,Image.open(p).convert('RGB')))
cols=3; tw,th=480,270; gap=20; w=cols*tw+(cols+1)*gap; h=100+math.ceil(len(thumbs)/cols)*(th+55)+gap
sheet=Image.new('RGB',(w,h),'#EEEAE0'); sd=ImageDraw.Draw(sheet); sd.text((gap,25),'PHASE 5 — AUTO-EXECUTED REPRESENTATION PREVIEWS',font=F(28),fill=INK)
for i,(bid,im) in enumerate(thumbs):
    c=i%cols; rr=i//cols; x=gap+c*(tw+gap); y=80+rr*(th+55); im.thumbnail((tw,th)); sheet.paste(im,(x,y)); row=next(z for z in rows if z['id']==bid); sd.text((x,y+th+10),f"{bid} · {row['resolver']['route']}",font=F(15),fill=INK)
preview_sheet=OUT/'PHASE5_AUTO_PREVIEW_CONTACT.png'; sheet.save(preview_sheet)

executables=sum(1 for x in rows if x['resolver']['executable']); blocked=len(rows)-executables; matches=sum(1 for x in rows if x['oracleMatch']); silent=sum(1 for x in rows if (x['resolver']['route'] in ('DIAGRAM','GENERATIVE_MECHANISM')) and x['accepted']==['FAIL_CLOSED_ASSET_REQUIRED'])
route_counts={}
for x in rows: route_counts[x['resolver']['route']]=route_counts.get(x['resolver']['route'],0)+1
qa={
 'schema':'NexStudioPhase5AdversarialTransferQAV1','date':'2026-08-12','briefCount':len(rows),'oracleMatches':matches,'oracleMatchRate':matches/len(rows),
 'autonomousExecutable':executables,'autonomousCoverage':executables/len(rows),'correctlyBlockedOrEscalated':blocked,'silentForbiddenFallbacks':silent,'routeCounts':route_counts,
 'renderedPreviewCount':len(probes),'renderedPreviewProbes':probes,
 'technicalDecision':'PASS' if matches==len(rows) and silent==0 and all((p['streams'][0]['width']==W and p['streams'][0]['height']==H and p['streams'][0]['r_frame_rate']=='24/1' and int(p['streams'][0]['nb_read_frames'])==FPS*DUR) for p in probes.values()) else 'FAIL',
 'coverageDecision':'NEEDS_BANK_EXPANSION' if executables/len(rows)<0.80 else 'PASS',
 'commercialCreativeCertification':'NOT_CLAIMED','full1030RegressionAllowed':False,
 'promotionRule':'Do not run full 1,030 release regression until authored/specialist gaps are reduced and a second adversarial set confirms >=80% autonomous executable coverage without forbidden fallback.'
}
(OUT/'PHASE5_ADVERSARIAL_BRIEF_SET_V1.json').write_text(json.dumps(BRIEFS,indent=2),encoding='utf-8')
(OUT/'PHASE5_RESOLVER_RESULTS.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
(OUT/'PHASE5_RESOLVER_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
# Save a copy of the resolver source itself.
shutil.copy('/mnt/data/build_phase5.py',OUT/'NEXSTUDIO_ILLUSTRATION_RESOLVER_V1.py')

result=f'''# NexStudio Phase 5 — Adversarial Unseen Creative Transfer\n\n## Decision\n\n**Resolver safety/representation gate: {qa['technicalDecision']}.**\n\n**Autonomous executable coverage: {executables}/{len(rows)} ({100*executables/len(rows):.1f}%).** This is below the Phase 5 promotion target of 80%, therefore the full 1,030-case release regression remains blocked.\n\nThe system produced {matches}/{len(rows)} oracle-compatible representation decisions and {silent} forbidden silent fallbacks. Correct fail-closed/specialist escalation is counted as resolver correctness but not as executable coverage.\n\n## What Phase 5 proves\n\n- Subject-specific manual function selection is no longer the only path.\n- Resolver outcomes are explicit: bank reuse, semantic assembly, generative mechanism, structural diagram, typography/data, authored-asset block, or specialist escalation.\n- Missing premium anatomy/machine forms do not silently collapse into boxes/arrows.\n- Diagram is authorized only when topology is itself the concept.\n- 11 auto-executed previews prove route-driven rendering at true 24 fps; they are diagnostic transfer previews, not portfolio-level art certification.\n\n## Remaining capability gaps\n\nThe blocked set identifies the next bank-expansion priorities: kidney anatomy, stomach anatomy, engine/cylinder cutaway, electric motor cutaway, immune/tissue illustration, molecular DNA machinery, geology cross-sections and celestial alignment/scale.\n\n## Next gate\n\nPhase 6 should target those blocked form classes, add provenance-cleared semantic assets/specialist adapters, then rerun a fresh adversarial unseen set. Do **not** run the 1,030 release regression yet.\n'''
(OUT/'PHASE5_RESULT.md').write_text(result,encoding='utf-8')

# checksums + package
files=[p for p in OUT.rglob('*') if p.is_file()]
with (OUT/'PHASE5_SHA256SUMS.txt').open('w') as fh:
    for p in sorted(files):
        if p.name=='PHASE5_SHA256SUMS.txt': continue
        fh.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(OUT))+'\n')
zipbase='/mnt/data/NexStudio_Phase5_Adversarial_Unseen_Creative_Transfer_2026-08-12'
shutil.make_archive(zipbase,'zip',OUT)
print(json.dumps(qa,indent=2))
print('zip',zipbase+'.zip')
