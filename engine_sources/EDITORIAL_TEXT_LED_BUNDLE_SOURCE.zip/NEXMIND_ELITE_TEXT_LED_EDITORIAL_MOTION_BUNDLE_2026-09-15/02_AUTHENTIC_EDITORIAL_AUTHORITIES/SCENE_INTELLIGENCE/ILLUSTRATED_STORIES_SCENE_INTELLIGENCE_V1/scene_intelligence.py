from __future__ import annotations
from typing import Dict,Any,List
from semantic_beat_model import normalize_beat
from representation_planner import score_representations
from restaging_loop import replan_until_pass
from character_performance_adapter import select_pose_role
from motion_direction_adapter import bind_motion_intent
from scene_intelligence_schema import serial

VERSION='1.0.0-alpha.1'

def compile_beat(raw: Dict[str,Any], aspects=('16:9','1:1','9:16')) -> Dict[str,Any]:
    beat=normalize_beat(raw)
    decision=score_representations(beat)
    pose_role=select_pose_role(beat)
    outputs={}
    overall='PASS'
    for aspect in aspects:
        plan,qa,history=replan_until_pass(beat,decision,aspect)
        if plan is None:
            outputs[aspect]={'status':'FAIL','qa':serial(qa),'restaging_history':history}
            overall='FAIL'; continue
        plan.motion_intent=bind_motion_intent(beat,plan)
        outputs[aspect]={'status':'PASS','plan':serial(plan),'qa':serial(qa),'restaging_history':history}
    return {
      'schema':'IllustratedStoriesSceneIntelligenceResultV1', 'version':VERSION,
      'status':overall, 'beat_id':beat.beat_id, 'representation_decision':serial(decision),
      'character_pose_role_request':pose_role, 'aspects':outputs,
      'routing_guard':{'content_labels_used_for_representation':False,'content_labels_used_for_layout':False}
    }
