from __future__ import annotations
import math
from scene_intelligence_schema import *
from scene_relationship_authority import hierarchy, build_constraints, allowed_overlap_pairs

ASPECT_DIMS={'16:9':(1.0,0.5625),'1:1':(1.0,1.0),'9:16':(0.5625,1.0)}

# Topology-aware general composition. Labels/content never enter this module.
def _centrality(beat):
    d={e.id:0. for e in beat.entities}
    for r in beat.relations:
        d[r.source]+=r.strength; d[r.target]+=r.strength
    return d

def _direction_target(beat, eid):
    priority=['looks_at','gestures_to','acts_on','moves_toward','hands_to','receives','blocks']
    for typ in priority:
        for r in beat.relations:
            if r.type==typ and r.source==eid: return r.target,typ
    return None,None

def _node_size(tier, kind, aspect):
    if tier=='hero': base=.38
    elif tier=='support': base=.24
    else: base=.13
    if kind=='person':
        return (base*.70, base*1.30)
    if kind=='text': return (base*1.6, base*.55)
    return (base,base*.82)

def _primary_axis(aspect):
    return 'vertical' if aspect=='9:16' else 'horizontal'

def plan_composition(beat: SemanticBeat, rep: str, aspect: str, variant: int=0) -> ScenePlan:
    if aspect not in ASPECT_DIMS: raise ValueError('UNSUPPORTED_ASPECT')
    W,H=ASPECT_DIMS[aspect]
    h=hierarchy(beat); cent=_centrality(beat)
    ranked=sorted(beat.entities,key=lambda e:(-(.65*e.importance+.35*min(1,cent[e.id]/3)),e.id))
    axis=_primary_axis(aspect)
    nodes=[]
    # general normalized anchors; variant changes direction/bias only, never topic behavior.
    if axis=='horizontal':
        anchors=[(.30,.54),(.70,.50),(.50,.26),(.52,.79),(.84,.72),(.16,.76)]
    else:
        anchors=[(.50,.36),(.50,.68),(.28,.54),(.72,.54),(.50,.82),(.50,.16)]
    # invert spatial bias for restaging variant
    if variant%2==1: anchors=[(1-x,y) for x,y in anchors]
    for i,e in enumerate(ranked):
        x,y=anchors[i%len(anchors)]
        nw,nh=_node_size(h[e.id],e.kind,aspect)
        # dominant hero gets more scale but bounded for mobile safety
        if h[e.id]=='hero':
            nw=min(nw, W*.68); nh=min(nh,H*.64)
        x=max(nw/2+.03,min(W-nw/2-.03,x*W))
        y=max(nh/2+.03,min(H-nh/2-.03,y*H))
        facing='neutral'
        if e.kind=='person':
            target,typ=_direction_target(beat,e.id)
            if target:
                # face toward target's expected position after all nodes placed; provisional from index.
                tidx=next((j for j,q in enumerate(ranked) if q.id==target),None)
                if tidx is not None:
                    tx=anchors[tidx%len(anchors)][0]*W
                    facing='right' if tx>x else 'left' if tx<x else 'front'
            else: facing='front'
        nodes.append(SceneNode('node:'+e.id,e.kind,e.id,h[e.id],x,y,nw,nh,facing,'midground',[]))
    # relational restaging: pull semantic pairs into interpretable proximity, while preserving silhouettes.
    by={n.semantic_id:n for n in nodes}
    for r in beat.relations:
        a,b=by[r.source],by[r.target]
        if r.type in {'holds','acts_on','hands_to','receives','looks_at','gestures_to'}:
            # put target in attention/contact zone, not across person's torso
            # Attention/action targets belong in a clear interaction zone, not across the actor silhouette.
            sep=(a.w+b.w)/2 + .045*W
            if axis=='horizontal':
                sign=1 if a.x<=W*.5 else -1
                target_x=a.x+sign*sep
                # if edge-clamped on chosen side, try the opposite side rather than accepting an overlap
                lo=b.w/2+.03; hi=W-b.w/2-.03
                if not (lo<=target_x<=hi):
                    sign*=-1; target_x=a.x+sign*sep
                b.x=max(lo,min(hi,target_x))
                b.y=max(b.h/2+.03,min(H-b.h/2-.03,a.y-.03*H))
                if a.kind=='person': a.facing='right' if sign>0 else 'left'
            else:
                # Portrait prioritizes vertical staging because side-by-side hero/object pairs
                # cannot maintain silhouette clearance at mobile width.
                vsep=(a.h+b.h)/2 + .045*H
                target_y=a.y+vsep
                lo_y=b.h/2+.03; hi_y=H-b.h/2-.03
                if not (lo_y<=target_y<=hi_y):
                    target_y=a.y-vsep
                b.y=max(lo_y,min(hi_y,target_y))
                # small diagonal offset preserves a readable gaze/gesture lane without collision
                xoff=.09*W
                target_x=a.x+xoff if a.x<=W*.5 else a.x-xoff
                lo_x=b.w/2+.03; hi_x=W-b.w/2-.03
                b.x=max(lo_x,min(hi_x,target_x))
                if a.kind=='person':
                    dx=b.x-a.x
                    a.facing='front' if abs(dx)<.08*W else ('right' if dx>0 else 'left')
        elif r.type in {'transforms','resolves_to','reveals','produces','connects_to','causes','before','after'}:
            # Sequential/causal relations require two distinct readable states, never accidental overlap.
            if axis=='horizontal':
                sep=(a.w+b.w)/2 + .07*W
                sign=1 if a.x<=W*.5 else -1
                lo=b.w/2+.03; hi=W-b.w/2-.03
                tx=a.x+sign*sep
                if not (lo<=tx<=hi): tx=a.x-sign*sep
                b.x=max(lo,min(hi,tx))
                b.y=max(b.h/2+.03,min(H-b.h/2-.03,a.y))
            else:
                sep=(a.h+b.h)/2 + .06*H
                lo=b.h/2+.03; hi=H-b.h/2-.03
                ty=a.y+sep
                if not (lo<=ty<=hi): ty=a.y-sep
                b.y=max(lo,min(hi,ty))
                b.x=max(b.w/2+.03,min(W-b.w/2-.03,a.x))
        elif r.type=='blocks':
            # blocker belongs between source and its intended travel region; no arbitrary overlap.
            if axis=='horizontal': b.x=(a.x+W*.80)/2
            else: b.y=(a.y+H*.78)/2
        elif r.type=='rests_on':
            a.x=b.x; a.y=b.y-b.h/2-a.h/2+.01
            a.layer='foreground'; b.layer='midground'
        elif r.type=='inside':
            a.x=b.x; a.y=b.y; a.w=min(a.w,b.w*.55); a.h=min(a.h,b.h*.55)
    # record allowed overlaps from semantic ownership
    pairs=allowed_overlap_pairs(beat)
    for a,b in pairs:
        by[a].allow_overlap_with.append(b); by[b].allow_overlap_with.append(a)
    # normalized metrics only
    area=sum(n.w*n.h for n in nodes)/(W*H)
    payload={e.id:e.label for e in beat.entities}
    motion={'camera':'stable','dominant_motion_count':1,'screen_direction':'preserve','black_white_only':True}
    return ScenePlan(beat.beat_id,aspect,rep,nodes,build_constraints(beat),motion,
                     {'occupied_area':round(area,4),'node_count':len(nodes),'aspect_w':W,'aspect_h':H},payload)
