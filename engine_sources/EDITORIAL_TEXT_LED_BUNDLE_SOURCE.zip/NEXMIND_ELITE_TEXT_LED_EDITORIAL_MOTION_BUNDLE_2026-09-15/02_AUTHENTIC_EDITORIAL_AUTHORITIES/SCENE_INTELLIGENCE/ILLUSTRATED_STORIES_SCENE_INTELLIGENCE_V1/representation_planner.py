from __future__ import annotations
from scene_intelligence_schema import *

FORMS=['character_led','character_object','object_led','relationship_led','spatial_contrast','state_transformation','typography_led','data_in_context']

# IMPORTANT: all scoring is abstract-feature/topology based. No labels or topic nouns.
def score_representations(beat: SemanticBeat) -> RepresentationDecision:
    f=beat.features
    persons=sum(1 for e in beat.entities if e.kind=='person')
    objects=sum(1 for e in beat.entities if e.kind in {'object','system','place','state','result'})
    relation_types={r.type for r in beat.relations}
    has_contact=bool(relation_types & {'holds','acts_on','blocks','supports','rests_on','surrounds','moves_toward','moves_away_from'})
    has_social=bool(relation_types & {'hands_to','receives','compares'}) or persons>=2
    has_transform=bool(relation_types & {'transforms','resolves_to','produces','reveals'})
    scores={k:0.0 for k in FORMS}
    scores['character_led'] = .44*f.human_agency + .26*f.emotional_intensity + .18*(persons>0) + .12*(1-f.evidence_density)
    scores['character_object'] = .30*f.human_agency + .25*f.physicality + .20*f.relational_density + .15*has_contact + .10*(persons>0 and objects>0)
    scores['object_led'] = .28*(1-f.human_agency) + .28*f.physicality + .20*(objects>0) + .14*f.causality + .10*(1-f.sociality)
    scores['relationship_led'] = .30*f.relational_density + .27*f.sociality + .20*has_social + .13*f.human_agency + .10*(len(beat.relations)>1)
    scores['spatial_contrast'] = .42*f.spatiality + .22*f.comparison_degree + .18*('blocks' in relation_types) + .18*('moves_toward' in relation_types or 'moves_away_from' in relation_types)
    scores['state_transformation'] = .48*f.transformation_degree + .22*has_transform + .16*f.causality + .14*f.emotional_intensity
    scores['typography_led'] = .34*(1-f.physicality) + .22*(1-f.relational_density) + .20*(1-f.human_agency) + .14*(1-f.evidence_density) + .10*(len(beat.entities)<=2)
    scores['data_in_context'] = .72*f.evidence_density + .12*f.causality + .08*f.comparison_degree + .12*(any(e.kind=='evidence' for e in beat.entities))
    # explicit override is allowed only as upstream creative intent, not topic routing.
    if beat.explicit_representation in scores:
        scores[beat.explicit_representation]+=1.0
    ranking=sorted(scores,key=lambda k:(-scores[k],FORMS.index(k)))
    sel=ranking[0]
    reasons=[]
    if f.human_agency>.65: reasons.append('high_human_agency')
    if f.emotional_intensity>.6: reasons.append('high_emotional_intensity')
    if f.relational_density>.55: reasons.append('dense_relations')
    if f.transformation_degree>.55 or has_transform: reasons.append('state_change_structure')
    if f.spatiality>.55: reasons.append('strong_spatial_structure')
    if f.evidence_density>.55: reasons.append('evidence_heavy')
    if has_contact: reasons.append('physical_relation_present')
    return RepresentationDecision(sel,{k:round(float(v),5) for k,v in scores.items()},reasons,ranking[1:])
