from __future__ import annotations
import math
from scene_intelligence_schema import *
from scene_relationship_authority import allowed_overlap_pairs


def _rect(n): return (n.x-n.w/2,n.y-n.h/2,n.x+n.w/2,n.y+n.h/2)
def _inter(a,b):
    ax0,ay0,ax1,ay1=_rect(a); bx0,by0,bx1,by1=_rect(b)
    iw=max(0,min(ax1,bx1)-max(ax0,bx0)); ih=max(0,min(ay1,by1)-max(ay0,by0))
    return iw*ih

def evaluate(beat: SemanticBeat, plan: ScenePlan) -> QAResult:
    fails=[]; warns=[]; nodes=plan.nodes; by={n.semantic_id:n for n in nodes}
    allowed=allowed_overlap_pairs(beat)
    W=plan.composition_metrics['aspect_w']; H=plan.composition_metrics['aspect_h']
    # bounds
    for n in nodes:
        x0,y0,x1,y1=_rect(n)
        if x0<0 or y0<0 or x1>W or y1>H:
            fails.append({'code':'OUT_OF_BOUNDS','node':n.semantic_id})
    # overlaps must have semantic ownership
    for i,a in enumerate(nodes):
        for b in nodes[i+1:]:
            ia=_inter(a,b)
            if ia<=0: continue
            frac=ia/max(1e-9,min(a.w*a.h,b.w*b.h))
            pair=tuple(sorted((a.semantic_id,b.semantic_id)))
            if pair not in allowed and frac>.04:
                fails.append({'code':'UNOWNED_OVERLAP','pair':pair,'fraction':round(frac,3)})
            elif frac>.55 and pair in allowed:
                warns.append({'code':'CONTACT_TOO_MUDDLED','pair':pair,'fraction':round(frac,3)})
    # attention direction
    for r in beat.relations:
        if r.type in {'looks_at','gestures_to','acts_on','moves_toward','hands_to','receives'}:
            a,b=by[r.source],by[r.target]
            if a.kind=='person':
                if b.x>a.x and a.facing=='left': fails.append({'code':'FACING_AWAY','source':r.source,'target':r.target})
                if b.x<a.x and a.facing=='right': fails.append({'code':'FACING_AWAY','source':r.source,'target':r.target})
    # support surfaces
    for r in beat.relations:
        if r.type=='rests_on':
            a,b=by[r.source],by[r.target]
            a_bottom=a.y+a.h/2; b_top=b.y-b.h/2
            if abs(a_bottom-b_top)>.05*H: fails.append({'code':'BROKEN_SUPPORT_CONTACT','source':r.source,'target':r.target})
        if r.type=='inside':
            a,b=by[r.source],by[r.target]
            ax0,ay0,ax1,ay1=_rect(a); bx0,by0,bx1,by1=_rect(b)
            if not (bx0<=ax0 and by0<=ay0 and bx1>=ax1 and by1>=ay1): fails.append({'code':'BROKEN_CONTAINMENT','source':r.source,'target':r.target})
    # composition density / negative space
    occupied=sum(n.w*n.h for n in nodes)/(W*H)
    if occupied>.72: fails.append({'code':'OVERDENSE_COMPOSITION','occupied':round(occupied,3)})
    elif occupied>.58: warns.append({'code':'DENSE_COMPOSITION','occupied':round(occupied,3)})
    # hierarchy
    heroes=[n for n in nodes if n.hierarchy=='hero']
    if len(heroes)!=1: fails.append({'code':'HERO_COUNT','count':len(heroes)})
    if heroes:
        h=heroes[0]
        support_area=max([n.w*n.h for n in nodes if n.hierarchy!='hero'] or [0])
        if h.w*h.h < support_area*1.12: warns.append({'code':'WEAK_HERO_DOMINANCE'})
    # score
    score=max(0.0,1.0-.14*len(fails)-.035*len(warns))
    status='PASS' if not fails and score>=.82 else ('REPLAN' if score>=.45 else 'FAIL')
    return QAResult(status,round(score,4),fails,warns,{'occupied_area':round(occupied,4),'fail_count':len(fails),'warning_count':len(warns)})
