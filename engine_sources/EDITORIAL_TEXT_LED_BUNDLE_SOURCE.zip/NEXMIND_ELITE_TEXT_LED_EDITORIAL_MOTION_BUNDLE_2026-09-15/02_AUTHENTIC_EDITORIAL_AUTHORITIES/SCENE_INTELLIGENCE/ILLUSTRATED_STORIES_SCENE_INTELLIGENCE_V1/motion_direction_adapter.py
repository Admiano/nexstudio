from __future__ import annotations
from scene_intelligence_schema import *

# Output contract consumed downstream by ILLUSTRATED_STORIES_MOTION_DIRECTION_AUTHORITY_V1.
def bind_motion_intent(beat: SemanticBeat, plan: ScenePlan) -> dict:
    f=beat.features
    if f.transformation_degree>.55: object_motion='state_change_or_reveal'
    elif f.physicality>.6: object_motion='scene_native_physical_motion'
    elif f.evidence_density>.55: object_motion='data_mark_change'
    else: object_motion='minimal_scene_native_motion'
    return {
      'camera':'stable', 'palette':'black_white_only', 'dominant_motion_count':1,
      'character_entry':'motivated_entry' if f.human_agency>.35 else 'none',
      'character_exit':'transition_motivated_exit' if f.human_agency>.35 else 'none',
      'object_motion':object_motion,
      'typography':'bold_editorial_kinetic_type',
      'transition_family':'relationship_or_shape_motivated',
      'screen_direction':'preserve_semantic_progression',
      'hold_rule':'settled_read_hold_after_primary_reveal'
    }
