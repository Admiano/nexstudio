import os,sys,unittest
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from scene_intelligence import compile_beat

# Subject labels are intentionally diverse. They are payload only.
CASES=[
 {'id':'trust','labels':['customer','service'], 'features':(.85,.70,.70,.35,.20,.55,.10,.50,.25,.45,.45), 'rel':'looks_at'},
 {'id':'merge','labels':['team A','team B'], 'features':(.75,.35,.90,.45,.55,.25,.10,.35,.20,.80,.55), 'rel':'hands_to'},
 {'id':'learning','labels':['learner','skill'], 'features':(.90,.75,.65,.55,.70,.45,.10,.65,.55,.30,.60), 'rel':'acts_on'},
 {'id':'bottleneck','labels':['shipment','gate'], 'features':(.15,.45,.72,.20,.35,.90,.10,.85,.20,.10,.75), 'rel':'blocks'},
 {'id':'family','labels':['parent','choice'], 'features':(.80,.62,.78,.15,.75,.25,.05,.40,.65,.75,.35), 'rel':'looks_at'},
 {'id':'finance','labels':['asset','risk'], 'features':(.10,.30,.45,.40,.75,.15,.90,.20,.60,.05,.65), 'rel':'compares'},
 {'id':'recovery','labels':['person','mistake'], 'features':(.90,.85,.65,.85,.25,.45,.05,.55,.55,.15,.65), 'rel':'resolves_to'},
 {'id':'product','labels':['user','interface'], 'features':(.75,.45,.72,.80,.25,.35,.05,.45,.20,.20,.45), 'rel':'acts_on'},
]

class Blind(unittest.TestCase):
 def test_all_compile(self):
  for c in CASES:
   ha,ei,rd,td,cd,sp,ed,ph,un,so,ca=c['features']
   kind2='person' if c['rel']=='hands_to' else ('evidence' if c['id']=='finance' else 'object')
   entities=[{'id':'a','kind':'person' if ha>.5 else 'object','label':c['labels'][0],'importance':.9,'agency':ha,'physicality':ph},
             {'id':'b','kind':kind2,'label':c['labels'][1],'importance':.8,'physicality':ph}]
   rel=c['rel']
   # resolves_to requires state/result endpoint; still generic topology.
   if rel=='resolves_to': entities[1]['kind']='state'
   if rel=='hands_to': entities[0]['kind']=entities[1]['kind']='person'
   raw={'beat_id':c['id'],'text':'blind payload','entities':entities,'relations':[{'type':rel,'source':'a','target':'b'}],
        'features':{'human_agency':ha,'emotional_intensity':ei,'relational_density':rd,'transformation_degree':td,
                    'comparison_degree':cd,'spatiality':sp,'evidence_density':ed,'physicality':ph,'uncertainty':un,'sociality':so,'causality':ca},
        'protagonist_id':'a' if entities[0]['kind']=='person' else None}
   result=compile_beat(raw)
   self.assertEqual(result['status'],'PASS',(c['id'],result))

if __name__=='__main__': unittest.main()
