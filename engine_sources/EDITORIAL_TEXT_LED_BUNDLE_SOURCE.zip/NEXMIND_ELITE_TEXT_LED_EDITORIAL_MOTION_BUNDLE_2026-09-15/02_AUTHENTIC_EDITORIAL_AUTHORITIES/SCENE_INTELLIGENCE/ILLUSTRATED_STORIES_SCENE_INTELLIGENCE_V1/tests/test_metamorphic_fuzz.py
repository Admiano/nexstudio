import os,sys,random,copy,unittest,string
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from scene_intelligence import compile_beat

REL=['looks_at','acts_on','moves_toward','blocks','transforms','produces','connects_to','causes']
class Fuzz(unittest.TestCase):
 def test_100_label_mutations_preserve_visual_routing(self):
  rng=random.Random(7331)
  for i in range(100):
   rel=rng.choice(REL)
   ha=rng.random(); ph=rng.random(); ei=rng.random(); rd=.45+.5*rng.random()
   a_kind='person' if ha>.45 else 'object'; b_kind='object'
   raw={'beat_id':f'f{i}','text':'one payload','entities':[
       {'id':'a','kind':a_kind,'label':'alpha','importance':.9,'agency':ha,'physicality':ph},
       {'id':'b','kind':b_kind,'label':'beta','importance':.75,'physicality':ph}],
       'relations':[{'type':rel,'source':'a','target':'b'}],
       'features':{'human_agency':ha,'emotional_intensity':ei,'emotional_valence':rng.uniform(-1,1),
                   'relational_density':rd,'transformation_degree':rng.random(),'comparison_degree':rng.random(),
                   'spatiality':rng.random(),'physicality':ph,'evidence_density':rng.random()*.4,
                   'uncertainty':rng.random(),'sociality':rng.random(),'causality':rng.random(),'continuity_required':rng.random()},
       'protagonist_id':'a' if a_kind=='person' else None}
   x=compile_beat(raw)
   mut=copy.deepcopy(raw); mut['text']=''.join(rng.choice(string.ascii_letters+' ') for _ in range(30)); mut['entities'][0]['label']='ZZZ-'+str(rng.random()); mut['entities'][1]['label']='QQQ-'+str(rng.random())
   y=compile_beat(mut)
   self.assertEqual(x['representation_decision'],y['representation_decision'])
   for aspect in x['aspects']:
    self.assertEqual(x['aspects'][aspect]['status'],y['aspects'][aspect]['status'])
    if x['aspects'][aspect]['status']=='PASS':
     px=copy.deepcopy(x['aspects'][aspect]['plan']); py=copy.deepcopy(y['aspects'][aspect]['plan'])
     px['payload_labels']={}; py['payload_labels']={}
     self.assertEqual(px,py)
if __name__=='__main__': unittest.main()
