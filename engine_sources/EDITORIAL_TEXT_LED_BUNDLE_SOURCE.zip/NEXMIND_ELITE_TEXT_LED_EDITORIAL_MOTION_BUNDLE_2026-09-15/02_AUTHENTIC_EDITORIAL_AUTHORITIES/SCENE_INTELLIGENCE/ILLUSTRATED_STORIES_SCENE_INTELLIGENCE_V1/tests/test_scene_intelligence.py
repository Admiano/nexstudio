import json, copy, os, sys, unittest
sys.path.insert(0,os.path.dirname(os.path.dirname(__file__)))
from scene_intelligence import compile_beat

BASE={
 'beat_id':'b','text':'payload text',
 'entities':[{'id':'p','kind':'person','label':'AAA','importance':.9,'agency':1,'physicality':.6},
             {'id':'o','kind':'object','label':'BBB','importance':.8,'physicality':.8}],
 'relations':[{'type':'looks_at','source':'p','target':'o'},{'type':'acts_on','source':'p','target':'o'}],
 'features':{'human_agency':.9,'emotional_intensity':.65,'relational_density':.8,'physicality':.7,'continuity_required':.8},
 'protagonist_id':'p'
}

class Tests(unittest.TestCase):
 def test_three_aspects(self):
  r=compile_beat(BASE); self.assertEqual(r['status'],'PASS'); self.assertEqual(set(r['aspects']),{'16:9','1:1','9:16'})
 def test_label_invariance(self):
  a=compile_beat(BASE)
  b=copy.deepcopy(BASE); b['entities'][0]['label']='completely unrelated payload'; b['entities'][1]['label']='another domain noun'; b['text']='different subject entirely'
  z=compile_beat(b)
  self.assertEqual(a['representation_decision']['selected'],z['representation_decision']['selected'])
  for aspect in a['aspects']:
   pa=a['aspects'][aspect]['plan']; pz=z['aspects'][aspect]['plan']
   # compare layout after stripping labels
   for p in (pa,pz): p['payload_labels']={}
   self.assertEqual(pa,pz)
 def test_facing_alignment(self):
  r=compile_beat(BASE)
  for aspect in r['aspects']:
   nodes=r['aspects'][aspect]['plan']['nodes']; by={n['semantic_id']:n for n in nodes}
   p,o=by['p'],by['o']
   self.assertFalse((o['x']>p['x'] and p['facing']=='left') or (o['x']<p['x'] and p['facing']=='right'))
 def test_no_unowned_overlap(self):
  r=compile_beat(BASE)
  for aspect in r['aspects']:
   self.assertFalse(any(f['code']=='UNOWNED_OVERLAP' for f in r['aspects'][aspect]['qa']['failures']))
 def test_data_can_win(self):
  x=copy.deepcopy(BASE); x['features'].update({'human_agency':.05,'emotional_intensity':.05,'relational_density':.15,'physicality':.1,'evidence_density':.95})
  x['entities'].append({'id':'e','kind':'evidence','label':'number','importance':.9})
  r=compile_beat(x); self.assertEqual(r['representation_decision']['selected'],'data_in_context')

if __name__=='__main__': unittest.main()
