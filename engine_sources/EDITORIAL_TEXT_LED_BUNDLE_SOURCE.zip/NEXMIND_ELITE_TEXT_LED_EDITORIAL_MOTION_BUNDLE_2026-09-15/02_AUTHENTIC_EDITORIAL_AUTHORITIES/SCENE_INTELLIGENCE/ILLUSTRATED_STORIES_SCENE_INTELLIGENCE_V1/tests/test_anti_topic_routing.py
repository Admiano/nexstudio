import os,re,unittest
ROOT=os.path.dirname(os.path.dirname(__file__))
# These benchmark-domain nouns must not exist inside routing/layout modules.
FORBIDDEN=['customer','service','shipment','family','finance','asset','learner','skill','product','interface','parent','crypto','checkout','supermarket']
TARGETS=['representation_planner.py','composition_authority.py','scene_relationship_authority.py','restaging_loop.py']
class Scan(unittest.TestCase):
 def test_no_topic_routing_tokens(self):
  for fn in TARGETS:
   text=open(os.path.join(ROOT,fn)).read().lower()
   for w in FORBIDDEN:
    self.assertNotIn(w,text,(fn,w))
if __name__=='__main__': unittest.main()
