from __future__ import annotations
from scene_intelligence_schema import *
from composition_authority import plan_composition
from semantic_pixel_qa import evaluate


def replan_until_pass(beat: SemanticBeat, decision: RepresentationDecision, aspect: str, max_attempts: int=6):
    representations=[decision.selected]+decision.fallback_order
    history=[]
    attempt=0
    for rep in representations:
        for variant in (0,1):
            if attempt>=max_attempts: break
            plan=plan_composition(beat,rep,aspect,variant)
            qa=evaluate(beat,plan)
            history.append({'attempt':attempt,'representation':rep,'variant':variant,'qa':serial(qa)})
            if qa.status=='PASS': return plan,qa,history
            attempt+=1
        if attempt>=max_attempts: break
    # return best candidate rather than pretending pass
    best=max(history,key=lambda x:x['qa']['score']) if history else None
    return None,QAResult('FAIL',best['qa']['score'] if best else 0.0,
                         [{'code':'RESTAGING_EXHAUSTED','best':best}],[],{}),history
