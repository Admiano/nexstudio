from __future__ import annotations
from scene_intelligence_schema import *

# Abstract state -> generic pose-role requests. No subject labels/topic nouns.
def select_pose_role(beat: SemanticBeat) -> str | None:
    if not any(e.kind=='person' for e in beat.entities) or beat.features.human_agency<.35:
        return None
    f=beat.features
    if f.uncertainty>.62 or (f.emotional_intensity>.58 and f.emotional_valence<-.15):
        return 'SEATED_THINK_LISTEN' if f.physicality<.55 else 'FLOOR_THINK'
    if f.emotional_valence>.45 and f.emotional_intensity>.45:
        return 'CONFIDENT_HOLD'
    if f.relational_density>.52 or f.sociality>.52:
        return 'EXPLAIN_CONVERSE'
    if f.continuity_required>.6 and f.physicality>.5:
        return 'ARRIVE_WALK'
    return 'PRESENT_POINT'
