from __future__ import annotations
from collections import defaultdict
from scene_intelligence_schema import *

INTERACTION_RELATIONS={'holds','acts_on','blocks','supports','rests_on','surrounds','inside','behind','in_front_of','hands_to','receives'}
ATTENTION_RELATIONS={'looks_at','gestures_to','acts_on','moves_toward','receives','hands_to','blocks'}

def hierarchy(beat: SemanticBeat) -> Dict[str,str]:
    degree=defaultdict(float)
    for r in beat.relations:
        degree[r.source]+=r.strength; degree[r.target]+=r.strength
    scored=[]
    for i,e in enumerate(beat.entities):
        score=.58*e.importance + .22*min(1,degree[e.id]/3) + .20*(e.id==beat.protagonist_id)
        scored.append((score,i,e.id))
    scored.sort(key=lambda x:(-x[0],x[1]))
    out={}
    for i,(_,_,eid) in enumerate(scored): out[eid]='hero' if i==0 else ('support' if i<=3 else 'micro')
    return out

def build_constraints(beat: SemanticBeat) -> List[SceneConstraint]:
    c=[]
    # relationship ownership
    for r in beat.relations:
        if r.type in INTERACTION_RELATIONS:
            c.append(SceneConstraint('semantic_contact_or_spatial_relation',r.source,r.target,{'relation':r.type,'strength':r.strength}))
        if r.type in ATTENTION_RELATIONS:
            c.append(SceneConstraint('attention_alignment',r.source,r.target,{'relation':r.type,'directionality':r.directionality}))
        if r.type=='rests_on': c.append(SceneConstraint('support_surface_required',r.source,r.target,{}))
        if r.type=='inside': c.append(SceneConstraint('containment_required',r.source,r.target,{}))
        if r.type=='blocks': c.append(SceneConstraint('occlusion_or_path_block_required',r.source,r.target,{}))
    c.append(SceneConstraint('no_overlap_without_semantic_relationship','*',None,{}))
    c.append(SceneConstraint('hero_silhouette_separation','*',None,{'minimum_clearance':.025}))
    c.append(SceneConstraint('negative_space_floor','*',None,{'min_fraction':.18}))
    c.append(SceneConstraint('one_visual_center','*',None,{}))
    return c

def allowed_overlap_pairs(beat: SemanticBeat) -> set[tuple[str,str]]:
    pairs=set()
    for r in beat.relations:
        if r.type in INTERACTION_RELATIONS:
            pairs.add(tuple(sorted((r.source,r.target))))
    return pairs
