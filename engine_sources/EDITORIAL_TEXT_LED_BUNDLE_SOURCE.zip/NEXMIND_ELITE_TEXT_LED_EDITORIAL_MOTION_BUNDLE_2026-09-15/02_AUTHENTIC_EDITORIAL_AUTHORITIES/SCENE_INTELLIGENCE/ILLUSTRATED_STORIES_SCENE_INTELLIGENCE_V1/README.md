# ILLUSTRATED_STORIES_SCENE_INTELLIGENCE_V1

First executable alpha of the general-purpose Illustrated Stories scene-intelligence layer.

Pipeline:

`script semantics -> Semantic Beat Model -> Representation Planner -> Scene Relationship Authority -> Composition Authority -> Semantic Pixel QA -> Restaging Loop -> Character/Motion adapters`

This is intentionally **not** a finished illustration renderer. Its job is to stop the renderer from inventing inaccurate/muddled arrangements by resolving meaning, relationships, hierarchy, facing, contact, support, aspect composition and representation before pixels are drawn.

## Anti-hardcoding boundary
Subject labels are carried only as asset/display payload. Representation and layout use entity kinds, explicit semantic relations, topology and continuous abstract features. A metamorphic label-invariance test verifies that changing all subject labels while preserving semantic structure produces the same representation/layout.

## Current implementation
- semantic beat normalization/validation
- eight-form representation scoring
- relationship-owned constraints
- aspect-native topology-aware composition for 16:9 / 1:1 / 9:16
- facing/attention alignment
- support/containment/contact semantics
- no-unowned-overlap QA
- density/hierarchy QA
- generic restaging/fallback loop
- abstract character pose-role request
- binding seam to Motion Direction Authority
- blind-domain and anti-topic tests

## Not yet claimed
- free-text semantic parsing at production quality
- final authored illustration generation
- arbitrary-scene commercial pixel certification
- automatic asset-family style normalization at final pixels
