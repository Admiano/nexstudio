from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any, List

@dataclass(frozen=True)
class PrimitiveEvent:
    primitive:str
    layer:str
    start_frame:int
    end_frame:int
    easing:str
    semantic_reason:str
    source_donor:str
    guard:str=''


def _ev(pid,layer,s,e,ease,reason,source,guard=''):
    return asdict(PrimitiveEvent(pid,layer,max(0,int(s)),max(int(s)+1,int(e)),ease,reason,source,guard))

def compile_donor_primitives(beat:Dict[str,Any],treatment:Dict[str,Any],duration_frames:int)->List[Dict[str,Any]]:
    """Assimilate donor behavior without donor visual identity.

    The decision is semantic. No primitive is emitted because a donor component exists.
    """
    sem=treatment.get('semantic_function','')
    tid=treatment.get('treatment','')
    out=[]
    if sem in {'HOOK','PAYOFF'} or tid in {'PROGRESSIVE_HERO_BUILD','PAYOFF_LOCKUP'}:
        out.append(_ev('WORD_STAGGER_RISE','HERO_TEXT',0,duration_frames*.22,'expo_out',
                       'text is the lead actor; stagger follows reading order',
                       'NexTypography:large-statement/subtitle-card'))
    if beat.get('emphasis_words'):
        out.append(_ev('WORD_EMPHASIS_PULSE','HERO_TEXT',duration_frames*.16,duration_frames*.36,'back_out_restrained',
                       'explicit semantic emphasis words supplied by beat',
                       'NexTypography:word-by-word-emphasis','single settle; no bounce loop'))
    if sem=='PROOF' or beat.get('evidence'):
        out.append(_ev('RULE_DRAW','SUPPORT_VISUAL',duration_frames*.28,duration_frames*.48,'cubic_out',
                       'evidence/source relationship gains a restrained editorial rule',
                       'NexTypography:source-citation/chapter-opener'))
    if sem=='PROCESS' and beat.get('process_steps'):
        out.append(_ev('CONNECTOR_DRAW','SUPPORT_VISUAL',duration_frames*.26,duration_frames*.68,'cubic_in_out',
                       'ordered states require a causal connector',
                       'NexMotion:connect','connector must terminate at semantic nodes'))
    numeric=beat.get('numeric_value')
    if numeric is not None:
        out.append(_ev('NUMERIC_COUNT','HERO_TEXT',duration_frames*.08,duration_frames*.52,'cubic_out',
                       'explicit numeric truth is present',
                       'NexMotion:numeric-count / NexTypography:statistic-headline','forbidden without explicit numeric data'))
    if beat.get('highlight_phrase'):
        out.append(_ev('MARKER_HIGHLIGHT','HERO_TEXT',duration_frames*.30,duration_frames*.55,'quad_out',
                       'explicit highlight phrase supplied by treatment',
                       'NexMotion:marker-highlight','style comes from project, not donor'))
    if sem in {'PROOF','PROCESS'} and beat.get('trace_path'):
        out.append(_ev('PATH_DRAW','SUPPORT_VISUAL',duration_frames*.32,duration_frames*.72,'cubic_out',
                       'trace path is semantically meaningful',
                       'NexTypography:pathDraw/callout-label'))
    if beat.get('completion_state') is True:
        out.append(_ev('TICK_CONFIRM','SUPPORT_VISUAL',duration_frames*.62,duration_frames*.80,'back_out_restrained',
                       'explicit completion state',
                       'NexMotion:tick-confirm','single event only'))
    return out
