from __future__ import annotations
from typing import Any, Dict
import importlib, pathlib, sys
from dataclasses import asdict
ROOT=pathlib.Path('/mnt/data/NEXSTUDIO_TEXT_LED_EDITORIAL_MOTION_ASSEMBLY_V1')
SRC_DIR=ROOT/'frozen/MOTION_ENSEMBLE/EDITORIAL_MOTION_ENSEMBLE_DIRECTOR_V1'

def _load():
    try:
        if str(SRC_DIR) not in sys.path: sys.path.insert(0,str(SRC_DIR))
        return importlib.import_module('editorial_motion_ensemble_director_v1')
    except Exception:return None
_V1=_load()

def _authentic(duration_frames:int,visual:Dict[str,Any],treatment:Dict[str,Any],fps:int=30):
    if _V1 is None:return None
    try:
        ms=round(duration_frames/fps*1000); has=visual['kind']!='NONE'
        req=_V1.EnsembleRequest(duration_ms=ms,shot_role='TEXT_LED',hero_motion_count=1,support_motion_count=1,
            illustration_motion_count=1 if has else 0,character_present=visual['kind']=='HUMAN',background_stage_motion=True,
            transition_mode='OBJECT_OR_TEXT_CARRIER' if has else 'TEXT_CARRIER',beat_energy=.62)
        return asdict(_V1.EditorialMotionEnsembleDirectorV1().plan(req))
    except Exception as exc:return {'pass_gate':False,'warnings':['ADAPTER_ERROR:'+type(exc).__name__]}

def compile_ensemble(duration_frames:int,text_motion:Dict[str,Any],visual:Dict[str,Any],treatment:Dict[str,Any],fps:int=30)->Dict[str,Any]:
    authentic=_authentic(duration_frames,visual,treatment,fps)
    events=list(text_motion.get('frame_events',[])); tid=treatment['treatment'];vk=visual['kind']
    # Preserve the authentic role-aware sequencing as a foundation record; successor specs remain frame-indexed.
    if vk!='NONE':
        if tid in {'ANCHORED_SCREENSHOT_PROOF','HERO_TO_EVIDENCE_HANDOFF'}: s=round(duration_frames*.22);e=round(duration_frames*.40)
        elif tid=='PROCESS_RAIL':s=round(duration_frames*.28);e=round(duration_frames*.55)
        else:s=round(duration_frames*.32);e=round(duration_frames*.52)
        events.append({'layer':'SUPPORT_VISUAL','event':'SEMANTIC_VISUAL_ENTRY','start_frame':s,'end_frame':e,'hold_frames':0,'easing':'cubic_out','path':'ROLE_NATIVE','scale_from':.93,'scale_to':1.0,'opacity_from':0,'opacity_to':1,'blur_policy':'SHARP_INFORMATION_LAYER','z_order_event':'NONE','semantic_reason':visual['semantic_reason']})
    trans_start=round(duration_frames*.88);carrier='SUPPORT_VISUAL' if visual.get('continuity_key') else 'HERO_TEXT'
    events.append({'layer':carrier,'event':'TRANSITION_CARRIER','start_frame':trans_start,'end_frame':duration_frames,'hold_frames':0,'easing':'cubic_in_out','path':'SEMANTIC_EXIT','scale_from':1,'scale_to':1,'opacity_from':1,'opacity_to':1,'blur_policy':'SHARP_INFORMATION_LAYER','z_order_event':'NONE','semantic_reason':'single transition owner prevents competing exit motion'})
    events.sort(key=lambda x:(x['start_frame'],x['end_frame']));warnings=[]
    dominant=[e for e in events if e['event'] in {'HERO_SCALE_PROMOTION','SEMANTIC_VISUAL_ENTRY','PHRASE_RECONFIGURE','TRANSITION_CARRIER'}]
    for i,a in enumerate(dominant):
        for b in dominant[i+1:]:
            if a['layer']!=b['layer'] and min(a['end_frame'],b['end_frame'])-max(a['start_frame'],b['start_frame'])>4:warnings.append(f"DOMINANT_OVERLAP:{a['event']}:{b['event']}")
    return {'duration_frames':duration_frames,'events':events,'transition_carrier':carrier,'warnings':sorted(set(warnings)),
            'source_foundation':'EDITORIAL_MOTION_ENSEMBLE_DIRECTOR_V1 + reference-derived frame-indexed successor events',
            'authentic_v1_plan':authentic,'principle':'one dominant motion event at a time; support motion follows reading order'}
