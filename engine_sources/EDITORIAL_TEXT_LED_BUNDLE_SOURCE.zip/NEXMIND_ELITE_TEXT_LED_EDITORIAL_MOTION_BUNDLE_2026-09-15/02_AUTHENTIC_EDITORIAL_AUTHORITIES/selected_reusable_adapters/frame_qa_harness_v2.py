from __future__ import annotations
import argparse, hashlib, importlib.util, json, pathlib
from PIL import Image, ImageDraw, ImageFont

ROOT=pathlib.Path('/mnt/data/NEXSTUDIO_TEXT_LED_EDITORIAL_MOTION_ASSEMBLY_V1')
RENDERER_PATH=ROOT/'src/proof_renderer_v5.py'
DEFAULT_PLAN=ROOT/'proofs/ATLAS_FRESH_UNSEEN_PROOF_PLAN_V4.json'
FPS=30
TRANSITION_FRAMES=11

spec=importlib.util.spec_from_file_location('editorial_proof_renderer_v5',RENDERER_PATH)
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)

def load_plan(path=DEFAULT_PLAN): return json.loads(pathlib.Path(path).read_text())
def beats_for(aspect,plan=None): return (plan or load_plan())['aspects'][aspect]
def beat_frames(b): return int(round(float(b['beat']['duration_sec'])*FPS))

def render_beat(aspect,beat_index,progress,plan=None):
    plan=plan or load_plan(); b=beats_for(aspect,plan)[beat_index]; n=beat_frames(b)
    fi=min(n-1,max(0,round(float(progress)*(n-1))))
    W,H=r.ASPECTS[aspect]; img=Image.new('RGBA',(W,H),(*r.BG,255))
    r.draw_scene(img,b['beat'],aspect,fi,n,b['composition']); return img

def render_transition(aspect,boundary_index,progress,plan=None):
    plan=plan or load_plan(); bs=beats_for(aspect,plan)
    if boundary_index<1 or boundary_index>=len(bs): raise IndexError('boundary_index must be 1..len(beats)-1')
    prev_b,curr_b=bs[boundary_index-1],bs[boundary_index]
    fi=min(TRANSITION_FRAMES-1,max(0,round(float(progress)*(TRANSITION_FRAMES-1))))
    return r._semantic_transition(prev_b,curr_b,aspect,fi,TRANSITION_FRAMES,beat_frames(prev_b),beat_frames(curr_b))

def render_frame(aspect,frame_number,plan=None):
    plan=plan or load_plan(); bs=beats_for(aspect,plan); frame_number=max(0,int(frame_number)); cursor=0
    for i,b in enumerate(bs):
        n=beat_frames(b)
        if frame_number < cursor+n:
            fi=frame_number-cursor
            if i>0 and fi<TRANSITION_FRAMES:
                return r._semantic_transition(bs[i-1],b,aspect,fi,TRANSITION_FRAMES,beat_frames(bs[i-1]),n)
            local_fi=min(n-1,fi+(TRANSITION_FRAMES if i>0 else 0))
            W,H=r.ASPECTS[aspect];img=Image.new('RGBA',(W,H),(*r.BG,255));r.draw_scene(img,b['beat'],aspect,local_fi,n,b['composition']);return img
        cursor+=n
    return render_beat(aspect,len(bs)-1,1.0,plan)

def image_sha(img): return hashlib.sha256(img.tobytes()).hexdigest()

def progress_sheet(aspect,out_path,plan=None,progresses=(0,.2,.5,.8,1.0),mode='beats'):
    plan=plan or load_plan(); bs=beats_for(aspect,plan); W,H=r.ASPECTS[aspect]
    thumb_w=220; thumb_h=round(H*thumb_w/W); head=24
    rows=len(bs) if mode=='beats' else len(bs)-1
    sheet=Image.new('RGB',(thumb_w*len(progresses),(thumb_h+head)*rows),(243,243,240));d=ImageDraw.Draw(sheet)
    ft=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',10)
    for row in range(rows):
        for col,p in enumerate(progresses):
            img=render_beat(aspect,row,p,plan) if mode=='beats' else render_transition(aspect,row+1,p,plan)
            im=img.convert('RGB').resize((thumb_w,thumb_h),Image.Resampling.LANCZOS)
            x=col*thumb_w;y=row*(thumb_h+head);sheet.paste(im,(x,y+head))
            label=(bs[row]['beat']['id'] if mode=='beats' else f"{bs[row]['beat']['id']}→{bs[row+1]['beat']['id']}")
            d.text((x+4,y+5),f'{label} · {p:.2f}',font=ft,fill=(35,35,35))
    out_path=pathlib.Path(out_path);out_path.parent.mkdir(parents=True,exist_ok=True);sheet.save(out_path,quality=93);return out_path

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--aspect',required=True,choices=r.ASPECTS);ap.add_argument('--out',required=True);ap.add_argument('--plan',default=str(DEFAULT_PLAN))
    g=ap.add_mutually_exclusive_group(required=True);g.add_argument('--frame',type=int);g.add_argument('--beat',type=int);g.add_argument('--transition',type=int);g.add_argument('--sheet',choices=['beats','transitions'])
    ap.add_argument('--progress',type=float,default=.5);args=ap.parse_args();plan=load_plan(args.plan)
    if args.sheet:
        progress_sheet(args.aspect,args.out,plan,mode=args.sheet);print(args.out)
    else:
        if args.frame is not None: img=render_frame(args.aspect,args.frame,plan)
        elif args.beat is not None: img=render_beat(args.aspect,args.beat,args.progress,plan)
        else: img=render_transition(args.aspect,args.transition,args.progress,plan)
        pathlib.Path(args.out).parent.mkdir(parents=True,exist_ok=True);img.convert('RGB').save(args.out);print(json.dumps({'out':args.out,'sha256_pixels':image_sha(img),'size':img.size},indent=2))
