from __future__ import annotations
from typing import Any, Dict, List

def evaluate(plan:Dict[str,Any])->Dict[str,Any]:
    hard=[]; scores={}
    spatial=plan.get('spatial_qa',{})
    if not spatial.get('pass',False): hard += spatial.get('warnings',[])
    motion=plan.get('ensemble',{})
    if any(x.startswith('DOMINANT_OVERLAP') for x in motion.get('warnings',[])): hard += motion['warnings']
    treatment=plan['treatment']['treatment']; visual=plan['visual']['kind']
    scores['typography_hierarchy']=0.9 if treatment in {'PROGRESSIVE_HERO_BUILD','HERO_SCALE_PROMOTION','PAYOFF_LOCKUP','HERO_TO_EVIDENCE_HANDOFF'} else 0.82
    scores['semantic_fit']=0.92 if visual!='NONE' or treatment in {'PROGRESSIVE_HERO_BUILD','PAYOFF_LOCKUP','CONTROLLED_EMPTY_SPACE'} else 0.80
    scores['composition']=0.88 if plan['composition'].get('native_profile') and not hard else 0.55
    scores['motion_sophistication']=min(.94,.64+.025*len(plan.get('ensemble',{}).get('events',[])))
    scores['support_usefulness']=.9 if visual!='NONE' else .84
    scores['reference_grammar_alignment']=.9
    average=sum(scores.values())/len(scores)
    # This is a planning evaluator only. It cannot certify visual shipping quality.
    return {'hard_failures':sorted(set(hard)),'planning_score':round(average,3),'dimensions':scores,
            'technical_plan_pass':not hard,
            'visual_shipping_status':'REQUIRES_RENDERED_PIXEL_AND_MOTION_REVIEW',
            'warning':'Numeric/planning score cannot overrule weak rendered visuals.'}
