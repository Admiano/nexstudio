from __future__ import annotations
from typing import Any, Dict, List

def _inside(box,W,H):
    return box['x']>=0 and box['y']>=0 and box['x']+box['w']<=W and box['y']+box['h']<=H

def _overlap(a,b):
    x=max(0,min(a['x']+a['w'],b['x']+b['w'])-max(a['x'],b['x']))
    y=max(0,min(a['y']+a['h'],b['y']+b['h'])-max(a['y'],b['y']))
    return x*y

def validate(composition:Dict[str,Any], source_aspect_ratio:float|None=None, placed_aspect_ratio:float|None=None)->Dict[str,Any]:
    W,H=composition['size']; t=composition['text_zone']; v=composition['visual_zone']; warnings=[]
    if not _inside(t,W,H): warnings.append('TEXT_OUT_OF_FRAME')
    if composition['visual_kind']!='NONE' and not _inside(v,W,H): warnings.append('VISUAL_OUT_OF_FRAME')
    if composition['visual_kind']!='NONE':
        ov=_overlap(t,v); denom=max(1,min(t['w']*t['h'],v['w']*v['h']))
        if ov/denom>.08: warnings.append('SETTLED_TEXT_VISUAL_COLLISION')
    if source_aspect_ratio and placed_aspect_ratio and abs(source_aspect_ratio-placed_aspect_ratio)/source_aspect_ratio>.015:
        warnings.append('ASSET_DISTORTION')
    return {'pass':not warnings,'warnings':warnings,'metrics':{'text_visual_overlap_px2':_overlap(t,v) if composition['visual_kind']!='NONE' else 0}}
