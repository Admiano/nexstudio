# Reference Editorial Motion Grammar V1

- **PROGRESSIVE_HERO_BUILD** — Hook, promise, setup, or cumulative claim where meaning becomes stronger as phrase completes
- **PHRASE_REPLACEMENT** — Contrast, correction, reframe, before/after, misconception-to-truth
- **HERO_SCALE_PROMOTION** — Payoff word, critical number, product/name reveal, decisive contrast
- **HERO_TO_EVIDENCE_HANDOFF** — Move from claim to proof/demo without losing narrative continuity
- **EVIDENCE_PERSISTENCE_CARRIER** — Adjacent beats discuss the same product/proof surface
- **ANCHORED_SCREENSHOT_PROOF** — Product proof, interface demonstration, code, document, repository, real evidence
- **SEQUENTIAL_SUPPORT_LIST** — Short proof points, requirements, features, constraints after a clear headline
- **QUIET_SUPPORT_AFTER_HERO** — Clarification, italic aside, explanatory tail after a strong claim
- **CONTRAST_RECONFIGURATION** — Two alternatives, before/after, manual/automatic, expensive/free, fragmented/shared
- **PROCESS_RAIL** — Short process, sequence, handoff, workflow, cause-effect
- **WORD_OBJECT_BRIDGE** — A keyword should become, reveal, or attach to a concrete object/evidence surface
- **OBJECT_LED_TRANSITION** — A screenshot/card/document/device/object is the strongest continuity carrier into next beat
- **PAYOFF_LOCKUP** — Final synthesis, memorable conclusion, product promise
- **CTA_LOCKUP** — Explicit action request at end or creator/social CTA
- **CONTROLLED_EMPTY_SPACE** — Confidence beat, pause, transition, isolated key phrase
