# Product Launch Creative Runtime V1 — Architecture

## Ownership

**Product Launch Director** owns creative intent and shot sequence.

**Rhythm Director** owns energy, velocity profile, peak budget and stillness.

**Cinematic Surface** owns product-region selection and cinematographic hierarchy.

**Type Motion** owns semantic typography and type continuity.

**AE Compositor** owns optical/material/compositing treatment.

**HyperFrames** owns timing playback, seeking, media synchronization, inspection and final rendering.

## Director execution order

For a beat such as `component-extract`:

1. Rhythm Director resolves beat start, action point, reaction point and settle window.
2. Cinematic Surface identifies the target semantic product region.
3. Type Motion preserves any metric/type continuity object attached to that region.
4. Product motion performs the actual semantic change.
5. AE Compositor applies depth separation, shadow, DOF, rim/light response, camera treatment and finishing.
6. All motion settles before the next kinetic peak unless the Director explicitly creates a carry transition.

## Non-negotiable rules

- Movement never creates a connector by default.
- Product UI is preserved; cinematography selects/crops/reframes it.
- Text is a scene object, not an overlay.
- A maximum of four major kinetic peaks is the default for a ~25-second Product Launch film.
- Holds are real stillness, not tiny idle animation.
- Effects are compositing primitives, not decorative defaults.
- HyperFrames remains the only render authority for Product Launch.
