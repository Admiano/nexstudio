# Whiteboard Drawing Artist VNext

## Goal
Move from "planner + asset arranger" to an actual illustration constructor.

## Construction levels

### L0 — Existing asset
Use exact certified SVG/object.

### L1 — Modular recomposition
Compose heads/bodies/poses/props/environment fragments from public-safe components.

### L2 — Parametric drawing
Construct objects using curves, polygons, paths, text, booleans, rounded primitives, transforms and templates.

### L3 — Perspective line-art from 3D
Place approved 3D objects into a scene and extract feature edges to SVG line art. This solves many furniture, room, appliance, vehicle and architecture cases without image generation.

### L4 — Governed new-art fallback
If the scene cannot be constructed, invoke an admitted art/vector provider. Normalize/vectorize it, validate recognizability/style, attach semantics/anchors and store for future reuse when allowed.

## Required capabilities
- semantic object decomposition;
- recognizable silhouettes;
- scene perspective;
- object-to-object spatial relations;
- character pose selection or construction;
- semantic stroke grouping;
- deterministic drawing order;
- occlusion-aware drawing;
- erasing/revealing/highlighting;
- ratio-aware composition;
- SVG sanitization;
- provenance and dedupe.

## handanim use
Mine/adapt:
- scene/drawable model;
- progressive sketch animation;
- hatching/scribble systems;
- SVG import and stroke sequencing;
- AI two-stage architecture as reference.

Do NOT inherit its current limitation of describing scenes only in simple geometry primitives.

## Quality gates
A scene is not accepted merely because all requested nouns are present.
Check:
- immediate recognizability without labels;
- coherent composition;
- relation correctness;
- no accidental overlaps;
- perspective consistency;
- meaningful visual storytelling;
- usable draw order;
- legibility in 16:9, 1:1 and 9:16 where required.
