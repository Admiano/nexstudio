# NexStudio Agent Operating Contract

This file is authoritative for coding agents working in this repository. Read it before editing NexStudio Studio, NexMind, Faceless Explainer, Paper Motion runtime, storyboard, or render code.

## 1. Product boundary

NexStudio currently contains distinct creative products that may share production infrastructure but must not be collapsed into one creative system.

- **Faceless Explainer** is the product governed by this file. It is a premium, brand-aware explainer-video system directed by NexMind and visually built on the **NexStudio Paper Motion Library v3.0.0-rc1**.
- **Paperbook Stories** is a separate creative product with a more literal handcrafted paper-world/storytelling language. Do not force Paperbook-specific directing rules into Faceless Explainer.

Faceless Explainer may be modern, illustrative, diagrammatic, data-led, UI-led, typography-led, or hybrid, but its authored visual substrate must still inherit the Paper Motion system's tactile material language where paper construction is used: cut-paper depth, paper grain, printed-ink character, layered shadows, restrained handmade irregularity, and deliberate physical motion.

A cream background plus flat SVG primitives is **not** sufficient Paper Motion fidelity.

## 2. Non-negotiable intelligence architecture

Fresh customer productions use this chain:

```text
User request / evidence
        ↓
NexMind Story Director
        ↓
NexMind Visual Director
        ↓
Coverage Director
        ↓
NexMind Art Director
        ↓
Deterministic Art Direction Resolver
        ↓
Resolved VisualConstructionPlans / ScenePlans
        ↓
NexMind Motion Director
        ↓
Deterministic Motion Craft / semantic timeline
        ↓
Paper Motion-backed compiler/runtime
        ↓
Storyboard Review / preview / encoded render
```

The canonical fresh-production orchestration entry point is `runNexMindExplainerDirectors`.

Do not bypass this path for a customer production with a topic-specific deterministic story generator or a developer-authored creative-plan script.

### Director ownership

**Story Director owns:** intent, KnowledgePack, facts/evidence boundaries, narrative grammar, semantic beats, narration/display-message separation.

**Visual Director owns:** what should be seen, visual entities, relationships, semantic visual grammar, continuity identity, coverage intent, subject-specific visual requirements.

**Art Director owns:** visual hierarchy, composition archetype, hero prominence, relative placement intent, silhouette intent, balance, negative space, shot/framing intent, typography treatment, visual density, settled-state aesthetic constraints, allowed continuity transformation.

**Motion Director owns:** causal actions, actor/target/relationship, action ordering, continuity handoff intent, camera intent, transition intent, timing intent.

**Deterministic runtime owns:** pixels, coordinates, geometry generation, SVG/DOM, component execution, frame timing, easing implementation, capture, encoding.

NexMind must not output HTML, CSS, JavaScript, TypeScript, React source, bespoke SVG source, or normal-production raw pixel coordinates.

## 3. Topic-specific data vs topic-specific code

This distinction is mandatory.

### Allowed

Topic-specific semantics may exist in:

- persisted production plans and production-scoped data;
- user-supplied media/evidence;
- NexMind structured Story/Visual/Art/Motion outputs;
- production-scoped generated assets;
- tests, fixtures, benchmarks, and evaluation datasets;
- reusable finite library assets whose names naturally describe what they depict (for example a leaf icon or document component).

### Forbidden in shared production paths

Do not add:

- `plantGrow()`, `germinateSeed()`, `photosynthesisScene()`, `blockchainTransactionScene()`, `aiAgentScene()`, or equivalent topic-named runtime handlers;
- topic-keyword branches that silently choose facts, story beats, coordinates, motion, or layouts;
- shared coordinate tables tuned to one benchmark topic;
- developer-authored `scripts/<topic>-creative-plan.ts` as the production implementation;
- hidden generic fallbacks that recognize benchmark nouns and special-case them;
- benchmark-specific copy/data leaking into arbitrary productions.

The benchmark question is always:

> What reusable Explainer capability is missing or performing poorly?

Repair the reusable capability, then prove it with the current benchmark and at least one unrelated fixture where practical.

## 4. Paper Motion is the visual foundation

The Faceless Explainer library is based on **NexStudio Paper Motion Library v3.0.0-rc1**, the 506-entry release currently packaged under `runtime-assets/explainer-motion-v1/library/`.

The Paper Motion registry is the first closed-world reusable vocabulary. Prefer existing registry components where they actually fit the visual job.

Coverage order is:

1. reuse an appropriate Paper Motion component;
2. construct with generic Paper Motion-aware primitives;
3. use a semantic diagram/mechanism;
4. request/create a production-scoped asset when the subject cannot be represented credibly;
5. use approved user media where appropriate;
6. surface an explicit coverage gap rather than silently substituting nonsense.

Do not force a poor library match merely to claim reuse.

New generic construction primitives must inherit Paper Motion material semantics instead of creating a second flat illustration engine beside the library.

### Audio note

The Paper Motion release contains historical/candidate audio metadata. Do not assume those old candidate sounds are authorized for production. Use only the current authorized NexStudio SFX source/policy for customer output.

## 5. Art-direction rules

A beautiful settled key state is a first-class requirement. Animation does not rescue a bad composition.

The Art Director should express **relative creative constraints**, not hard-coded pixels. The resolver owns concrete geometry.

Examples of valid Art Director intent:

- hero prominence;
- balanced-asymmetric silhouette;
- macro detail;
- vertical growth;
- horizontal journey;
- cutaway;
- converging inputs;
- branching system;
- wide reveal;
- negative-space region;
- typography secondary to illustration;
- preserve identity while allowing growth/reorientation/morph.

Do not reduce every scene to the same title-top-left + hero-center template.

Continuity means persistent identity and visual lineage, **not identical geometry**. An object may grow, straighten, reframe, morph, rotate, or become more developed while remaining the same continuity object.

For composite heroes, art-directed prominence must propagate to visible structural descendants. Do not allow an invisible group anchor to be large while its visible children remain tiny.

## 6. Motion rules

Animate the **semantic delta**, not the whole scene graph again.

If a structural relationship is already established from a previous scene, it should normally begin settled and visible. Do not replay its construction simply because the relationship still exists in the new scene plan.

Examples:

```text
established network + new transaction
→ animate transaction through network
```

not

```text
rebuild network
→ then animate transaction
```

Use causal dependencies for meaning-bearing chains. Source → path → target should be visually legible.

Attached children must originate from their attachment anchors. They must not appear floating and later slide onto their parent.

Incoming scenes must not pre-play their semantic timeline during a transition and then reset at scene start.

Whole-frame fades are not a default transition. Prefer object continuation, state transformation, path continuation, camera follow, focus transfer, shape match, or a motivated cut.

Avoid idle bobbing, generic reveal spam, perpetual secondary motion, and springs applied without material meaning.

## 7. Rendering and deterministic seek

Canonical Explainer frame rate is **30 fps** unless a future explicit VideoSpec contract changes it.

Frame timing resolves to integer frames. Preview and production must use the same semantic motion runtime.

Long deterministic renders may rehydrate a fresh capture context in bounded batches. This is allowed because deterministic seek is part of the runtime contract; it prevents browser state accumulation from making long renders unreliable.

Audience capture is restricted to `[data-nex-production-canvas]`. Studio/review/debug controls must never enter encoded pixels.

## 8. QA hierarchy

Internal validators are guardrails. **The encoded visual artifact is authoritative.**

Never declare creative success because:

- TypeScript passes;
- tests pass;
- continuity IDs match;
- bounding-box thresholds pass;
- a JSON report says `PASS`.

Engineering QA and creative QA are separate gates.

### Engineering QA

Includes schema validity, deterministic seek, attachment integrity, no debug leakage, correct frame rate, no unresolved references, causal event graph validity, build/type/test health.

### Creative QA

Includes composition, hierarchy, silhouette, Paper Motion fidelity, meaningful motion, visual causality, continuity as perceived by a viewer, transition craft, camera motivation, readability without overdependence on text, and a visible payoff.

A severe visual defect overrides a nominal engineering PASS.

## 9. NexMind testing rules

Never commit provider credentials.

When no live provider credentials are available, injected/fixture NexMind responses may test:

- orchestration;
- schemas/contracts;
- retries/review states;
- downstream deterministic execution;
- generality of the runtime.

Report this accurately as **injected/fixture testing**, not live NexMind inference.

When credentials are available locally, run live cross-topic evaluations and preserve the structured Story/Visual/Art/Motion artifacts for review.

At minimum, live/generalization evaluation should include unrelated domains such as science, crypto/finance mechanisms, AI/workflows, comparison, and an unfamiliar subject requiring a production-scoped asset.

## 10. Approval/workflow safety

Engineering benchmarks must not mutate customer approval state.

Unless the user explicitly approves scenes through the product workflow:

- keep scenes `DRAFT`;
- do not fake approval;
- do not freeze VideoSpec;
- do not begin commercial final delivery merely because an engineering benchmark renders.

## 11. Required agent workflow for a visual defect

When a rendered defect is found:

1. inspect the actual encoded frame/video;
2. trace the corresponding Story/Visual/Art/Motion plans;
3. classify the defect as planning, coverage, art-resolution, motion-performance, compiler, or render/capture failure;
4. repair the smallest **generic** mechanism that owns the failure;
5. add/update a generic regression test;
6. rerender the relevant short proof first;
7. inspect the actual output again;
8. run an unrelated fixture where the changed mechanism should generalize;
9. only then propagate to the full benchmark.

Do not patch the benchmark coordinates as the default response.

## 12. Validation commands

Useful focused commands include:

```bash
npx tsc --noEmit
npx vitest run src/studio/explainer-motion-v1 --reporter=dot
npx tsx scripts/audit-art-direction-hardcoding.ts
node --check runtime-assets/explainer-motion-v1/library/components/visual-constructions.js
node --check runtime-assets/explainer-motion-v1/library/runtime/motion-craft-engine.js
```

Full project `npm run build` and `npm run typecheck` invoke Prisma generation. In network-restricted environments Prisma may attempt an external engine download. Report that environment blocker accurately; do not rewrite production architecture merely to make a restricted sandbox fake a full build.

Browser tests can also be blocked by hardened environments that prohibit `file://` and loopback browser navigation. Distinguish environment-blocked tests from product failures.

## 13. Status language

Use precise statuses. Examples:

- `ENGINEERING_PASS_CREATIVE_REVIEW_REQUIRED`
- `NEXMIND_FIXTURE_PIPELINE_PASS_LIVE_PROVIDER_NOT_TESTED`
- `BUILD_BLOCKED_BY_EXTERNAL_PRISMA_ENGINE_DOWNLOAD`

Do not use `FINAL`, `ELITE`, `10/10`, `CREATIVE_PASS`, or equivalent unless the actual encoded outputs have been inspected and meet that standard.

## 14. Current benchmark role

The current plant-growth production is a **benchmark/regression case**, not the architecture.

Improving it is valuable only when the improvement either:

- comes from better NexMind production-scoped direction; or
- improves a reusable Explainer capability.

A future arbitrary topic must be able to run through the same Story → Visual → Coverage → Art → Motion → deterministic Paper Motion pipeline without a developer creating a new topic renderer or topic creative-plan script.
