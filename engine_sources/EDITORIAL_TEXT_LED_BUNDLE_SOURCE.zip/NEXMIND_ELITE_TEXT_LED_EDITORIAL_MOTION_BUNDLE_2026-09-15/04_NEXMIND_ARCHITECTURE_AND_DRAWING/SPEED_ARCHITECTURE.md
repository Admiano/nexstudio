# NexMind Compiled Fast Production Architecture

```text
USER BRIEF
   |
   +--> exact production/revision fingerprint hit? ---- yes --> restore accepted outputs
   |
   v
LOCAL ROUTER / RETRIEVER
(Model2Vec + semantic route policy + local vector index)
   |
   +--> confident low-entropy decision --> local contracts
   |
   +--> creative/ambiguous -------------> NEXMIND CREATIVE SPINE
                                             |
                                             v
                                structured production intent
                                             |
                   +-------------------------+--------------------------+
                   |                         |                          |
              registries                feasibility                 reuse
          scene/motion/camera          hard gates               exact/semantic
                   |                         |                          |
                   +-------------------------+--------------------------+
                                             |
                                      PRODUCTION DAG
                                             |
                    +------------------------+------------------------+
                    |                        |                        |
               graphics/audio          independent beats        captions/QA
                    |                        |                        |
                    +------------------------+------------------------+
                                             |
                                   LOW-COST PREVIEW RENDER
                                             |
                                   temporal/perceptual preflight
                                             |
                                    targeted causal repair
                                             |
                                      FINAL RENDER ONCE
                                             |
                                         FINAL PRODUCER
```

## Model spending law
Use premium reasoning on the parts where a human director would actually think. Use deterministic software where a production assistant would apply already-approved rules/assets.
