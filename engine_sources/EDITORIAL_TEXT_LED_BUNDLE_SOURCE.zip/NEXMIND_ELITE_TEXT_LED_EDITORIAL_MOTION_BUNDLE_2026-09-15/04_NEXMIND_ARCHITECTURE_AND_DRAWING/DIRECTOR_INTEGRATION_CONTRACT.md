# Director → AEV1 Motion Grammar Integration Contract

The Director does not author arbitrary animation code. It selects a supported `mechanismId` and receives the closed mapping from `NexStudioAEV1Resolver.compile(mechanismId)`.

For each beat, the compiler passes:

```json
{
  "mechanismId": "C09",
  "motionGrammars": ["MG01", "MG06", "MG07", "MG14"],
  "assetIds": ["..."],
  "fallbackPolicy": "closed-vocabulary-safe-first"
}
```

The renderer builds semantic DOM roles (`source`, `item`, `dock`, `target`, etc.) and drives `NexStudioMotionGrammar.apply(root, grammarId, normalizedProgress, options)` deterministically.

Unknown or unsafe mechanism requests must use `NexStudioAEV1Resolver.safeResolve()` and fall toward data, product media, icon/object composition, kinetic typography or safe abstraction. No runtime path is allowed to generate a custom scene merely because retrieval failed.
