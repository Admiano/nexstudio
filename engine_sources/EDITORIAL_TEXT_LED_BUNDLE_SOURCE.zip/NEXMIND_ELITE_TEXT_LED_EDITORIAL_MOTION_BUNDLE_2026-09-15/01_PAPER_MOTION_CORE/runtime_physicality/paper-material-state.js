(function(root,factory){
 const api=factory(root.NexPaperMaterialTokens || (typeof require==='function'?require('./paper-material-token-bundle.js'):null));
 if(typeof module==='object'&&module.exports) module.exports=api;
 root.NexPaperMaterialState=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(tokens){
 'use strict';
 if(!tokens) throw new Error('NexPaperMaterialTokens is required');
 const byId=(arr)=>Object.fromEntries(arr.map(x=>[x.id,x]));
 const shadowById=byId(tokens.shadowStates), stateById=byId(tokens.engineStates), motionById=byId(tokens.motionProfiles);
 const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
 const mix=(a,b,t)=>a+(b-a)*t;
 const mid=(r)=>Array.isArray(r)?(r[0]+r[1])/2:r;
 const EASING={
  linear:t=>t,
  smooth:t=>t*t*(3-2*t),
  'power1.out':t=>1-(1-t)*(1-t),
  'power1.inOut':t=>t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2,
  'power2.out':t=>1-Math.pow(1-t,3),
  'power2.inOut':t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2,
  'power3.out':t=>1-Math.pow(1-t,4),
  'power4.out':t=>1-Math.pow(1-t,5),
  'expo.out':t=>t===1?1:1-Math.pow(2,-10*t),
  'sine.inOut':t=>-(Math.cos(Math.PI*t)-1)/2,
  'back.out(1.35)':t=>{const c=1.35,c3=c+1;return 1+c3*Math.pow(t-1,3)+c*Math.pow(t-1,2)},
  'back.out(1.7)':t=>{const c=1.7,c3=c+1;return 1+c3*Math.pow(t-1,3)+c*Math.pow(t-1,2)}
 };
 function ease(id,t){return (EASING[id]||EASING.smooth)(clamp(t,0,1));}
 function stableHash(input){let h=2166136261>>>0;for(let i=0;i<String(input).length;i++){h^=String(input).charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
 function seededUnit(seed,index){let x=(stableHash(seed)+Math.imul(index+1,0x9e3779b1))>>>0;x^=x>>>16;x=Math.imul(x,0x7feb352d);x^=x>>>15;x=Math.imul(x,0x846ca68b);x^=x>>>16;return (x>>>0)/4294967295;}
 function irregularity(seed,index,amplitude){return (seededUnit(seed,index)*2-1)*amplitude;}
 function validateState(id){if(!stateById[id]) throw new Error('Unknown paper state: '+id);return stateById[id];}
 function resolveState(id,position=.5){const state=validateState(id), base=shadowById[state.baseShadowState];return {id,...state,shadow:{elevation:mid(base.elevationPxAt1080),offsetX:mid(base.shadowOffsetXPxAt1080),offsetY:mid(base.shadowOffsetYPxAt1080),blur:mid(base.blurPxAt1080),opacity:mid(base.opacity),rotationTolerance:base.rotationToleranceDegrees,bend:mid(base.bendDegrees),edgeVisibility:mid(base.edgeVisibilityRatio)},position:clamp(position,0,1)};}
 function profile(id){const p=motionById[id||'subtle-handmade'];if(!p) throw new Error('Unknown motion profile: '+id);return p;}
 function interpolate(a,b,t){const out={};for(const k of new Set([...Object.keys(a),...Object.keys(b)])){const av=a[k],bv=b[k];out[k]=(typeof av==='number'&&typeof bv==='number')?mix(av,bv,t):(t<.5?av:bv)}return out;}
 function reducedMotionConfig(){return JSON.parse(JSON.stringify(tokens.reducedMotion));}
 return {tokens,states:stateById,shadowStates:shadowById,motionProfiles:motionById,clamp,mix,mid,ease,stableHash,seededUnit,irregularity,validateState,resolveState,profile,interpolate,reducedMotionConfig};
});
