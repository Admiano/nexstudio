(function(root){'use strict';
 const data=()=>root.NexPaperActionCompatibilityMatrix||{actions:{}};
 const id=x=>typeof x==='string'?x:(x?.config?.sourceRigId||x?.config?.productionId||x?.id);
 function get(action){const a=data().actions[action];if(!a)throw new Error(`Unknown paper action ${action}`);return a}
 function validate(config){const errors=[];let a;try{a=get(config.action)}catch(e){return{valid:false,errors:[e.message]}};
  const actor=id(config.actor),prop=id(config.prop),target=id(config.target);
  if(a.category==='character'&&!actor)errors.push('Actor rig is required');
  if(a.actors?.length&&actor&&!a.actors.includes(actor))errors.push(`${actor} is not compatible with ${config.action}`);
  if(a.props?.length&&prop&&!a.props.includes(prop))errors.push(`${prop} is not compatible with ${config.action}`);
  if(a.requiredAnchors?.actor?.length&&config.actor?.anchors)for(const x of a.requiredAnchors.actor)if(!config.actor.anchors.has(x))errors.push(`Missing actor anchor ${x}`);
  if(a.requiredAnchors?.prop?.length&&config.prop?.anchors)for(const x of a.requiredAnchors.prop)if(!config.prop.anchors.has(x))errors.push(`Missing prop anchor ${x}`);
  if(a.requiredAnchors?.target?.length&&config.target?.anchors)for(const x of a.requiredAnchors.target)if(!config.target.anchors.has(x))errors.push(`Missing target anchor ${x}`);
  if(config.environmentAnchor&&config.environment?.config){try{root.NexPaperEnvironmentAnchors.get(config.environment.config,config.environmentAnchor)}catch(e){errors.push(e.message)}}
  return{valid:!errors.length,errors,action:a,actor,prop,target}}
 function supports(action,actor,prop){return validate({action,actor,prop}).valid}
 function actors(action){return get(action).actors||[]}
 function props(action){return get(action).props||[]}
 function validatePlacement(environment,anchorId,ignoreRigId){const env=environment?.config?environment:root.NexPaperEnvironment?.get(environment);if(!env)return{valid:false,collisions:[],errors:['Environment is required']};const collisions=[...env.placements.values()].filter(x=>x.anchorId===anchorId&&x.rig.id!==ignoreRigId).map(x=>({rigId:x.rig.id,anchorId:x.anchorId,category:x.category}));return{valid:!collisions.length,collisions,errors:collisions.length?[`Anchor ${anchorId} is already occupied`]:[]}}
 function matrix(){return data()}
 root.NexPaperActionCompatibility={version:'1.0.0',get,validate,validatePlacement,supports,actors,props,matrix};
})(typeof self!=='undefined'?self:this);