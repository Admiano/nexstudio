(function(root,factory){
 const dep=root.NexPaperMaterialState || (typeof require==='function'?require('./paper-material-state.js'):null);
 const api=factory(dep); if(typeof module==='object'&&module.exports)module.exports=api;root.NexPaperShadow=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(State){
 'use strict';
 const {clamp}=State;
 function calculate(input={}){
  const elevation=Math.max(0,input.elevation||0), rotationX=input.rotationX||0,rotationY=input.rotationY||0;
  const fold=Math.abs(input.fold||0),curl=Math.abs(input.curl||0),cameraY=input.cameraY||0;
  const contact=input.contact||'partial', strength=input.strength==null?1:input.strength;
  const baseY=clamp(1+.45*elevation,1,54), baseBlur=clamp(2+.62*elevation,2,64);
  const directional=1+Math.abs(rotationX)*.018+Math.abs(rotationY)*.012+Math.abs(cameraY)*.008;
  const foldBoost=Math.min(10,fold*.055),curlBoost=Math.min(8,curl*.11);
  let opacity=clamp(.22-.0011*elevation,.10,.24)*strength;
  if(contact==='none') opacity*=.78; if(contact==='surface') opacity*=1.04;
  return {offsetX:(baseY*.18+rotationY*.08)*directional,offsetY:(baseY+rotationX*.06)*directional,blur:baseBlur+foldBoost+curlBoost,opacity:clamp(opacity,.06,.3),spread:clamp(elevation*.015,0,1.5),contactOpacity:contact==='none'?0:clamp(.19-elevation*.006,.02,.19),foldOpacity:clamp((fold/180)*.24,0,.24),spineOpacity:clamp((input.spine||0)*.22,0,.22)};
 }
 function apply(root,values){
  const s=root.style;s.setProperty('--npm-shadow-x',values.offsetX.toFixed(3)+'px');s.setProperty('--npm-shadow-y',values.offsetY.toFixed(3)+'px');s.setProperty('--npm-shadow-blur',values.blur.toFixed(3)+'px');s.setProperty('--npm-shadow-opacity',values.opacity.toFixed(4));s.setProperty('--npm-contact-opacity',values.contactOpacity.toFixed(4));s.setProperty('--npm-fold-shadow-opacity',values.foldOpacity.toFixed(4));s.setProperty('--npm-spine-opacity',values.spineOpacity.toFixed(4));
 }
 return {calculate,apply};
});
