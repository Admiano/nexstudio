(function(root,factory){
 const S=root.NexPaperMaterialState || (typeof require==='function'?require('./paper-material-state.js'):null);
 const api=factory(S);if(typeof module==='object'&&module.exports)module.exports=api;root.NexPaperDeformation=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(State){
 'use strict';
 const {clamp,irregularity}=State;
 function polygon(seed,style){
  if(style==='straight')return 'polygon(0 0,100% 0,100% 100%,0 100%)';
  const amp=style==='torn'?1.8:.7, pts=[];
  for(let i=0;i<=10;i++)pts.push(`${i*10}% ${clamp(irregularity(seed,i,amp),0,3).toFixed(2)}%`);
  for(let i=10;i>=0;i--)pts.push(`${i*10}% ${(100-clamp(irregularity(seed,i+20,amp),-3,3)).toFixed(2)}%`);
  return 'polygon('+pts.join(',')+')';
 }
 function creaseSvg(seed,count=9){
  let lines='';for(let i=0;i<count;i++){const x1=8+State.seededUnit(seed,i)*84,y1=8+State.seededUnit(seed,i+19)*84,x2=8+State.seededUnit(seed,i+39)*84,y2=8+State.seededUnit(seed,i+59)*84;lines+=`<path d="M ${x1.toFixed(1)} ${y1.toFixed(1)} Q ${((x1+x2)/2+irregularity(seed,i+71,10)).toFixed(1)} ${((y1+y2)/2+irregularity(seed,i+91,10)).toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}"/>`;}
  return `<svg class="npm-crease-map" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">${lines}</svg>`;
 }
 function set(root,params={}){
  const s=root.style;
  for(const [k,v] of Object.entries({bend:params.bend||0,curl:params.curl||0,fold:params.fold||0,crumple:params.crumple||0,roll:params.roll||0}))s.setProperty('--npm-'+k,String(v));
  root.dataset.deformation=params.mode||root.dataset.deformation||'none';
  root.classList.toggle('npm-is-folded',(params.fold||0)>.5);root.classList.toggle('npm-is-curled',(params.curl||0)>.5);root.classList.toggle('npm-is-crumpled',(params.crumple||0)>.05);root.classList.toggle('npm-is-bent',Math.abs(params.bend||0)>.5);
  updateSegments(root,params);
 }
 function updateSegments(root,p){
  const segs=[...root.querySelectorAll('.npm-bend-segment')], n=Math.max(1,segs.length-1),bend=p.bend||0,roll=p.roll||0,cr=p.crumple||0;
  segs.forEach((el,i)=>{const u=i/n-.5;const rz=u*bend*.12+irregularity(root.dataset.seed,i,cr*8);const ry=Math.sin(u*Math.PI)*bend*.65;const z=Math.cos(u*Math.PI)*Math.abs(bend)*.9+irregularity(root.dataset.seed,i+30,cr*12);el.style.transform=`translateZ(${z.toFixed(2)}px) rotateY(${(ry+roll*u).toFixed(2)}deg) rotateZ(${rz.toFixed(2)}deg)`;el.style.opacity=cr>.85?.88:1;});const panels=[...root.querySelectorAll('.npm-accordion-panel')],fold=p.fold||0;panels.forEach((el,i)=>{const dir=i%2===0?1:-1;const angle=dir*fold*.38;const z=Math.sin((i+1)/panels.length*Math.PI)*fold*.16;el.style.transform=`translateZ(${z.toFixed(2)}px) rotateY(${angle.toFixed(2)}deg)`;el.style.filter=`brightness(${(1-(i%2)*.09).toFixed(2)})`;});
 }
 function buildCreases(root,seed){const host=root.querySelector('.npm-front');host.querySelector('.npm-crease-map')?.remove();host.insertAdjacentHTML('beforeend',creaseSvg(seed));}
 return {polygon,creaseSvg,set,buildCreases};
});
