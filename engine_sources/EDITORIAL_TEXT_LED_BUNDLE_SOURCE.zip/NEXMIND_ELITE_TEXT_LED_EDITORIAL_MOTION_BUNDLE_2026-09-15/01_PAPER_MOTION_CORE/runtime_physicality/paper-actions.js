(function(root){'use strict';
 const Q=()=>root.NexPaperActionSequencer,R=()=>root.NexPaperRig,X=()=>root.NexPaperActionAttachments,C=()=>root.NexPaperActionCompatibility,M=()=>root.NexPaperMaterial;
 const instances=new Map();let seq=0;
 const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
 function getRig(ref){return ref?.root?ref:R().get(ref)}
 function materials(rig){return rig?[...rig.nodes.values()].map(n=>n.material).filter(Boolean):[]}
 function setMaterialVars(rig,vars,state){for(const el of materials(rig)){for(const [k,v] of Object.entries(vars||{}))el.style.setProperty(k,String(v));if(state)el.dataset.state=state}}
 function setMaterialState(rig,state){for(const el of materials(rig))try{M().setState(el,state,{immediate:true})}catch(_){}}
 function styleSnapshot(rig){if(!rig)return null;return{left:rig.root.style.left,top:rig.root.style.top,scale:rig.root.style.getPropertyValue('--npr-root-scale'),rotation:rig.root.style.getPropertyValue('--npr-root-r'),className:rig.root.className}}
 function restoreStyle(rig,s){if(!rig||!s)return;rig.root.style.left=s.left;rig.root.style.top=s.top;rig.root.style.setProperty('--npr-root-scale',s.scale||1);rig.root.style.setProperty('--npr-root-r',s.rotation||'0deg');rig.root.className=s.className;delete rig.root.dataset.actionState}
 function localPoint(rig){return{x:parseFloat(rig.root.style.left)||0,y:parseFloat(rig.root.style.top)||0}}
 function findNode(rig,ids){for(const id of ids)if(rig?.nodes?.has(id))return id;return null}
 function poseHinge(rig,amount,opening=true){const id=findNode(rig,['cover','front-cover','flap','top-flap','front-card','middle-card']);if(id)R().pose(rig,id,{rotation:(opening?-145:0)*amount});return id}
 function addMark(rig,cls,text){if(!rig)return null;let m=rig.root.querySelector('.'+cls);if(!m){m=document.createElement('div');m.className='npa-action-mark '+cls;m.textContent=text||'';rig.root.appendChild(m)}return m}
 function removeMarks(rig){rig?.root.querySelectorAll('.npa-action-mark').forEach(x=>x.remove())}
 function ctx(config){const actor=getRig(config.actor),target=getRig(config.target),prop=getRig(config.prop),tool=getRig(config.tool),environment=config.environment?.config?config.environment:root.NexPaperEnvironment?.get(config.environment);return{config,actor,target,prop,tool,environment,hand:config.handPreference==='left'?'left':'right',energy:clamp(config.energy??.65),reduced:!!config.reducedMotion}}
 function actionTarget(c){return c.prop||c.target}
 function rootDestination(c,anchor){if(!c.environment||!anchor)return null;const p=X().environmentPoint(c.environment,anchor),r=c.environment.root.getBoundingClientRect(),w=c.actor?.root.offsetWidth||0,h=c.actor?.root.offsetHeight||0;return{x:p.x-w/2,y:p.y-h,world:p}}
 function resetContext(c,snaps){for(const r of [c.actor,c.target,c.prop,c.tool,...Object.values(c.config.props||{})])if(r?.root){if(r.attachment)X().detach(r,{preserveWorld:false});R().resetPose(r);restoreStyle(r,snaps[r.id]);r.root.style.setProperty('--npr-walk-y','0px');r.root.style.setProperty('--npr-attach-comp-x','0px');r.root.style.setProperty('--npr-attach-comp-y','0px');removeMarks(r);setMaterialState(r,'flat')}if(c.actor?.type==='character')R().expression(c.actor,'neutral');if(c.target?.type==='character')R().expression(c.target,'neutral');root.NexPaperRigAttachments?.updateAll()}
 function phase(u,a,b,curve='smooth'){return Q().phase(u,a,b,curve)}
 function handPoint(actor,hand,stage){return X().world(actor,`${hand}-hand-anchor`,stage)}
 function placeNearHand(c,t,fromPoint){const hp=handPoint(c.actor,c.hand,c.actor.stage);X().interpolate(c.prop,fromPoint,hp,t,{fromRotation:-2,toRotation:c.hand==='right'?-8:8})}
 function applyPrimitive(id,c,u,snaps){const actor=c.actor,prop=c.prop,target=c.target,tool=c.tool,obj=actionTarget(c),hand=c.hand,energy=c.energy,reduced=c.reduced;
  const smooth=Q().ease.smooth,out=Q().ease.out;
  if(id==='notice'){if(actor){R().lookAt(actor,prop||target||actor);R().expression(actor,u<.55?'focus':'surprised');R().headTilt(actor,(reduced?2:7)*Math.sin(Math.PI*u));}return}
  if(id==='look-at'){if(actor)R().lookAt(actor,target||prop);return}
  if(id==='point'){if(actor){R().lookAt(actor,target||prop);R().point(actor,hand);R().expression(actor,'focus')}return}
  if(id==='reach'){if(actor){R().lookAt(actor,prop||target);R().reach(actor,hand,phase(u,.05,.8));R().expression(actor,'focus')}return}
  if(id==='pick-up'&&actor&&prop){const from=X().world(prop,X().preferredAnchor(prop,['grip-anchor','page-anchor']),prop.stage);R().lookAt(actor,prop);R().reach(actor,hand,phase(u,0,.32));if(u<.55)placeNearHand(c,phase(u,.25,.55),from);else X().attachToHand(actor,prop,hand,{rotation:hand==='right'?-8:8});setMaterialState(prop,u<.35?'slightly-lifted':'held');return}
  if(id==='carry'&&actor&&prop){const start=localPoint(actor),dest=rootDestination(c,c.config.environmentAnchor||c.config.exitAnchor||'actor-right');X().attachToHand(actor,prop,hand,{rotation:-7});const t=phase(u,.08,.92);if(dest)R().setRoot(actor,{x:Q().mix(start.x,dest.x,t),y:Q().mix(start.y,dest.y,t),rotation:(reduced?0:Math.sin(t*Math.PI*2)*1.4)});R().walkPose(actor,t*2.2);R().expression(actor,'happy');setMaterialState(prop,'held');return}
  if((id==='push'||id==='pull')&&actor&&prop){const p0=localPoint(prop),sign=id==='push'?1:-1,t=phase(u,.18,.82);R().reach(actor,hand,1);R().bodyLean(actor,sign*(reduced?2:7));R().setRoot(prop,{x:p0.x+sign*(reduced?24:100)*t,y:p0.y});setMaterialState(prop,'slightly-lifted');return}
  if((id==='pass'||id==='receive')&&actor&&target&&prop){const fromActor=id==='pass'?actor:target,toActor=id==='pass'?target:actor,fromHand=id==='pass'?hand:'right',toHand=id==='pass'?'left':hand;if(u<.38){X().attachToHand(fromActor,prop,fromHand,{rotation:-7});R().reach(fromActor,fromHand,.75);R().reach(toActor,toHand,phase(u,.1,.38));}else if(u<.78){X().blendHands(prop,fromActor,toActor,phase(u,.38,.78),fromHand,toHand,{rotation:-2});R().reach(fromActor,fromHand,.75);R().reach(toActor,toHand,.85);}else{X().attachToHand(toActor,prop,toHand,{rotation:6});R().expression(toActor,'happy')}setMaterialState(prop,'held');return}
  if(id==='place'&&actor&&prop){const hp=handPoint(actor,hand,actor.stage);X().attachToHand(actor,prop,hand,{rotation:-6});const t=phase(u,.35,.8);if(c.config.environmentAnchor&&c.environment){const ep=X().environmentPoint(c.environment,c.config.environmentAnchor);if(u<.82){X().detach(prop,{preserveWorld:false});X().interpolate(prop,hp,ep,t,{fromRotation:-6,toRotation:ep.rotation||0});}else X().placeAtEnvironment(prop,c.environment,c.config.environmentAnchor)}else if(target){const slot=X().preferredAnchor(target,[c.config.targetAnchor,'insert-slot','page-anchor','pin-anchor','stamp-anchor','grip-anchor']);const tp=X().world(target,slot,target.stage);if(u<.82){X().detach(prop,{preserveWorld:false});X().interpolate(prop,hp,tp,t,{fromRotation:-6,toRotation:0})}else if(slot==='insert-slot')X().insertInto(prop,target,slot);else root.NexPaperRigAttachments.attach(prop,target,slot,{propAnchor:X().preferredAnchor(prop,['page-anchor','grip-anchor'])})}R().reach(actor,hand,1-t*.7);setMaterialState(prop,u<.75?'held':'flat');return}
  if(id==='pin'&&actor&&prop){R().reach(actor,hand,phase(u,.05,.48));if(c.environment&&c.config.environmentAnchor)X().placeAtEnvironment(prop,c.environment,c.config.environmentAnchor);if(u>.6){for(const m of materials(prop))if(!m.classList.contains('npm-has-pin'))M().attachPin(m,{left:50,top:8});setMaterialState(prop,'pinned');addMark(prop,'npa-pin-hit','●')}return}
  if(id==='tape'&&actor&&obj){R().reach(actor,hand,phase(u,.05,.55));if(u>.55){for(const m of materials(obj))if(!m.classList.contains('npm-has-tape'))M().attachTape(m,{left:50,top:50,width:42,rotation:-8});setMaterialState(obj,'repaired');addMark(obj,'npa-tape-hit','')}return}
  if(id==='stamp'&&actor&&target){R().reach(actor,hand,1);const hit=phase(u,.25,.58,'out'),lift=phase(u,.58,.92);R().pose(actor,`${hand}-upper-arm`,{rotation:(hand==='right'?-50:50)+(hand==='right'?20:-20)*lift});if(tool){const base=localPoint(tool);R().setRoot(tool,{x:base.x,y:base.y+(reduced?12:55)*Math.sin(Math.PI*hit)})}if(u>.52)addMark(target,'npa-stamp-mark','APPROVED');return}
  if(id==='inspect'&&actor&&prop){R().lookAt(actor,prop);R().expression(actor,'focus');R().reach(actor,hand,.7);if(tool){const pr=prop.root.getBoundingClientRect(),stage=tool.stage.getBoundingClientRect(),angle=u*Math.PI*2;X().position(tool,{x:pr.left-stage.left+pr.width*(.35+.25*Math.cos(angle)),y:pr.top-stage.top+pr.height*(.45+.18*Math.sin(angle))},{rotation:-8})}addMark(prop,'npa-inspection-ring','');return}
  if(id==='repair'&&actor&&target){R().expression(actor,u<.35?'surprised':'focus');R().reach(actor,hand,phase(u,.15,.55));if(u>.48){for(const m of materials(target))if(!m.classList.contains('npm-has-tape'))M().attachTape(m,{left:48,top:52,width:46,rotation:-5});setMaterialVars(target,{'--npm-crumple':String(Q().mix(.4,.08,phase(u,.48,1))),'--npm-bend':String(Q().mix(14,1,phase(u,.48,1)))});addMark(target,'npa-repair-patch','FIXED')}return}
  if(id==='reject'&&actor&&prop){R().expression(actor,'surprised');R().point(actor,hand);const p0=localPoint(prop),t=phase(u,.35,.9,'out');R().setRoot(prop,{x:p0.x+(reduced?30:150)*t,y:p0.y-(reduced?8:40)*Math.sin(Math.PI*t),rotation:(reduced?3:16)*t});setMaterialVars(prop,{'--npm-crumple':String(.75*t),'--npm-bend':String(36*t)},t>.5?'crumpled':'flat');addMark(prop,'npa-reject-mark','REJECT');return}
  if(id==='retry'&&actor&&prop){R().expression(actor,u<.4?'focus':'happy');const t=phase(u,.15,.95);setMaterialVars(prop,{'--npm-crumple':String(Q().mix(.72,.08,t)),'--npm-bend':String(Q().mix(34,1,t)),'--npm-elevation':String(Q().mix(12,1,t))},t>.88?'flattened':'landing');if(u>.72)removeMarks(prop);return}
  if(id==='celebrate'&&actor){R().expression(actor,'happy');R().pose(actor,'left-upper-arm',{rotation:reduced?18:58});R().pose(actor,'right-upper-arm',{rotation:reduced?-18:-58});const base=localPoint(actor);R().setRoot(actor,{x:base.x,y:base.y-(reduced?3:18)*Math.abs(Math.sin(u*Math.PI*3)),rotation:(reduced?0:Math.sin(u*Math.PI*4)*3)});return}
  if(id==='deliver'&&actor&&prop){const start=localPoint(actor),dest=rootDestination(c,c.config.environmentAnchor||'packaging-exit');X().attachToHand(actor,prop,hand,{rotation:-5});const t=phase(u,.08,.78);if(dest)R().setRoot(actor,{x:Q().mix(start.x,dest.x,t),y:Q().mix(start.y,dest.y,t)});R().walkPose(actor,t*2.4);R().expression(actor,'happy');if(u>.82&&target?.anchors?.has('insert-slot'))X().insertInto(prop,target,'insert-slot');return}
  // object actions
  if(id==='write'&&obj){const m=addMark(obj,'npa-writing-stroke','A clear idea becomes a physical line.');m?.style.setProperty('--npa-progress',String(phase(u,.08,.95)));return}
  if(id==='tear'&&obj){setMaterialVars(obj,{'--npa-tear':String(phase(u,.12,.85)),'--npm-bend':String(12*Math.sin(Math.PI*u))},u>.78?'torn':'flat');obj.root.classList.add('npa-tearing');return}
  if(id==='fold'&&obj){setMaterialVars(obj,{'--npm-fold':(160*phase(u,.08,.9))+'deg','--npm-elevation':String(8*phase(u,.08,.9))},u>.88?'folded':'flat');return}
  if(id==='unfold'&&obj){setMaterialVars(obj,{'--npm-fold':(160*(1-phase(u,.08,.9)))+'deg','--npm-elevation':String(8*(1-phase(u,.08,.9)))},u>.88?'flat':'folded');return}
  if((id==='open'||id==='close')&&obj){const t=phase(u,.08,.92),amt=id==='open'?t:1-t;poseHinge(obj,amt,true);obj.root.dataset.actionState=id;return}
  if(id==='slide'&&obj){const p0=localPoint(obj),ep=c.environment&&c.config.environmentAnchor?X().environmentPoint(c.environment,c.config.environmentAnchor):{x:p0.x+(reduced?30:180),y:p0.y};R().setRoot(obj,{x:Q().mix(p0.x,ep.x,phase(u,.08,.92)),y:Q().mix(p0.y,ep.y,phase(u,.08,.92))});setMaterialState(obj,'slightly-lifted');return}
  if((id==='stack'||id==='shuffle')&&obj){const t=phase(u,.08,.92);let n=0;for(const rec of obj.nodes.values())if(rec.material){const s=id==='shuffle'?Math.sin((n+1)*2.3+t*Math.PI*2):1;R().pose(obj,rec.id,{rotation:(reduced?2:9)*s*(id==='stack'?(1-t):1),x:(rec.defaultTransform.x||0)+(id==='stack'?0:(reduced?3:14)*s)});n++}return}
  if(id==='crumple'&&obj){const t=phase(u,.08,.92);setMaterialVars(obj,{'--npm-crumple':String(t),'--npm-bend':String(48*t),'--npm-elevation':String(12*t)},t>.85?'crumpled':'flat');return}
  if(id==='flatten'&&obj){const t=phase(u,.08,.92);setMaterialVars(obj,{'--npm-crumple':String(Q().mix(1,.1,t)),'--npm-bend':String(Q().mix(48,.8,t)),'--npm-elevation':String(Q().mix(12,0,t))},t>.85?'flattened':'crumpled');return}
  if(id==='pop-up'&&obj){const t=phase(u,.08,.9,'back');obj.root.style.setProperty('--npr-root-scale',String(Q().mix(.08,1,t)));obj.root.style.setProperty('--npr-root-r',(reduced?0:Q().mix(-8,0,t))+'deg');setMaterialVars(obj,{'--npm-fold':(90*(1-t))+'deg','--npm-elevation':String(16*t)});return}
  if(id==='grow'&&obj){const t=phase(u,.08,.9,'back');obj.root.style.setProperty('--npr-root-scale',String(Q().mix(.15,1,t)));setMaterialVars(obj,{'--npm-elevation':String(10*Math.sin(Math.PI*t))});return}
  if(id==='attach'&&prop&&target){const slot=X().preferredAnchor(target,[c.config.targetAnchor,'insert-slot','pin-anchor','page-anchor','grip-anchor']);if(u<.75){const a=X().world(prop,X().preferredAnchor(prop,['grip-anchor','page-anchor']),prop.stage),b=X().world(target,slot,target.stage);X().interpolate(prop,a,b,phase(u,.1,.75))}else if(slot==='insert-slot')X().insertInto(prop,target,slot);else root.NexPaperRigAttachments.attach(prop,target,slot,{propAnchor:X().preferredAnchor(prop,['page-anchor','grip-anchor'])});return}
  if(id==='detach'&&prop){if(u<.35&&target){const slot=X().preferredAnchor(target,[c.config.targetAnchor,'insert-slot','pin-anchor','page-anchor','grip-anchor']);root.NexPaperRigAttachments.attach(prop,target,slot,{propAnchor:X().preferredAnchor(prop,['page-anchor','grip-anchor'])})}else X().detach(prop,{preserveWorld:true});const p0=localPoint(prop);R().setRoot(prop,{x:p0.x+(reduced?15:65)*phase(u,.35,.9),y:p0.y-(reduced?5:25)*phase(u,.35,.9)});return}
  if(id==='reveal'&&obj){const t=phase(u,.08,.92);obj.root.style.clipPath=`inset(0 ${100*(1-t)}% 0 0 round 4px)`;setMaterialVars(obj,{'--npm-elevation':String(5*Math.sin(Math.PI*t))});return}
  if(id==='package'&&prop&&target){poseHinge(target,phase(u,0,.28),true);if(u>.25&&u<.78){const a=X().world(prop,X().preferredAnchor(prop,['grip-anchor','page-anchor']),prop.stage),b=X().world(target,'insert-slot',target.stage);X().interpolate(prop,a,b,phase(u,.25,.75))}else if(u>=.78){X().insertInto(prop,target,'insert-slot');poseHinge(target,1-phase(u,.78,1),true)}return}
  if(id==='transform'&&obj){const t=phase(u,.08,.92,'inOut');obj.root.style.setProperty('--npr-root-scale',String(1+.08*Math.sin(Math.PI*t)));obj.root.style.setProperty('--npr-root-r',(reduced?0:Q().mix(-6,6,t))+'deg');setMaterialVars(obj,{'--npm-fold':(100*Math.sin(Math.PI*t))+'deg','--npm-curl':String(35*Math.sin(Math.PI*t))});obj.root.classList.toggle('npa-transformed',t>.52);return}
 }
 function applyCompound(id,c,u,snaps){const actor=c.actor,prop=c.prop,target=c.target,tool=c.tool,extras=c.config.props||{};const t=u;
  if(id==='sort-and-stamp'){
   if(t<.16)return applyPrimitive('receive',{...c,target:c.config.actorB||target},t/.16,snaps);
   if(t<.32)return applyPrimitive('open',{...c,prop:extras.brief||prop,target:null},(t-.16)/.16,snaps);
   if(t<.58)return applyPrimitive('shuffle',{...c,prop:extras.brief||prop,target:null},(t-.32)/.26,snaps);
   if(t<.78)return applyPrimitive('stamp',{...c,target:extras.document||prop,tool:extras.stamp||tool},(t-.58)/.2,snaps);
   return applyPrimitive('pass',{...c,prop:extras.document||prop,target:c.config.actorB||target},(t-.78)/.22,snaps)
  }
  if(id==='inspect-and-repair'){
   const timeline=extras.timeline||prop;if(t<.28)return applyPrimitive('inspect',{...c,prop:timeline,tool:extras.magnifier||tool},t/.28,snaps);
   if(t<.43)return applyPrimitive('notice',{...c,prop:timeline},(t-.28)/.15,snaps);
   if(t<.58)return applyPrimitive('reject',{...c,prop:timeline},(t-.43)/.15,snaps);
   if(t<.86)return applyPrimitive('repair',{...c,target:timeline},(t-.58)/.28,snaps);
   const check=extras.checklist||target; if(check)addMark(check,'npa-check-update','✓ UPDATED');return
  }
  if(id==='package-and-deliver'){
   const timeline=extras.timeline||prop,pkg=extras.package||target,envlp=extras.envelope||tool;
   if(t<.18)return applyPrimitive('fold',{...c,prop:timeline,target:null},t/.18,snaps);
   if(t<.5)return applyPrimitive('package',{...c,prop:timeline,target:pkg},(t-.18)/.32,snaps);
   if(t<.68)return applyPrimitive('open',{...c,prop:envlp,target:null},(t-.5)/.18,snaps);
   if(t<.84)return applyPrimitive('attach',{...c,prop:pkg,target:envlp,config:{...c.config,targetAnchor:'insert-slot'}},(t-.68)/.16,snaps);
   return applyPrimitive('deliver',{...c,prop:envlp,target:null},(t-.84)/.16,snaps)
  }
  if(id==='brief-to-storyboard'){
   const brief=extras.brief||prop,board=extras.storyboard||target;if(t<.2)return applyPrimitive('pick-up',{...c,prop:brief},t/.2,snaps);
   if(t<.42)return applyPrimitive('unfold',{...c,prop:brief,target:null},(t-.2)/.22,snaps);
   if(t<.68)return applyPrimitive('transform',{...c,prop:brief,target:null},(t-.42)/.26,snaps);
   if(t<.88)return applyPrimitive('place',{...c,prop:brief,target:board,config:{...c.config,targetAnchor:'pin-1'}},(t-.68)/.2,snaps);
   return applyPrimitive('pin',{...c,prop:brief,target:board},(t-.88)/.12,snaps)
  }
  if(id==='investigate-and-pin'){
   const photo=extras.photo||prop,article=extras.article||target;if(t<.32)return applyPrimitive('inspect',{...c,prop:photo,tool:extras.magnifier||tool},t/.32,snaps);
   if(t<.52)return applyPrimitive('place',{...c,prop:photo,config:{...c.config,environmentAnchor:'pinned-photo-a'}},(t-.32)/.2,snaps);
   if(t<.66)return applyPrimitive('pin',{...c,prop:photo,config:{...c.config,environmentAnchor:'pinned-photo-a'}},(t-.52)/.14,snaps);
   if(t<.86)return applyPrimitive('slide',{...c,prop:article,config:{...c.config,environmentAnchor:'newspaper-area'}},(t-.66)/.2,snaps);
   return applyPrimitive('reveal',{...c,prop:extras.note||article},(t-.86)/.14,snaps)
  }
 }
 function create(config){if(!config?.action)throw new Error('Action id is required');const definition=root.NexPaperActionDefinitions?.[config.action];if(!definition)throw new Error(`Unknown paper action ${config.action}`);const c=ctx(config),check=C().validate({...config,actor:c.actor,prop:c.prop,target:c.target,environment:c.environment});if(!check.valid&&!config.allowCompatibilityOverride)throw new Error(check.errors.join('; '));const id=config.id||`paper-action-${++seq}`;const all=[c.actor,c.target,c.prop,c.tool,...Object.values(config.props||{})].filter(x=>x?.root);for(const r of all)r.root.dataset.reducedMotion=String(c.reduced);const snaps=Object.fromEntries(all.map(r=>[r.id,styleSnapshot(r)]));const duration=(config.duration||definition.defaultDurationMs/1000);const timeline=Q().create({duration,reducedMotion:c.reduced,reset:()=>resetContext(c,snaps),apply:u=>definition.category==='compound'?applyCompound(config.action,c,u,snaps):applyPrimitive(config.action,c,u,snaps),onUpdate:config.onUpdate,onComplete:config.onComplete});const instance={id,action:config.action,category:definition.category,definition,config,context:c,timeline,seek:s=>timeline.seek(s),progress:p=>timeline.progress(p),play:s=>timeline.play(s),pause:()=>timeline.pause(),restart:()=>timeline.restart(),inspect(){return{engine:'NexPaperActions',version:'1.0.0',id,action:config.action,category:definition.category,duration:timeline.duration,currentTime:timeline.currentTime,actor:c.actor?.id||null,target:c.target?.id||null,prop:c.prop?.id||null,tool:c.tool?.id||null,environment:c.environment?.config?.id||null,attachment:c.prop?X().snapshot(c.prop):null,compatibility:check,deterministic:true,seekable:true,reducedMotion:c.reduced}}};instances.set(id,instance);return instance}
 function inspect(ref){return(typeof ref==='string'?instances.get(ref):ref)?.inspect?.()}
 function destroy(ref){const i=typeof ref==='string'?instances.get(ref):ref;if(!i)return;i.pause();instances.delete(i.id)}
 root.NexPaperActions={version:'1.0.0',create,inspect,destroy,definitions:root.NexPaperActionDefinitions,manifests:root.NexPaperActionManifests,compatibility:C(),instances};
})(typeof self!=='undefined'?self:this);